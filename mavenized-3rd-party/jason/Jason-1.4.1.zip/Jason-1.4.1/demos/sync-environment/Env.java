// Environment code for project act-sync.mas2j

import jason.asSyntax.Structure;

public class Env extends jason.environment.Environment {

    @Override
    public boolean executeAction(String agName, Structure action) {
        return true;
    }
}

