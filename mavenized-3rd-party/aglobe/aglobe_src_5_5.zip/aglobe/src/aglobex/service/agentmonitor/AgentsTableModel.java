package aglobex.service.agentmonitor;

import java.awt.Component;
import java.util.Map;

import javax.swing.JProgressBar;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;

import aglobex.service.agentmonitor.AgentMonitorParameters.MonitoredObject;
import aglobex.service.agentmonitor.AgentMonitorParameters.MonitoredValue;

class AgentsTableModel extends AbstractTableModel implements AgentMonitorListener {

    private static final long serialVersionUID = -3323314489064349884L;

    private final String[] columnNames;

    private AgentMonitorScanned lastScanned = null;

    public AgentsTableModel(AgentMonitorService.Shell amsShell) {
        super();
        this.columnNames = AgentMonitorParameters.MonitoredValue.getNames(
                AgentMonitorParameters.AGENT_FULL.getMonitoredValuesUnion());
        amsShell.addAgentMonitorListener(this, AgentMonitorParameters.AGENT_FULL);
    }

    @Override
	public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public String getColumnName(int col) {
        return columnNames[col];
    }

    @Override
	public int getRowCount() {
      if (lastScanned == null) {
        return 0;
      }
        Map<Object, Object[]> objectMap = lastScanned.getObjectMap(MonitoredObject.AGENT);
        if (objectMap == null) {
            return 0;
        }

        return objectMap.size();
    }

    @Override
	public Object getValueAt(int row, int col) {
        if (lastScanned == null) {
            return null;
        }

        Object data[] = lastScanned.getObjectMap(MonitoredObject.AGENT).values().toArray();

        if (row < data.length) {
            Object dataRow[] = (Object[]) data[row];
            if (col < dataRow.length) {
                return processValue(dataRow[col], col);
            }
        }
        return null;
    }

    @Override
    public Class<?> getColumnClass(int c) {
        Object value = getValueAt(0, c);
        if (value == null) {
            return Void.class;
        }
        return value.getClass();
    }

    public Object processValue(Object value, int col) {
        switch (MonitoredValue.values()[col]) {
        case CPU_LOAD:
            return new ProgressValue((Double) value, (int)((Double) value *100.0));
        case CPU_TIME:
            return new FormattedValue<Long, String> ((Long)value,
                    (Long)value /86400000L + "d " + (Long)value /3600000L + "h" +
                    (Long)value /60000L    + "m"  + (Long)value /1000L    + "s");
        case RUNNING_TIME:
            return new FormattedValue<Long, String> ((Long)value,
                    (Long)value /86400000L + "d " + (Long)value /3600000L + "h" +
                    (Long)value /60000L    + "m"  + (Long)value /1000L    + "s");

        default:
            return value;
        }
    }

    @Override
	public void afterScanned(AgentMonitorScanned scanned) {
        lastScanned = scanned;
        fireTableDataChanged();
    }
}

class ProgressValueRenderer extends JProgressBar implements TableCellRenderer {

    private static final long serialVersionUID = -1745357288951199737L;

    public ProgressValueRenderer() {
        super();
        setStringPainted(true);
    }

    @Override
	public Component getTableCellRendererComponent(JTable table,
            Object value, boolean isSelected, boolean hasFocus, int row,
            int column) {
        if (value != null) {
            int newValue = ((ProgressValue) value).formattedValue;
            setValue(newValue);
        }

        return this;
    }
}

class FromattedValueRenderer extends DefaultTableCellRenderer implements TableCellRenderer {

    private static final long serialVersionUID = 9146986355221690357L;

    @Override
    public Component getTableCellRendererComponent(JTable table,
            Object value, boolean isSelected, boolean hasFocus, int row,
            int column) {
        if (value != null) {
            value = ((FormattedValue<?,?>) value).formattedValue;
        }

        return super.getTableCellRendererComponent(table, value, isSelected,
                hasFocus, row, column);
    }
}

class FormattedValue<T extends Comparable<T>,U> implements Comparable<FormattedValue<T,U>> {
    public T comparingValue;
    public U formattedValue;

    public FormattedValue(T comparingValue, U formattedValue) {
        this.comparingValue = comparingValue;
        this.formattedValue = formattedValue;
    }

    @Override
	public int compareTo(FormattedValue<T,U> o) {
        return comparingValue.compareTo(o.comparingValue);
    }
}

class ProgressValue extends FormattedValue<Double, Integer> {
    public ProgressValue(Double comparingValue, Integer formattedValue) {
        super(comparingValue, formattedValue);
    }
}
