package aglobex.service.agentmonitor;

public interface AgentMonitorListener {

    void afterScanned(AgentMonitorScanned scanned);
}
