package aglobex.service.agentmonitor;

import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import aglobe.util.gui.RememberPositionJFrame;

class AgentMonitorServiceGUI extends RememberPositionJFrame {

    private static final long serialVersionUID = 1030175111778446184L;
    private AgentMonitorService owner = null;
    private JPanel jPanel = null;
    private JTabbedPane jTabbedPane = null;
    private JScrollPane jScrollPane = null;
    private JTable jTable = null;
    private AgentsTableModel agentsTableModel = null;
    private TableSorter tableSorter = null;
    /**
     * This is the default constructor
     *
     * @param agentMonitorService AgentMonitorService
     */
    public AgentMonitorServiceGUI(AgentMonitorService agentMonitorService) {
        super(agentMonitorService);

        this.owner = agentMonitorService;
        initialize();
    }

    /**
     * This method initializes this
     */
    private void initialize() {
        this.setContentPane(getJPanel());
        this.setSize(500,300);
        this.setTitle("agent/monitor");
    }

    /**
     * This method initializes jPanel
     *
     * @return javax.swing.JPanel
     */
    private JPanel getJPanel() {
        if (jPanel == null) {
            jPanel = new JPanel();
            jPanel.setLayout(new BorderLayout());
            jPanel.add(getJTabbedPane(), java.awt.BorderLayout.CENTER);
        }
        return jPanel;
    }

    /**
     * This method initializes jTabbedPane
     *
     * @return javax.swing.JTabbedPane
     */
    private JTabbedPane getJTabbedPane() {
        if (jTabbedPane == null) {
            jTabbedPane = new JTabbedPane();
            jTabbedPane.addTab("Agents", null, getJScrollPane(), null);
        }
        return jTabbedPane;
    }

    /**
     * This method initializes jScrollPane
     *
     * @return javax.swing.JScrollPane
     */
    private JScrollPane getJScrollPane() {
        if (jScrollPane == null) {
            jScrollPane = new JScrollPane();
            jScrollPane.setViewportView(getJTable());
        }
        return jScrollPane;
    }

    /**
     * This method initializes jTable
     *
     * @return javax.swing.JTable
     */
    private JTable getJTable() {
        if (jTable == null) {
            jTable = new JTable();
            jTable.setModel(getTableSorter());
            jTable.setDefaultRenderer(ProgressValue.class, new ProgressValueRenderer());
            jTable.setDefaultRenderer(FormattedValue.class, new FromattedValueRenderer());
        }
        return jTable;
    }

    /**
     * This method initializes agentsTableModel
     *
     * @return aglobex.service.agentmonitor.AgentsTableModel
     */
    private AgentsTableModel getAgentsTableModel() {
        if (agentsTableModel == null) {
            AgentMonitorService.Shell amsShell =
                (AgentMonitorService.Shell) owner.getServiceShell(owner);
            agentsTableModel = new AgentsTableModel(amsShell);
        }
        return agentsTableModel;
    }

    /**
     * This method initializes tableSorter
     *
     * @return aglobex.service.agentmonitor.TableSorter
     */
    private TableSorter getTableSorter() {
        if (tableSorter == null) {
            tableSorter = new TableSorter();
            tableSorter.setTableModel(getAgentsTableModel());
            tableSorter.setTableHeader(jTable.getTableHeader());
        }
        return tableSorter;
    }
}
