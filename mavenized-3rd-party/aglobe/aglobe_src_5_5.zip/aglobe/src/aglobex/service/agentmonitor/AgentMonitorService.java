package aglobex.service.agentmonitor;

import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import aglobe.container.AgentContainer;
import aglobe.container.agent.AgentManager;
import aglobe.container.service.Service;
import aglobe.container.service.ServiceShell;
import aglobe.container.service.ShellOwner;
import aglobe.ontology.AgentInfo;
import aglobe.ontology.Message;
import aglobe.platform.Platform;
import aglobe.platform.thread.AglobeThreadPool;
import aglobex.service.agentmonitor.AgentMonitorParameters.MonitoredObject;
import aglobex.service.agentmonitor.AgentMonitorParameters.MonitoredValue;

public class AgentMonitorService extends Service {

    /**
     * Name of the service.
     */
    public final static String SERVICENAME = "agent/monitor";

    /**
     * Services's GUI.
     */
    private AgentMonitorServiceGUI gui;

   /**
   * Public constructor.
   */
    public AgentMonitorService() {
    }

    @Override
    public ServiceShell getServiceShell(ShellOwner shellOwner) {
        return new Shell(shellOwner, this);
    }

    @Override
    public void init() {
        gui = new AgentMonitorServiceGUI(this);
        gui.setTitle(SERVICENAME);
        gui.setVisible(true);
    }

    @Override
	public void handleIncomingMessage(Message m) {
        m.release();
    }

    private synchronized void addListener(AgentMonitorListener agentMonitorListener,
            AgentMonitorParameters agentMonitorParameters) {
        AgentMonitor monitor = new AgentMonitor(this, agentMonitorParameters);
        monitor.addListener(agentMonitorListener);
        AglobeThreadPool.getThread(monitor, "Agent monitor thread").start();
    }

    public static class Shell extends ServiceShell {

        private static final long serialVersionUID = -8522017733483348718L;

        private AgentMonitorService agentMonitorService;

        private Shell(ShellOwner shellOwner, AgentMonitorService agentMonitorService) {
            super(shellOwner);
            this.agentMonitorService = agentMonitorService;
        }

        @Override
        public boolean isValid() {
             return agentMonitorService != null;
        }

        @Override
        public void setContainer(AgentContainer container) throws Exception {
            throw new RuntimeException("Not supported yet");
        }

        @Override
        public void postInit() {
        }

        public void addAgentMonitorListener(AgentMonitorListener agentMonitorListener,
                AgentMonitorParameters agentMonitorParameters) {
            agentMonitorService.addListener(agentMonitorListener, agentMonitorParameters);
        }
    }
}

class AgentMonitor implements Runnable {

    private final ThreadMXBean threadMXBean;
    private final AgentMonitorService agentMonitorService;
    private final Set<AgentMonitorListener> listeners = new HashSet<AgentMonitorListener>();

    /**
     * @param agentMonitorParameters
     */
    public AgentMonitor(AgentMonitorService agentMonitorService,
            AgentMonitorParameters agentMonitorParameters) {
        super();

        this.agentMonitorService    = agentMonitorService;
        this.threadMXBean           = ManagementFactory.getThreadMXBean();

        if (!threadMXBean.isThreadCpuTimeSupported()) {
           this.agentMonitorService.logWarning("ThreadCpuTime is not supported!");
        } else {
            threadMXBean.setThreadCpuTimeEnabled(true);
        }
    }

    public void addListener(AgentMonitorListener agentMonitorListener) {
        listeners.add(agentMonitorListener);
    }

    @Override
	public void run() {
        AgentMonitorScanned lastScanned = new AgentMonitorScanned();
        long lastMillis = 0L;
        long currentMillis = 0L;
        long startMillis = System.currentTimeMillis();

        while (true) {
            AgentMonitorScanned scanned = new AgentMonitorScanned();
            Collection<AgentContainer> agentContainers =  Platform.getContainers();
            for (AgentContainer container : agentContainers) {
                AgentManager agentManager = container.getAgentManager();
                List<AgentInfo> agents = agentManager.getRunningAgents();

                for (AgentInfo agentInfo : agents) {
                    Object values[] = new Object[MonitoredValue.length];

                    String agentName = agentInfo.getReadableName();
                    values[MonitoredValue.NAME.ordinal()] = agentName;

                    values[MonitoredValue.CONTAINER_NAME.ordinal()] = container.getContainerName();

                    ThreadGroup atg = agentManager.getAgentThreadGroup(agentInfo.getName());
                    Thread sts[] = AglobeThreadPool.enumerateThreads(atg);
                    currentMillis = System.currentTimeMillis();
                    Long threadsCpuTime = getThreadsCpuTime(sts);
                    values[MonitoredValue.THREADS_CPU_TIME.ordinal()] = threadsCpuTime;

                    double load = 0.0;
                    Object lastThreadsCpuTime = lastScanned.getValue(MonitoredObject.AGENT,
                            agentName, MonitoredValue.THREADS_CPU_TIME);
                    if (lastThreadsCpuTime != null) {
                        load = (threadsCpuTime - (Long) lastThreadsCpuTime)
                                /(currentMillis - lastMillis +1) /1000000.0;
                    }

                    values[MonitoredValue.THREAD_COUNT.ordinal()] = getThreadsCount(sts);
                    values[MonitoredValue.CPU_LOAD.ordinal()] = load;

                    long runningTime = 0;
                    currentMillis = System.currentTimeMillis();
                    Object lastRunningTime = lastScanned.getValue(MonitoredObject.AGENT,
                            agentName, MonitoredValue.RUNNING_TIME);
                    if (lastRunningTime != null) {
                        runningTime = (Long) lastRunningTime + (currentMillis - lastMillis);
                    }
                    values[MonitoredValue.RUNNING_TIME.ordinal()] = runningTime;

                    long cpuTime = 0;
                    Object lastCpuTime = lastScanned.getValue(MonitoredObject.AGENT,
                            agentName, MonitoredValue.CPU_TIME);
                    if (lastCpuTime != null) {
                        cpuTime = (Long) lastCpuTime + (threadsCpuTime - (Long) lastThreadsCpuTime)/1000000L;
                    }
                    values[MonitoredValue.CPU_TIME.ordinal()] = cpuTime;


                    // save scanned values
                    Map<Object, Object[]> scannedObjectMap = scanned.getObjectMap(MonitoredObject.AGENT);
                    scannedObjectMap.put(agentName, values);
                }
            }

            synchronized (this) {
                lastScanned = scanned;
            }

            for (AgentMonitorListener listener : listeners) {
                listener.afterScanned(lastScanned);
            }

            synchronized (this) {
                try {
                    lastMillis = System.currentTimeMillis();
                    wait(1000 - (lastMillis - startMillis));
                    startMillis = System.currentTimeMillis();
                } catch (InterruptedException e) {
                } catch (IllegalArgumentException e) {
                }
            }
        }
    }

    private long getThreadsCpuTime(Thread threads[]) {
        long sum = 0L;
        for (int i = 0; i < threads.length; i++) {
            if (threads[i] == null) {
                break;
            }
            sum += threadMXBean.getThreadCpuTime(threads[i].getId());
        }
        return sum;
    }

    private int getThreadsCount(Thread threads[]) {
        int i;
        for (i = 0; i < threads.length; i++) {
            if (threads[i] == null) {
                break;
            }
        }
        return i;
    }
}
