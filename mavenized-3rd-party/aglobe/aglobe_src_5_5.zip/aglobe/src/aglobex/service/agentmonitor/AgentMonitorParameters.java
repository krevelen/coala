package aglobex.service.agentmonitor;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

public class AgentMonitorParameters {

    public static final AgentMonitorParameters AGENT_FULL;
    static {
        AGENT_FULL = new AgentMonitorParameters();
        Monitored m = new Monitored();
        m.monitoredObjects.add(MonitoredObject.AGENT);
        AGENT_FULL.monitored.add(m);
    }

    long scanPeriod;
    Set<Monitored> monitored;

    public AgentMonitorParameters() {
        this.scanPeriod = 1000;
        this.monitored = new HashSet<Monitored>(2);
    }

    public AgentMonitorParameters(long scanPeriod, Set<Monitored> monitored) {
        this.scanPeriod = scanPeriod;
        this.monitored = monitored;
    }

    public Set<MonitoredValue> getMonitoredValuesUnion() {
        Set<MonitoredValue> union = new HashSet<MonitoredValue>();
        for (Monitored value : monitored) {
            union.addAll(value.monitoredValues);
        }
        return union;
    }

    public static class Monitored {
        Set<MonitoredObject> monitoredObjects;
        Map<MonitoredObject, List<String>> monitoredObjectsNames;
        Set<MonitoredValue>  monitoredValues;

        public Monitored() {
            this.monitoredObjects = new HashSet<MonitoredObject>(2);
            this.monitoredObjectsNames = null;
            this.monitoredValues = new HashSet<MonitoredValue>(MonitoredValue.FULL_SET);
        }

        public Monitored(Set<MonitoredObject> monitoredObjects,
                Map<MonitoredObject, List<String>> monitoredObjectsNames,
                Set<MonitoredValue>  monitoredValues) {
            this.monitoredObjects = monitoredObjects;
            this.monitoredObjectsNames = monitoredObjectsNames;
            this.monitoredValues = monitoredValues;
        }
    }

    public static enum MonitoredObject {
        PLATFORM, CONTAINER, AGENT, SERVICE, THREAD;

        public final static int length = MonitoredObject.values().length;
    }

    public static enum MonitoredValue {
        NAME("Name"),
        CONTAINER_NAME("Cont. name"),
        CPU_LOAD("CPU Load"),
        CPU_TIME("CPU Time"),
        THREAD_COUNT("Threads"),
        RUNNING_TIME("Run Time"),

        THREADS_CPU_TIME(null);

        public final static int length = MonitoredValue.values().length;

        private final String name;

        public static final HashSet<MonitoredValue> FULL_SET =
            new HashSet<MonitoredValue>(Arrays.asList(MonitoredValue.values()));

        public static String[] getNames(Set<MonitoredValue> monitoredValues) {
            int countNamed = 0;
            for (MonitoredValue monitoredValue : monitoredValues) {
                if (monitoredValue.name != null) {
                    ++countNamed;
                }
            }
            String[] names = new String[countNamed];

            SortedSet<MonitoredValue> ss = new TreeSet<MonitoredValue>(monitoredValues);
            int i = 0;
            for (MonitoredValue monitoredValue : ss) {
                if (monitoredValue.name != null) {
                    names[i] = monitoredValue.name;
                    ++i;
                }
            }

            return names;
        }

        private MonitoredValue(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }
    }
}
