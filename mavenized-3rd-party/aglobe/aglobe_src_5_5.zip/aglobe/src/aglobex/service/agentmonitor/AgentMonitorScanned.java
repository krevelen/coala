package aglobex.service.agentmonitor;

import java.util.HashMap;
import java.util.Map;

import aglobex.service.agentmonitor.AgentMonitorParameters.MonitoredObject;
import aglobex.service.agentmonitor.AgentMonitorParameters.MonitoredValue;

public class AgentMonitorScanned {

    private Map<Object, Object[]>[] data;

    @SuppressWarnings("unchecked")
    public AgentMonitorScanned() {
        data = new Map[MonitoredObject.length];
    }

    public Object getValue(MonitoredObject mo, Object mapIndex, MonitoredValue mv) {
        if (data[mo.ordinal()] != null) {
            Object values[] = data[mo.ordinal()].get(mapIndex);
            if (values != null) {
                if (values[mv.ordinal()] != null) {
                    return values[mv.ordinal()];
                }
            }
        }
        return null;
    }

    public Map<Object, Object[]> getObjectMap(MonitoredObject mo) {
        int index = mo.ordinal();

        if (data[index] == null) {
            data[index] = new HashMap<Object, Object[]>();
        }
        return data[index];
    }
}
