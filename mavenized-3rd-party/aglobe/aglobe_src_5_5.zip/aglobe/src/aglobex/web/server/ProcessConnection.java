package aglobex.web.server;


import java.io.*;
import java.net.*;
import java.util.*;

import aglobe.container.*;
import aglobe.container.agent.*;
import aglobe.container.service.*;
import aglobe.ontology.*;


class MenuInfo {
    String url;
    AgentContainer selContainer = null;
    boolean agentsExpanded = false;
    AgentInfo selAgent = null;
    boolean servicesExpanded = false;
    ServiceInfo selService = null;
    String webPageKey = null;
}


class ProcessConnection implements Runnable {

    private final static boolean ENABLE_LOGIN = true;

    private final static int URL_TYPE_AGLOBE = 1;
    private final static int URL_TYPE_STATIC_IMAGE = 2;
    private final static int URL_TYPE_VIRTUAL_IMAGE = 3;
    private final static int URL_TYPE_GENERIC = 4;

    protected HttpsServer httpsServer;
    protected Socket client;
    protected BufferedReader inputStream;
    protected DataOutputStream outputStream;

    protected AgentContainer container;
    protected AgentManager agentManager;
    protected ServiceManager serviceManager;

    protected HtmlGenerator htmlGen;

    protected HashMap<String,String> contentTypeMap;

    protected boolean cmdGet = false;
    protected boolean cmdPost = false;
    protected String url = null;
    protected String cookieID = null;
    protected String dataType = null;
    protected String data = null;

    protected String containerName = null;
    protected boolean typeAgents = false;
    protected boolean typeServices = false;
    protected String entityName = null;
    protected String webPageKey = null;

    protected UserInfo userInfo;
    protected boolean sendCookie;


    public ProcessConnection(HttpsServer httpsServer, Socket socket) {
        this.httpsServer = httpsServer;
        client = socket;
        try {
            inputStream = new BufferedReader(new InputStreamReader(client.
                    getInputStream()));
            outputStream = new DataOutputStream(client.getOutputStream());
        } catch (IOException ex) {
            System.out.println("Exception#1: " + ex.getMessage());
        }

        container = httpsServer.getWebServerService().getContainer();
        agentManager = container.getAgentManager();
        serviceManager = container.getServiceManager();

        htmlGen = new HtmlGenerator(httpsServer, container);

        contentTypeMap = new HashMap<String,String>();
        contentTypeMap.put(".bmp", "image/bmp");
        contentTypeMap.put(".gif", "image/gif");
        contentTypeMap.put(".jpg", "image/jpeg");
        contentTypeMap.put(".png", "image/png");

        userInfo = null;
        sendCookie = false;

    }


    @Override
	public void run() {
        processMain();
        try {
            client.close();
        } catch (IOException ex) {
            System.out.println("Exception#2: " + ex.getMessage());
        }
    }


    protected void setStateVars(String containerName,
                                boolean typeAgents,
                                boolean typeServices,
                                String entityName) {
        this.containerName = containerName;
        this.typeAgents = typeAgents;
        this.typeServices = typeServices;
        this.entityName = entityName;
    }


    public static String encodeURL(String url) {
        try {
            return URLEncoder.encode(url, "UTF-8");
        } catch (UnsupportedEncodingException ex) {
            return null;
        }
    }


    public static String decodeURL(String url) {
        try {
            return URLDecoder.decode(url, "UTF-8");
        } catch (UnsupportedEncodingException ex) {
            return null;
        }
    }


    protected void processMain() {
        if (!parseRequest(inputStream)) {
            // invalid request
            return;
        }

        if (getURLtype(url) == URL_TYPE_STATIC_IMAGE) {
            // static images can be accessed without previous login
            processCookieValid();
            return;
        }

        userInfo = null;
        if (ENABLE_LOGIN) {
            userInfo = httpsServer.getUserInfo(cookieID);
        }
        else {
            userInfo = new UserInfo("admin", true, true);
        }
        htmlGen.setUserInfo(userInfo);

        if (userInfo == null) {
            // cookie is missing or invalid
            processCookieInvalid();
        } else {
            // cookie is valid
            processCookieValid();
        }
    }


    protected void processCookieInvalid() {
        if (cmdPost && dataType.equals("application/x-www-form-urlencoded")) {
            // process form data
            String urlLow = url.toLowerCase();

            if (urlLow.equals("login.html")) {
                // this is login form data
                HashMap<String, String> loginData = parseFormData(data);
                userInfo = checkLoginData(loginData);
                if (userInfo != null) {
                    // valid login
                    processLoginOK(loginData);
                }
                else {
                    // invalid login
                    sendLoginPage(true, loginData);
                }
                return;
            }
        }

        HashMap<String, String> loginData = new HashMap<String, String>();
        if (cmdGet) {
            loginData.put("cmdget", "true");
        }
        if (cmdPost) {
            loginData.put("cmdpost", "true");
        }
        loginData.put("url", url);
        loginData.put("datatype", dataType);
        loginData.put("data", data);

        sendLoginPage(false, loginData);
    }


    protected void processLoginOK(HashMap<String, String> loginData) {
        httpsServer.registerUser(userInfo);
        htmlGen.setUserInfo(userInfo);

        cmdGet = loginData.get("cmdget") != null;
        cmdPost = loginData.get("cmdpost") != null;
        url = loginData.get("url");
        if (url == null) {
            url = "";
        }
        else {
            if (url.equalsIgnoreCase("logoff.html")) {
                url = "";
            }
        }
        cookieID = null;
        dataType = loginData.get("datatype");
        data = loginData.get("data");

        sendCookie = true;
        processCookieValid();
    }


    protected void processCookieValid() {
        String urlLow = url.toLowerCase();
        String urlPrefix = HtmlGenerator.aglobeURL(container.getContainerName());
        String urlPrefixLow = urlPrefix.toLowerCase();

        if (cmdPost && dataType.equals("application/x-www-form-urlencoded")) {

            // process form data

            HashMap<String,String> formData = parseFormData(data);

            if (urlLow.equals(urlPrefixLow + "/createagent.html")) {
                if (formData.containsKey("submit")) {
                    // create a new agent
                    AgentInfo agentInfo = processCreateAgent(formData);
                    if (agentInfo != null) {
                        // agent created successfully
                        setStateVars(container.getContainerName(),
                                     true, false,
                                     agentInfo.getName());
                        sendAgentPage(agentInfo);
                    }
                    else {
                        // agent not created, try again
                        setStateVars(container.getContainerName(), true, false, null);
                        sendCreateAgent(true,
                                        formData.get("agentname"),
                                        formData.get("mainclass"),
                                        processAddNewParam(formData));
                    }
                    return;
                }

                if (formData.containsKey("addparam")) {
                    // add a new parameter
                    setStateVars(container.getContainerName(), true, false, null);
                    sendCreateAgent(false,
                                    formData.get("agentname"),
                                    formData.get("mainclass"),
                                    processAddNewParam(formData));
                    return;
                }

                return;
            }

            if (urlLow.equals(urlPrefixLow + "/createservice.html")) {
                if (formData.containsKey("submit")) {
                    ServiceInfo serviceInfo = processCreateService(formData);
                    if (serviceInfo != null) {
                        // service created successfully
                        setStateVars(container.getContainerName(),
                                     false, true,
                                     serviceInfo.getName());
                        sendServicePage(serviceInfo);
                    }
                    else {
                        // service not created, try again
                        setStateVars(container.getContainerName(), false, true, null);
                        sendCreateService(true,
                                          formData.get("servicename"),
                                          formData.get("mainclass"));
                    }
                    return;
                }

                return;
            }
        }
        else {

            // process HTML page request or image/file request

            if (urlLow.equals("logoff.html")) {
                if (httpsServer.deregisterUser(cookieID)) {
                    userInfo = null;
                    htmlGen.setUserInfo(userInfo);
                    sendLoginPage(false, null);
                }
                return;
            }

            if (urlLow.equals(urlPrefixLow + "/createagenttemp.html")) {
                if (!userInfo.canCreate()) {
                    return;
                }
                setStateVars(container.getContainerName(), true, false, null);
                sendTemporaryPage("Create agent",
                                  "Loading data...<BR><BR>Wait please.\n",
                                  "/" + urlPrefix + "/createagent.html");
                return;
            }

            if (urlLow.equals(urlPrefixLow + "/createagent.html")) {
                if (!userInfo.canCreate()) {
                    return;
                }
                setStateVars(container.getContainerName(), true, false, null);
                sendCreateAgent(false, null, null, null);
                return;
            }

            if (urlLow.equals(urlPrefixLow + "/createservicetemp.html")) {
                if (!userInfo.canCreate()) {
                    return;
                }
                setStateVars(container.getContainerName(), false, true, null);
                sendTemporaryPage("Create service",
                                  "Loading data...<BR><BR>Wait please.\n",
                                  "/" + urlPrefix + "/createservice.html");
                return;
            }

            if (urlLow.equals(urlPrefixLow + "/createservice.html")) {
                if (!userInfo.canCreate()) {
                    return;
                }
                setStateVars(container.getContainerName(), false, true, null);
                sendCreateService(false, null, null);
                return;
            }

            if (urlLow.startsWith(urlPrefixLow + "/killagent.html?")) {
                if (!userInfo.canKill()) {
                    return;
                }
                processKillAgent(url.substring(urlPrefixLow.length() + 16));
                setStateVars(container.getContainerName(), true, false, null);
                sendContainerPage();
                return;
            }

            if (urlLow.startsWith(urlPrefixLow + "/killservice.html?")) {
                if (!userInfo.canKill()) {
                    return;
                }
                processKillService(url.substring(urlPrefixLow.length() + 18));
                setStateVars(container.getContainerName(), false, true, null);
                sendContainerPage();
                return;
            }

            int urlType = getURLtype(url);
            switch (urlType) {

            case URL_TYPE_AGLOBE: // A-globe HTML page request
                parseAglobeURL(url);  // parse URL
                processPageRequest(); // send an appropriate page
                return;

            case URL_TYPE_STATIC_IMAGE: // image request
                sendFile(translateFileURL(url));
                return;

            case URL_TYPE_VIRTUAL_IMAGE:
                parseAglobeURL(url);  // parse URL
                processVirtualImageRequest();
                return;

            case URL_TYPE_GENERIC:
                sendHomepage();
                return;
            }

        }
    }


    protected boolean parseRequest(BufferedReader inputStream) {
        try {
            String s = inputStream.readLine();
            if (s == null) {
                return false; // unexpected end of stream
            }

            StringTokenizer st = new StringTokenizer(s);
            if (st.countTokens() < 2) {
                return false; // unexpected syntax
            }

            String token = st.nextToken().toUpperCase();
            if (token.equals("GET")) {
                cmdGet = true;
            } else {
                if (token.equals("POST")) {
                    cmdPost = true;
                } else {
                    return false; // unknown command
                }
            }

            url = decodeURL(st.nextToken());
            if (url.startsWith("/")) {
                url = url.substring(1);
            }

            int dataLength = 0;

            while (true) {
                s = inputStream.readLine();
                if (s == null) {
                    return false; // unexpected end of stream
                }

                String su = s.toUpperCase();
                if (su.startsWith("COOKIE:")) {
                    st = new StringTokenizer(s, ":; \t");
                    if (st.countTokens() < 2) {
                        continue; // unexpected syntax
                    }
                    st.nextToken();
                    while (st.hasMoreTokens()) {
                        token = st.nextToken();
                        if (token.toUpperCase().startsWith("SID=")) {
                            cookieID = token;
                            break;
                        }
                    }
                } else {
                    if (su.startsWith("CONTENT-TYPE:")) {
                        st = new StringTokenizer(s, ": \t");
                        if (st.countTokens() != 2) {
                            continue;
                        }
                        st.nextToken();
                        dataType = st.nextToken();
                    } else {
                        if (su.startsWith("CONTENT-LENGTH:")) {
                            st = new StringTokenizer(s, ": \t");
                            if (st.countTokens() != 2) {
                                continue;
                            }
                            st.nextToken();
                            dataLength = Integer.parseInt(st.nextToken());
                        } else {
                            if (su.length() == 0) { // empty line - end of header
                                if (dataType != null && dataLength > 0) {
                                    char[] buffer = new char[dataLength];
                                    if (inputStream.read(buffer, 0, dataLength) !=
                                        dataLength) {
                                        dataType = null;
                                        dataLength = 0;
                                    } else {
                                        data = new String(buffer);
                                    }
                                }
                                return true;
                            }
                        }
                    }
                }
            }
        } catch (IOException ex) {
            System.out.println("Exception#3: " + ex.getMessage());
            return false;
        }
    }


    protected int getURLtype(String url) {
        String s = url.toLowerCase();
        if (s.equals("aglobe") || s.startsWith("aglobe/")) {
            if (s.endsWith(".png") || s.contains(".png?")) {
                return URL_TYPE_VIRTUAL_IMAGE;
            }
            return URL_TYPE_AGLOBE;
        }
        if (s.equals("images") || s.startsWith("images/")) {
            return URL_TYPE_STATIC_IMAGE;
        }
        return URL_TYPE_GENERIC;
    }


    /*
       Valid URL format:
          aglobe
            [/<container_name>
              [/(agents|services)
                [/(<agent_name>|<service_name>)]
              ]
            ]
       Examples:
          aglobe
          aglobe/MyContainer
          aglobe/MyContainer/agents
          aglobe/MyContainer/services
          aglobe/MyContainer/agents/MyAgent
          aglobe/MyContainer/services/MyService
     */
    protected void parseAglobeURL(String url) {
        containerName = null;
        typeAgents = false;
        typeServices = false;
        entityName = null;

        String token;

        if (url == null) {
            return;
        }
        StringTokenizer st = new StringTokenizer(url, "/");
        if (!st.hasMoreTokens()) {
            return;
        }
        if (!st.nextToken().toLowerCase().equals("aglobe")) {
            return;
        }
        if (!st.hasMoreTokens()) {
            return;
        }

        containerName = st.nextToken();
        if (!st.hasMoreTokens()) {
            return;
        }

        token = st.nextToken();
        if (token.equalsIgnoreCase("agents")) {
            typeAgents = true;
        }
        else {
            if (token.equalsIgnoreCase("services")) {
                typeServices = true;
            }
            else {
                return;
            }
        }
        if (!st.hasMoreTokens()) {
            return;
        }

        entityName = st.nextToken().replace('_', '/');
        if (!st.hasMoreTokens()) {
            return;
        }

        webPageKey = st.nextToken();
        while (st.hasMoreTokens()) {
            webPageKey += "/" + st.nextToken();
        }
    }


    protected URL translateFileURL(String url) {
        if (getURLtype(url) == URL_TYPE_STATIC_IMAGE) {
            url = url.substring(7);
            return aglobex.web.server.resources.Void.class.getResource(url);
        }

        try {
            return new URL(url);
        } catch (MalformedURLException ex) {
            return null;
        }
    }


    protected HashMap<String,String> parseFormData(String data) {
        HashMap<String,String> map = new HashMap<String,String>();
        if (data == null) {
            return map;
        }
        StringTokenizer st = new StringTokenizer(data, "&");
        while (st.hasMoreTokens()) {
            StringTokenizer st2 = new StringTokenizer(st.nextToken(), "=");
            if (st2.countTokens() != 2) {
                continue;
            }
            String key = decodeURL(st2.nextToken());
            String value = decodeURL(st2.nextToken());
            map.put(key, value);
        }
        return map;
    }


    protected UserInfo checkLoginData(HashMap<String, String> loginData) {
        String login = loginData.get("login");
        if (login == null) {
            return null;
        }
        String password = loginData.get("password");
        if (password == null) {
            return null;
        }

        if (login.equals("admin") && password.equals(".")) {
            return new UserInfo(login, true, true);
        }
        if (login.equals("guest") && password.equals(".")) {
            return new UserInfo(login, false, false);
        }

        return null;
    }


    protected void processPageRequest() {
        if (entityName == null) {
            sendContainerPage();
            return;
        }

        if (typeAgents) {
            AgentInfo agentInfo = agentManager.getAgentInfo(entityName);
            if (agentInfo != null) {
                sendAgentPage(agentInfo);
            }
            else {
                // agent not found
                sendContainerPage();
            }
            return;
        }

        if (typeServices) {
            ServiceInfo serviceInfo = serviceManager.getServiceInfo(entityName);
            if (serviceInfo != null) {
                sendServicePage(serviceInfo);
            }
            else {
                // service not found
                sendContainerPage();
            }
            return;
        }

        sendHomepage();
    }


    protected void processVirtualImageRequest() {
        if (containerName == null ||
            entityName == null ||
            webPageKey == null) {
            sendNotFound();
            return;
        }

        int index = webPageKey.lastIndexOf("/");
        String key;
        if (index < 0) {
            key = webPageKey;
        }
        else {
            key = webPageKey.substring(index + 1);
        }

        index = key.indexOf("?");
        if (index >= 0) {
            key = key.substring(0, index);
        }

        ImageRequestListener listener;
        if (typeAgents) {
            listener = httpsServer.getAgentImageListener(entityName, key);
        }
        else {
            if (typeServices) {
                listener = httpsServer.getServiceImageListener(entityName, key);
            }
            else {
                sendNotFound();
                return;
            }
        }

        InputStream inputStream = null;
        if (listener != null) {
            inputStream = listener.getImagePNGContent(key);
        }
        if (inputStream != null) {
            sendPNGImage(inputStream);
        }
        else {
            sendNotFound();
        }
    }


    protected AgentInfo processCreateAgent(HashMap<String,String> formData) {
        AgentInfo info = new AgentInfo();
        String agentName = formData.get("agentname");
        if (agentName == null) {
            return null;
        }
        info.setName(agentName);
        info.setReadableName(agentName);
        info.setType("");
        String mainClass = formData.get("mainclass");
        if (mainClass == null) {
            return null;
        }
        info.setMainClass(mainClass);
        info.setLibraries(new Libraries());

        List<AglobeParam> params = info.getAglobeParam();
        for (int id = 1; ; id++) {
            String name = formData.get("paramName" + id);
            if (name == null) {
                break;
            }
            String value = formData.get("paramValue" + id);
            if (value == null) {
                break;
            }
            if (name.length() > 0) {
                AglobeParam p = new AglobeParam();
                p.setName(name);
                p.setValue(value);
                params.add(p);
            }
        }

        try {
            agentManager.createAgent(info, false);
        } catch (Exception ex) {
            return null;
        }
        return info;
    }


    protected ServiceInfo processCreateService(HashMap<String,String> formData) {
        ServiceInfo info = new ServiceInfo();
        String serviceName = formData.get("servicename");
        if (serviceName == null) {
            return null;
        }
        info.setName(serviceName);
        String mainClass = formData.get("mainclass");
        if (mainClass == null) {
            return null;
        }
        info.setMainClass(mainClass);
        info.setLibraries(new Libraries());
        try {
            serviceManager.registerService(info, true);
        } catch (Exception ex) {
            return null;
        }
        return info;
    }


    protected LinkedList<AglobeParam> processAddNewParam(HashMap<String,String> formData) {
        LinkedList<AglobeParam> params = new LinkedList<AglobeParam>();
        for (int id = 1; ; id++) {
            String name = formData.get("paramName" + id);
            if (name == null) {
                break;
            }
            String value = formData.get("paramValue" + id);
            if (value == null) {
                break;
            }
            if (name.length() > 0) {
                AglobeParam param = new AglobeParam();
                param.setName(name);
                param.setValue(value);
                params.add(param);
            }
        }

        String name = formData.get("newParamName");
        String value = formData.get("newParamValue");
        if (name != null && value != null) {
            if (name.length() > 0) {
                AglobeParam param = new AglobeParam();
                param.setName(name);
                param.setValue(value);
                params.add(param);
            }
        }

        return params;
    }


    protected void processKillAgent(String agentName) {
        agentManager.killAgent(agentName);
        try {
            Thread.sleep(250);
        } catch (InterruptedException ex) {
        }
    }


    protected void processKillService(String serviceName) {
        serviceManager.deregisterService(serviceName);
        try {
            Thread.sleep(250);
        } catch (InterruptedException ex) {
        }
    }


    protected void sendHTML(String content) {
        String s = new String();
        try {
            s += "HTTP/1.0 200 OK\r\n";
            if (sendCookie) {
                if (userInfo != null) {
                    Cookie cookie = userInfo.getCookie();
                    s += "Set-Cookie: " + cookie.getID() + ";Secure\r\n";
                }
            }
            s += "Cache-Control: max-age=0, must-revalidate\r\n" +
                    "Content-Type: text/html\r\n" +
                    "Content-Length: " + content.length() + "\r\n" +
                    "\r\n" +
                    content;
            outputStream.writeBytes(s);
            outputStream.flush();
        } catch (IOException ex) {
        }
    }


    protected void sendNotFound() {
        try {
            outputStream.writeBytes(
                    "HTTP/1.0 404 not found\r\n" +
                    "\r\n");
            outputStream.flush();
        } catch (IOException e) {
            System.out.println("Exception#4: " + e.getMessage());
        }
    }


    protected void sendRedirect(String urlNew) {
        String s = new String();
        try {
            s += "HTTP/1.0 303\r\n";
            s += "Location: " + urlNew + "\r\n";
            s += "\r\n";
            outputStream.writeBytes(s);
            outputStream.flush();
        } catch (IOException ex) {
        }
    }


    protected void sendFile(URL url) {
        InputStream is = null;
        try {
            is = new FileInputStream(new File(url.toURI()));
        } catch (Exception ex) {
            // file not found
            sendNotFound();
            return;
        }

        try {
            String contentType = null;
            String filename = url.getFile();
            int ext = filename.lastIndexOf(".");
            if (ext > 0) {
                contentType = contentTypeMap.get(filename.substring(ext));
            }
            if (contentType == null) {
                contentType = "unknown/unknown";
            }
            int contentLength = is.available();
            outputStream.writeBytes(
                    "HTTP/1.0 200 OK\r\n" +
                    "Cache-Control: max-age=0, must-revalidate\r\n" +
                    "Content-Type: " + contentType + "\r\n" +
                    "Content-Length: " + contentLength + "\r\n" +
                    "\r\n");
            byte buffer[] = new byte[contentLength];
            is.read(buffer);
            outputStream.write(buffer);
            outputStream.flush();
        } catch (IOException ex) {
            System.out.println("Exception#5: " + ex.getMessage());
        }
    }


    protected void sendPNGImage(InputStream inputStream) {
        try {
            int contentLength = inputStream.available();
            outputStream.writeBytes(
                    "HTTP/1.0 200 OK\r\n" +
                    "Cache-Control: max-age=0, must-revalidate\r\n" +
                    "Content-Type: image/png\r\n" +
                    "Content-Length: " + contentLength + "\r\n" +
                    "\r\n");
            byte buffer[] = new byte[contentLength];
            inputStream.read(buffer);
            outputStream.write(buffer);
            outputStream.flush();
        } catch (IOException ex) {
            System.out.println("Exception#6: " + ex.getMessage());
        }
    }


    protected String buildMenu() {
        MenuInfo menuInfo = new MenuInfo();
        menuInfo.url = "aglobe";
        if (containerName != null &&
            containerName.equals(container.getContainerName())) {
            menuInfo.selContainer = container;
            menuInfo.url += "/" + containerName;
        }
        menuInfo.agentsExpanded = typeAgents;
        if (menuInfo.agentsExpanded) {
            menuInfo.url += "/agents";
            if (entityName != null) {
                menuInfo.selAgent = agentManager.getAgentInfo(entityName);
            }
        }
        menuInfo.servicesExpanded = typeServices;
        if (menuInfo.servicesExpanded) {
            menuInfo.url += "/services";
            if (entityName != null) {
                menuInfo.selService = serviceManager.getServiceInfo(entityName);
            }
        }
        menuInfo.webPageKey = webPageKey;
        if (menuInfo.selAgent != null || menuInfo.selService != null) {
            menuInfo.url += "/" + entityName.replace("/", "_");
            if (webPageKey != null) {
                menuInfo.url += "/" + webPageKey;
            }
        }

        return htmlGen.menu(menuInfo);
    }


    protected void sendLoginPage(boolean prevLoginFailed,
                                 HashMap<String, String> loginData) {
        String html = htmlGen.htmlPageTemplate(
            null,
            "Login",
            htmlGen.loginPage(prevLoginFailed, loginData));
        sendHTML(html);
    }


    protected void sendHomepage() {
        setStateVars(null, false, false, null);
        String html = htmlGen.htmlPageTemplate(
            buildMenu(),
            null,
            null);
        sendHTML(html);
    }


    protected void sendContainerPage() {
        String html = htmlGen.htmlPageTemplate(
            buildMenu(),
            "container" + "&nbsp;&nbsp;" + container.getContainerName(),
            htmlGen.containerPage());
        sendHTML(html);
    }


    protected void sendAgentPage(AgentInfo agentInfo) {
        PageKeyTree tree = httpsServer.getAgentKeyTree(agentInfo.getName());
        String webPageContent = null;
        int refreshRate = 0;
        if (tree != null && webPageKey != null) {
            WebRequestListener listener = tree.getListener(webPageKey);
            if (listener != null) {
                Map<String,String> params = new HashMap<String,String>();
                webPageContent = listener.getWebPageContent(webPageKey, params);
                refreshRate = listener.refreshRate();
            }
        }
        String contentTitle = "agent&nbsp;&nbsp;" + agentInfo.getName();
        if (webPageContent != null) {
            contentTitle += "&nbsp;&nbsp;/" + webPageKey;
        }
        String html = htmlGen.htmlPageTemplate(
            refreshRate != 0 ? "<META http-equiv=\"refresh\" content=\"" + refreshRate + "\">\n" : null,
            buildMenu(),
            contentTitle,
            htmlGen.agentPage(agentInfo, webPageContent));
        sendHTML(html);
    }


    protected void sendServicePage(ServiceInfo serviceInfo) {
        PageKeyTree tree = httpsServer.getAgentKeyTree(serviceInfo.getName());
        String webPageContent = null;
        int refreshRate = 0;
        if (tree != null && webPageKey != null) {
            WebRequestListener listener = tree.getListener(webPageKey);
            if (listener != null) {
                Map<String,String> params = new HashMap<String,String>();
                webPageContent = listener.getWebPageContent(webPageKey, params);
                refreshRate = listener.refreshRate();
            }
        }
        String contentTitle = "service&nbsp;&nbsp;" + serviceInfo.getName();
        if (webPageContent != null) {
            contentTitle += "&nbsp;&nbsp;/" + webPageKey;
        }
        String html = htmlGen.htmlPageTemplate(
            refreshRate != 0 ? "<META http-equiv=\"refresh\" content=\"" + refreshRate + "\">\n" : null,
            buildMenu(),
            contentTitle,
            htmlGen.servicePage(serviceInfo, webPageContent));
        sendHTML(html);
    }


    protected void sendTemporaryPage(String contentTitle,
                                     String content,
                                     String nextURL) {
        String html = htmlGen.htmlPageTemplate(
            "<META http-equiv=\"refresh\" content=\"0;url=" + nextURL + "\">\n",
            buildMenu(),
            contentTitle,
            content);
        sendHTML(html);
    }


    protected void sendCreateAgent(boolean prevFailed,
                                   String agentName,
                                   String nameClass,
                                   LinkedList<AglobeParam> params) {
        String html = htmlGen.htmlPageTemplate(
            buildMenu(),
            "Create agent",
            htmlGen.formCreateAgent(prevFailed, agentName, nameClass, params));
        sendHTML(html);
    }


    protected void sendCreateService(boolean prevFailed,
                                     String serviceName,
                                     String mainClass) {
        String html = htmlGen.htmlPageTemplate(
            buildMenu(),
            "Create service",
            htmlGen.formCreateService(prevFailed, serviceName, mainClass));
        sendHTML(html);
    }

}
