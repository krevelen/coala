package aglobex.web.server;

import java.util.*;


public interface WebRequestListener {
    public String getWebPageContent(String key, Map<String,String> params);

    /**
     * @return int - automatic page refresh rate in seconds (0 => no refresh)
     */
    public int refreshRate();
}
