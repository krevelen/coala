package aglobex.web.server;

import java.io.*;

import aglobe.container.*;
import aglobe.container.service.*;
import aglobe.ontology.*;

/**
 * <p>Title: A-Globe</p>
 *
 * <p>Description: Web server service provides web interface.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.23 $ $Date: 2010/08/04 11:48:06 $
 */
public class WebServerService
    extends Service {

  /**
   * Service name
   */
  public static final String SERVICENAME = "web/server";

  /**
   * Https server
   */
  protected HttpsServer httpsServer;

  /**
   * Method has to be overriden.
   *
   * @return ServiceShell
   * @param shellOwner ElementaryEntity - agent/service
   */
  @Override
public ServiceShell getServiceShell(ShellOwner shellOwner) {
    return new Shell(shellOwner, this);
  }

  /**
   * Must be overriden if the service is interrested in incoming Messages.
   *
   * @param m The Message.
   */
  @Override
public void handleIncomingMessage(Message m) {
    logSevere("Unexpected incoming message: " + m);
    m.release();
  }

  /**
   * The service should use this method for starting or restarting the service.
   *
   */
  @Override
public void init() {
    // init service
  }

  public void initWebServer() {
      httpsServer = new HttpsServer(this);
  }

  /**
   * The service should finish here and do the necessary cleanups.
   *
   */
  @Override
public void finish() {
    // stop service
  }

  /**
   *
   * <p>Title: A-Globe</p>
   *
   * <p>Description: Web server service shell</p>
   *
   * <p>Copyright: Copyright (c) 2005</p>
   *
   * <p>Company: Gerstner Laboratory</p>
   *
   * @author David Sislak
   * @version $Revision: 1.23 $ $Date: 2010/08/04 11:48:06 $
   */
  public class Shell
      extends ServiceShell {
    /**
     * Link to the directory service.
     */
    transient WebServerService theservice = null;


    private transient boolean postInit = false;

    /**
     * Constructor used for serialization purposes. DO NOT USE THIS constructor.
     */
    public Shell() {
      super();
    }

    /**
     * Private constructor of Shell. It is called from
     * <code>getServiceShell()</code> of <code>WebServerShell</code>.
     *
     * @param shellOwner ElementaryEntity - agent/service
     * @param _theservice WebServerService
     */
    private Shell(ShellOwner shellOwner, WebServerService _theservice) {
      super(shellOwner);
      theservice = _theservice;
    }

    /**
     *  Dispose this shell.
     */
    @Override
    public void dispose() {
      // deregister all web content provided by owner agent
      // .....

      super.dispose();
    }

    /**
     * isValid
     * @return boolean
     */
    @Override
    public boolean isValid() {
      return theservice != null;
    }

    /**
     * This method assigns a container to the <code>Shell</code> of the
     * <code>DirectoryService</code>.
     *
     * @param container AgentContainer
     * @throws Exception
     */
    @Override
    public void setContainer(AgentContainer container) throws Exception {
        Service s = container.getServiceManager().getServiceInstance(WebServerService.SERVICENAME);
        if ((s != null) && (s instanceof WebServerService)) {
            theservice = (WebServerService) s;
            // remember values
            postInit = true;

        }
        else {
            throw new Exception(container.getContainerName() +
            ": Cannot reconect to the WebServer Service");
        }
    }

    /**
     * Called after init of the owner agent
     */
    @Override
    public void postInit() {
      if (!postInit) {
        return;
      }
      // reregister web content
      // ..........
    }

    /**
     * The object implements the writeExternal method to save its contents by
     * calling the methods of DataOutput for its primitive values or calling the
     * writeObject method of ObjectOutput for objects, strings, and arrays.
     *
     * @param out the stream to write the object to
     * @throws IOException Includes any I/O exceptions that may occur
     */
    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
      super.writeExternal(out);
    }

    /**
     * The object implements the readExternal method to restore its contents by
     * calling the methods of DataInput for primitive types and readObject for
     * objects, strings and arrays.
     *
     * @param in the stream to read data from in order to restore the object
     * @throws IOException if I/O errors occur
     * @throws ClassNotFoundException If the class for an object being restored
     *   cannot be found.
     */
    @Override
    public void readExternal(ObjectInput in) throws IOException,
        ClassNotFoundException {
      super.readExternal(in);
    }


    public boolean registerWebPage(String key,
                                   WebRequestListener listener) {
        return httpsServer.registerWebPage(shellOwner, key, true, listener);
    }


    public boolean registerWebPage(String key, boolean addSorted,
                                   WebRequestListener listener) {
        return httpsServer.registerWebPage(shellOwner, key, addSorted, listener);
    }


    public boolean deregisterWebPage(String key) {
        return httpsServer.deregisterWebPage(shellOwner, key);
    }


    public String registerImage(ImageRequestListener listener) {
        return httpsServer.registerImage(shellOwner, listener);
    }


    public boolean deregisterImage(String key) {
        return httpsServer.deregisterImage(shellOwner, key);
    }

  }
}
