package aglobex.web.server.resources;


public class Void {

    private Void() {
    }

}
