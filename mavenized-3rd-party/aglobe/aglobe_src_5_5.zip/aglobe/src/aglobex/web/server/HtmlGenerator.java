package aglobex.web.server;

import java.util.*;

import aglobe.container.*;
import aglobe.container.agent.*;
import aglobe.container.service.*;
import aglobe.ontology.*;


public class HtmlGenerator {

    private final static String SERVER_IP = "192.168.0.2";
    private final static String BASE_URL = "https://" + SERVER_IP + "/";

    private HttpsServer httpsServer;
    private AgentContainer container;
    private String containerName;
    private AgentManager agentManager;
    private ServiceManager serviceManager;

    private String bodyAttribs;
    private UserInfo userInfo;

    public HtmlGenerator(HttpsServer httpsServer, AgentContainer container) {
        this.httpsServer = httpsServer;
        this.container = container;
        containerName = container.getContainerName();
        agentManager = container.getAgentManager();
        serviceManager = container.getServiceManager();
        bodyAttribs = "onLoad=\"setTimeout('doRefresh()', 2000)\"";
        userInfo = null;
    }


    public void setBodyAttribs(String bodyAttribs) {
        this.bodyAttribs = bodyAttribs;
    }


    public void setUserInfo(UserInfo userInfo) {
        this.userInfo = userInfo;
    }


    public static String aglobeURL(String urlRel) {
        return "aglobe/" + urlRel;
    }


    public static String containerURL(String containerName) {
        return "aglobe/" + containerName;
    }


    public static String agentURL(String containerName, String agentName) {
        return "aglobe/" + containerName + "/agents/" + agentName;
    }


    public static String serviceURL(String containerName, String serviceName) {
        return "aglobe/" + containerName + "/services/" + serviceName;
    }


    public static String imageURL(String urlRel) {
        return "images/" + urlRel;
    }


    public static String genericURL(String urlRel) {
        return urlRel;
    }


    private String a(String url, String content) {
        return "<A href=\"" + url + "\">" + content + "</A>";
    }


    private String ax(String url, String attribs, String content) {
        return "<A href=\"" + url + "\" " + attribs + ">" + content + "</A>";
    }


    private String img(String url, int width, int height) {
        return "<IMG src=\"" + url + "\" width=\"" + width + "\" height=\"" + height + "\">";
    }


    private String imgx(String attribs, String url, int width, int height) {
        return "<IMG src=\"" + url + "\" width=\"" + width + "\" height=\"" + height + "\" attribs=\"" + attribs + "\">";
    }


    private String tr(String content) {
        return "<TR>" + content + "</TR>";
    }


    private String td(String content) {
        return "<TD>" + content + "</TD>";
    }


    private String tdx(String attribs, String content) {
        return "<TD " + attribs + ">" + content + "</TD>";
    }


    private String cssRules() {
        String s = new String();

        s += "HTML { width: 100%; height: 123% }\n";
        s += "BODY { width: 100%; height: 80%; margin: 0px }\n";

        s += "TABLE.mainFrame { width: 100%; height: 100% }\n";
        s += "TABLE.mainFrame TD.bar { height: 60px; background: url(images/bar.png); background-repeat: repeat-x }\n";
        s += "TABLE.mainFrame TD.barsep { width: 10px; height: 60px; background: url(images/barsep.png); background-repeat: no-repeat }\n";
        s += "TABLE.mainFrame TD.sepv { width: 10px; background: url(images/sepv.png); background-repeat: repeat-y }\n";
        s += "TABLE.mainFrame TD.seph { height: 10px; background: url(images/seph.png); background-repeat: repeat-x }\n";
        s += "TABLE.mainFrame TD.sepcross { width: 10px; height: 10px; background: url(images/sepcross.png); background-repeat: no-repeat }\n";
        s += "TABLE.mainFrame TR.bottom { height: 50px }\n";
        s += "TABLE.mainFrame TR.bottom TD.logos { padding-left: 10px }\n";

        s += "BODY { font-family: Arial; background-color: #EEEEEE }\n";
        s += "TABLE { font-size: inherit }\n";
        s += "IMG { border: 0px }\n";
        s += "INPUT { border: 1px solid black }\n";
        s += "INPUT { font-family: Arial; font-size: 9pt }\n";
        s += "SELECT { font-family: Arial; font-size: 9pt }\n";
        s += "OPTION { font-family: Arial; font-size: 9pt }\n";

        s += "A:link { color: black }\n";
        s += "A:active { color: black }\n";
        s += "A:visited { color: black }\n";

        s += "DIV.menuBlock { font-size: 9pt; padding-left: 10px }\n";

        s += "DIV.menuBlock TABLE { border-collapse: collapse }\n";
        s += "DIV.menuBlock IMG { vertical-align: middle }\n";
        s += "DIV.menuBlock A { text-decoration: none }\n";
        s += "DIV.menuBlock A:link { color: black }\n";
        s += "DIV.menuBlock A:active { color: black }\n";
        s += "DIV.menuBlock A:visited { color: black }\n";
        s += "DIV.menuBlock TD { white-space: nowrap }\n";
        s += "DIV.menuBlock TD.containerName { font-weight: bold }\n";
        s += "DIV.menuBlock TD.agentName { font-weight: bold }\n";
        s += "DIV.menuBlock TD.serviceName { font-weight: bold }\n";
        s += "DIV.menuBlock TD.pageName { font-weight: bold }\n";
        s += "DIV.menuBlock TD.emptyList { font-style: italic }\n";
        s += "DIV.menuBlock TABLE.webPagesTree A:link { color: #2A3A8C }\n";
        s += "DIV.menuBlock TABLE.webPagesTree A:active { color: #2A3A8C }\n";
        s += "DIV.menuBlock TABLE.webPagesTree A:visited { color: #2A3A8C }\n";

        s += "DIV.contentTitle { font-size: 12pt; font-weight: bold; padding-left: 10px; padding-top: 12px }\n";
        s += "DIV.userInfo { font-size: 12pt; font-weight: bold; padding-top: 12px; padding-right: 10px }\n";
        s += "DIV.contentBlock { font-size: 9pt; padding-left: 10px }\n";

        s += "DIV.loginBlock {}\n";

        s += "DIV.entityBasicInfo TD.itemContent { width: 400px; background-color: #D9E3ED; padding: 3px; border: 1px solid #808080 }\n";
        s += "DIV.entityBasicInfo TD.paramTable { padding: 0px }\n";
        s += "DIV.entityBasicInfo TD.paramTable TABLE { width: 100% }\n";
        s += "DIV.entityBasicInfo TD.headerName, DIV.entityBasicInfo TD.headerValue { border: 1px solid #808080; padding-left: 5px; background-color: #BED5EB }\n";
        s += "DIV.entityBasicInfo TD.listNames, DIV.entityBasicInfo TD.listValues { padding-left: 6px }\n";

        s += "FORM.login INPUT.login, FORM.login INPUT.password { width: 150px }\n";

        s += "FORM.createAgent TD.itemContent { width: 400px; background-color: #D9E3ED; padding: 3px; border: 1px solid #808080 }\n";
        s += "FORM.createAgent INPUT.agentName { width: 99% }\n";
        s += "FORM.createAgent SELECT.mainClass { width: 100% }\n";
        s += "FORM.createAgent TD.paramTable { padding: 0px }\n";
        s += "FORM.createAgent TD.paramTable TABLE { width: 100% }\n";
        s += "FORM.createAgent TD.headerName, FORM.createAgent TD.headerValue { border: 1px solid #808080; padding-left: 5px; background-color: #BED5EB }\n";
        s += "FORM.createAgent TD.listNames, FORM.createAgent TD.listValues { padding-left: 6px }\n";
        s += "FORM.createAgent TD.paramName, FORM.createAgent TD.paramValue { width: 40%; padding-left: 0px; padding-right: 4px }\n";
        s += "FORM.createAgent INPUT.paramName, FORM.createAgent INPUT.paramValue { width: 100% }\n";

        s += "FORM.createService TD.itemContent { width: 400px; background-color: #D9E3ED; padding: 3px; border: 1px solid #808080 }\n";
        s += "FORM.createService INPUT.serviceName { width: 99% }\n";
        s += "FORM.createService SELECT.mainClass { width: 100% }\n";

        s += ".warning { color: #D00000; font-weight: bold }\n";

        s += "\n";

        s += "TABLE.GeneralInfo TD.ItemName {}\n";
        s += "TABLE.GeneralInfo TD.ItemContent { width: 400px; background-color: #D9E3ED; padding: 3px; border: 1px solid #808080 }\n";
        s += "TABLE.GeneralInfo TD.AlignLeft { text-align: left }\n";
        s += "TABLE.GeneralInfo TD.AlignCenter { text-align: center }\n";
        s += "TABLE.GeneralInfo TD.AlignRight { text-align: right }\n";
        s += "TABLE.GeneralInfo IMG { vertical-align: middle }\n";
        s += "TABLE.GeneralInfo A { text-decoration: none }\n";
        s += "TABLE.Table { width: 400px; border-collapse: collapse }\n";
        s += "TABLE.Table TD { padding: 3px; border: 1px solid #808080 }\n";
        s += "TABLE.Table TR.Header TD { background-color: #BED5EB; text-align: center }\n";
        s += "TABLE.Table TR.Content TD { background-color: #D9E3ED }\n";
        s += "TABLE.Table TR.NoBorder TD { border: none }\n";
        s += "TABLE.Table TD.Header { background-color: #BED5EB }\n";
        s += "TABLE.Table TD.Content { background-color: #D9E3ED }\n";
        s += "TABLE.Table TD.AlignLeft { text-align: left }\n";
        s += "TABLE.Table TD.AlignCenter { text-align: center }\n";
        s += "TABLE.Table TD.AlignRight { text-align: right }\n";
        s += "TABLE.Table IMG { vertical-align: middle }\n";
        s += "TABLE.Table A { text-decoration: none }\n";

        return s;
    }


    public String mainBlock(String head, String body) {
        String s = new String();
        if (head == null) {
            head = "";
        }
        if (body == null) {
            body = "";
        }
        s +=
                "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\">" +
                "<HTML>\n" +
                "\n" +
                "<HEAD>\n" +
                "<META http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\">\n" +
                "<BASE href=\"" + BASE_URL + "\">\n" +
                "<STYLE type=\"text/css\" media=\"screen\">\n" +
                "<!--\n" +
                cssRules() +
                "-->\n" +
                "</STYLE>\n" +
                head +
                "</HEAD>\n" +
                "\n" +
                "<BODY " + bodyAttribs + ">\n" +
                body +
                "</BODY>\n" +
                "\n" +
                "</HTML>\n";
        return s;
    }


    public String htmlPageTemplate(String menu, String contentTitle, String content) {
        return htmlPageTemplate(null, menu, contentTitle, content);
    }


    public String htmlPageTemplate(String htmlHead, String menu, String contentTitle, String content) {
        String body = new String();
        if (menu == null) {
            menu = "&nbsp;\n";
        }
        if (contentTitle == null) {
            contentTitle = "";
        }
        String userText = "";
        String logoff = "";
        if (userInfo != null) {
            userText = "user&nbsp;&nbsp;" + userInfo.getName();
            logoff = ax(genericURL("logoff.html"), "title=\"Logoff\"", img(imageURL("logoff.png"), 18, 44));
        }
        if (content == null) {
            content = "&nbsp;\n";
        }
        body += "<TABLE class=\"mainFrame\" cellpadding=\"0\" cellspacing=\"0\">\n";
        body += "<TR class=\"top\">\n" +
                "<TD class=\"bar\" valign=\"top\">" +
                ax("http://agents.felk.cvut.cz", "target=\"self\" title=\"ATG\"",
                   img(imageURL("atg.png"), 110, 44)) + "\n" +
                "<TD class=\"barsep\">\n" +
                "<TD class=\"bar contentTitle\" valign=\"top\">\n" +
                "<DIV class=\"contentTitle\">" + contentTitle + "</DIV>\n" +
                "<TD class=\"bar userInfo\" valign=\"top\" align=\"right\">\n" +
                "<DIV class=\"userInfo\">" + userText + "</DIV>\n"  +
                "<TD class=\"bar logoff\" valign=\"top\">\n" + logoff + "\n" +
                "</TR>\n";
        body += "<TR style=\"height: 100%\">\n";
        body += "<TD class=\"menu\" valign=\"top\">\n";

        body += "<DIV class=\"menuBlock\">\n";
        body += menu;
        body += "</DIV>\n";

        body += "<TD class=\"sepv\">\n";
        body += "<TD class=\"content\" colspan=\"3\" valign=\"top\">\n";

        body += "<DIV class=\"contentBlock\">\n";
        body += content;
        body += "</DIV>\n";

        body += "</TR>\n";
        body += "<TR>\n" +
                "<TD class=\"seph\">\n" +
                "<TD class=\"sepcross\">\n" +
                "<TD class=\"seph\" colspan=\"3\">\n" +
                "</TR>\n";
        body += "<TR class=\"bottom\">\n";
        body += "<TD class=\"logos\">" +
                ax("http://cyber.felk.cvut.cz/gerstner/", "target=\"_blank\" title=\"Gerstner Lab\"",
                   img(imageURL("gl.png"), 100, 40)) +
                "&nbsp;&nbsp;&nbsp;" +
                ax("http://www.cvut.cz", "target=\"_blank\" title=\"CTU Prague\"",
                   img(imageURL("cvut.png"), 60, 40)) + "\n" +
                "<TD class=\"sepv\">\n" +
                "<TD colspan=\"3\">\n";
        body += "</TR>\n";
        body += "</TABLE>\n";
        return mainBlock(htmlHead, body);
    }


    public String loginPage(boolean prevLoginFailed,
                            HashMap<String, String> loginData) {
        String s = new String();
        s += "<DIV class=\"loginBlock\">\n";
        s += "<FORM class=\"login\" action=\"" + genericURL("login.html") + "\" method=\"post\">\n";
        s += "<TABLE>\n";
        if (prevLoginFailed) {
            s += tr(tdx("class=\"warning\" colspan=\"2\"", "Invalid login!")) + "\n";
            s += tr(tdx("colspan=\"2\"", "&nbsp;")) + "\n";
        }
        s += tr(td("Login: ") +
                td("<INPUT class=\"login\" type=\"text\" name=\"login\">")) + "\n";
        s += tr(td("Password: ") +
                td("<INPUT class=\"password\" type=\"password\" name=\"password\">")) + "\n";
        s += tr(tdx("colspan=\"2\"", "&nbsp;")) + "\n";
        s += tr(tdx("colspan=\"2\"", "<INPUT type=\"submit\" name=\"submit\" value=\"Submit\">")) + "\n";
        s += "</TABLE>\n";

        if (loginData != null) {
            String cmdGet = loginData.get("cmdget");
            if (cmdGet != null) {
                s += "<INPUT type=\"hidden\" name=\"cmdget\" value=\"true\">\n";
            }
            String cmdPost = loginData.get("cmdpost");
            if (cmdPost != null) {
                s += "<INPUT type=\"hidden\" name=\"cmdpost\" value=\"true\">\n";
            }
            String url = loginData.get("url");
            if (url != null) {
                s += "<INPUT type=\"hidden\" name=\"url\" value=\"" + url + "\">\n";
            }
            String dataType = loginData.get("datatype");
            if (dataType != null) {
                s += "<INPUT type=\"hidden\" name=\"datatype\" value=\"" + dataType + "\">\n";
            }
            String data = loginData.get("data");
            if (data != null) {
                s += "<INPUT type=\"hidden\" name=\"data\" value=\"" + data + "\">\n";
            }
        }

        s += "</FORM>\n";
        s += "</DIV>\n";
        return s;
    }


    public String containerPage() {
        String s = new String();
        return s;
    }


    public String agentPage(AgentInfo info, String webPageContent) {
        String s = new String();
        if (webPageContent == null) {
            Libraries libs = info.getLibraries();
            s += entityBasicInfo(true,
                                 info.getName(),
                                 info.getMainClass(),
                                 null,
                                 libs != null ? libs.getLibrary() : null,
                                 info.getAglobeParam());
        }
        else {
            s += addWebPageContent(webPageContent);
        }
        return s;
    }


    public String servicePage(ServiceInfo info, String webPageContent) {
        String s = new String();
        if (webPageContent == null) {
            Libraries libs = info.getLibraries();
            s += entityBasicInfo(false,
                                 info.getName(),
                                 info.getMainClass(),
                                 info.getDescription(),
                                 libs != null ? libs.getLibrary() : null,
                                 null);
        }
        else {
            addWebPageContent(webPageContent);
        }
        return s;
    }


    public String formCreateAgent(boolean prevFailed,
                                  String agentName,
                                  String mainClass,
                                  LinkedList<AglobeParam> params) {
        String s = new String();
        String actionURL = containerURL(containerName) + "/createagent.html";
        s += "<FORM class=\"createAgent\" action=\"" + actionURL + "\" method=\"post\">\n";
        s += "<TABLE>\n";
        if (prevFailed) {
            s += tr(tdx("class=\"warning\" colspan=\"2\"", "Error!")) + "\n";
            s += tr(tdx("colspan=\"2\"", "&nbsp;")) + "\n";
        }
        if (agentName == null) {
            agentName = "";
        }
        s += tr(tdx("class=\"itemName\"", "Agent&nbsp;name: ") +
                tdx("class=\"itemContent\"", "<INPUT class=\"agentName\" type=\"text\" name=\"agentname\" value=\"" + agentName + "\">")) + "\n";
        s += "<TR>" + tdx("class=\"itemName\"", "Main&nbsp;class: ") + "\n";
        s += "<TD class=\"itemContent\"><SELECT class=\"mainClass\" name=\"mainclass\" size=\"1\">\n";
        List<String> list = container.getClassFinder().getAgentList();
        Iterator<String> iter = list.iterator();
        while (iter.hasNext()) {
            String item = iter.next();
            s += "<OPTION ";
            if (item.equals(mainClass)) {
                s += "selected ";
            }
            s += "value=\"" + item + "\">" + item + "</OPTION>\n";
        }
        s += "</SELECT></TD></TR>\n";

        int paramsCount = 0;
        if (params != null) {
            paramsCount = params.size();
        }
        s += tr(tdx("colspan=\"2\"", "&nbsp;")) + "\n";
        s += "<TR><TD class=\"itemName\">Parameters: </TD><TD class=\"itemContent paramTable\">\n";
        s += "<TABLE>\n";
        String paramNames = "";
        String paramValues = "";
        for (int i = 0; i < paramsCount; i++) {
            AglobeParam p = params.get(i);
            paramNames += p.getName() + "<BR>";
            paramValues += p.getValue() + "<BR>";
        }
        s += tr(tdx("class=\"headerName\"", "name") +
                tdx("class=\"headerValue\"", "value") +
                td("")) + "\n";
        if (paramsCount > 0) {
            s += tr(tdx("class=\"listNames\"", paramNames) +
                    tdx("class=\"listValues\"", paramValues) +
                    td("")) + "\n";
            for (int i = 0; i < paramsCount; i++) {
                AglobeParam p = params.get(i);
                int id = i + 1;
                s += "<INPUT type=\"hidden\" name=\"paramName" + id + "\" value=\"" + p.getName() + "\">\n";
                s += "<INPUT type=\"hidden\" name=\"paramValue" + id + "\" value=\"" + p.getValue() + "\">\n";
            }
        }
        s += tr(tdx("class=\"paramName\"", "<INPUT class=\"paramName\" type=\"text\" name=\"newParamName\">") +
                tdx("class=\"paramValue\"", "<INPUT class=\"paramValue\" type=\"text\" name=\"newParamValue\">") +
                td("<INPUT type=\"submit\" name=\"addparam\" value=\"< Add parameter\">")) + "\n";
        s += "</TABLE>\n";
        s += "</TD></TR>\n";

        s += tr(tdx("colspan=\"2\"", "&nbsp;")) + "\n";
        s += tr(td("") + td("<INPUT type=\"submit\" name=\"submit\" value=\"Submit\">")) + "\n";
        s += "</TABLE>\n";
        s += "</FORM>\n";
        return s;
    }


    public String formCreateService(boolean prevFailed,
                                    String serviceName,
                                    String mainClass) {
        String s = new String();
        String actionURL = containerURL(containerName) + "/createservice.html";
        s += "<FORM class=\"createService\" action=\"" + actionURL + "\" method=\"post\">\n";
        s += "<TABLE>\n";
        if (prevFailed) {
            s += tr(tdx("class=\"warning\" colspan=\"2\"", "Error!")) + "\n";
            s += tr(tdx("colspan=\"2\"", "&nbsp;")) + "\n";
        }
        if (serviceName == null) {
            serviceName = "";
        }
        s += tr(tdx("class=\"itemName\"", "Service&nbsp;name: ") +
                tdx("class=\"itemContent\"", "<INPUT class=\"serviceName\" type=\"text\" name=\"servicename\" value=\"" + serviceName + "\">")) + "\n";
        s += "<TR>" + tdx("class=\"itemName\"", "Main&nbsp;class: ") + "\n";
        s += "<TD class=\"itemContent\"><SELECT class=\"mainClass\" name=\"mainclass\" size=\"1\">\n";
        List<String> list = container.getClassFinder().getServiceList();
        Iterator<String> iter = list.iterator();
        while (iter.hasNext()) {
            String item = iter.next();
            s += "<OPTION ";
            if (item.equals(mainClass)) {
                s += "selected ";
            }
            s += "value=\"" + item + "\">" + item + "</OPTION>\n";
        }
        s += "</SELECT></TD></TR>\n";
        s += tr(tdx("colspan=\"2\"", "&nbsp;")) + "\n";
        s += tr(td("") + td("<INPUT type=\"submit\" name=\"submit\" value=\"Submit\">")) + "\n";
        s += "</TABLE>\n";
        s += "</FORM>\n";
        return s;
    }


    //-----------------------------------------------


    private String entityBasicInfo(boolean isAgent,
                                   String entityName,
                                   String mainClass,
                                   String description,
                                   List<String> libraries,
                                   List<AglobeParam> parameters) {
        String s = new String();

        s += "<DIV class=\"entityBasicInfo\">\n";
        s += "<TABLE>\n";
        s += tr(tdx("class=\"itemName\"", isAgent ? "Agent&nbsp;name: " : "Service&nbsp;name: ") +
                tdx("class=\"itemContent\"", entityName)) + "\n";
        s += tr(tdx("class=\"itemName\"", "Container&nbsp;name: ") +
                tdx("class=\"itemContent\"", containerName)) + "\n";
        if (mainClass.equals("")) {
            mainClass = "<I>undefined</I>";
        }
        s += tr(tdx("class=\"itemName\"", "Main&nbsp;class: ") +
                tdx("class=\"itemContent\"",  mainClass)) + "\n";

        if (!isAgent) { // only services have description
            if (description == null) {
                description = "";
            }
            s += tr(tdx("class=\"itemName\"", "Description: ") +
                    tdx("class=\"itemContent\"",  description)) + "\n";
        }

        int libsCount = 0;
        if (libraries != null) {
            libsCount = libraries.size();
        }
        String libs;
        if (libsCount > 0) {
            libs = "";
            for (int i = 0; i < libsCount; i++) {
                libs += libraries.get(i) + "<BR>";
            }
        }
        else {
            libs = "<I>no libraries</I>";
        }
        s += tr(tdx("colspan=\"2\"", "&nbsp;")) + "\n";
        s += tr(tdx("class=\"itemName\"", "Libraries: ") +
                tdx("class=\"itemContent\"", libs)) + "\n";


        if (isAgent) { // only agents have parameters
            int paramsCount = 0;
            if (parameters != null) {
                paramsCount = parameters.size();
            }
            s += tr(tdx("colspan=\"2\"", "&nbsp;")) + "\n";
            s += "<TR><TD class=\"itemName\">Parameters: </TD><TD class=\"itemContent paramTable\">\n";
            s += "<TABLE>\n";
            if (paramsCount > 0) {
                String paramNames = "";
                String paramValues = "";
                for (int i = 0; i < paramsCount; i++) {
                    AglobeParam p = parameters.get(i);
                    paramNames += p.getName() + "<BR>";
                    paramValues += p.getValue() + "<BR>";
                }
                s += tr(tdx("class=\"headerName\"", "name") +
                        tdx("class=\"headerValue\"", "value")) + "\n";
                s += tr(tdx("class=\"listNames\"", paramNames) +
                        tdx("class=\"listValues\"", paramValues)) + "\n";
            } else {
                s += tr(td("<I>no parameters</I>")) + "\n";
            }
            s += "</TABLE>\n";
            s += "</TD></TR>\n";
        }

        s += "</TABLE>\n";
        s += "</DIV>\n";
        return s;
    }


    private String addWebPageContent(String webPageContent) {
        String s = new String();
        if (webPageContent != null) {
            s += webPageContent;
        }
        return s;
    }


    private String menuContainerList(MenuInfo menuInfo) {
        String s = new String();
        boolean expanded = true;
        s += "<TABLE class=\"menu\">\n";
        String urlRefresh = genericURL(menuInfo.url);
        s += tr(
                td(img(imageURL(expanded ? "minus.png" : "plus.png"), 9, 9)) +
                td("container list&nbsp;&nbsp;" +
                   ax(urlRefresh, "title=\"Refresh\"",
                      imgx("align=\"top\"", imageURL("refresh.png"), 14, 16)))
                ) + "\n";
        if (expanded) {
            s += "<TR><TD></TD><TD>\n";
            s += "<TABLE class=\"menu\">\n";

            String selName = null;
            if (menuInfo.selContainer != null) {
                selName = menuInfo.selContainer.getContainerName();
            }
            boolean selected = false;
            if (selName != null) {
                selected = selName.equals(containerName);
            }
            String urlContainer = containerURL(selected ? "" : containerName);
            s += tr(
                td(a(urlContainer, img(imageURL(selected ? "minus.png" : "plus.png"), 9, 9))) +
                tdx("class=\"containerName\"", a(urlContainer, containerName))
                    ) + "\n";
            if (selected) {
                s += "<TR><TD></TD><TD>\n";
                s += menuAgentList(menuInfo.agentsExpanded,
                                   menuInfo.selAgent,
                                   menuInfo.webPageKey);
                s += menuServiceList(menuInfo.servicesExpanded,
                                     menuInfo.selService,
                                     menuInfo.webPageKey);
                s += "</TD></TR>\n";
            }

            s += "</TABLE>\n";
            s += "</TD></TR>\n";
        }
        s += "</TABLE>\n";
        return s;
    }


    private String menuAgentList(boolean expanded,
                                 AgentInfo selection,
                                 String webPageKey) {
        String s = new String();
        s += "<TABLE class=\"menu\">\n";
        String urlList = containerURL(containerName) + (expanded ? "" : "/agents");
        String urlCreate = containerURL(containerName) + "/createagenttemp.html";
        String iconCreate;
        if (userInfo.canCreate()) {
            iconCreate = ax(urlCreate, "title=\"Create agent\"",
                            imgx("align=\"top\"", imageURL("create_enabled.png"), 14, 15));
        }
        else {
            iconCreate = imgx("align=\"top\"", imageURL("create_disabled.png"), 14, 15);
        }
        s += tr(
                td(a(urlList, img(imageURL(expanded ? "minus.png" : "plus.png"), 9, 9))) +
                td(a(urlList, "agent list") + "&nbsp;&nbsp;&nbsp;" + iconCreate)
                ) + "\n";
        if (expanded) {
            s += "<TR><TD></TD><TD>\n";
            s += "<TABLE class=\"menu\">\n";

            List<AgentInfo> list = agentManager.getRunningAgents();
            Iterator<AgentInfo> iter = list.iterator();
            if (!iter.hasNext()) {
                s += tr(td("&bull;") + tdx("class=\"emptyList\"", "no agents")) + "\n";
            }
            else {
                String selName = null;
                if (selection != null) {
                    selName = selection.getName();
                }
                boolean selected = false;
                while (iter.hasNext()) {
                    AgentInfo agent = iter.next();
                    if (selName != null) {
                        selected = selName.equals(agent.getName());
                    }
                    s += menuAgentItem(selected, agent, webPageKey) + "\n";
                }
            }

            s += "</TABLE>\n";
            s += "</TD></TR>\n";
        }
        s += "</TABLE>\n";
        return s;
    }


    private String menuServiceList(boolean expanded,
                                   ServiceInfo selection,
                                   String webPageKey) {
        String s = new String();
        s += "<TABLE class=\"menu\">\n";
        String urlList = containerURL(containerName) + (expanded ? "" : "/services");
        String urlCreate = containerURL(containerName) + "/createservicetemp.html";
        String iconCreate;
        if (userInfo.canCreate()) {
            iconCreate = ax(urlCreate, "title=\"Create service\"",
                            imgx("align=\"top\"", imageURL("create_enabled.png"), 14, 15));
        }
        else {
            iconCreate = imgx("align=\"top\"", imageURL("create_disabled.png"), 14, 15);
        }
        s += tr(
                td(a(urlList, img(imageURL(expanded ? "minus.png" : "plus.png"), 9, 9))) +
                td(a(urlList, "service list") + "&nbsp;&nbsp;&nbsp;" + iconCreate)
                ) + "\n";
        if (expanded) {
            s += "<TR><TD></TD><TD>\n";
            s += "<TABLE class=\"menu\">\n";

            List<ServiceInfo> list = serviceManager.getRunningServices();
            Iterator<ServiceInfo> iter = list.iterator();
            if (!iter.hasNext()) {
                s += tr(td("&bull;") + tdx("class=\"emptyList\"", "no services")) + "\n";
            }
            else {
                String selName = null;
                if (selection != null) {
                    selName = selection.getName();
                }
                boolean selected = false;
                while (iter.hasNext()) {
                    ServiceInfo service = iter.next();
                    if (selName != null) {
                        selected = selName.equals(service.getName());
                    }
                    s += menuServiceItem(selected, service, webPageKey) + "\n";
                }
            }

            s += "</TABLE>\n";
            s += "</TD></TR>\n";
        }
        s += "</TABLE>\n";
        return s;
    }


    private String menuAgentItem(boolean expanded,
                                 AgentInfo agent,
                                 String webPageKey) {
        String s = new String();
        String agentName = agent.getName();
        String urlRoot = containerURL(containerName) + "/agents/";
        String urlAgent = urlRoot + (expanded ? "" : agentName.replace('/', '_'));
        String content = a(urlAgent, agentName) + "&nbsp;";
        if (userInfo.canKill() && agent.getMainClass().length() > 0) {
            String urlKill = containerURL(containerName) + "/killagent.html?" + agentName;
            content += ax(urlKill, "title=\"Kill agent\"", img(imageURL("kill_enabled.png"), 9, 9));
        }
        else {
            content += img(imageURL("kill_disabled.png"), 9, 9);
        }
        s += tdx("class=\"agentName\"", content) + "\n";
        if (expanded) {
            PageKeyTree tree = httpsServer.getAgentKeyTree(agentName);
            s += "<TR><TD></TD><TD>\n";
            s += "<TABLE class=\"menu webPagesTree\">\n";
            if (tree != null) {
                StringTokenizer tokens = null;
                if (webPageKey != null) {
                    tokens = new StringTokenizer(webPageKey, "/");
                }
                PageKeyTree.Item treeRoot = tree.getTreeRoot();
                if (treeRoot.hasChildren()) {
                    urlRoot += agentName.replace('/', '_');
                    s += menuWebPagesTree(treeRoot, tokens, urlRoot);
                }
                else {
                    s += tr(td("&bull;") + tdx("class=\"emptyList\"", "no pages")) + "\n";
                }
            }
            else {
                s += tr(td("&bull;") + tdx("class=\"emptyList\"", "no pages")) + "\n";
            }
            s += "</TABLE>\n";
            s += "</TD></TR>\n";
        }
        s = tr(td(a(urlAgent, img(imageURL(expanded ? "minus.png" : "plus.png"), 9, 9))) + s);
        return s;
    }


    private String menuServiceItem(boolean expanded,
                                   ServiceInfo service,
                                   String webPageKey) {
        String s = new String();
        String serviceName = service.getName();
        String urlRoot = containerURL(containerName) + "/services/";
        String urlService = urlRoot + (expanded ? "" : serviceName.replace('/', '_'));
        String content = a(urlService, serviceName) + "&nbsp;";
        if (userInfo.canKill() && service.getMainClass().length() > 0) {
            String urlKill = containerURL(containerName) + "/killservice.html?" + serviceName;
            content += ax(urlKill, "title=\"Kill service\"", img(imageURL("kill_enabled.png"), 9, 9));
        }
        else {
            content += img(imageURL("kill_disabled.png"), 9, 9);
        }
        s += tdx("class=\"serviceName\"", content) + "\n";
        if (expanded) {
            PageKeyTree tree = httpsServer.getServiceKeyTree(serviceName);
            s += "<TR><TD></TD><TD>\n";
            s += "<TABLE class=\"menu webPagesTree\">\n";
            if (tree != null) {
                StringTokenizer tokens = null;
                if (webPageKey != null) {
                    tokens = new StringTokenizer(webPageKey, "/");
                }
                PageKeyTree.Item treeRoot = tree.getTreeRoot();
                if (treeRoot.hasChildren()) {
                    urlRoot += serviceName.replace('/', '_');
                    s += menuWebPagesTree(treeRoot, tokens, urlRoot);
                    s += "</TD></TR>\n";
                }
                else {
                    s += tr(td("&bull;") + tdx("class=\"emptyList\"", "no pages")) + "\n";
                }
            }
            else {
                s += tr(td("&bull;") + tdx("class=\"emptyList\"", "no pages")) + "\n";
            }
            s += "</TABLE>\n";
        }
        s = tr(td(a(urlService, img(imageURL(expanded ? "minus.png" : "plus.png"), 9, 9))) + s);
        return s;
    }


    private String menuWebPagesTree(PageKeyTree.Item root,
                                    StringTokenizer tokens,
                                    String urlRoot) {
        return menuWebPagesTree(0, root, tokens, urlRoot);
    }


    private String menuWebPagesTree(int treeLevel,
                                    PageKeyTree.Item root,
                                    StringTokenizer tokens,
                                    String urlRoot) {
        String s = new String();
        s += "<TR>";
        if (treeLevel > 0) {
            s += "<TD></TD>";
        }
        s += "<TD>\n";
        s += "<TABLE class=\"menu webPagesTree\">\n";
        String key = null;
        if (tokens != null && tokens.hasMoreTokens()) {
            key = tokens.nextToken();
        }
        Vector<PageKeyTree.Item> children = root.getChildren();
        int size = children.size();
        for (int i = 0; i < size; i++) {
            PageKeyTree.Item child = children.get(i);
            String childName = child.getName();
            boolean childIsSelected = false;
            if (key != null) {
                childIsSelected = childName.equals(key);
            }
            boolean hasChildren = child.hasChildren();
            String urlChild = urlRoot;
            String symbol = null;
            if (hasChildren) {
                if (childIsSelected) {
                    symbol = a(urlChild, img(imageURL("minus.png"), 9, 9));
                }
                else {
                    urlChild += "/" + childName;
                    symbol = a(urlChild, img(imageURL("plus.png"), 9, 9));
                }
            }
            else {
                urlChild += "/" + childName;
                symbol = "&bull;";
            }
            s += tr(td(symbol) + tdx("class=\"pageName\"", a(urlChild, childName))) + "\n";
            if (childIsSelected && hasChildren) {
                urlChild += "/" + childName;
                s += menuWebPagesTree(treeLevel + 1, child, tokens, urlChild);
            }
        }
        s += "</TABLE>\n";
        s += "</TD></TR>\n";
        return s;
    }


    public String menu(MenuInfo menuInfo) {
        String s = new String();
        s += menuContainerList(menuInfo);
        return s;
    }

}
