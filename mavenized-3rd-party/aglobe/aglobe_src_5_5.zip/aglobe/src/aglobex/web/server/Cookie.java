package aglobex.web.server;


public class Cookie {

    final public static long TIMEOUT = 600; // cookie timeout [seconds]

    protected String id;
    protected long timestamp;


    public Cookie(String id, long timestamp) {
        this.id = id;
        setTimestamp(timestamp);
    }


    public String getID() {
        return id;
    }


    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }


    public boolean isExpired(long currTime) {
        return (currTime > timestamp + TIMEOUT * 1000);
    }

}
