package aglobex.web.server;

import java.util.*;


public class PageKeyTree {

    public class Item {
        protected String name;
        protected WebRequestListener listener;
        protected Vector<Item> children;

        public Item(String name, WebRequestListener listener) {
            this.name = name;
            this.listener = listener;
            children = new Vector<Item>();
        }

        public String getName() {
            return name;
        }

        public WebRequestListener getListener() {
            return listener;
        }

        public void setListener(WebRequestListener listener) {
            this.listener = listener;
        }

        public boolean hasChildren() {
            return children.size() > 0;
        }

        public Vector<Item> getChildren() {
            return children;
        }

        public boolean addChild(Item item, boolean sorted) {
            String itemName = item.getName();
            if (getChild(itemName) != null) {
                return false;
            }
            if (sorted) {
                int size = children.size();
                for (int i = 0; i < size; i++) {
                    Item c = children.get(i);
                    if (itemName.compareToIgnoreCase(c.getName()) < 0) {
                        children.add(i, item);
                        return true;
                    }
                }
            }
            children.add(item);
            return true;
        }

        public boolean removeChild(String name) {
            int size = children.size();
            for (int i = 0; i < size; i++) {
                Item item = children.get(i);
                if (name.equals(item.getName())) {
                    children.remove(i);
                    return true;
                }
            }
            return false;
        }

        public Item getChild(String name) {
            int size = children.size();
            for (int i = 0; i < size; i++) {
                Item item = children.get(i);
                if (name.equals(item.getName())) {
                    return item;
                }
            }
            return null;
        }
    }


    protected Item tree;
    protected HashMap<String,WebRequestListener> map;


    public PageKeyTree() {
        tree = new Item("", null);
        map = new HashMap<String,WebRequestListener>();
    }


    public boolean add(String key, WebRequestListener listener, boolean sorted) {
        StringTokenizer st = new StringTokenizer(key, "/");
        if (!st.hasMoreTokens()) {
            return false;
        }
        Item item = tree;
        while (st.hasMoreTokens()) {
            String name = st.nextToken();
            boolean isLast = st.hasMoreTokens();
            Item child = item.getChild(name);
            if (child == null) {
                if (isLast) {
                    child = new Item(name, listener);
                }
                else {
                    child = new Item(name, null);
                }
                item.addChild(child, sorted);
            }
            else {
                if (isLast) {
                    child.setListener(listener);
                }
            }
            item = child;
        }
        map.put(key, listener);
        return true;
    }


    public boolean remove(String key) {
        StringTokenizer st = new StringTokenizer(key, "/");
        if (!st.hasMoreTokens()) {
            return false;
        }
        Item item = tree;
        while (st.hasMoreTokens()) {
            String name = st.nextToken();
            boolean isLast = !st.hasMoreTokens();
            Item child = item.getChild(name);
            if (child == null) {
                return false;
            }
            if (isLast) {
                if (child.hasChildren()) {
                    return false;
                }
                item.removeChild(name);
            }
            else {
                item = child;
            }
        }
        map.remove(key);
        return true;
    }


    public WebRequestListener getListener(String key) {
        return map.get(key);
    }


    public Item getTreeRoot() {
        return tree;
    }


    public void print() {
        print(tree, 0);
        System.out.println();
    }


    protected void print(Item item, int offset) {
        for (int i = 0; i < offset; i++) {
            System.out.print(" ");
        }
        System.out.println(item.getName() + ": " + item.getListener());
        Vector<Item> children = item.getChildren();
        for (int i = 0; i < children.size(); i++) {
            print(children.get(i), offset + 3);
        }
    }
}
