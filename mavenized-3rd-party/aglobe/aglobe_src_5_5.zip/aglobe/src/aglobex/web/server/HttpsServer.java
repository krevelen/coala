package aglobex.web.server;


import java.net.ServerSocket;
import java.net.Socket;
import java.security.KeyStore;
import java.util.HashMap;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;

import javax.net.ServerSocketFactory;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocket;

import aglobe.container.service.ShellOwner;
import aglobe.container.transport.Address;
import aglobe.platform.thread.AglobeThreadPool;

 
public class HttpsServer implements Runnable {

    protected static final int HTTPS_PORT = 443;
    protected static final String keystore = "serverkeys.bin";
    protected static final char keystorepass[] = "password1".toCharArray();
    protected static final char keypassword[] = "password2".toCharArray();

    protected WebServerService webServerService;
    protected Random random;
    protected Vector<UserInfo> activeUsers;

    protected HashMap<String,PageKeyTree> agentWebPages;
    protected HashMap<String,PageKeyTree> serviceWebPages;

    protected HashMap<String,ImageKeyMap> agentImages;
    protected HashMap<String,ImageKeyMap> serviceImages;

    protected long webImageCounter;
    protected HashMap<String,ImageRequestListener> webImages;

    public HttpsServer(WebServerService webServerService) {
        this.webServerService = webServerService;
        random = new Random();
        activeUsers = new Vector<UserInfo>();

        agentWebPages = new HashMap<String,PageKeyTree>();
        serviceWebPages = new HashMap<String,PageKeyTree>();

        agentImages = new HashMap<String,ImageKeyMap>();
        serviceImages = new HashMap<String,ImageKeyMap>();

        new Timer().scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                synchronized (activeUsers) {
                    long currTime = System.currentTimeMillis();
                    for (int i = activeUsers.size() - 1; i >= 0; i--) {
                        Cookie cookie = activeUsers.get(i).getCookie();
                        if (cookie.isExpired(currTime)) {
                            activeUsers.remove(i);
                        }
                    }
                }
            }
        }, 0, 5000);

        Thread serverThread = AglobeThreadPool.getThread(this, "WebServerThread");
        serverThread.start();
    }


    public WebServerService getWebServerService() {
        return webServerService;
    }


    public ServerSocket getServer() throws Exception {
        KeyStore ks = KeyStore.getInstance("JKS");
        ks.load(WebServerService.class.getResourceAsStream(keystore),
                keystorepass);
        KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
        kmf.init(ks, keypassword);
        SSLContext sslcontext = SSLContext.getInstance("SSLv3");
        sslcontext.init(kmf.getKeyManagers(), null, null);
        ServerSocketFactory ssf = sslcontext.getServerSocketFactory();
        SSLServerSocket serversocket = (SSLServerSocket)
                                       ssf.createServerSocket(HTTPS_PORT);
        return serversocket;
    }


    public void registerUser(UserInfo userInfo) {
        String id = "SID=" + Math.abs(random.nextLong());
        Cookie cookie = new Cookie(id, System.currentTimeMillis());
        userInfo.setCookie(cookie);
        String userName = userInfo.getName();
        synchronized (activeUsers) {
            for (int i = activeUsers.size() - 1; i >= 0; i--) {
                if (activeUsers.get(i).getName().equals(userName)) {
                    activeUsers.remove(i);
                    break;
                }
            }
            activeUsers.add(userInfo);
        }
    }


    public boolean deregisterUser(String cookieID) {
        synchronized (activeUsers) {
            for (int i = activeUsers.size() - 1; i >= 0; i--) {
                Cookie cookie = activeUsers.get(i).getCookie();
                if (cookie.getID().equals(cookieID)) {
                    activeUsers.remove(i);
                    return true;
                }
            }
            return false;
        }
    }


    public UserInfo getUserInfo(String cookieID) {
        if (cookieID == null) {
            return null;
        }
        synchronized (activeUsers) {
            for (int i = activeUsers.size() - 1; i >= 0; i--) {
                UserInfo userInfo = activeUsers.get(i);
                Cookie cookie = userInfo.getCookie();
                if (cookie.getID().equals(cookieID)) {
                    cookie.setTimestamp(System.currentTimeMillis());
                    return userInfo;
                }
            }
            return null;
        }
    }


    public boolean registerWebPage(ShellOwner owner,
                                   String key, boolean sorted,
                                   WebRequestListener listener) {
        Address address = owner.getAddress();
        if (address == null) {
            return false;
        }

        HashMap<String,PageKeyTree> map;
        if (address.isAgent()) {
            map = agentWebPages;
        }
        else {
            if (address.isService()) {
                map = serviceWebPages;
            }
            else {
                return false;
            }
        }

        String name = address.getName();
        PageKeyTree tree = map.get(name);
        if (tree == null) {
            tree = new PageKeyTree();
            map.put(name, tree);
        }
        tree.remove(key);
        return tree.add(key, listener, sorted);
    }


    public boolean deregisterWebPage(ShellOwner owner, String key) {
        Address address = owner.getAddress();
        if (address == null) {
            return false;
        }

        HashMap<String,PageKeyTree> map;
        if (address.isAgent()) {
            map = agentWebPages;
        }
        else {
            if (address.isService()) {
                map = serviceWebPages;
            }
            else {
                return false;
            }
        }

        PageKeyTree keytree = map.get(address.getName());
        if (keytree == null) {
            return false;
        }
        return keytree.remove(key);
    }


    public PageKeyTree getAgentKeyTree(String agentName) {
        return agentWebPages.get(agentName);
    }


    public PageKeyTree getServiceKeyTree(String serviceName) {
        return serviceWebPages.get(serviceName);
    }


    public String registerImage(ShellOwner owner,
                                ImageRequestListener listener) {
        Address address = owner.getAddress();
        if (address == null) {
            return null;
        }

        HashMap<String,ImageKeyMap> map;
        if (address.isAgent()) {
            map = agentImages;
        }
        else {
            if (address.isService()) {
                map = serviceImages;
            }
            else {
                return null;
            }
        }

        String name = address.getName();
        ImageKeyMap keymap = map.get(name);
        if (keymap == null) {
            keymap = new ImageKeyMap();
            map.put(name, keymap);
        }
        String key = keymap.generateKey();
        keymap.add(key, listener);
        return key;
    }


    public boolean deregisterImage(ShellOwner owner, String key) {
        Address address = owner.getAddress();
        if (address == null) {
            return false;
        }

        HashMap<String,ImageKeyMap> map;
        if (address.isAgent()) {
            map = agentImages;
        }
        else {
            if (address.isService()) {
                map = serviceImages;
            }
            else {
                return false;
            }
        }

        ImageKeyMap keymap = map.get(address.getName());
        if (keymap == null) {
            return false;
        }
        return keymap.remove(key);
    }


    public ImageRequestListener getAgentImageListener(String agentName, String key) {
        ImageKeyMap keymap = agentImages.get(agentName);
        if (keymap == null) {
            return null;
        }
        return keymap.getListener(key);
    }


    public ImageRequestListener getServiceImageListener(String serviceName, String key) {
        ImageKeyMap keymap = serviceImages.get(serviceName);
        if (keymap == null) {
            return null;
        }
        return keymap.getListener(key);
    }


    @Override
	public void run() {
        ServerSocket listen;
        try {
            listen = getServer();
            while (true) {
                Socket client = listen.accept();
                AglobeThreadPool.getThread(new ProcessConnection(this, client),"Process connection thread");
            }
        } catch (Exception ex) {
            System.out.println("Exception:" + ex.getMessage());
        }
    }
}
