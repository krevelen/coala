package aglobex.web.server;


public class UserInfo {

    protected String name;
    protected Cookie cookie;
    protected boolean canCreate;
    protected boolean canKill;


    public UserInfo(String name,
                    boolean canCreate, boolean canKill) {
        this.name = name;
        this.cookie = null;
        this.canCreate = canCreate;
        this.canKill = canKill;
    }


    public String getName() {
        return name;
    }


    public void setCookie(Cookie cookie) {
        this.cookie = cookie;
    }


    public Cookie getCookie() {
        return cookie;
    }


    public boolean canCreate() {
        return canCreate;
    }


    public boolean canKill() {
        return canKill;
    }

}
