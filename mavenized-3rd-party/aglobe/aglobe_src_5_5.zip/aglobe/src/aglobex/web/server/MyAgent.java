package aglobex.web.server;

import java.io.*;
import java.util.*;

import aglobe.container.agent.*;
import aglobe.ontology.*;


public class MyAgent extends Agent {

    private static final long serialVersionUID = 5381302464551368528L;

    @Override
    public void init(AgentInfo a, int initState) {


    }


    @Override
	public void handleIncomingMessage(Message m) {
        m.release();
    }
}


class MyWebPage implements WebRequestListener {

    private String content;

    public MyWebPage(String content) {
        this.content = content;
    }

    @Override
	public String getWebPageContent(String key, Map<String,String> params) {
        return content;
    }

    @Override
	public int refreshRate() {
        return 0;
    }
}


class MyImage implements ImageRequestListener {

    protected String filename;

    MyImage(String filename) {
        this.filename = filename;
    }

    @Override
	public InputStream getImagePNGContent(String key) {
        try {
            return new FileInputStream(filename);
        } catch (FileNotFoundException ex) {
            return null;
        }
    }
}
