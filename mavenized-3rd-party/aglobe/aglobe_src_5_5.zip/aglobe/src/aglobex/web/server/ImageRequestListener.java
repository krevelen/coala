package aglobex.web.server;

import java.io.*;


public interface ImageRequestListener {
    public InputStream getImagePNGContent(String key);
}
