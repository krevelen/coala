package aglobex.web.server;

import java.util.*;


public class ImageKeyMap {

    protected HashMap<String,ImageRequestListener> map;
    protected long keyMax;


    public ImageKeyMap() {
        map = new HashMap<String,ImageRequestListener>();
        keyMax = 0;
    }


    public String generateKey() {
        keyMax++;
        return Long.toString(keyMax) + ".png";
    }


    public boolean add(String key, ImageRequestListener listener) {
        map.put(key, listener);
        return true;
    }


    public boolean remove(String key) {
        map.remove(key);
        return true;
    }


    public ImageRequestListener getListener(String key) {
        return map.get(key);
    }
}
