package aglobex.protocol.queryref;

import aglobe.container.agent.*;
import aglobe.container.transport.*;
import aglobe.ontology.*;

/**
 * Initiator part of QueryRef protocol.
 *
 * Does not implement canceling of started protocol - can be implemented.
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: ATG, FEE CTU</p>
 * @author Jan Tozicka
 * @version 1.0
 */

abstract public class QueryRefInitiatorTask extends aglobex.protocol.query.QueryInitiatorTask {
    public static int DEFAULT_TIMEOUT = 1000;

    /** content of the query*/
    protected Object queryContent;

    public boolean metaWillRefuse;


    /**
     * starts fipa query-ref protocol.
     * @param owner owner of this task
     * @param participant Address of participant in this protocol - receiver of this query
     * @param content the query content
     */
    @Deprecated
    public QueryRefInitiatorTask(CMAgent owner, Address participant,
                                 Object content) {
        this(owner, participant, content, DEFAULT_TIMEOUT);
    }

    public QueryRefInitiatorTask(CMAgent owner, Address participant,
                                 Object content, boolean autostart) {
        this(owner, participant, content, DEFAULT_TIMEOUT, autostart);
    }

    @Deprecated
    public QueryRefInitiatorTask(CMAgent owner, Address participant,
            Object content, String action) {
        this(owner, participant, content, DEFAULT_TIMEOUT, action);
    }

    // petr
    public QueryRefInitiatorTask(CMAgent owner, Address participant,
                                 Object content, int timeout, boolean autostart, boolean willRef) {
      super(owner, participant, content, timeout, MessageConstants.QUERY_REF, false);
      this.queryContent = content;
      metaWillRefuse = willRef;
      if (autostart) {
        start();
      }

    }

  /**
   * starts fipa query-ref protocol.
   *
   * @param owner owner of this task
   * @param participant Address of participant in this protocol - receiver of
   *   this query
   * @param content the query content
   * @param timeout int
   */
  public QueryRefInitiatorTask(CMAgent owner, Address participant,
                                 Object content, int timeout) {
        this(owner, participant, content, timeout, true);
    }

   public QueryRefInitiatorTask(CMAgent owner, Address participant,
           Object content, int timeout, String action) {
       this(owner, participant, content, timeout, false, action);
   }

   public QueryRefInitiatorTask(CMAgent owner, Address participant,
           Object content, int timeout, boolean autostart, String action) {
       super(owner, participant, content, timeout, MessageConstants.QUERY, true, action);
       this.queryContent = content;
       if (autostart) {
           start();
       }
   }
    public QueryRefInitiatorTask(CMAgent owner, Address participant,
                                 Object content, int timeout, boolean autostart) {
        super(owner, participant, content, timeout, MessageConstants.QUERY_REF, false);
        this.queryContent = content;
        if (autostart) {
          start();
        }
    }

    @Override
	public void handleIncomingMessage(Message msg) {
        String performative = msg.getPerformative();
        if (!MessageConstants.QUERY.equalsIgnoreCase(msg.getProtocol())) {
            // bad protocol ...
            notUnderstood(msg);
        } else {
            if (MessageConstants.INFORM_RESULT.equalsIgnoreCase(performative)) {
                informResult(msg.getContent());
            } else if (MessageConstants.NOT_UNDERSTOOD.equalsIgnoreCase(performative)) {
                notUnderstoodReceived(msg);
            } else {
                String stringContent = new String();
                if (msg.getContent()!=null)
                    stringContent = msg.getContent() instanceof String ? (String) msg.getContent() : msg.getContent().toString();
                if (MessageConstants.FAILURE.equalsIgnoreCase(performative)) {
                    failure(stringContent);
                } else if (MessageConstants.AGREE.equalsIgnoreCase(performative)) {
                    queryAgreed();
                } else if (MessageConstants.REFUSE.equalsIgnoreCase(performative)) {
                    queryRefused();
                } else {
                    notUnderstood(msg);
                }
            }
        }
        msg.release();
    }

    /**
     * notUnderstoodReceived -- called when NOT_UNDERSTOOD arrives
     * @param msg
     */
    protected void notUnderstoodReceived(Message msg) {
    }

    /**
   * Is called when inform-result message comes with result.
   *
   * @param result Object
   */
  abstract protected void informResult(Object result);
}
