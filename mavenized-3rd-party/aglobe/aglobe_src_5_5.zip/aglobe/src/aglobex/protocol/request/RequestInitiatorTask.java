package aglobex.protocol.request;

import aglobe.container.task.*;
import aglobe.ontology.*;
import aglobe.container.transport.*;

/**
 * Initiator part of Request protocol.
 *
 * Does not implement canceling of started protocol - can be implemented.
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: ATG, FEE CTU</p>
 * @author Jan Tozicka
 * @version 1.0
 */

abstract public class RequestInitiatorTask extends TimeoutTask {

    /** Agent from which the service was requested */
    protected Address participant;
    /** Content of the request message */
    protected Object content;
    /** Agent to which the task belongs */
    protected ConversationUnit owner;
    /** default timeout to use for waiting for responses */
    private static final int DEFAULT_TIMEOUT = 10000;

    public static final String TIMEOUT_TEXT = "TIMEOUT";

    /**
     * starts fipa request protocol. This constructor sends the Request message.
     * @param owner owner of this task
     * @param participant Address of participant in this protocol - receiver of this request
     * @param content the request content
     */
    public RequestInitiatorTask(ConversationUnit owner, Address participant, Object content) {
        this(owner, participant, content, true, false);
    }

    /**
     * starts fipa request protocol.
     * @param owner owner of this task
     * @param participant Address of participant in this protocol - receiver of this request
     * @param content the request content
     * @param start if true, sends the request message. If not, user must call start method later.(in inherited constructor)
     */
    public RequestInitiatorTask(ConversationUnit owner, Address participant, Object content, boolean start) {
        this(owner, participant, content, start, false);
    }

    /**
     * starts fipa request protocol.
     * @param owner owner of this task
     * @param participant Address of participant in this protocol - receiver of this request
     * @param content the request content
     * @param start if true, sends the request message. If not, user must call start method later.(in inherited constructor)
     * @param messageAsReference boolean
     */
    public RequestInitiatorTask(ConversationUnit owner, Address participant, Object content, boolean start, boolean messageAsReference) {
        super(owner, DEFAULT_TIMEOUT, messageAsReference);
        this.participant = participant;
        this.content = content;
        this.owner = owner;
        if (start) {
          start();
        }
    }
    /**
     * Starts the task execution by sending the first (REQUEST) message.
     */
    public void start()
    {
        Message requestMsg = Message.newInstance(MessageConstants.REQUEST,  owner.getConversationUnit().getConversationUnit().getAddress(), participant);
        requestMsg.setProtocol(MessageConstants.REQUEST);
        requestMsg.setContent(content);

        try {
            sendMessage(requestMsg);
        } catch (InvisibleContainerException ex) {
            owner.getConversationUnit().getConversationUnit().logSevere("Cannot send request message: "+ex);
            cancelTask();
        }
        requestMsg.release();
    }

    @Override
	public void handleIncomingMessage(Message msg) {
        String performative = msg.getPerformative();
        if (!MessageConstants.REQUEST.equalsIgnoreCase(msg.getProtocol())) {
            // bad protocol ...
            notUnderstood(msg);
        } else if (MessageConstants.INFORM_DONE.equalsIgnoreCase(performative)) {
            informDone();
        } else if (MessageConstants.INFORM_RESULT.equalsIgnoreCase(performative)) {
            informResult(msg.getContent());
        } else if (MessageConstants.NOT_UNDERSTOOD.equalsIgnoreCase(performative)) {
        } else if (MessageConstants.FAILURE.equalsIgnoreCase(performative)) {
            String stringContent = msg.getContent() instanceof String ?
           (String) msg.getContent() : msg.getContent().toString();
            failure(msg.getContent(),stringContent);
        } else if (MessageConstants.AGREE.equalsIgnoreCase(performative)) {
            requestAgreed();
        } else if (MessageConstants.REFUSE.equalsIgnoreCase(performative)) {
            requestRefused();
        } else {
            notUnderstood(msg);
        }
        msg.release();
    }

    /**
     * Is called when agree message comes as reply to request.
     */
    protected void requestAgreed() {
    }

    /**
     * Is called when refuse message comes as reply to request.
     */
    protected void requestRefused() {
    }

    /**
     * Timeout is considered as a failure to execute the task. Don't forget to cancel the task when appropriate to avoid the timeouts.
     */
    @Override
    protected void timeout()
    {
        // we will treat timeout as a failure.
        failure(null,TIMEOUT_TEXT);
    }

    /**
     * Is called when failure message comes as reply to request.
     * The reason is get from the message content.
     * @param result
     * @param reason message content.
     */
    protected void failure(Object result, String reason) {
    }

    /**
     * Is called when inform-done message comes as reply to request.
     */
    abstract protected void informDone();

    /**
     * Is called when inform-result message comes as reply to request.
     * The result is get from the message content.
     * @param result message content.
     */
    abstract protected void informResult(Object result);

  /**
   * Replies to <code>msg</code> with not-understood message
   *
   * @param msg Message
   */
  protected void notUnderstood(Message msg) {
      sendNotUnderstood(msg,null);
    }

}
