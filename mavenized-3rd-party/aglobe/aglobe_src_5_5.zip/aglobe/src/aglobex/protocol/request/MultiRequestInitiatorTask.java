package aglobex.protocol.request;

import aglobe.container.task.*;
import aglobe.ontology.*;
import aglobe.container.agent.*;
import aglobe.container.transport.*;
import java.util.*;

/**
 * Initiator part of Request protocol. Requests are sent sequentially.
 *
 * Does not implement canceling of started protocol - can be implemented.
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: ATG, FEE CTU</p>
 * @author Jan Tozicka
 * @version 1.0
 */

abstract public class MultiRequestInitiatorTask extends Task {

    protected Collection<Address> participants;
    private Iterator<Address> participantsIterator;
    private Object content;
    private Address owner;
    private final CMAgent ownerAgent;

    /**
     * starts fipa request protocol. Sends next request when previous is refused.
     * @param owner owner of this task
     * @param participants List of Address of participants in this protocol - receivers of this request
     * @param content the request content
     */
    @Deprecated
    public MultiRequestInitiatorTask(CMAgent owner, Collection<Address> participants,
                                     Object content) {
        this(owner, participants, content, true);
    }

    public MultiRequestInitiatorTask(CMAgent owner, Collection<Address> participants,
            Object content, boolean autostart) {
        this(owner, participants, content, autostart, false);
    }


    public MultiRequestInitiatorTask(CMAgent owner, Collection<Address> participants,
                                     Object content, boolean autostart, boolean messageAsReference) {
        super(owner, messageAsReference);

        this.participants = participants;
        this.content = content;
        this.owner = owner.getAddress();
        this.ownerAgent = owner;

        if (autostart) {
            start();
        }
    }

    public void start() {
        participantsIterator = participants.iterator();

        sendNextRequest();
    }

    private void sendNextRequest() {
        if (!participantsIterator.hasNext()) {
            allRefused();
            return;
        }

        Address participant = participantsIterator.next();

        Message requestMsg = Message.newInstance(MessageConstants.REQUEST,
                                         owner, participant);
        requestMsg.setProtocol(MessageConstants.REQUEST);
        requestMsg.setContent(content);

        try {
            sendMessage(requestMsg);
        } catch (InvisibleContainerException ex) {
            ownerAgent.logSevere("Cannot send request message: "+ex+"\nparticipant will be removed.");
            participantsIterator.remove();
        }
        requestMsg.release();
    }

    /**
     * allRefused
     */
    protected abstract void allRefused();

    @Override
	public void handleIncomingMessage(Message msg) {
        String performative = msg.getPerformative();
        if (!MessageConstants.REQUEST.equalsIgnoreCase(msg.getProtocol())) {
            // bad protocol ...
            notUnderstood(msg);
        } else if (MessageConstants.INFORM_DONE.equalsIgnoreCase(performative)) {
            informDone(msg.getSender());
        } else if (MessageConstants.INFORM_RESULT.equalsIgnoreCase(performative)) {
            informResult(msg.getSender(), msg.getContent());
        } else if (MessageConstants.NOT_UNDERSTOOD.equalsIgnoreCase(
            performative)) {
        } else {
            String stringContent = msg.getContent() instanceof String ?
                (String) msg.getContent() : msg.getContent().toString();
            if (MessageConstants.FAILURE.equalsIgnoreCase(performative)) {
                failure(stringContent);
            } else if (MessageConstants.AGREE.equalsIgnoreCase(performative)) {
                requestAgreed(msg.getSender());
            } else if (MessageConstants.REFUSE.equalsIgnoreCase(performative)) {
                requestRefused();
            } else {
                notUnderstood(msg);
            }
        }
        msg.release();
    }

    /**
     * Is called when agree message comes as reply to request.
     *
     * @param participant Address
     */
    protected void requestAgreed(Address participant) {
    }

    /**
     * Is called when refuse message comes as reply to request.
     */
    protected void requestRefused() {
        sendNextRequest();
    }

    /**
     * Is called when failure message comes as reply to request.
     * The reason is get from the message content.
     * @param reason message content.
     */
    protected void failure(String reason) {
    }

    /**
     * Is called when inform-done message comes as reply to request.
     *
     * @param participant Address
     */
    abstract protected void informDone(Address participant);

    /**
     * Is called when inform-result message comes as reply to request. The
     * result is get from the message content.
     *
     * @param participant Address
     * @param result message content.
     */
    abstract protected void informResult(Address participant, Object result);

    /**
     * Replies to <code>msg</code> with not-understood message
     *
     * @param msg Message
     */
    protected void notUnderstood(Message msg) {
        sendNotUnderstood(msg,null);
    }

}
