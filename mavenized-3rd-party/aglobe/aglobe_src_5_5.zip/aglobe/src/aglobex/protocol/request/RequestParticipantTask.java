package aglobex.protocol.request;

import aglobe.container.task.*;
import aglobe.ontology.*;
import aglobe.container.transport.*;

/**
 * Participant part of Request protocol. The participant is agent offering requested service.
 *
 * Does not implement canceling of started protocol - can be implemented.
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: ATG, FEE CTU</p>
 * @author Jan Tozicka
 * @version 1.0
 */

abstract public class RequestParticipantTask extends Task {

    protected Message requestMessage;

    private final ConversationUnit owner;

    /**
     * starts fipa request protocol.
     * @param owner owner of this task - needed for sending messages
     * @param requestMessage the received request message
     */
    public RequestParticipantTask(ConversationUnit owner, Message requestMessage) {
        this(owner, requestMessage, true, false);
    }

    /**
     * starts fipa request protocol. If auto process is <code>false</code> processRequest method is not called.
     * @param owner owner of this task - needed for sending messages
     * @param requestMessage the received request message
     * @param autostart boolean
     */
    public RequestParticipantTask(ConversationUnit owner, Message requestMessage, boolean autostart) {
        this(owner, requestMessage, autostart, false);
    }

    /**
     * starts fipa request protocol. If auto process is <code>false</code> processRequest method is not called.
     * @param owner owner of this task - needed for sending messages
     * @param requestMessage the received request message
     * @param autostart boolean
     * @param messageAsReference boolean
     */
    public RequestParticipantTask(ConversationUnit owner, Message requestMessage, boolean autostart, boolean messageAsReference) {
        super(owner, messageAsReference);
        assert (requestMessage != null);
        this.requestMessage = requestMessage;
        this.owner = owner;

        if (!MessageConstants.REQUEST.equalsIgnoreCase(requestMessage.
                getProtocol()) ||
                !MessageConstants.REQUEST.equalsIgnoreCase(requestMessage.
                        getPerformative())) {
            throw new IllegalArgumentException(requestMessage.getProtocol() +
                    "." +
                    requestMessage.getPerformative() +
                    " is not good subscribe combination...");
        }

        if (autostart) {
            owner.getConversationUnit().getConversationUnit().addEvent(new Runnable() {
                @Override
				public void run() {
                    start();
                }
            });
        }
    }

    public void start() {
        processRequest(requestMessage);
    }

    @Override
	public void handleIncomingMessage(Message msg) {
        notUnderstood(msg);
        msg.release();
    }

    /**
     * Replies to <code>msg</code> with not-understood message
     *
     * @param msg Message
     */
    protected void notUnderstood(Message msg) {
        sendNotUnderstood(msg,null);
    }

    /**
     * Is called when request comes. Can call agree or refuse methods to reply to
     * this message.
     *
     * @param requestMessage Message
     */
    abstract protected void processRequest(Message requestMessage);

    /**
     * Replies to <code>requestMessage</code> with agree message
     */
    protected void agree() {
        Message re = requestMessage.getReply();
        re.setPerformative(MessageConstants.AGREE);
        re.setContent(requestMessage.getContent());
        try {
            sendMessage(re);
        } catch (InvisibleContainerException ex) {
            owner.getConversationUnit().getConversationUnit().logSevere("Cannot send request message: "+ex);
        }
        re.release();
    }

    /**
     * Replies to <code>requestMessage</code> with refuse message
     */
    protected void refuse() {
        Message re = requestMessage.getReply();
        re.setPerformative(MessageConstants.REFUSE);
        re.setContent(requestMessage.getContent());
        try {
            sendMessage(re);
        } catch (InvisibleContainerException ex) {
            owner.getConversationUnit().getConversationUnit().logSevere("Cannot send refuse message: "+ex);
        }
        re.release();
        cancelTask();
    }

    /**
     * use to send inform-done message
     */
    protected void informDone() {
        Message re = requestMessage.getReply();
        re.setPerformative(MessageConstants.INFORM_DONE);
        re.setContent(requestMessage.getContent());
        try {
            sendMessage(re);
            cancelTask();
        } catch (InvisibleContainerException ex) {
            owner.getConversationUnit().getConversationUnit().logSevere("Cannot send inform done message: "+ex);
        }
        re.release();
    }

    /**
     * use to send inform-result message. the parameter specifies the result of the operation
     * @param result result of the request
     */
    protected void informResult(Object result) {
        Message re = requestMessage.getReply();
        re.setPerformative(MessageConstants.INFORM_RESULT);
        re.setContent(result);
        try {
            sendMessage(re);
            cancelTask();
        } catch (InvisibleContainerException ex) {
            owner.getConversationUnit().getConversationUnit().logSevere("Cannot send inform result message: "+ex);
        }
        re.release();
    }

    /**
     * use to send failure message. the parameter specifies the reason of failure
     * @param result result of failure
     * @param reason reason of failure
     */
    protected void failure(Object result, String reason) {
        Message re = requestMessage.getReply();
        re.setPerformative(MessageConstants.FAILURE);
        re.setContent(result);
        re.setReason(reason);
        try {
            sendMessage(re);
        } catch (InvisibleContainerException ex) {
            owner.getConversationUnit().getConversationUnit().logSevere("Cannot send failure message: "+ex);
        }
        re.release();
        cancelTask();
    }

    /**
     * use to send failure message. the parameter specifies the reason of failure
     * @param result result of failure
     */
    protected void failure(Object result) {
        Message re = requestMessage.getReply();
        re.setPerformative(MessageConstants.FAILURE);
        re.setContent(result);
        try {
            sendMessage(re);
        } catch (InvisibleContainerException ex) {
            owner.getConversationUnit().getConversationUnit().logSevere("Cannot send failure message: "+ex);
        }
        re.release();
        cancelTask();
    }

    /**
     * This method cancels this task.
     *
     */
    @Override
    public void cancelTask() {

        if (requestMessage != null) {
            requestMessage.release();
            requestMessage = null;
        }
        super.cancelTask();
    }
}
