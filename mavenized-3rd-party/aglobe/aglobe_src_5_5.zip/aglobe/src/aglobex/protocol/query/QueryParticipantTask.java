package aglobex.protocol.query;

import aglobe.container.task.*;
import aglobe.ontology.*;
import aglobe.container.agent.*;
import aglobe.container.transport.*;

/**
 * Participant part of Query protocol. The participant is agent knowing queried info.
 * Abstract class is used by QueryIf and QueryRef tasks.
 *
 * Does not implement cancelling of started protocol - can be implemented.
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: ATG, FEE CTU</p>
 * @author Jan Tozicka
 * @version 1.0
 */

abstract public class QueryParticipantTask extends Task {

    protected Message queryMessage;

    protected final CMAgent owner;

    /**
     * starts fipa query protocol.
     * @param owner owner of this task - needed for sending messages
     * @param queryMessage the recieved query message
     */
    @Deprecated
    public QueryParticipantTask(CMAgent owner, Message queryMessage) {
        this(owner, queryMessage, true);
    }

  /**
   * starts fipa queryRef protocol. If autoprocess is <code>false</code>
   * processRequest method is not called.
   *
   * @param owner owner of this task - needed for sending messages
   * @param queryMessage the recieved query message
   * @param autoprocess boolean
   */
  public QueryParticipantTask(CMAgent owner, Message queryMessage,
                                boolean autoprocess) {
	  this(owner, queryMessage, autoprocess, false);
    }
  
  /**
   * starts fipa queryRef protocol. If autoprocess is <code>false</code>
   * processRequest method is not called.
   *
   * @param owner owner of this task - needed for sending messages
   * @param queryMessage the recieved query message
   * @param autoprocess boolean
   * @param messageAsReference boolean
   */
  public QueryParticipantTask(CMAgent owner, Message queryMessage,
          boolean autoprocess, boolean messageAsReference) {
      super(owner, messageAsReference);
      this.queryMessage = queryMessage;
      this.owner = owner;

      if (!MessageConstants.QUERY.equalsIgnoreCase(queryMessage.getProtocol())) {
          throw new IllegalArgumentException(queryMessage.getProtocol() + "." +
                                             queryMessage.getPerformative() +
                                             " is not good subscribe combination...");
      }

      if (autoprocess) {
          owner.addEvent(new Runnable() {
              @Override
			public void run() {
                  start();
              }
          });
      }
	  
  }

    public void start() {
        processQuery(queryMessage);
    }

    @Override
	public void handleIncomingMessage(Message msg) {
        notUnderstood(msg);
        msg.release();
    }

    /**
     * Replies to <code>msg</code> with not-understood message
     * @param msg Message, that ha not been understood.
     */
    protected void notUnderstood(Message msg) {
        sendNotUnderstood(msg,null);
    }

    /**
     * Is called when query comes.
     * Can call agree or refuse methods to reply to this message.
     * @param queryMessage incomming query message
     */
    abstract protected void processQuery(Message queryMessage);

    /**
     * Replies to <code>queryMessage</code> with agree message
     */
    protected void agree() {
        Message re = queryMessage.getReply();
        re.setPerformative(MessageConstants.AGREE);
        re.setContent(queryMessage.getContent());
        try {
            sendMessage(re);
        } catch (InvisibleContainerException ex) {
            owner.logSevere("Cannot send agree message: "+ex);
        }
        re.release();
    }

    /**
     * Replies to <code>queryMessage</code> with refuse message
     */
    protected void refuse() {
        Message re = queryMessage.getReply();
        re.setPerformative(MessageConstants.REFUSE);
        re.setContent(queryMessage.getContent());
        try {
            sendMessage(re);
        } catch (InvisibleContainerException ex) {
            owner.logSevere("Cannot send refuse message: "+ex);
        }
        re.release();
    }

    /**
     * use to send failure message. the parameter specifies the reason of failure
     * @param reason reason of failure
     */
    protected void failure(Object reason) {
        Message re = queryMessage.getReply();
        re.setPerformative(MessageConstants.FAILURE);
        re.setContent(reason);
        try {
            sendMessage(re);
        } catch (InvisibleContainerException ex) {
            owner.logSevere("Cannot send failure message: "+ex);
        }
        re.release();
    }

    /**
     * This method canceles this task.
     *
     */
    @Override
    public void cancelTask() {
        if (queryMessage != null) {
            queryMessage.release();
            queryMessage = null;
        }
        super.cancelTask();
    }

}
