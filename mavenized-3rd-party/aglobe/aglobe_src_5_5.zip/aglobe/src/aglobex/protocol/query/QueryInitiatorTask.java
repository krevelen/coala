package aglobex.protocol.query;

import aglobe.container.task.*;
import aglobe.ontology.*;
import aglobe.container.agent.*;
import aglobe.container.transport.*;

/**
 * Initiator part of Query protocol. Abstract class for QueryIf and QueryRef
 *
 * Does not implement cancelling of started protocol - can be implemented.
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: ATG, FEE CTU</p>
 * @author Jan Tozicka
 * @version 1.0
 */

abstract public class QueryInitiatorTask extends TimeoutTask {
    public static int DEFAULT_TIMEOUT = 1000;
    protected Address participant;
    protected Message queryMsg;
    /**
     * starts fipa query-if protocol.
     *
     * @param owner owner of this task
     * @param participant Address of participant in this protocol - reciever of
     *   this query
     * @param content the query content
     * @param performative String
     */
    @Deprecated
    public QueryInitiatorTask(CMAgent owner, Address participant,
                              Object content, String performative) {
        this(owner, participant, content, DEFAULT_TIMEOUT, performative);
    }

    /**
     * starts fipa query-if protocol.
     *
     * @param owner owner of this task
     * @param participant Address of participant in this protocol - reciever of
     *   this query
     * @param content the query content
     * @param timeout int
     * @param performative String
     */
    @Deprecated
    public QueryInitiatorTask(CMAgent owner, Address participant,
                              Object content, int timeout, String performative) {
        this(owner, participant, content, timeout, performative, true);
    }

    public QueryInitiatorTask(CMAgent owner, Address participant,
                              Object content, int timeout, String performative,
                              boolean autostart) {
    	this(owner, participant, content, timeout, performative, autostart, false);
    }

    public QueryInitiatorTask(CMAgent owner, Address participant,
            Object content, int timeout, String performative,
            boolean autostart, boolean messageAsReference) {
        super(owner, timeout, messageAsReference);
        this.participant = participant;

        queryMsg = Message.newInstance(performative, owner.getAddress(),
                                       participant);
        queryMsg.setProtocol(MessageConstants.QUERY);
        queryMsg.setContent(content);

        if (autostart) {
            start();
        }
    }

    

    public QueryInitiatorTask(CMAgent owner, Address participant,
                              Object content, int timeout, String performative,
                              boolean autostart, String action) {
    	this(owner, participant, content, timeout, performative, autostart, action, false);
    }
    
    public QueryInitiatorTask(CMAgent owner, Address participant,
            Object content, int timeout, String performative,
            boolean autostart, String action, boolean messageAsReference) {
        super(owner, timeout, messageAsReference);
        this.participant = participant;

        queryMsg = Message.newInstance(performative, owner.getAddress(),
                                       participant);
        queryMsg.setProtocol(MessageConstants.QUERY_REF);
        queryMsg.setContent(content);
        queryMsg.setReason(action);

        if (autostart) {
            start();
        }
    	
    }

    @Override
    protected void timeout() {
    }

    public void start() {
        try {
            sendMessage(queryMsg);
        } catch (InvisibleContainerException ex) {
            super.rescheduleTimer(0);
            timeout(); // we consider this to result in timeput anyway, no need to wait...
        }
    }

    /**
     * Is called when agree message comes as reply to query.
     */
    protected void queryAgreed() {
    }

    /**
     * Is called when refuse message comes as reply to query.
     */
    protected void queryRefused() {
    }

    /**
     * Is called when failure message comes as reply to query.
     * The reason is get from the message content.
     * @param reason message content.
     */
    protected void failure(String reason) {
    }

    /**
     * Replies to <code>msg</code> with not-understood message
     *
     * @param msg Message
     */
    protected void notUnderstood(Message msg) {
        sendNotUnderstood(msg, null);
    }

    /**
     * This method canceles this task.
     */
    @Override
    public void cancelTask() {
        if (queryMsg != null) {
            queryMsg.release();
            queryMsg = null;
        }
        super.cancelTask();
    }
}
