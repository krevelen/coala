package aglobex.protocol.subscribe;

import java.util.ArrayList;

/**
 * Used to handle a list of SubscribeParticipant tasks. Facilitates informResult sending.
 */
public class SubscribeParticipantList extends ArrayList<SubscribeParticipantTask> {

    private static final long serialVersionUID = 5198494426622304393L;

    /**
     * Used to send inform-result message to all subscribers.
     * @param result result of the subscribe
     * @param reason reason of the inform, optional
     */
    public void informResult(Object result, String reason) {
        for (SubscribeParticipantTask subsc : this) {
            subsc.informResult(result,reason);
        }
    }

    /**
     * Used to send inform-result message to al participants.
     * @param result result of the subscribe
     */
    public void informResult(Object result) {
        informResult(result, null);
    }
}
