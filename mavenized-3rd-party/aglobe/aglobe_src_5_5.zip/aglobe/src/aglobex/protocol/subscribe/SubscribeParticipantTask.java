package aglobex.protocol.subscribe;

import aglobe.container.task.*;
import aglobe.ontology.*;
import aglobe.container.transport.*;

/**
 * Participant part of Subscribe protocol. The participant is agent offering subscribed service.
 *
 * Does not implement canceling of started protocol - can be implemented.
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: ATG, FEE CTU</p>
 * @author Jan Tozicka
 * @version $Revision: 1.35 $ $Date: 2010/08/04 11:48:05 $
 */

abstract public class SubscribeParticipantTask extends Task {
    protected Message subscribeMessage;
    protected Message cancelMessage;
    protected final ConversationUnit owner;

    /**
     * starts fipa subscribe protocol - participant part
     *
     * @param owner owner of this task - needed for sending messages
     * @param subscribeMessage the received subscribe message
     */
    public SubscribeParticipantTask (ConversationUnit owner, Message subscribeMessage) {
        this(owner, subscribeMessage, true, false);
    }

    /**
     * prepare fipa subscribe protocol - participant part task
     *
     * @param owner CMAgent
     * @param subscribeMessage Message
     * @param autostart boolean
     */
    public SubscribeParticipantTask (ConversationUnit owner, Message subscribeMessage, boolean autostart) {
        this(owner, subscribeMessage, autostart, false);
    }

    /**
     * prepare fipa subscribe protocol - participant part task
     *
     * @param owner CMAgent
     * @param subscribeMessage Message
     * @param autostart boolean
     * @param messageAsReference boolean
     */
    public SubscribeParticipantTask (ConversationUnit owner, Message subscribeMessage, boolean autostart, boolean messageAsReference) {
        super(owner, messageAsReference);
        this.subscribeMessage = subscribeMessage;
        this.owner = owner;

        if (!MessageConstants.SUBSCRIBE.equalsIgnoreCase(subscribeMessage.getProtocol()) ||
                !MessageConstants.SUBSCRIBE.equalsIgnoreCase(subscribeMessage.getPerformative())) {
            throw new IllegalArgumentException(subscribeMessage.getProtocol()+ "." +subscribeMessage.getPerformative() +
            " is not good subscribe combination...");
        }

        if (autostart) {
            owner.getConversationUnit().getConversationUnit().addEvent(new Runnable() {
                @Override
				public void run() {
                    start();
                }
            });
        }
    }

    /**
     * Handles incoming messages
     * @param msg Message
     */
    @Override
	public void handleIncomingMessage(Message msg) {
        String performative = msg.getPerformative();
        if (MessageConstants.CANCEL_META_PROTOCOL.equalsIgnoreCase(msg.getProtocol())) {
            if (MessageConstants.CANCEL.equalsIgnoreCase(performative)) {
                cancelMessage = msg;
                subscriptionCancelled();
                return;
            }
        }
        notUnderstood(msg);
        msg.release();
    }

    /**
     * Start protocol
     */
    public final void start() {
        processSubscribe(subscribeMessage);
    }

    /**
     * Returns subscription message
     * @return Message
     */
    public final Message getSubscribeMessage() {
        return subscribeMessage;
    }

    /**
     * Replies to <code>msg</code> with not-understood message
     *
     * @param msg Message
     */
    protected final void notUnderstood(Message msg) {
        sendNotUnderstood(msg,null);
    }

    /**
     * Is called when request comes. Can call agree or refuse methods to reply to
     * this message.
     *
     * @param subscribeMessage Message
     */
    abstract protected void processSubscribe(Message subscribeMessage);

    /**
     * Replies to <code>subscribeMessage</code> with agree message
     */
    protected final void agree() {
        Message re = subscribeMessage.getReply();
        re.setPerformative(MessageConstants.AGREE);
        re.setContent(subscribeMessage.getContent());
        try {
            sendMessage(re);
        } catch (InvisibleContainerException ex) {
            handleInvisibleContainer("Cannot send agree message", ex);
        }
        re.release();
    }

    /**
     * Replies to <code>subscribeMessage</code> with refuse message
     */
    protected final void refuse() {
        Message re = subscribeMessage.getReply();
        re.setPerformative(MessageConstants.REFUSE);
        re.setContent(subscribeMessage.getContent());
        try {
            sendMessage(re);
        } catch (InvisibleContainerException ex) {
            handleInvisibleContainer("Cannot send refuse message", ex);
        }
        re.release();
    }

    /**
     * use to send inform-result message. the parameter specifies the result of
     * the operation
     *
     * @param result result of the subscribe
     * @param reason String
     */
    public void informResult(Object result, String reason) {
        Message re = subscribeMessage.getReply();
        re.setPerformative(MessageConstants.INFORM_RESULT);
        re.setContent(result);
        if (reason != null) {
            re.setReason(reason);
        }
        try {
            sendMessage(re);
        } catch (InvisibleContainerException ex) {
            handleInvisibleContainer("Cannot send inform result message", ex);
        }
        re.release();
    }

    /**
     * use to send inform-result message. the parameter specifies the result of
     * the operation
     *
     * @param result result of the subscribe
     */
    public void informResult(Object result) {
        informResult(result, null);
    }

    /**
     * use to send failure message. the parameter specifies the reason of failure
     *
     * @param result Object
     * @param reason String
     */
    protected final void failure(Object result, String reason) {
        Message re = subscribeMessage.getReply();
        re.setPerformative(MessageConstants.FAILURE);
        re.setContent(result);
        if (reason != null) {
            re.setReason(reason);
        }
        try {
            sendMessage(re);
        } catch (InvisibleContainerException ex) {
            handleInvisibleContainer("Cannot send failure message", ex);
        }
        re.release();
    }

    /**
     * use to send failure message. the parameter specifies the reason of failure
     *
     * @param result reason of failure
     */
    protected final void failure(Object result) {
        failure(result, null);
    }

    /**
     * Method is called when cancellation request for the subscription is
     * received. Method should decide if cancellation is possible and
     * call sendCancelationResult with positive or negative status.
     * By default this method agree with cancellation.
     */
    protected void subscriptionCancelled() {
        sendCancelationResult(true);
    }

    /**
     * Send cancellation result back to the subscriber.
     * @param done boolean - true if task agree with the cancellation, otherwise false
     */
    protected final void sendCancelationResult(boolean done) {
        Message m = cancelMessage.getReply();
        if (done) {
            m.setPerformative(MessageConstants.INFORM_DONE);
        } else {
            m.setPerformative(MessageConstants.FAILURE);
        }
        try {
            sendMessage(m);
        } catch (InvisibleContainerException ex) {
            if (done) {
                cancelTask();
            }
            handleInvisibleContainer("Cannot send cancelation result message", ex);
        }
        m.release();
        if (done) {
            cancelTask();
        }
    }

    /**
     * This method defines handling of the InvisibleContainerException. By
     * default it prints an error message to the logger.
     *
     * @param errorMessage String
     * @param ex InvisibleContainerException
     */
    protected void handleInvisibleContainer(String errorMessage,
            InvisibleContainerException ex) {
        owner.getConversationUnit().getConversationUnit().logSevere(errorMessage + ": " + ex);
    }

    /**
     * This method cancels this task.
     *
     */
    @Override
    public void cancelTask() {
        if (subscribeMessage != null) {
            subscribeMessage.release();
            subscribeMessage = null;
        }
        if (cancelMessage != null) {
            cancelMessage.release();
            cancelMessage = null;
        }
        super.cancelTask();
    }
}
