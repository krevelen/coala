package aglobex.protocol.subscribe;

import aglobe.container.task.*;
import aglobe.ontology.*;
import aglobe.container.transport.*;


/**
 * Initiator part of Subscribe protocol. The Initiator is agent subscribing some service.
 *
 * Does not implement canceling of started protocol - can be implemented.
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: ATG, FEE CTU</p>
 * @author Jan Tozicka
 * @version $Revision: 1.38 $ $Date: 2010/08/04 11:48:05 $
 */

abstract public class SubscribeInitiatorTask extends Task {
    protected ConversationUnit owner;
    private Message subscribeMsg;
    protected Address participant;
    protected Object subscribeContent;
    protected Message lastIncommingMessage;
    private Message agreeMessage;
    private boolean cancelRequested = false;


    /**
     * subscribes <code>participant</code> for something specified in
     * <code>content</code>
     *
     * @param owner CMAgent
     * @param participant of participant to be subscribed.
     * @param content content of subscribe message
     */
    public SubscribeInitiatorTask(ConversationUnit owner, Address participant,
            Object content) {
        this(owner, participant, content, true, false);
    }

    /**
     * Prepare subscription task representing initiator in the
     * FIPA subscribe protocol
     *
     * @param owner CMAgent
     * @param participant Address
     * @param content Object
     * @param autostart boolean
     */
    public SubscribeInitiatorTask(ConversationUnit owner, Address participant,
            Object content, boolean autostart) {
        this(owner, participant, content, autostart, false);
    }

    /**
     * Prepare subscription task representing initiator in the
     * FIPA subscribe protocol
     *
     * @param owner CMAgent
     * @param participant Address
     * @param content Object
     * @param autostart boolean
     * @param messageAsReference boolean
     */
    public SubscribeInitiatorTask(ConversationUnit owner, Address participant,
            Object content, boolean autostart, boolean messageAsReference) {
        super(owner, messageAsReference);
        this.owner = owner;
        this.participant = participant;
        subscribeContent = content;

        subscribeMsg = Message.newInstance();
        subscribeMsg.setPerformative(MessageConstants.SUBSCRIBE);
        subscribeMsg.setProtocol(MessageConstants.SUBSCRIBE);

        subscribeMsg.setContent(content);

        subscribeMsg.setSender(owner.getAddress());

        subscribeMsg.setReceiver(participant);

        if (autostart) {
            start();
        }
    }

    /**
     * Prepare subscription task representing initiator in the FIPA subscribe
     * protocol
     *
     * @param owner CMAgent
     * @param participant Address
     * @param content Object
     * @param reason String
     * @param autostart boolean
     */

    public SubscribeInitiatorTask(ConversationUnit owner, Address participant,
            Object content, String reason, boolean autostart) {
        this(owner, participant, content, reason, autostart, false);
    }

    /**
     * Prepare subscription task representing initiator in the FIPA subscribe
     * protocol
     *
     * @param owner CMAgent
     * @param participant Address
     * @param content Object
     * @param reason String
     * @param autostart boolean
     * @param messageAsReference boolean
     */
    public SubscribeInitiatorTask(ConversationUnit owner, Address participant,
            Object content, String reason, boolean autostart, boolean messageAsReference) {
        super(owner, messageAsReference);
        this.owner = owner;
        this.participant = participant;
        subscribeContent = content;

        subscribeMsg = Message.newInstance();
        subscribeMsg.setPerformative(MessageConstants.SUBSCRIBE);
        subscribeMsg.setProtocol(MessageConstants.SUBSCRIBE);

        subscribeMsg.setContent(content);
        subscribeMsg.setReason(reason);

        subscribeMsg.setSender(owner.getAddress());

        subscribeMsg.setReceiver(participant);

        if (autostart) {
            start();
        }
    }

    /**
     * Start protocol iteration
     */
    public final void start() {
        try {
            sendMessage(subscribeMsg);
        } catch (InvisibleContainerException ex) {
            handleInvisibleContainer("Cannot send subscribe message", ex);
            cancelTask();
        }
    }

    /**
     * Returns subscription message
     * @return Message
     */
    public final Message getSubscribeMessage() {
        return subscribeMsg;
    }

    /**
     * Handles incoming messages
     * @param msg Message
     */
    @Override
	public void handleIncomingMessage(Message msg) {
        if ((lastIncommingMessage != null) && (lastIncommingMessage != agreeMessage)) {
            lastIncommingMessage.release();
        }
        lastIncommingMessage = msg;
        String performative = msg.getPerformative();
        if (MessageConstants.SUBSCRIBE.equalsIgnoreCase(msg.getProtocol())) {
            if (MessageConstants.INFORM_RESULT.equalsIgnoreCase(performative)) {
                subscribeInformResult(msg.getContent(), msg.getReason());
                return;
            } else if (MessageConstants.FAILURE.equalsIgnoreCase(performative)) {
                interactionFailure(msg.getContent(), msg.getReason());
                return;
            } else if (MessageConstants.AGREE.equalsIgnoreCase(performative)) {
                agreeMessage = msg;
                if (!cancelRequested) {
                    subscribeAgreed();
                } else {
                    // postponed cancellation
                    cancelRequested = false;
                    cancelSubscribtion();
                }
                return;
            } else if (MessageConstants.REFUSE.equalsIgnoreCase(performative)) {
                subscribeRefused();
                return;
            } else if (MessageConstants.NOT_UNDERSTOOD.equalsIgnoreCase(
                    performative)) {
                subscribeNotUnderstood();
                return;
            }
        } else if (MessageConstants.CANCEL_META_PROTOCOL.equalsIgnoreCase(msg.
                getProtocol())) {
            if (MessageConstants.INFORM_DONE.equalsIgnoreCase(performative)) {
                cancelationInformDone();
                return;
            } else if (MessageConstants.FAILURE.equalsIgnoreCase(performative)) {
                cancelationFailure("Client refuse it");
                return;
            }
        }
        notUnderstood(msg);
    }

    /**
     * Replies to <code>msg</code> with not-understood message
     *
     * @param msg Message
     */
    protected final void notUnderstood(Message msg) {
        sendNotUnderstood(msg, null);
    }

    /**
     * Replies to last received message with not-understood message
     */
    protected final void notUnderstood() {
        notUnderstood(lastIncommingMessage);
    }

    /**
     * Cancel subscription. Can be called only if subscription is agreed.
     * It initiates FIPA cancel meta protocol for unsubscription.
     */
    public void cancelSubscribtion() {
        if (agreeMessage == null) {
            cancelRequested = true;
            return;
        }
        Message m = agreeMessage.getReply();
        m.setPerformative(MessageConstants.CANCEL);
        m.setProtocol(MessageConstants.CANCEL_META_PROTOCOL);
        try {
            sendMessage(m);
        } catch (InvisibleContainerException ex) {
            cancelationFailure("Cannot send cancelation message: "+ex);
        }
        m.release();
    }

    /**
     * Called when subscription is agreed
     */
    protected void subscribeAgreed() {
    }

    /**
     * Called when subscription is refused.
     * By default this method cancel the task
     */
    protected void subscribeRefused() {
        cancelTask();
    }

    /**
     * Called when subscription is not understood
     */
    protected void subscribeNotUnderstood() {
    }

    /**
     * Called when inform result is received for the subscription
     * @param object Object
     * @param reason String
     */
    protected void subscribeInformResult(Object object, String reason) {
        subscribeInformResult(object);
    }

    /**
     * Called when inform result is received for the subscription
     * @param object Object
     */
    abstract protected void subscribeInformResult(Object object);

    /**
     * Called when failure is received for the subscription
     * @param object Object
     * @param reason String
     */
    protected void interactionFailure(Object object, String reason) {
        interactionFailure(object);
    }

    /**
     * Called when failure is received for the subscription
     * @param object Object
     */
    protected void interactionFailure(Object object) {
    }

    /**
     * Called when cancellation was successful. By default this cancel the task.
     */
    protected void cancelationInformDone() {
        cancelTask();
    }

    /**
     * Called when cancellation wasn't successful.
     *
     * @param errorMessage String
     */
    protected void cancelationFailure(String errorMessage) {
        owner.getConversationUnit().getConversationUnit().logWarning("Subscription cannot be cancelled due to: "+errorMessage);
        cancelTask();
    }

    /**
     * This method defines handling of the InvisibleContainerException. By
     * default it prints an error message to the logger.
     *
     * @param errorMessage String
     * @param ex InvisibleContainerException
     */
    protected void handleInvisibleContainer(String errorMessage,
            InvisibleContainerException ex) {
        owner.getConversationUnit().getConversationUnit().logSevere(errorMessage + ": " + ex);
    }

    /**
     * This method cancels this task.
     *
     */
    @Override
    public void cancelTask() {
        if (subscribeMsg != null) {
            subscribeMsg.release();
            subscribeMsg = null;
        }
        if (agreeMessage != null) {
            agreeMessage.release();
            agreeMessage = null;
        }
        if (lastIncommingMessage != null) {
            lastIncommingMessage.release();
            lastIncommingMessage = null;
        }
        super.cancelTask();
    }
}
