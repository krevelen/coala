package aglobex.protocol.queryif;

import aglobe.ontology.*;
import aglobe.container.agent.*;
import aglobe.container.transport.*;

/**
 * Initiator part of QueryIf protocol.
 *
 * Does not implement canceling of started protocol - can be implemented.
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: ATG, FEE CTU</p>
 * @author Jan Tozicka
 * @version 1.0
 */

abstract public class QueryIfInitiatorTask extends aglobex.protocol.query.QueryInitiatorTask {
    public static final String TRUE = "TRUE";
    public static final String FALSE = "FALSE";
    public static int DEFAULT_TIMEOUT = 1000;

    /**
     * starts fipa query-if protocol.
     * @param owner owner of this task
     * @param participant Address of participant in this protocol - receiver of this query
     * @param content the query content
     */
    @Deprecated
    public QueryIfInitiatorTask(CMAgent owner, Address participant,
                                Object content) {
        this(owner, participant, content, true);
    }

  /**
   * starts fipa query-if protocol.
   *
   * @param owner owner of this task
   * @param participant Address of participant in this protocol - receiver of
   *   this query
   * @param content the query content
   * @param autostart boolean
   */
    public QueryIfInitiatorTask(CMAgent owner, Address participant,
            Object content, boolean autostart) {
        this(owner, participant, content, DEFAULT_TIMEOUT, autostart);
    }

    /**
     * starts fipa query-if protocol.
     *
     * @param owner owner of this task
     * @param participant Address of participant in this protocol - reciever of
     *   this query
     * @param content the query content
     * @param autostart boolean
     * @param messageAsReference boolean
     */
  public QueryIfInitiatorTask(CMAgent owner, Address participant,
                                Object content, boolean autostart, boolean messageAsReference) {
        this(owner, participant, content, DEFAULT_TIMEOUT, autostart, messageAsReference);
    }

  /**
   * starts fipa query-if protocol.
   *
   * @param owner owner of this task
   * @param participant Address of participant in this protocol - receiver of
   *   this query
   * @param content the query content
   * @param timeout int
   */
      @Deprecated
      public QueryIfInitiatorTask(CMAgent owner, Address participant,
                                Object content, int timeout) {
        this(owner, participant, content, timeout, true);
    }

      public QueryIfInitiatorTask(CMAgent owner, Address participant,
            Object content, int timeout, boolean autostart) {
          this(owner, participant, content, timeout, autostart, false);
      }

    public QueryIfInitiatorTask(CMAgent owner, Address participant,
                                Object content, int timeout, boolean autostart, boolean messageAsReference) {
        super(owner, participant, content, timeout, MessageConstants.QUERY_IF, autostart, messageAsReference);
    }

    @Override
	public void handleIncomingMessage(Message msg) {
        String performative = msg.getPerformative();
        if (!MessageConstants.QUERY.equalsIgnoreCase(msg.getProtocol())) {
            // bad protocol ...
            notUnderstood(msg);
        } else {
            if (MessageConstants.INFORM_TF.equalsIgnoreCase(performative)) {
                if (msg.getContent() instanceof String) {
                    String reply = (String) msg.getContent();
                    if (TRUE.equalsIgnoreCase(reply)) {
                        informTrue();
                    } else if (FALSE.equalsIgnoreCase(reply)) {
                        informFalse();
                    } else {
                        notUnderstood(msg);
                    }
                } else {
                    notUnderstood(msg);
                }
            } else if (MessageConstants.NOT_UNDERSTOOD.equalsIgnoreCase(
                performative)) {
            } else {
                String stringContent = msg.getContent() instanceof String ?
                    (String) msg.getContent() : msg.getContent().toString();
                if (MessageConstants.FAILURE.equalsIgnoreCase(performative)) {
                    failure(stringContent);
                } else if (MessageConstants.AGREE.equalsIgnoreCase(performative)) {
                    queryAgreed();
                } else if (MessageConstants.REFUSE.equalsIgnoreCase(
                    performative)) {
                    queryRefused();
                } else {
                    notUnderstood(msg);
                }
            }
        }
        msg.release();
    }

    /**
     * Is called when inform-t/f message comes with positive reply.
     */
    abstract protected void informTrue();

    /**
     * Is called when inform-t/f message comes with negative reply.
     */
    abstract protected void informFalse();
}
