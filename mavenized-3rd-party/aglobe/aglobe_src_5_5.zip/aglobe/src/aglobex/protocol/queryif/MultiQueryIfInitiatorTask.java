package aglobex.protocol.queryif;

import aglobe.container.task.*;
import aglobe.ontology.*;
import aglobe.container.agent.*;
import aglobe.container.transport.*;
import java.util.*;


/**
 * Initiator part of Request protocol.
 *
 * Does not implement canceling of started protocol - can be implemented.
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: ATG, FEE CTU</p>
 * @author Jan Tozicka
 * @version 1.0
 */

abstract public class MultiQueryIfInitiatorTask extends Task {

    protected Collection<Address> participants;
    private Iterator<Address> participantsIterator;
    private Object content;
    private Address owner;
    private final CMAgent ownerAgent;

    private Set<Address> positiveReplies = new HashSet<Address>();
    private Set<Address> negativeReplies = new HashSet<Address>();

    /**
     * starts fipa queryIf protocol. Sends next queryIf when previous is replied.
     * @param owner owner of this task
     * @param participants List of Address of participants in this protocol - receivers of this queryIf
     * @param content the request content
     */
    @Deprecated
    public MultiQueryIfInitiatorTask(CMAgent owner, Collection<Address> participants,
                                     Object content) {
        this(owner, participants, content, true);
    }


    public MultiQueryIfInitiatorTask(CMAgent owner, Collection<Address> participants,
                                     Object content, boolean autostart) {
        this(owner, participants, content, autostart, false);
    }

    public MultiQueryIfInitiatorTask(CMAgent owner, Collection<Address> participants,
            Object content, boolean autostart, boolean messageAsReference) {
        super(owner, messageAsReference);

        this.participants = participants;
        this.content = content;
        this.owner = owner.getAddress();
        this.ownerAgent = owner;

        if (autostart) {
            start();
        }
    }



    public void start() {
        participantsIterator = participants.iterator();

        sendNextQueryIf();
    }

    private void sendNextQueryIf() {
        if (!participantsIterator.hasNext()) {
            processReplies(positiveReplies, negativeReplies);
            return;
        }

        Address participant = participantsIterator.next();

        Message queryMsg = Message.newInstance(MessageConstants.QUERY_IF,
                                         owner, participant);
        queryMsg.setProtocol(MessageConstants.QUERY);
        queryMsg.setContent(content);

        try {
            sendMessage(queryMsg);
        } catch (InvisibleContainerException ex) {
            ownerAgent.logSevere("Cannot send query_if message: "+ex+"\nparticipant removed.");
            participantsIterator.remove();
        }
        queryMsg.release();
    }

  /**
   * sets of Address contains particapant's that replied true/false
   *
   * @param positiveReplies Set
   * @param negativeReplies Set
   */
  protected abstract void processReplies(Set<Address> positiveReplies, Set<Address> negativeReplies);

    @Override
	public void handleIncomingMessage(Message msg) {
        String performative = msg.getPerformative();
        if (!MessageConstants.QUERY.equalsIgnoreCase(msg.getProtocol())) {
            // bad protocol ...
            notUnderstood(msg);
            if (MessageConstants.INFORM_TF.equalsIgnoreCase(performative)) {
                if (msg.getContent() instanceof String) {
                    String reply = (String) msg.getContent();
                    if (aglobex.protocol.queryif.QueryIfInitiatorTask.TRUE.equalsIgnoreCase(reply)) {
                        positiveReplies.add(msg.getSender());
                        sendNextQueryIf();
                    } else if (QueryIfInitiatorTask.FALSE.equalsIgnoreCase(reply)) {
                        negativeReplies.add(msg.getSender());
                        sendNextQueryIf();
                    } else {
                        notUnderstood(msg);
                    }
                } else {
                    notUnderstood(msg);
                }
            } else {
                notUnderstood(msg);
            }
        } else {
            notUnderstood(msg);
        }
        msg.release();
    }

  /**
   * Replies to <code>msg</code> with not-understood message
   *
   * @param msg Message
   */
  protected void notUnderstood(Message msg) {
      sendNotUnderstood(msg,null);
    }

    public Object getContent() {
        return content;
    }
}
