package aglobex.protocol.queryif;

import aglobe.ontology.*;
import aglobe.container.agent.*;
import aglobe.container.transport.*;

/**
 * Participant part of QueryIf protocol. The participant is agent knowing queried info.
 *
 * Does not implement canceling of started protocol - can be implemented.
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: ATG, FEE CTU</p>
 * @author Jan Tozicka
 * @version 1.0
 */

abstract public class QueryIfParticipantTask extends aglobex.protocol.query.QueryParticipantTask {

    /**
     * starts fipa queryIf protocol.
     * @param owner owner of this task - needed for sending messages
     * @param queryMessage the received query message
     */
    @Deprecated
    public QueryIfParticipantTask(CMAgent owner, Message queryMessage) {
        super(owner, queryMessage);
    }

  /**
   * starts fipa queryIf protocol. If auto process is <code>false</code>
   * processRequest method is not called.
   *
   * @param owner owner of this task - needed for sending messages
   * @param queryMessage the received query message
   * @param autoprocess boolean
   */
   public QueryIfParticipantTask(CMAgent owner, Message queryMessage,
            boolean autoprocess) {
        this(owner, queryMessage, autoprocess, false);
    }

   /**
    * starts fipa queryIf protocol. If auto process is <code>false</code>
    * processRequest method is not called.
    *
    * @param owner owner of this task - needed for sending messages
    * @param queryMessage the received query message
    * @param autoprocess boolean
    * @param messageAsReference boolean
    */
    public QueryIfParticipantTask(CMAgent owner, Message queryMessage,
                                  boolean autoprocess, boolean messageAsReference) {
        super(owner, queryMessage, autoprocess, messageAsReference);
    }

    /**
     * use to send positive informTF message
     */
    protected void informTrue() {
        Message re = queryMessage.getReply();
        re.setPerformative(MessageConstants.INFORM_TF);
        re.setContent(aglobex.protocol.queryif.QueryIfInitiatorTask.TRUE);
        try {
            sendMessage(re);
        } catch (InvisibleContainerException ex) {
            owner.logSevere("Cannot send inform true message: "+ex);
        }
        re.release();
    }

    /**
     * use to send negative informTF message
     */
    protected void informFalse() {
        Message re = queryMessage.getReply();
        re.setPerformative(MessageConstants.INFORM_TF);
        re.setContent(QueryIfInitiatorTask.FALSE);
        try {
            sendMessage(re);
        } catch (InvisibleContainerException ex) {
            owner.logSevere("Cannot send inform false message: "+ex);
        }
        re.release();
    }
}
