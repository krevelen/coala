package aglobex.protocol.ecnp;

import java.util.Collection;

import aglobe.container.task.ConversationUnit;
import aglobe.container.transport.Address;
import aglobe.ontology.Message;
import aglobex.protocol.ecnp.ECNPTask.ECNPTaskMap;

public interface ECNPTaskFactory<InitTask extends ECNPSubInitiatorTask, ParticipantTask extends ECNPSubParticipantTask> {

    InitTask getInitiatorInstance(ConversationUnit owner, Collection<Address> participants,Object cfpContent, int shortTimeout, int longTimeout, String reason, ECNPTask<InitTask,ParticipantTask> ownertask);
    ParticipantTask getParticipantInstance(ConversationUnit owner, int shortTimeout, int longTimeout, Message cfpMessage, ECNPTask<InitTask,ParticipantTask> ownertask);
    ECNPTask<InitTask,ParticipantTask> getECNPTaskInstance(int msec, ECNPTaskMap<InitTask,ParticipantTask> taskMap, String mapKey);
}
