package aglobex.protocol.ecnp;

import aglobe.container.task.ConversationUnit;
import aglobe.container.transport.InvisibleContainerException;
import aglobe.ontology.Message;
import aglobex.protocol.cnp.CNPParticipantTask;

/**
 * Creates the task that refers to its creator task when it obtains the necessary info or timeouts.
 * @author premek
 *
 */
public abstract class ECNPSubParticipantTask
      extends CNPParticipantTask {

    public static final int STATUS_CREATE = 0;
    public static final int STATUS_PROPOSE = 1;
    public static final int STATUS_TEMP_ACCEPTED = 2;
    public static final int STATUS_ACCEPTED = 3;

    protected ECNPTask<ECNPSubInitiatorTask, ECNPSubParticipantTask> ownerTask;

    /**
     * Message with Proposal-accepted
     */
    protected Message temporaryAcceptMessage;
    protected int shortTimeout;
    protected int longTimeout;
    protected int status = STATUS_CREATE;

    public ECNPSubParticipantTask(ConversationUnit owner, int shortTimeout,
            int longTimeout, Message cfpMessage,
            ECNPTask<ECNPSubInitiatorTask,
            ECNPSubParticipantTask> ownerTask) {
        this(owner, shortTimeout, longTimeout, cfpMessage,  ownerTask, false);
    }

    public ECNPSubParticipantTask(ConversationUnit owner, int shortTimeout,
                                  int longTimeout, Message cfpMessage,
                                  ECNPTask<ECNPSubInitiatorTask,
                                  ECNPSubParticipantTask> ownerTask,
                                  boolean messageAsReference) {
        super(owner, shortTimeout, cfpMessage, false, messageAsReference);
        this.ownerTask = ownerTask;
        this.shortTimeout = shortTimeout;
        this.longTimeout = longTimeout;
    }

    @Override
    protected void prepareProposal() {
    }

    protected void proposalTemporaryAccepted(Message acceptMessage) {
        status = STATUS_TEMP_ACCEPTED;
        ownerTask.handleParticipantProposalTemporaryAccepted(this,
              acceptMessage);
    }

    @Override
    protected void proposalAccepted(Message acceptMessage) {
        status = STATUS_TEMP_ACCEPTED;
        ownerTask.handleParticipantProposalAccepted(this, acceptMessage);
    }

    @Override
    protected void proposalRefused(Message refuseMessage) {
        ownerTask.handleParticipantProposalRefused(this, refuseMessage);
    }

    /**
     * sends proposal to initiatorTask
     *
     * @param content of the message
     */
    @Override
    public void sendProposal(Object content) {
        super.sendProposal(content);
        rescheduleTimer(longTimeout);
        status = STATUS_PROPOSE;
    }

    /**
     * sends refuse to initiatorTask
     */
    @Override
    public void sendRefuse() {
        super.sendRefuse();
    }

    /**
     * sends refuse to initiatorTask
     *
     * @param reason of the message
     */
    @Override
    public void sendRefuse(String reason) {
        super.sendRefuse(reason);
    }

    /**
     * sends inform-done to initiatorTask
     *
     * @param content of the message
     */
    @Override
    public void sendDone(Object content) {
        try {
            super.sendDone(content);
        }
        catch (InvisibleContainerException e) {
            cancelTask();
        }
    }

    /**
     * sends failure to initiatorTask
     *
     * @param content of the message
     */
    @Override
    public void sendFailure(Object content) {
        try {
            super.sendFailure(content);
        }
        catch (InvisibleContainerException e) {
            cancelTask();
        }
    }

    @Override
    public void handleIncomingMessage(Message m) {
        // check if the message comes from the good agent/service
        if (initiator.equals(m.getSender())) {
            // TEMPORARY ACCEPTED
            if (ECNPTask.TEMPORARY_ACCEPT_PROPOSAL.equalsIgnoreCase(m.
                  getPerformative())) {
                temporaryAcceptMessage = m;
                proposalTemporaryAccepted(m);
                rescheduleTimer(longTimeout);
            }
            else
                super.handleIncomingMessage(m);
        }
    }

    @Override
    public void cancelTask() {
        ownerTask.particip.remove(this);
        super.cancelTask();
    }

    public int getStatus() {
        return status;
    }

}
