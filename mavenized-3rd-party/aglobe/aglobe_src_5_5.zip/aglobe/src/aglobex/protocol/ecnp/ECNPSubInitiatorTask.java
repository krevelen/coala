package aglobex.protocol.ecnp;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import aglobe.container.task.ConversationUnit;
import aglobe.container.transport.Address;
import aglobe.container.transport.InvisibleContainerException;
import aglobe.ontology.Message;
import aglobe.ontology.MessageConstants;
import aglobex.protocol.cnp.CNPInitiatorTask;

public abstract class ECNPSubInitiatorTask extends CNPInitiatorTask {

    public static final int STATUS_TEMPORARY_ACCEPT_SENT = 4;

    protected ECNPTask<ECNPSubInitiatorTask,ECNPSubParticipantTask> ownerTask;
    /** Code for the reply for the temporary accept/refuse replies */
    protected String replyWithTAR;
    protected int shortTimeout;
    protected int longTimeout;

    public ECNPSubInitiatorTask(ConversationUnit cu, Collection<Address> participants,Object cfpContent, int shortTimeout, int longTimeout, String reason, ECNPTask<ECNPSubInitiatorTask,ECNPSubParticipantTask> ownerTask) {
        this(cu, participants, cfpContent, shortTimeout, longTimeout, reason, ownerTask, false);
    }

    public ECNPSubInitiatorTask(ConversationUnit cu, Collection<Address> participants,Object cfpContent, int shortTimeout, int longTimeout, String reason, ECNPTask<ECNPSubInitiatorTask,ECNPSubParticipantTask> ownerTask, boolean messageAsReference) {
        super(cu, participants, cfpContent, longTimeout, reason, false, messageAsReference);
        this.ownerTask = ownerTask;
        this.shortTimeout = shortTimeout;
        this.longTimeout = longTimeout;
    }

    @Override
    public void handleIncomingMessage(Message m) {
        super.handleIncomingMessage(m);
    }

    @Override
    protected List<Address> evaluateReplies() {
        return null;
    }

    @Override
    protected void handleReplies() {
        // update the status to refuse future messages
        status = STATUS_REPLIES_EVALUATED;
        ownerTask.handleInitiatorReplies(this,participants,receivedOffers);
    }

    protected boolean evaluateTemporaryAcceptTimeout() {
        return ownerTask.handleInitiatorTemporaryAcceptTimeout(this);
    }

    @Override
    protected boolean evaluateAcceptReply(Message m) {
        return ownerTask.handleInitiatorAcceptReply(this,m);
    }

    @Override
    protected void evaluateAcceptTimeout() {
        ownerTask.handleInitiatorAcceptTimeout(this);
    }

    public @Override void cancelTask() {
        ownerTask.init.remove(this);
        super.cancelTask();
    }

    @Override
    protected void timeout() {
        if (STATUS_TEMPORARY_ACCEPT_SENT == status)
        {
            if (evaluateTemporaryAcceptTimeout()==true) {
                //send refuse to all
                sendAcceptsToParticipants(new HashMap<Address,Object>());
                cancelTask();
            }
        }
        else
            super.timeout();
    }

    /**
     * sends temporaryAcceptProposal/refuseProposal to participants
     *
     * @param tempAcceptedParticipants Map of participants and its contents in message
     */
    public void sendTemporaryAcceptsToParticipants(Map<Address, Object> tempAcceptedParticipants) {
        Collection<Address> refusedParticipants = new LinkedList<Address>(participants);
        // swith task status
        status = STATUS_TEMPORARY_ACCEPT_SENT;
        // prepare teh reply-with field
        replyWithTAR = "TAR" + replyWith;
        // send the answers

        //System.out.println("@@@@@ CNPInitiatorTask sending accept to "+acceptedParticipants.size()+" of participants");

        for (Map.Entry<Address,Object> elem : tempAcceptedParticipants.entrySet()) {

            Address address = elem.getKey();
            Object replyObject = elem.getValue();
            // remove the address from participants to avoid sending the refuse...
            refusedParticipants.remove(address);
            // retrieve the proposal message and create reply
            Message tempAcceptProposal = receivedOffers.get(address).getReply();
            tempAcceptProposal.setPerformative(ECNPTask.TEMPORARY_ACCEPT_PROPOSAL);
            tempAcceptProposal.setReplyWith(replyWithTAR);
            if (replyObject != null) {
                tempAcceptProposal.setContent(replyObject);
            }
            // send acceptProposal
            try {
                sendMessage(tempAcceptProposal);
            } catch (InvisibleContainerException e) {}
            tempAcceptProposal.release();
        }
        // send refuse messages now
        for (Iterator<Address> i = refusedParticipants.iterator(); i.hasNext(); )
        {
            Address address = i.next();
            participants.remove(address);
            // retrieve the proposal message and create reply
            Object m1 = receivedOffers.get(address);
            if (null != m1)
            {
                Message loser = (Message)m1;
                // answer only accept proposals...
                if (loser.getPerformative().equalsIgnoreCase(MessageConstants.PROPOSAL))
                {
                    Message rejectProposal = (loser).getReply();
                    rejectProposal.setPerformative(MessageConstants.REJECT_PROPOSAL);
                    rejectProposal.setContent(loser.getContent());
                    rejectProposal.setReplyWith(replyWithAR);
                    // send rejectProposal
                    try {
                        sendMessage(rejectProposal);
                    } catch (InvisibleContainerException e) {}
                    rejectProposal.release();
                }
            }
        }
        // check if we continue or not...
        if (0 != tempAcceptedParticipants.size())
        {
            rescheduleTimer(shortTimeout);
        }
        else
        {
            // no-one was accepted, so we may cancel now. no more messages expected.
            cancelTask();
        }

    }

    /**
     * sends acceptProposal/refuseProposal to participants
     *
     * @param acceptedParticipants Map of participants and its contents in message
     */
    public void sendAcceptsToParticipants(Map<Address, Object> acceptedParticipants) {
        Collection<Address> refusedParticipants = new LinkedList<Address>(participants);
        // swith task status
        status = STATUS_ACCEPT_SENT;
        // prepare teh reply-with field
        replyWithAR = "AR" + replyWith;
        // send the answers

        for (Map.Entry<Address,Object> elem : acceptedParticipants.entrySet()) {

            Address address = elem.getKey();
            if (participants.contains(address)) {

                Object replyObject = elem.getValue();
                // remove the address from participants to avoid sending the refuse...
                refusedParticipants.remove(address);
                // retrieve the proposal message and create reply
                Message acceptProposal = receivedOffers.get(address).getReply();
                acceptProposal.setPerformative(MessageConstants.ACCEPT_PROPOSAL);
                acceptProposal.setReplyWith(replyWithAR);
                if (replyObject != null) {
                    acceptProposal.setContent(replyObject);
                }
                // send acceptProposal
                try {
                    sendMessage(acceptProposal);
                } catch (InvisibleContainerException e) {
                }
                acceptProposal.release();
               }
        }
        // send refuse messages now
        for (Iterator<Address> i = refusedParticipants.iterator(); i.hasNext(); )
        {
            Address address = i.next();
            participants.remove(address);
            // retrieve the proposal message and create reply
            Object m1 = receivedOffers.get(address);
            if (null != m1)
            {
                Message loser = (Message)m1;
                // answer only accept proposals...
                if (loser.getPerformative().equalsIgnoreCase(MessageConstants.PROPOSAL))
                {
                    Message rejectProposal = (loser).getReply();
                    rejectProposal.setPerformative(MessageConstants.REJECT_PROPOSAL);
                    rejectProposal.setContent(loser.getContent());
                    rejectProposal.setReplyWith(replyWithAR);
                    // send rejectProposal
                    try {
                        sendMessage(rejectProposal);
                    } catch (InvisibleContainerException e) {}
                    rejectProposal.release();
                }
            }
        }
        // check if we continue or not...
        if (0 != acceptedParticipants.size())
        {
            rescheduleTimer(longTimeout);
        }
        else
        {
            // no-one was accepted, so we may cancel now. no more messages expected.
            cancelTask();
        }
    }

    public Collection<Address> getParticipants() {
        return participants;
    }
}
