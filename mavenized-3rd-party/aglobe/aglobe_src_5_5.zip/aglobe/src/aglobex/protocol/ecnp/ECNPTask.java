/**
 *
 */
package aglobex.protocol.ecnp;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;

import aglobe.container.task.ConversationUnit;
import aglobe.container.task.TimeoutTask;
import aglobe.container.transport.Address;
import aglobe.ontology.Message;
import aglobe.ontology.MessageConstants;

/**
 * Implements Extended Contract Net Protocol, so far optimized for transport negotiation.
 *
 */

public abstract class ECNPTask<InitTask extends ECNPSubInitiatorTask, ParticipantTask extends ECNPSubParticipantTask> extends TimeoutTask {

    public final static String TEMPORARY_ACCEPT_PROPOSAL = "TEMPORARY-ACCEPT-PROPOSAL";

    public static final int TOTALTIMEOUT = 5000;
    public static final int SHORTTIMEOUT = 1000;
    public static final int LONGTIMEOUT = 2000;

    /** Task list where this task is referenced */
    ECNPTaskMap<?,?> ownerTaskMap = null;

    /** Key under which this task is referenced in the ownerTaskMap */
    String mapKey = null;

    /** Subtasks initialized by the task */
//	List<ECNPSubInitiatorTask> init = new LinkedList<ECNPSubInitiatorTask>();
    protected List<InitTask> init = new LinkedList<InitTask>();

    /** Subtasks initialized by the task upon the reception of the cfp from another teammember*/
//	List<ECNPSubParticipantTask> particip = new LinkedList<ECNPSubParticipantTask>();
    protected List<ParticipantTask> particip = new LinkedList<ParticipantTask>();

    protected ECNPTaskFactory<InitTask, ParticipantTask> factory;

    protected int totalTimeout;
    protected int shortTimeout;
    protected int longTimeout;

    /**
     * Constructor of the <code>ECNPTask</code>
     *
     * @param taskMap is a list of ECNPTask. New ECNPTask is member of this list
     * @param mapKey id of ECNPTadk in <code>taskMap</code>
     * @param factory is factory class used to create instances of <code>ECNPTask</code>, <code>ECNPSubInitiatorTask</code> and <code>ECNPSubParticipantTask</code>
     * @param totalTimeout is to interrupt <code>ECNPTask</code>
     * @param shortTimeout is used for waiting in <code>ECNPSubInitiatorTask</code> and <code>ECNPSubParticipantTask</code>
     * @param longTimeout is used for waiting in <code>ECNPSubInitiatorTask</code> and <code>ECNPSubParticipantTask</code>
     */
    public ECNPTask(ECNPTaskMap<?,?> taskMap, String mapKey, ECNPTaskFactory<InitTask, ParticipantTask> factory, int totalTimeout, int shortTimeout, int longTimeout) {
        this(taskMap, mapKey, factory, totalTimeout, shortTimeout, longTimeout, false);
    }

    /**
     * Constructor of the <code>ECNPTask</code>
     *
     * @param taskMap is a list of ECNPTask. New ECNPTask is member of this list
     * @param mapKey id of ECNPTadk in <code>taskMap</code>
     * @param factory is factory class used to create instances of <code>ECNPTask</code>, <code>ECNPSubInitiatorTask</code> and <code>ECNPSubParticipantTask</code>
     * @param totalTimeout is to interrupt <code>ECNPTask</code>
     * @param shortTimeout is used for waiting in <code>ECNPSubInitiatorTask</code> and <code>ECNPSubParticipantTask</code>
     * @param longTimeout is used for waiting in <code>ECNPSubInitiatorTask</code> and <code>ECNPSubParticipantTask</code>
     * @param messageAsReference
     */
    public ECNPTask(ECNPTaskMap<?,?> taskMap, String mapKey, ECNPTaskFactory<InitTask, ParticipantTask> factory, int totalTimeout, int shortTimeout, int longTimeout, boolean messageAsReference) {
        super(taskMap.owner, totalTimeout, messageAsReference);
        this.ownerTaskMap = taskMap;
        this.mapKey = mapKey;
        this.factory = factory;
        this.totalTimeout = totalTimeout;
        this.shortTimeout = shortTimeout;
        this.longTimeout = longTimeout;
    }

    /**
     * Creates new <code>ECNPSubInitiatorTask</code> and adds it to list of
     * <code>ECNPSubInitiatorTask</code>s
     *
     * @param participants is a list of ECNPTask. New ECNPTask is member of this
     *   list
     * @param offer id of ECNPTadk in <code>taskMap</code>
     */
    public void createOffer(Collection<Address> participants, Object offer) {
        InitTask initTask = factory.getInitiatorInstance(ownerTaskMap.owner,participants, offer, shortTimeout, longTimeout, mapKey, this);
        if (initTask.isCancelled() == false)
            init.add(initTask);
    }

    public void start() {
        for (ECNPSubInitiatorTask sit : init) {
            sit.start();
        }
        rescheduleTimer(totalTimeout);
    }


    @Override
	public void handleIncomingMessage(Message m) {
        if (MessageConstants.CFP.equalsIgnoreCase(m.getPerformative()))
        {
            // create a participant task to handle this CFP
            ParticipantTask participTask = factory.getParticipantInstance(ownerTaskMap.owner, shortTimeout, longTimeout, m, this);
            particip.add(participTask);
            participTask.start();
            handleParticipantCFPMessage(participTask,m);
        }
    }

    /**
     * This method is called, when new message is received in ECNPTask
     *
     * @param participantTask is <code>ECNPSubParticipantTask</code>, where CFP message is processed
     * @param m is CFP message
     */
    protected void handleParticipantCFPMessage(ParticipantTask participantTask, Message m) {
    }

    /**
     * This method is called, when all replies to initiating CFP messeage are received or timeout elapsed.
     * Replies contains performative PROPOSAL or REFUSE.
     *
     * @param initTask is <code>ECNPSubInitiatorTask</code>, where CFP message is processed
     * @param participants is collection of addresses. It contains list of participants that sent answers to CFP only
     * @param receivedOffers contains answers from participants.
     */
    protected void handleInitiatorReplies(InitTask initTask, Collection<Address> participants, HashMap<Address,Message> receivedOffers) {
    }

    /**
     * This method is called, when timeout, that is started by sendTemporaryAcceptsToParticipants method, elapsed.
     * It could by used to send finalAccept or refuses to participants.
     *
     * @param initTask is <code>ECNPSubInitiatorTask</code>, where CFP message is processed
     *
     * @return if true is returned, refuse is sent to all participants and initTask is cancelled.
     */
    protected boolean handleInitiatorTemporaryAcceptTimeout(InitTask initTask) {
        return true;
    }

    /**
     * This method is called, when temporary accept is received in by participantTask
     *
     * @param participantTask is <code>ECNPSubParticipantTask</code>, where CFP message is processed
     * @param acceptMessage is CFP message
     */
    protected void handleParticipantProposalTemporaryAccepted(ParticipantTask participantTask, Message acceptMessage) {
    }

    /**
     * This method is called, when final accept is received in by participantTask
     *
     * @param participantTask is <code>ECNPSubParticipantTask</code>, where CFP message is processed
     * @param acceptMessage is CFP message
     */
    protected void handleParticipantProposalAccepted(ParticipantTask participantTask, Message acceptMessage) {
        participantTask.cancelTask();
    }

    /**
     * This method is called, when final refuse is received in by participantTask
     *
     * @param participantTask is <code>ECNPSubParticipantTask</code>, where CFP message is processed
     * @param refuseMessage is CFP message
     */
    protected void handleParticipantProposalRefused(ParticipantTask participantTask, Message refuseMessage) {
        participantTask.cancelTask();
    }

    /**
     * This method is called, when there is some answer to final accept. It can be INFORM_DONE
     * or FAILURE as performative in message.
     *
     * @param initTask is <code>ECNPSubInitiatorTask</code>, where CFP message is processed
     * @param m is CFP message
     *
     * @return if false is returned, initTask is cancelled.
     */
    protected boolean handleInitiatorAcceptReply(InitTask initTask, Message m) {
        return true;
    }

    /**
     * This method is called, when timeout, that is started by sendAcceptsToParticipants method, elapsed.
     *
     * @param initTask is <code>ECNPSubInitiatorTask</code>, where CFP message is processed
     */
    protected void handleInitiatorAcceptTimeout(InitTask initTask) {
    }

    @Override
    protected void timeout() {
        List<InitTask> i = new LinkedList<InitTask>(init);
        for (InitTask it : i) {
            it.cancelTask();
        }
        List<ParticipantTask> p = new LinkedList<ParticipantTask>(particip);
        for (ParticipantTask pt : p) {
            pt.cancelTask();
        }
    }

    @Override
    public void cancelTask() {

        if (null != ownerTaskMap && null != mapKey){
            ownerTaskMap.remove(mapKey);
        }
        super.cancelTask();
    }

    /** This class is used by agent to store the exixting ECNP tasks. */
    public static class ECNPTaskMap<InitTask extends ECNPSubInitiatorTask, ParticipantTask extends ECNPSubParticipantTask> extends LinkedHashMap<String,ECNPTask<InitTask,ParticipantTask>>{

        private static final long serialVersionUID = -3879935600442791038L;
        protected ConversationUnit owner;
        protected ECNPTaskFactory<InitTask, ParticipantTask> factory;

        public ECNPTaskMap(ConversationUnit owner, ECNPTaskFactory<InitTask, ParticipantTask> factory) {
            super();
            this.owner = owner;
            this.factory = factory;
        }

        /**
         * This method should be called from idle task to process new CFP message
         *
         * @param msg - received CFP message
         * @param keyToUse - id of ECNPTask
         */
        public void handleMessage(Message msg, String keyToUse){
            ECNPTask<InitTask,ParticipantTask> task = get(keyToUse);
            if (null == task){
                task = factory.getECNPTaskInstance(ECNPTask.TOTALTIMEOUT, this,keyToUse);
                put(keyToUse, task);
            }
            task.handleIncomingMessage(msg);
        }

        /**
         * This method is used to create new <code>ECNPSubInitiatorTask</code> in ECNP task identified by keyToUse.
         * If no such ECNPTask exists, the new one is created.
         *
         * @param keyToUse - id of ECNPTask
         * @param offer - content of CFP message that is send to participants
         * @param participants - list of addresses where to send CFP message
         */
        public void createOffer(String keyToUse, Object offer, Collection<Address> participants) {
            ECNPTask<InitTask,ParticipantTask> task = get(keyToUse);
            if (null == task){
                task = factory.getECNPTaskInstance(ECNPTask.TOTALTIMEOUT, this,keyToUse);
                put(keyToUse, task);
            }
            task.createOffer(participants,offer);
        }

        /**
         * This method is starts ECNPTask. It iterates over all <code>ECNPSubInitiatorTask</code>s
         * and send its CFP message. Also sets up total timeout of ECNPTask.
         *
         * @param keyToUse - id of ECNPTask
         */
        public void startECNP(String keyToUse) {
            ECNPTask<InitTask,ParticipantTask> task = get(keyToUse);
            if (null == task){
                task = factory.getECNPTaskInstance(ECNPTask.TOTALTIMEOUT, this,keyToUse);
                put(keyToUse, task);
            }
            task.start();
        }
    }

    public String getMapKey() {
        return mapKey;
    }
}
