
package aglobex.protocol.cnp;

import aglobe.container.task.TimeoutTask;
import aglobe.container.transport.Address;
import aglobe.container.transport.InvisibleContainerException;
import aglobe.ontology.Message;
import aglobe.ontology.MessageConstants;

import java.util.*;
import aglobe.container.task.ConversationUnit;

/**
 * This task can be used by agents wishing to act as CNP manager (issuer).
 * It implements the CNP protocol as required by FIPA doc. # XC00029F
 * The principal user task is to implement proposalComaparaisonMethod used to select the best offer.
 */
public abstract class CNPInitiatorTask extends TimeoutTask
{
    /** Reference to the agent/service (typically) owning the Task. */
    protected ConversationUnit towner = null;

    /** status of the cfp*/
    protected int status = STATUS_NOT_SENT;
    public static final int STATUS_NOT_SENT = 0;
    public static final int STATUS_CFP_SENT = 1;
    /**
     * This state is between status 1 and 2
     */
    public static final int STATUS_REPLIES_EVALUATED = 3;
    public static final int STATUS_ACCEPT_SENT = 2;

    /** Used to store the answers to the cfp. */
    protected LinkedHashMap<Address,Message> receivedOffers = new LinkedHashMap<Address,Message>();

    /** Code for the reply for the cfp replies */
    protected String replyWith;
    /** Code for the reply for the accept/refuse replies */
    protected String replyWithAR;
    /** list of Participants. All to whom the cfp was sent before accept. After accept, only those, who were accepted.*/
    protected Collection<Address> participants;
    /** timeout for accept timer*/
    protected int accTimeout;
    /** Used to store the reason of the CFP (optional, may be null) */
    private String reason;
    /** Used to store the content of the CFP. */
    protected Object cfpContent;

    private CNPParticipantTask ownParticipantTask = null;

  /**
   * Creates the task and sends the request to participants.
   *
   * @param cu CNPTaskOwner
   * @param participants Collection
   * @param cfpContent Object
   * @param timeout int
   * @param reason String
   * @param autostart boolean
   */
  public CNPInitiatorTask(ConversationUnit cu, Collection<Address> participants, Object cfpContent, int timeout, String reason, boolean autostart)
    {
      this(cu, participants, cfpContent, timeout, reason, autostart, false);
    }

  /**
   * Creates the task and sends the request to participants.
   *
   * @param cu CNPTaskOwner
   * @param participants Collection
   * @param cfpContent Object
   * @param timeout int
   * @param reason String
   * @param autostart boolean
   * @param messageAsReference boolean
   */
  public CNPInitiatorTask(ConversationUnit cu, Collection<Address> participants, Object cfpContent, int timeout, String reason, boolean autostart, boolean messageAsReference){
      super(cu, timeout, messageAsReference);
      towner = cu;
      this.accTimeout = timeout;
      this.cfpContent = cfpContent;
      this.reason = reason;
      this.participants = new LinkedList<Address>(participants);
      // sends the cfp to all participants
      if (autostart) {
        start();
      }

  }


  /**
   * Creates the task and sends the request to participants.
   *
   * @param cu CNPTaskOwner
   * @param participants Collection
   * @param cfpContent Object
   * @param timeout int
   * @param reason String
   */
  @Deprecated
  public CNPInitiatorTask(ConversationUnit cu, Collection<Address> participants, Object cfpContent, int timeout, String reason)
    {
        this(cu, participants, cfpContent, timeout, reason, true);
    }

    /**
     * Used to start the task execution if it was created with autostart == false
     */
    public void start()
    {
        sendCfp(cfpContent, accTimeout, reason);
    }

    /**
     * This method is used in ECNP protocol to set (and later send) modified cfp from the same task
     * @param content Object
     */
    public void setCfpContent(Object content) {
        this.cfpContent = content;
    }

    /** Prepares the message and sends the cfp proposal to participants.
     *
     * @param cfpContent content of the message to send
     * @param timeout timeout to communicate to participants - used for reply before field
     * @param reason aa
     */
    protected void sendCfp(Object cfpContent, int timeout, String reason)
    {
        // prepare the message templete with the cfp content
        Message cfp = Message.newInstance(MessageConstants.CFP, towner.getConversationUnit().getConversationUnit().getAddress(), towner.getConversationUnit().getConversationUnit().getAddress());
        cfp.setContent(cfpContent);
        cfp.setProtocol(MessageConstants.CONTRACT_NET);
        // prepare the reply code with ID
        StringBuffer sb = new StringBuffer(towner.getConversationUnit().getConversationUnit().getAddress().getName());
        sb.append(System.currentTimeMillis());
        sb.append(Math.floor(Math.random()*1000));
        replyWith = sb.toString();
        cfp.setReplyWith(replyWith);
        if (null != reason) {
            cfp.setReason(reason);
        }
        // set all participants
        cfp.setReceivers(participants);
        // change the status here, to avoid error when reply arrives during sending
        status = STATUS_CFP_SENT;
        // send the message to all participants
        try
        {
            sendMessage(cfp);
        }
        catch (InvisibleContainerException e){
            // not available for multi-receiver messages
        }
        cfp.release();
    }

    @Override
	public void handleIncomingMessage(Message m)
    {
        //1. REPLY TO CFP MESSAGE
        // check reply-to param
        if (m.getInReplyTo().equalsIgnoreCase(replyWith)) {
//            System.out.println("CNP reply:"+m.getPerformative());
            // check if the reply comes from invited participant to whom sending succeeded
            // don't touch the participants here, in case the first message has arrived while we still send the cfp messages to others
            if ( STATUS_CFP_SENT == status ) {
//                System.out.println("CNP reply2:"+m.getPerformative());
                if (participants.contains(m.getSender())) {
//                    System.out.println("CNP reply3:"+m.getPerformative());
                    receivedOffers.put(m.getSender(), m);
                    // check if all replies have been received
                    if (receivedOffers.size() == participants.size()) {
//                        System.out.println("CNP reply4:"+m.getPerformative());
                       // stop the timer for the moment
                       rescheduleTimer(0);
                       handleReplies();
                    }
                }
            }
        }
        // REPLIES TO ACCEPT OR REFUSE...
        else if (m.getInReplyTo().equalsIgnoreCase(replyWithAR))
        {
            // isCancelled() is checked not to call the handleAccept after the evaluateAcceptTimeout
            if ((STATUS_ACCEPT_SENT == status) && !isCancelled())
            {
                // we are interested only in messages from those who were accepted
                if (participants.contains(m.getSender()))
                {
                    handleAcceptReply(m);
                }
            }
        }
    }

    /**
     * Implement this function using your choice criteria to return list of addresses of chosen participants.
     * Task will then send accept to these and folow the completion status. Task will also refuse the others.
     * Use participants and receivedOffers as an input for your treatment.
     * @return List of addresses to whom we send the proposal. List with 0 elements refuses all and cancels the task.
     * If user need perform other actions before sending accept and refuse messages, the method needs return null value.
     * In this case the inherited task is responsible for calling sendAnswersToParticipants method when it
     * wants send accept or refuse message.
     */
    protected abstract List<Address> evaluateReplies();

    /**
     * Overwrite this method if you need to send a content in the accept message.
     * @return Map - recommanded type is LinkedHashMap due to the fact that it is iterated though the elements.
     * Object stored under the address is a content of the accept message to the corresponding participant.
     * If user need perform other actions before sending accept and refuse messages, the method needs return null value.
     * In this case the inherited task is responsible for calling sendAnswersToParticipants method when it
     * wants send accept or refuse message.
     *
     */
    protected Map<Address,Object> evaluateRepliesWithContent() {
        List<Address> retVal = evaluateReplies();
        if (retVal == null) {
            return null;
        }

//        System.out.println("evaluateReplies returned: " + retVal.size());

        Map<Address,Object> returnVal = new LinkedHashMap<Address,Object>();
        for (Address elem : retVal) {
            returnVal.put(elem,null);
        }
        return returnVal;
    }

  /**
   * This function is called for each message received as a reply to accept
   * (e.g DONE or FAILURE, ...). Return true if you want to keep the task
   * running, or false to cancel the task.
   *
   * @return true to keep the task running, false to cancel it (when job is
   *   finished)
   * @param m Message
   */
  protected abstract boolean evaluateAcceptReply(Message m);

   /**
     * This function is called when timeout for accept reply (DONE or FAILURE, ...) elapses.
     */
    protected abstract void evaluateAcceptTimeout();

    /**
     * Implements the treatment and of received replies to cfp. Calls evaluateReplies to pick the winners.
     */
    protected void handleReplies()
    {
        // update the status to refuse future messages
        status = STATUS_REPLIES_EVALUATED;
        // evaluate the replies
        Map<Address,Object> accepted = evaluateRepliesWithContent();

        if (accepted != null) {
            // sends accept and refuse messages to the participants otherwise this method is
            // called by inherited class directly
            sendAnswersToParticipants(accepted);
        }
    }

    /**
     * Handles the response from the accepted participants. Cancels the task if required by evaluateAcceptReply.
     * @param m received message
     */
    private void handleAcceptReply(Message m)
    {
        if (!evaluateAcceptReply(m))
        {
            cancelTask();
            m.release();
        }
    }

    @Override
    protected void timeout()
    {
        if (STATUS_CFP_SENT == status)
        {
            handleReplies();
        }else if (STATUS_ACCEPT_SENT == status)
        {
            // call the handler function before canceling the task
            evaluateAcceptTimeout();
            cancelTask();
        }
    }

    /**
     * *DEPRECATED*
     * sends accept proposal/refuseProposal to participants
     *
     * @param acceptedParticipants List
     */
    protected void sendAnswersToParticipants(List<Address> acceptedParticipants) {
        Map<Address,Object> tmpVal = new LinkedHashMap<Address,Object>();
        for (Iterator<Address> iter = acceptedParticipants.iterator(); iter.hasNext(); ) {
            Address item = iter.next();
            tmpVal.put(item,null);
        }
        sendAnswersToParticipants(tmpVal);
    }

    /**
     * Sends acceptProposal/refuseProposal to participants
     * Refuse message is sent also to the agents that didn't sent their own proposal!
     * @param acceptedParticipants List
     */
    protected void sendAnswersToParticipants(Map<Address,Object> acceptedParticipants) {
        Collection<Address> refusedParticipants = new LinkedList<Address>(participants);
        // swith task status
        status = STATUS_ACCEPT_SENT;
        // prepare teh reply-with field
        replyWithAR = "AR" + replyWith;
        // send the answers

        //System.out.println("@@@@@ CNPInitiatorTask sending accept to "+acceptedParticipants.size()+" of participants");

        for (Map.Entry<Address,Object> elem : acceptedParticipants.entrySet()) {
            Address address = elem.getKey();
            Object replyObject = elem.getValue();
            // remove the address from participants to avoid sending the refuse...
            refusedParticipants.remove(address);
//            participants.remove(address);
            // retrieve the proposal message and create reply
            Message acceptProposal = receivedOffers.get(address).getReply();
            acceptProposal.setPerformative(MessageConstants.ACCEPT_PROPOSAL);
            acceptProposal.setReplyWith(replyWithAR);
            if (replyObject != null) {
                acceptProposal.setContent(replyObject);
            }
            // send acceptProposal
            try {
                sendMessage(acceptProposal);
            } catch (InvisibleContainerException e) {}
            acceptProposal.release();
        }
        // send refuse messages now
        for (Address address : refusedParticipants) {
            // remove refused from participants
            // participants will contain accepted only
            participants.remove(address);
            // retrieve the proposal message and create reply
            Object m1 = receivedOffers.get(address);
            if (null != m1) {
                Message loser = (Message) m1;
                // answer only accept proposals...
                if (loser.getPerformative().equalsIgnoreCase(MessageConstants.PROPOSAL)) {
                    Message rejectProposal = (loser).getReply();
                    rejectProposal.setPerformative(MessageConstants.REJECT_PROPOSAL);
                    rejectProposal.setContent(loser.getContent());
                    rejectProposal.setReplyWith(replyWithAR);
                    // send rejectProposal
                    try {
                        sendMessage(rejectProposal);
                    }
                    catch (InvisibleContainerException e) {}
                    rejectProposal.release();
                }
            }
        }
        // check if we continue or not...
        if (0 != acceptedParticipants.size()) {
/*            // participants will include only accepted from now on
            participants = acceptedParticipants.keySet();
*/          rescheduleTimer(accTimeout);
        }
        else {
            // no-one was accepted, so we may cancel now. no more messages expected.
            cancelTask();
        }
    }

    /**
     *
     * @param pT CNPParticipantTask
     * @throws Exception
     */
    public void registerOwnCNPParticipantTask(CNPParticipantTask pT) throws Exception {
        if (ownParticipantTask == null) {
            try {
                pT.setOwnerCNPInitiatorTask(this);
                ownParticipantTask = pT;
            } catch (Exception ex) {
                throw new Exception("The specified task is already assigned to another CNPInitiatorTask.");
            }
        } else {
            throw new Exception("Own CNPParticipantTask is already registered.");
        }
    }

    /**
     * This method sends a message through the conversation manager.
     *
     * @param m a message
     * @throws InvisibleContainerException
     */
    @Override
    public final void sendMessage(final Message m) throws InvisibleContainerException {
        if ((m.isMulticast() && m.getReceivers().contains(towner.getConversationUnit().getConversationUnit().getAddress())) ||
            (!m.isMulticast() && m.getReceiver().equals(towner.getConversationUnit().getConversationUnit().getAddress()))) {
            if (ownParticipantTask != null) {
                towner.getConversationUnit().getConversationUnit().addEvent(new Runnable() {
                    @Override
					public void run() {
                        if (MessageConstants.CFP.equals(m.getPerformative())) {
                            ownParticipantTask.cfpMessage = m;
                            ownParticipantTask.initiator = m.getSender();
                            ownParticipantTask.prepareProposal();
                        } else {
                            ownParticipantTask.handleIncomingMessage(m);
                        }
                    }
                });
            } else {
                throw new RuntimeException("Trying to send message to itself without registering own CNPParticipantTask.");
            }
        } else {
            log(m);
            super.sendMessage(m);
        }
    }

  /*
    @Override
    protected final void sendMessageAsReference(final Message m) throws InvisibleContainerException {
        if (m.getReceiver().equals(towner.getConversationManager().getElementaryConversationEntity().getAddress())) {
            if (ownParticipantTask != null) {
                towner.getConversationManager().getElementaryConversationEntity().addEvent(new Runnable() {
                    public void run() {
                        if (MessageConstants.CFP.equals(m.getPerformative())) {
                            ownParticipantTask.cfpMessage = m;
                            ownParticipantTask.initiator = m.getSender();
                            ownParticipantTask.prepareProposal();
                        } else {
                            ownParticipantTask.handleIncomingMessage(m);
                        }
                    }
                });
            } else {
                throw new RuntimeException("Trying to send message to itself without registering own CNPParticipantTask.");
            }
        } else {
            log(m);
            super.sendMessageAsReference(m);
        }
    }*/

    /**
     * every sent message can be logged using this method. This method is
     * supposed to be overwritten.
     *
     * @param message message
     */
    protected void log(Message message) {
    }

    /**
     * This method canceles this task.
     *
     */
    @Override
    public void cancelTask() {
//        for (Message elem : receivedOffers.values()) {
//            elem.release();
//        }
//        receivedOffers.clear();
        super.cancelTask();
    }
}

