package aglobex.protocol.cnp;

import aglobe.container.task.TimeoutTask;
import aglobe.container.transport.InvisibleContainerException;
import aglobe.container.transport.Address;
import aglobe.ontology.Message;
import aglobe.ontology.MessageConstants;
import aglobe.container.task.ConversationUnit;

/**
 * This task can be used by agents wishing to act as CNP participant and answer the cfp.
 * It implements the CNP protocol as required by FIPA doc. # XC00029F
 */
public abstract class CNPParticipantTask extends TimeoutTask
{
    protected ConversationUnit owner;

    /** Address of the CNP manager */
    protected Address initiator;
    /* Message with original CFP*/
    protected Message cfpMessage;
    /** Proposal sent as an answer to CFP, null if not sent yet */
    protected Object submitedProposal = null;

    /**
     * Message with Proposal-accepted
     */
    protected Message acceptMessage;

    /**
     * Iff null, all messages should be sent normally.
     */
    private CNPInitiatorTask ownerCNPInitiatorTask = null;

    /**
     * Creates the task and starts CFP processing if required by auto process.
     * @param owner CNPTaskOwner owning the Task
     * @param msec Timeout to cancel the task automatically (in msec)
     * @param cfpMessage CFP message as received from manager
     * @param autoprocess If true, calls prepareProposal automatically. otherwise, call it yourself from inhertited constructor.
     */
    public CNPParticipantTask(ConversationUnit owner, int msec, Message cfpMessage, boolean autoprocess){
        this(owner, msec, cfpMessage, autoprocess, false);
    }

    /**
     * Creates the task and starts CFP processing if required by auto process.
     * @param owner CNPTaskOwner owning the Task
     * @param msec Timeout to cancel the task automatically (in msec)
     * @param cfpMessage CFP message as received from manager
     * @param autoprocess If true, calls prepareProposal automatically. otherwise, call it yourself from inhertited constructor.
     * @param messageAsReference boolean
     */
    public CNPParticipantTask(ConversationUnit owner, int msec, Message cfpMessage, boolean autoprocess, boolean messageAsReference)
    {
        super(owner, msec, messageAsReference);
        this.owner = owner;
        this.cfpMessage = cfpMessage;
        this.initiator = cfpMessage.getSender();
        if (autoprocess) {
            owner.getConversationUnit().getConversationUnit().addEvent(new Runnable() {
                @Override
				public void run() {
                    start();
                }
            });
        }
    }

    @Deprecated
    public CNPParticipantTask(ConversationUnit owner, int msec, Message cfpMessage)
    {
        this(owner, msec, cfpMessage, true);
    }

    /**
     * return initiator
     *
     * @return Address
     */
    public Address getInitiator() {
        return initiator;
    }
    /**
     * This constructor should be used only in the situation when user registers this task to the
     * CNPInitiatorTask using method registerOwnCNPParticipantTask. Otherwise he needs to use
     * constructors with cfpMessage.
     *
     * @param owner ConversationUnit
     * @param msec int
     */
    @Deprecated
    public CNPParticipantTask(ConversationUnit owner, int msec) {
        super(owner, msec);
        this.owner = owner;
        this.cfpMessage = null;
    }

    /**
     * Implement this method to answer the call for proposals received in message cfpMessage.
     * Use sendProposal or sendRefuse methods to send your proposal so that the Task is in a consistent state.
     * Use cfpMessage member field to access the received proposal.
     */
    abstract protected void prepareProposal();

    /**
     * In the body of this method, start the action to fulfill the proposal.
     * @param acceptMessage message with accept - DONE or FAILURE must be reply to this message
     */
    abstract protected void proposalAccepted(Message acceptMessage);

    /**
     * This method is called when the proposal is refused by the proposing party.
     * It is also called, with null parameter, when timeout or communication problem occurs.
     * In the body, owner shall free the resources allocated for proposal.
     * @param refuseMessage message with refusal
     */
    abstract protected void proposalRefused(Message refuseMessage);

    /**
     * Answers the CFP with a proposal.
     * Fills in the variable submitedProposal.
     * @param content content of the proposal to be sent to initiator (manager)
     */
    public void sendProposal(Object content) {
        // check whether the task was not canceled e.g. by the timer before the proposal was prepared
        if (!isCancelled()) {
            Message prop = cfpMessage.getReply(owner.getAddress());
            prop.setPerformative(MessageConstants.PROPOSAL);
            prop.setContent(content);
            // store the answer for further use
            submitedProposal = content;
            try {
                sendMessage(prop);
            }
            catch (InvisibleContainerException e) {
                // notify the owner that it may un-commit the resources
                proposalRefused(null);
                // cancel the task, as the proposal was not sent and there is no reason to wait further
                cancelTask();
            }
            prop.release();
        }
    }

    public Object getSubmitedProposal() {
        return this.submitedProposal;
    }

    /**
     * Refuses the call for proposals, notifying the initiator that the owner is
     * not interested in it. Task is canceled afterwards, as there is no need to
     * keep it open.
     *
     * @param reason String
     */
    public void sendRefuse(String reason) {
        Message ref = cfpMessage.getReply();
        ref.setPerformative(MessageConstants.REFUSE);
        ref.setContent(cfpMessage.getContent());
        ref.setReason(reason);
        try {
            sendMessage(ref);
        }
        catch (InvisibleContainerException e) {}
        ref.release();
        cancelTask();
    }

    public void sendRefuse() {
        sendRefuse("");
    }

    /**
     *
     * @param content Object
     * @throws InvisibleContainerException
     */
    public void sendDone(Object content) throws InvisibleContainerException {
      Message doneMsg = acceptMessage.getReply();
      doneMsg.setPerformative(MessageConstants.INFORM_DONE);
      doneMsg.setContent(content);
      sendMessage(doneMsg);
      doneMsg.release();
    }

    /**
     *
     * @param content Object
     * @throws InvisibleContainerException
     */
    public void sendFailure(Object content) throws InvisibleContainerException {
      Message doneMsg = acceptMessage.getReply();
      doneMsg.setPerformative(MessageConstants.FAILURE);
      doneMsg.setContent(content);
      sendMessage(doneMsg);
      doneMsg.release();
    }

    @Override
	public void handleIncomingMessage(Message m) {
        // check whether the task was not already canceled (e.g. the accept message can arrive after the timeout passed)
        // timeout will be added into the agent's event queue first, message processing as second
        // thus both events, timeout and handle accept/reject will be called
        if (!isCancelled()) {
            // check if the message comes from the good agent/service
            if (initiator.equals(m.getSender())) {
                // ACCEPTED
                if (MessageConstants.ACCEPT_PROPOSAL.equalsIgnoreCase(m.getPerformative())) {
                    acceptMessage = m;
                    proposalAccepted(m);
                    // cancel the task after treatment
                    //cancelTask();
                    return;
                }
                // REJECTED
                else if (MessageConstants.REJECT_PROPOSAL.equalsIgnoreCase(m.getPerformative())) {
                    proposalRefused(m);
                    // cancel the task after treatment
                    cancelTask();
                }
            }
        }
        m.release();
    }

    /**
     * On timeout, when the answer to our proposal is not received, we cancel the task.
     */
    @Override
    protected void timeout() {
        String proposal;
        if (submitedProposal == null) {
            proposal = "\nbefore the proposal was sent!";
        } else {
            proposal = "\nsent proposal was:\n" + submitedProposal;
        }
        owner.getConversationUnit().getConversationUnit().logWarning(
        "Timeout elapsed for the task: " + cfpMessage + proposal);
        // notify the owner to un-commit the resources
        proposalRefused(null);
        // cancel the task
        cancelTask();
    }

    public void start() {
        prepareProposal();
    }

    void setOwnerCNPInitiatorTask(CNPInitiatorTask it) throws Exception {
        if (ownerCNPInitiatorTask == null) {
            ownerCNPInitiatorTask = it;
        } else {
            throw new Exception("Owner CNPInitiatorTask is already set.");
        }
    }

    /**
     * This method sends a message through the conversation manager.
     *
     * @param m a message
     * @throws InvisibleContainerException
     */
    @Override
    public final void sendMessage(final Message m) throws InvisibleContainerException {
        if (ownerCNPInitiatorTask == null) {
            log(m);
            super.sendMessage(m);
        } else {
            owner.getConversationUnit().getConversationUnit().addEvent(new Runnable() {
                @Override
				public void run() {
                    ownerCNPInitiatorTask.handleIncomingMessage(m);
                }
            });
        }
    }
/*
    @Override
    protected final void sendMessageAsReference(final Message m) throws InvisibleContainerException {
        if (ownerCNPInitiatorTask == null) {
            log(m);
            super.sendMessageAsReference(m);
        } else {
            owner.getConversationManager().getElementaryConversationEntity().addEvent(new Runnable() {
                public void run() {
                    ownerCNPInitiatorTask.handleIncomingMessage(m);
                }
            });
        }
    }*/

    /**
     * every sent message can be logged using this method. This method is
     * supposed to be overwritten.
     *
     * @param message message
     */
    protected void log(Message message) {
    }

    /**
     * This method cancels this task.
     *
     */
    @Override
    public void cancelTask() {
        if (cfpMessage != null) {
            cfpMessage.release();
            cfpMessage = null;
        }
        if (acceptMessage != null) {
            acceptMessage.release();
            acceptMessage = null;
        }
        super.cancelTask();
    }
}
