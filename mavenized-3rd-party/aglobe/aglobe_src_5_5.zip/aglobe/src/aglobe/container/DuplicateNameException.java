package aglobe.container;


/**
 * <p>Title: A-Globe</p>
 * <p>Description: Thrown when agent/service with duplicate name is started.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.9 $ $Date: 2008/11/23 09:14:11 $
 */
public final class DuplicateNameException extends Exception
{
    private static final long serialVersionUID = -2555547242391058677L;

    /**
     * Exception constructor
     * @param msg String - exception message
     */
    public DuplicateNameException(String msg) {
        super(msg);
    }
}
