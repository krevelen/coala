package aglobe.container;

import java.util.TimerTask;

/**
 * <p>Title: A-Globe</p>
 *
 * <p>Description: Timer interface denotes that the implementor is able to schedule
 *  an event to be executed in the entity thread.</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Agent Technology Center, Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.6 $ $Date: 2009/06/15 13:38:01 $
 */
public interface TimerOwner extends ContainerOwner, EventReceiver {
    /**
     * Adds an event to the owner's event queue to be executed ONCE, after the
     * specified delay passes. This event will be executed in the owner's thread.
     *
     * @param event Runnable
     * @param delay long - milliseconds in true clock time
     * @return TimerTask - handler to the planned timer task, it can be used for cancellation of the task
     */
    public TimerTask scheduleEvent(final Runnable event, final long delay);

    /**
     * Adds an event to the owner's event queue to be executed REPEATEDLY,
     * beginning after the specified delay. This event will be executed in the
     * owner's thread.

     * @param event Runnable
     * @param delay long - milliseconds in true clock time
     * @param period long - milliseconds in true clock time
     * @return TimerTask - handler to the planned timer task, which can be used for cancellation of the
     * task
     */
    public TimerTask scheduleEvent(final Runnable event, final long delay, final long period);
}
