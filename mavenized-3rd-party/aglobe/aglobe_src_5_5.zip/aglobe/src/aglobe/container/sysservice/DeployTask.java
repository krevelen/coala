package aglobe.container.sysservice;

import aglobe.ontology.*;
import aglobe.container.agent.*;
import aglobe.container.transport.*;
import aglobe.container.service.*;

import aglobe.container.*;
import aglobe.container.task.*;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: This <code>Task</code> deploys an agent
 * target address.  </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.22 $ $Date: 2010/08/04 11:48:05 $
 */
public final class DeployTask extends Task {
    /**
     * Owner entity
     */
    final ElementaryEntity owner;

    /**
     * Agent info with agent information about deployed agent
     */
    AgentInfo ai;

    /**
     * Deploy callback
     */
    DeployCallback callback;

    /**
     * Target for deployed agent
     */
    Address target;

    /**
     * Owner agent
     */
    Agent aOwner = null;

    /**
     * Owner service
     */
    aglobe.container.service.Service sOwner = null;

    /**
     * Synchronization lock
     */
    Object lock = new Object();

    /**
     * True iff deploy is finished
     */
    boolean finished = false;

    /**
     * Constructor of DeployTask. It deploys the agent.
     * @param owner It is an owner agent of the <code>DeployTask</code>
     * @param target target address of container
     * @param ai AgentInfo of agent to deploy.
     */
    public DeployTask(final CMAgent owner, final Address target, final AgentInfo ai) {
        this(owner, target, ai, null);
    }

    /**
     * Constructor of DeployTask. It deploys the agent.
     * @param owner It is an owner agent of the <code>DeployTask</code>
     * @param target target address of container
     * @param ai AgentInfo of agent to deploy.
     * @param messageAsReference - send message as reference
     */
    public DeployTask(final CMAgent owner, final Address target, final AgentInfo ai, final boolean messageAsReference){
        this(owner, target, ai, null, messageAsReference);
    }

    /**
     * Constructor of DeployTask. It deploys the agent.
     * @param owner It is an owner service of the <code>DeployTask</code>
     * @param target target address
     * @param ai AgentInfo of agent to deploy.
     */
    public DeployTask(final CMService owner, final Address target, final AgentInfo ai) {
        this(owner, target, ai, null);
    }

    /**
     * Constructor of DeployTask. It deploys the agent.
     * @param owner It is an owner service of the <code>DeployTask</code>
     * @param target target address
     * @param ai AgentInfo of agent to deploy.
     * @param messageAsReference - send message as reference
     */
    public DeployTask(final CMService owner, final Address target, final AgentInfo ai, final boolean messageAsReference) {
        this(owner, target, ai, null, messageAsReference);
    }

    /**
     * Constructor of DeployTask. It deploys the agent with
     * <code>DeployTaskCallback</code>
     *
     * @param owner It is an owner agent of the <code>DeployTask</code>
     * @param target target address
     * @param ai AgentInfo of agent to deploy.
     * @param callback DeployCallback
     */
    public DeployTask(final CMAgent owner, final Address target, final AgentInfo ai, final DeployCallback callback) {
        this(owner, target, ai, callback, false);
    }

    public DeployTask(final CMAgent owner, final Address target, final AgentInfo ai, final DeployCallback callback, final boolean messageAsReference) {
        super(owner, messageAsReference);
        this.owner = owner;
        this.ai = ai;
        this.callback = callback;
        this.target = target;
        this.aOwner = owner;

        final Address targetDeployService = target.deriveServiceAddress(DeployService.SERVICENAME);
        final Message m = Message.newInstance(MessageConstants.REQUEST, owner.getAddress(), targetDeployService);
        m.setContent(ai);
        try {
            sendMessage(m);
        } catch (InvisibleContainerException ex) {
            owner.logWarning("Undeliverable Message. Cannot deploy agent.");
            finish(DeployCallback.FAILED);
        }
        m.release();
    }

    /**
     * Constructor of DeployTask. It deploys the agent with
     * <code>DeployTaskCallback</code>
     *
     * @param owner It is an owner service of the <code>DeployTask</code>
     * @param target target address
     * @param ai AgentInfo of agent to deploy.
     * @param callback DeployCallback
     */
    public DeployTask(final CMService owner, final Address target, final AgentInfo ai, final DeployCallback callback) {
        this(owner, target, ai, callback, false);
    }

    /**
     * Constructor of DeployTask. It deploys the agent with
     * <code>DeployTaskCallback</code>
     *
     * @param owner It is an owner service of the <code>DeployTask</code>
     * @param target target address
     * @param ai AgentInfo of agent to deploy.
     * @param callback DeployCallback
     * @param messageAsReference
     */
    public DeployTask(final CMService owner, final Address target, final AgentInfo ai, final DeployCallback callback, final boolean messageAsReference) {
        super(owner, messageAsReference);
        this.owner = owner;
        this.ai = ai;
        this.callback = callback;
        this.target = target;
        this.sOwner = owner;

        Address targetDeployService = target.deriveServiceAddress(DeployService.SERVICENAME);
        Message m = Message.newInstance(MessageConstants.REQUEST, owner.getAddress(), targetDeployService);
        m.setContent(ai);
        try {
            sendMessage(m);
        } catch (InvisibleContainerException ex) {
            owner.logWarning("Undeliverable Message. Cannot deploy service.");
            finish(DeployCallback.FAILED);
        }
        m.release();
    }

    /**
     * This method cancels the deploy task.
     * @param r is status defined in <code>DeployCallback</code>
     */
    private void finish(final String r) {
        if (!finished) {

            finished = true;
            cancelTask();
            if (callback != null) {
                try {
                    if (aOwner != null)
                        callback.agentDeployFinished(r, aOwner);
                    if (sOwner != null)
                        callback.serviceDeployFinished(r, sOwner);
                } catch (Exception e) {
                    owner.logSevere("Exception thrown by 'DeployFinished' method: " + e);
                }
            }
        }
    }

    /**
     * This method handles incoming message into the deploy task.
     * @param m a message
     */
    @Override
	public void handleIncomingMessage(final Message m) {
        if (m.getPerformative().equals(MessageConstants.INFORM_DONE))
            finish(DeployCallback.DONE);
        else if (m.getPerformative().equals(MessageConstants.FAILURE))
            finish(DeployCallback.FAILED);
        else if (m.getPerformative().equals(MessageConstants.REFUSE))
            finish(DeployCallback.REFUSE);
        m.release();
    }

}
