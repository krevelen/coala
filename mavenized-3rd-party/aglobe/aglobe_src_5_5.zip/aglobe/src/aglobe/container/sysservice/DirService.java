package aglobe.container.sysservice;

import java.io.*;

import aglobe.container.*;
import aglobe.container.transport.*;
import aglobe.ontology.*;
import aglobe.container.service.*;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: DEPRECATED. The universal search service body. The implementing class should just
 * implement the abstract <code>search(Query)</code> method. This class interfaces
 * the informing messages as well as Shell calls to this method. Any exceptions thrown
 * are either passed up (in case of calls via Shell) or transformed into the
 * <code>FAULURE</code> message.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 *
 */
public abstract class DirService extends aglobe.container.service.Service implements MessageConstants
{
    /**
     * Constant for searching by name.
     */
    public final static String NAME = "name";

    /**
     * Constant for searching by name.
     */
    public final static String TYPE = "type";

    /**
     * Name of parameter in the query.
     */
    public final static String PARAM = "name";

    /**
     * Result of searching.
     */
    private final Query.QueryResult[] EMPTY_ARRAY = new Query.QueryResult[0];

    /**
     * The method returns <code>Shell</code> of <code>DirSer</code>
     *
     * @return ServiceShell
     * @param shellOwner ElementaryEntity
     */
    @Override
    public ServiceShell getServiceShell(final ShellOwner shellOwner)
    {
        return new Shell(shellOwner,this);
    }

    /**
     * Handle for incoming messages.
     * @param m a incoming message.
     * @throws aglobe.platform.transport.RecepientNotFound
     */
    @Override
	public void handleIncomingMessage(final Message m) throws aglobe.platform.transport.RecepientNotFound {
        if (!m.getPerformative().equalsIgnoreCase(REQUEST)) {
            String msg = "Wrong QUERY performative (" + m.getPerformative() +
            ")";
            sendNotUnderstood(m, msg);
            logWarning(msg);
        }

        if (m.getContent() instanceof Query) {
            Query q = (Query) m.getContent();
            Message re = m.getReply();

            Query nq = new Query();
            nq.setParam(q.getParam());
            nq.setValue(q.getValue());

            try {
                search(nq);
                re.setPerformative(MessageConstants.DONE);
            } catch (Exception ex) {
                re.setPerformative(MessageConstants.FAILURE);
                re.setReason(ex.toString());
            }

            re.setContent(nq);
            try {
                sendMessage(re);
            } catch (InvisibleContainerException ex) {
                logWarning(ex.toString());
            }
            re.release();
        } else {
            sendNotUnderstood(m,
                    "Wrong QUERY ontology (" + m.getOntology() + ")");
            logWarning("Wrong QUERY ontology (" + m.getOntology() + ")");
        }
        m.release();
    }


    /**
     * Abstract search method. Overridden by AgentDir and ServiceDir to perform appropriate search
     * @param query Query - query which may be performed
     */
    protected abstract void search(final Query query);

    /**
     * Searching by parameter and its value.
     * @param param String
     * @param value String
     * @return QueryResult[]
     */
    public Query.QueryResult[] search(final String param, final String value)
    {
        final Query q= new Query();
        q.setParam(param);
        q.setValue(value);

        search(q);
        return q.getQueryResult().toArray(EMPTY_ARRAY);
    }

    /**
     * <p>Title: A-Globe </p>
     * <p>Description: DEPRECATED. Shell of <code>DirService</code> </p>
     */
    public final static class Shell extends ServiceShell
    {
        /**
         * Service shell name
         */
        private String name;

        /**
         * Instance of DirService.
         */
        transient DirService theservice = null;

        /**
         * Constructor used for serialization purposes. DO NOT USE THIS constructor.
         */
        public Shell() {
            super();
        }

        /**
         * Private constructor of Shell. It is called from
         * <code>getServiceShell()</code> of <code>DirService</code>.
         *
         * @param shellOwner ElementaryEntity
         * @param _theservice DirService
         */
        private Shell(final ShellOwner shellOwner, final DirService _theservice) {
            super(shellOwner);
            theservice = _theservice;
            name = theservice.name;
        }

        /**
         * Returns true if the service is valid.
         * @return boolean
         */
        @Override
        public boolean isValid() {
            return theservice != null;
        }

        /**
         * This method assigns a container to the <code>Shell</code> of the
         * <code>DirService</code>.
         *
         * @param container AgentContainer
         * @throws Exception
         */
        @Override
        public void setContainer(final AgentContainer container) throws Exception {
            final Service s = container.getServiceManager().getServiceInstance(name);
            if ((s != null) && (s instanceof DirService)) {
                theservice = (DirService) s;
            } else {
                throw new Exception(container.getContainerName() + ": Cannot reconect to the Dir Service");
            }
        }

        /**
         * Called after initialize of the owner agent
         */
        @Override
        public void postInit() {

        }

        /**
         * This is search method in the <code>Shell</code> of the <code>DirService
         * </code>.
         * @param param String
         * @param value String
         * @return QueryResult[]
         */
        public Query.QueryResult[] search(final String param, final String value) {
            return theservice.search(param, value);
        }

        /**
         * Externalizable method
         * @param out ObjectOutput
         * @throws IOException
         */
        @Override
        public void writeExternal(final ObjectOutput out) throws IOException {
            super.writeExternal(out);
            out.writeObject(name);
        }

        /**
         * Externalizable method
         * @param in ObjectInput
         * @throws IOException
         * @throws ClassNotFoundException
         */
        @Override
        public void readExternal(final ObjectInput in) throws IOException, ClassNotFoundException {
            super.readExternal(in);
            name = (String) in.readObject();
        }

    }
}
