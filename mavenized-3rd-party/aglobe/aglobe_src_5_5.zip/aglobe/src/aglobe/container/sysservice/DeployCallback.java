package aglobe.container.sysservice;

import aglobe.container.agent.*;
import aglobe.container.service.*;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: Deploy callback listener. Is used internally for notifying about
 * deploy status.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.8 $ $Date: 2008/11/23 09:14:11 $
 */
public interface DeployCallback {

  /**
   * Positive result of deployment.
   */
  public static final String DONE   = "DONE";
  /**
   * Negative result of deployment.
   */
  public static final String FAILED = "FAILED";
  /**
   * Negative result of deployment.
   */
  public static final String REFUSE = "REFUSE";


  /**
   * This method is called if deployment of the agent was finished
   * with a result.
   * @param result String - result of the deploy process, one of the DONE, FAILED or REFUSE constant
   * @param agent Agent - agent which initiated the deploy process
   */
  public void agentDeployFinished(String result, Agent agent);


  /**
  * This method is called if deployment of the service was finished
   * with a result.
   * @param result String - result of the deploy process, one of the DONE, FAILED or REFUSE constant
   * @param service Service - service which initiated the deploy process
   */
  public void serviceDeployFinished(String result, Service service);
}
