package aglobe.container.sysservice;

import aglobe.container.agent.*;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: Agent mover callback listener. It is used internally in A-globe
 * for notifying about agent migration status.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.8 $ $Date: 2009/02/12 07:47:48 $
 */

public interface AgentMoverCallback
{
  /**
   * Positive result of deployment.
   */
  public static final Result DONE   = new Result();

  /**
   * Negative result of deployment.
   */
  public static final Result FAILED = new Result();

  /**
   * This method is called if deployment of the agent was finished with a result.
   *
   * @param result Result
   * @param agent deploying agent
   */
  public void agentMoveFinished(Result result, Agent agent);

  /**
   *
   * <p>Title: A-globe</p>
   *
   * <p>Description: Result object</p>
   *
   * <p>Copyright: Copyright (c) 2006</p>
   *
   * <p>Company: Agent Technology Center, Gerstner Laboratory</p>
   *
   * @author David Sislak
   * @version $Revision: 1.8 $ $Date: 2009/02/12 07:47:48 $
   */
  public static class Result {
      /**
       * Cannot be constructed from outside
       */
      private Result() {
      }
  }
}
