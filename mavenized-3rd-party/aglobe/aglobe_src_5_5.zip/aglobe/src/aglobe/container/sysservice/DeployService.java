package aglobe.container.sysservice;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import aglobe.container.library.LibraryManager;
import aglobe.container.library.LibraryRequesterCallback;
import aglobe.container.service.CMService;
import aglobe.container.service.ServiceShell;
import aglobe.container.service.ShellOwner;
import aglobe.container.task.Task;
import aglobe.container.transport.Address;
import aglobe.container.transport.InvisibleContainerException;
import aglobe.ontology.AgentInfo;
import aglobe.ontology.Message;
import aglobe.ontology.MessageConstants;
import aglobe.ontology.ServiceInfo;


/**
 * <p>Title: A-Globe</p>
 * <p>Description: Standard platform service, used to remotely deploy agent/service.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.37 $ $Date: 2010/12/01 12:36:10 $
 */
public final class DeployService extends CMService
{
    /**
     * Name of the service.
     */
    public static final String SERVICENAME= "container/deploy";

    /**
     * List of deployers
     */
    private LinkedList<Deployer> deployers = new LinkedList<Deployer>();

    /**
     * Public constructor of the service. It creates and sets the
     * <code>IdleTask</code> of the service.
     */
    public DeployService()
    {
        setIdleTask(new IdleTask(this, true));
    }

    /**
     * This method return always null, because there is no <code>Shell</code>
     *
     * @return null
     * @param shellOwner ElementaryEntity
     */
    @Override
    public ServiceShell getServiceShell(ShellOwner shellOwner)
    {
        return null;
    }

    /**
     * <p>Title: A-Globe</p>
     * <p>Description: It is the task which handles incoming message if there is no other
     * task associated for it.</p>
     */
    private class IdleTask extends Task {
        /**
         * Owner service
         */
        DeployService owner;

        /**
         * Constructor
         * @param owner DeployService
         */
        IdleTask(DeployService owner, boolean messageAsReference) {
            super(owner, messageAsReference);
            this.owner = owner;
        }

        /**
         * This is method for handling incoming messages. If there is a service or
         * an agent send a request, it is added to the list.
         * @param m a message
         */
        @Override
        synchronized public void handleIncomingMessage(Message m) {
            if (m.getPerformative().equalsIgnoreCase(MessageConstants.REQUEST)) {
                if ((m.getContent() instanceof AgentInfo) || (m.getContent() instanceof ServiceInfo)) {
                    synchronized (owner.deployers) {
                        owner.deployers.add(new Deployer(owner, m, true));
                        return;
                    }
                } else {
                    owner.logWarning("Bad ontology: " + m.getOntology());
                    sendNotUnderstood(m, "Bad ontology");
                }
            } else {
                owner.logWarning("Bad performative: " + m.getPerformative()+"\n"+m);
                sendNotUnderstood(m, "Bad performative");
            }
            m.release();
        }
    }


    /**
     *
     * <p>Title: A-Globe</p>
     * <p>Description: This task deployes an agent or a service. </p>
     */
    private class Deployer extends Task implements LibraryRequesterCallback {
        /**
         * Owner of the Deployer.
         */
        DeployService owner;

        /**
         * A message.
         */
        Message m;

        /**
         * Information about an agent.
         */
        AgentInfo ai;

        /**
         * Information about a service.
         */
        ServiceInfo si;

        /**
         * Flag of finished deployer task.
         */
        boolean finished = false;

        /**
         * Libraries transfered correctly.
         */
        boolean libsOK = true;

        /**
         * Number of libraries.
         */
        int libcnt;

        /**
         * Constructor of deployer Task.
         * @param owner is a <code>DeployService</code>
         * @param m message with <code>AgentInfo</code> or <code>ServiceInfo</code>
         * to be transfered. Destination of the agent/service is container where
         * runs <code>DeployService</code>.
         */
        @SuppressWarnings("unused")
		public Deployer(DeployService owner, Message m) {
            this(owner, m, false);
        }

        /**
         * Constructor of deployer Task.
         * @param owner is a <code>DeployService</code>
         * @param m message with <code>AgentInfo</code> or <code>ServiceInfo</code>
         * to be transfered. Destination of the agent/service is container where
         * runs <code>DeployService</code>.
         * @param messageAsReference boolean
         */
        Deployer(DeployService owner, Message m, boolean messageAsReference) {
            super(owner, messageAsReference);

            this.owner = owner;
            this.m = m;
            if (m.getContent() instanceof AgentInfo) {
                ai = (AgentInfo) m.getContent();
                si = null;
            } else {
                ai = null;
                si = (ServiceInfo) m.getContent();
            }

            Address srcContainer = m.getSender().deriveContainerAddress();

            boolean duplicate = false;
            List<String> libs;
            if (ai != null) {
                libs = ai.getLibraries().getLibrary();
                if (owner.getContainer().getAgentManager().existsAgent(ai.getName())) {
                    duplicate = true;
                } else {
                    for (Iterator<Deployer> iter = owner.deployers.iterator(); iter.hasNext(); ) {
                        Deployer item = iter.next();
                        if (item.finished) {
                            iter.remove();
                        } else {
                            if ((item.ai != null) && myEqueals(ai, item.ai)) {
                                duplicate = true;
                                break;
                            }
                        }
                    }
                }
            } else {
                libs = si.getLibraries().getLibrary();
                if (owner.getContainer().getServiceManager().existsService(si.getName())) {
                    duplicate = true;
                } else {
                    for (Iterator<Deployer> iter = owner.deployers.iterator(); iter.hasNext(); ) {
                        Deployer item = iter.next();
                        if (item.finished) {
                            iter.remove();
                        } else {
                            if ((item.si != null) && myEqueals(si, item.si)) {
                                duplicate = true;
                                break;
                            }
                        }
                    }
                }
            }

            if (duplicate) {
                Message re = m.getReply();
                re.setPerformative(MessageConstants.REFUSE);
                try {
                    sendMessageAsReference(re);
                } catch (InvisibleContainerException ex) {
                    owner.logWarning("Cannot send refuse to the requester: " + ex);
                }
                re.release();
                finished = true;
                cancelTask();
            } else {
                Message re = m.getReply();
                re.setPerformative(MessageConstants.AGREE);
                try {
                    sendMessageAsReference(re);
                } catch (InvisibleContainerException ex1) {
                    owner.logWarning("Cannot send agree to the requester: " + ex1);
                }
                re.release();

                LibraryManager lm = getContainer().getLibraryManager();
                libcnt = libs.size();
                if (libcnt > 0) {
                    for (Iterator<String> i = libs.iterator(); i.hasNext(); ) {
                        lm.obtainLibrary(owner.getContainer(),
                                srcContainer, i.next(), this);
                    }
                } else {
                    libraryRequestFinished(DONE);
                }
            }
        }

        /**
         * This method compares two agents by their AgentInfo.
         * @param ai1 <code>AgentInfo</code> of the first agent.
         * @param ai2 <code>AgentInfo</code> of the second agent.
         * @return true if name, readable name, type and main class are the same.
         */
        private boolean myEqueals(AgentInfo ai1, AgentInfo ai2) {
            if (!ai1.getName().equals(ai2.getName())) {
                return false;
            }
            if (!ai1.getReadableName().equals(ai2.getReadableName())) {
                return false;
            }
            if (!ai1.getType().equals(ai1.getType())) {
                return false;
            }
            if (!ai1.getMainClass().equals(ai2.getMainClass())) {
                return false;
            }
            return true;
        }

        /**
         * This method compares two services by ServiceInfo.
         * @param si1 <code>ServiceInfo</code> of the first service.
         * @param si2 <code>ServiceInfo</code> of the second service.
         * @return true if name and main class are the same.
         */
        private boolean myEqueals(ServiceInfo si1, ServiceInfo si2) {
            if (!si1.getName().equals(si2.getName())) {
                return false;
            }
            if (!si1.getMainClass().equals(si2.getMainClass())) {
                return false;
            }
            return true;
        }

        /**
         * The method handles massages with a exception. It cancels the deployer
         * task.
         * @param m a message
         * @param ex an exception
         */
        @SuppressWarnings("unused")
		public void handleIncomingMessage(Message m, Exception ex) {
            cancelTask();
        }

        /**
         * This method handles results of library transport.
         *
         * @param result Result
         */
        @Override
		synchronized public void libraryRequestFinished(LibraryRequesterCallback.Result result) {
            if (result == FAILED) {
                libsOK = false;
            }
            if (libcnt > 0) {
                --libcnt;
            }
            if (libcnt == 0) {
                if (libsOK) {
                    try {
                        Message re = m.getReply();
                        re.setPerformative(MessageConstants.INFORM_DONE);
                        try {
                            if (ai != null) {
                                owner.getContainer().getAgentManager().createAgent(ai, false);
                            } else {
                                owner.getContainer().getServiceManager().registerService(si, false);
                            }
                        } catch (Exception ex) {
                            owner.logSevere("Error while starting Agent/Service: " + ex);
                        }
                        sendMessageAsReference(re);
                        re.release();
                        finished = true;
                        cancelTask();
                        return;
                    } catch (InvisibleContainerException ex1) {
                        owner.logWarning("Cannot send done to the requester: " + ex1);
                    }
                } else {
                    Message re = m.getReply();
                    re.setPerformative(MessageConstants.FAILURE);
                    try {
                        sendMessageAsReference(re);
                        finished = true;
                        cancelTask();
                    } catch (InvisibleContainerException ex) {
                        owner.logWarning("Cannot send failure to the requester: " + ex);
                    }
                    re.release();
                }
            }
        }

        /**
         * The empty method for message handling of the Deployer task.
         *
         * @param m Message
         */
        @Override
		public void handleIncomingMessage(Message m) {
        }

        /**
         * Cancel the task
         */
        @Override
        public void cancelTask() {
            if (m != null) {
                m.release();
                m = null;
            }
            super.cancelTask();
        }
    }
}
