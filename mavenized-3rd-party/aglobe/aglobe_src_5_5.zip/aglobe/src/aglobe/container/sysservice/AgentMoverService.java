package aglobe.container.sysservice;

import aglobe.container.EventReceiver;
import aglobe.container.agent.Agent;
import aglobe.container.service.CMService;
import aglobe.container.service.ServiceShell;
import aglobe.container.service.ShellOwner;
import aglobe.container.task.TimeoutTask;
import aglobe.container.transport.Address;
import aglobe.container.transport.InvisibleContainerException;
import aglobe.ontology.AgentInfo;
import aglobe.ontology.Message;
import aglobe.ontology.MessageConstants;


/**
 * <p>Title: A-Globe</p>
 * <p>Description: This service moves an agent between two containers.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.33 $ $Date: 2010/08/04 11:48:05 $
 */
public final class AgentMoverService extends CMService
{
    /**
     * Timeout for agent motion.
     */
    private static final int TIMEOUT = 10000;

    /**
     * Name of the service.
     */
    public final static String SERVICENAME = "agent/mover";

    /**
     * This method create a task that moves the agent.
     *
     * @param a Agent - instance of agent to move
     * @param ai AgentInfo - <code>AgentInfo</code> of the moving agent
     * @param callback AgentMoverCallback - callback listener where result be sent
     * @param timeoutThreadReceiver EventReceiver - timeout thread receiver. If null, service will be used as receiver
     */
    public void moveAgent(Agent a, AgentInfo ai, AgentMoverCallback callback, EventReceiver timeoutThreadReceiver)
    {
        if (timeoutThreadReceiver != null) {
            new AgentMoverTask(this, a, ai, callback, timeoutThreadReceiver, true);
        } else {
            new AgentMoverTask(this, a, ai, callback, this, true);
        }
    }

    /**
     * <p>Title: A-Globe</p>
     * <p>Description: this task is responsible for agent motion</p>
     */
    private static class AgentMoverTask extends TimeoutTask
    {
        /**
         * Task owner service.
         */
        AgentMoverService owner;

        /**
         * Moving agent.
         */
        Agent agent;

        /**
         * <code>AgentInfo</code> of the moving agent.
         */
        AgentInfo ai;

        /**
         * Callback.
         */
        AgentMoverCallback callback;

        /**
         * Lock for synchronizing.
         */
        Object lock= new Object();

        /**
         * Flag for finished movement.
         */
        boolean finished= false;

        /**
         * Constructor of <code>AgentMoverTask</code>
         *
         * @param owner AgentMoverService - owner an <code>AgentMoverService</code>
         * @param a Agent - is moving agent
         * @param ai AgentInfo - is <code>AgentInfo</code> of the moving agent.
         * @param callback AgentMoverCallback
         * @param timeoutThreadReceiver EventReceiver - timeout thread receiver
         */
        public AgentMoverTask(AgentMoverService owner, Agent a, AgentInfo ai, AgentMoverCallback callback, EventReceiver timeoutThreadReceiver, boolean messageAsReference)
        {
            super(owner, TIMEOUT, timeoutThreadReceiver, messageAsReference);
            this.owner= owner;
            this.agent= a;
            this.ai= ai;
            this.callback= callback;


            synchronized(lock) {
                Address target= agent.getMigrationDest().deriveServiceAddress(DeployService.SERVICENAME);
                Message m= Message.newInstance(MessageConstants.REQUEST, owner.getAddress(), target);
                m.setContent(ai);
                try {
                    sendMessage(m);
                }
                catch (InvisibleContainerException ex) {
                    //owner.logWarning("Undeliverable message. Cannot move.");
                    finish(AgentMoverCallback.FAILED);
                }
                m.release();
            }
        }

        /**
         * This method cancels task when the time is out.
         */
        @Override
        protected void timeout()
        {
            synchronized(lock) {
                owner.logWarning("Timeout while moving agent: "+ai.getName());
                finish(AgentMoverCallback.FAILED);
            }
        }

        /**
         * This method cancels the deploy task.
         * @param r is status defined in <code>DeployCallback</code>
         */

        private void finish(AgentMoverCallback.Result r)
        {
            synchronized(lock) {
                if(!finished) {

                    finished= true;
                    cancelTask();
                    try {
                        callback.agentMoveFinished(r, agent);
                    } catch (Exception e) {
                        owner.logSevere("Exception thrown by 'agentMoveFinished' method: " + e);
                    }
                }
            }
        }

        /**
         * Handles incoming messages into the task.
         * @param m Message
         */
        @Override
		public void handleIncomingMessage(Message m)
        {
            synchronized (lock) {
                if (m.getPerformative().equals(MessageConstants.INFORM_DONE)) {
                    finish(AgentMoverCallback.DONE);
                } else if (m.getPerformative().equals(MessageConstants.FAILURE)) {
                    finish(AgentMoverCallback.FAILED);
                } else if (m.getPerformative().equals(MessageConstants.REFUSE)) {
                    finish(AgentMoverCallback.FAILED);
                }
            }
            m.release();
        }
    }

    /**
     * This method returns null, because there is no <code>Shell</code>.
     *
     * @return ServiceShell
     * @param shellOwner ElementaryEntity
     */
    @Override
    public ServiceShell getServiceShell(ShellOwner shellOwner)
    {
        return null;
    }
}
