/**
 *
 */
package aglobe.container;

import aglobe.container.agent.Agent;

/**
 * @internal
 * <p>Title: A-globe</p>
 *
 * <p>Description: Takes care about running entity in separate thread. It also catch all un-catched exceptions
 * by entity.</p>
 *
 * <p>Copyright: Copyright (c) 2009</p>
 *
 * <p>Company: Agent Technology Center</p>
 *
 * @author David Sislak
 * @version $Revision: 1.3 $ $Date: 2010/08/04 11:48:05 $
 *
 */
public abstract class EntityRunner implements Runnable {
    /**
     * entity instance
     */
    protected ElementaryEntity entity;

    /**
     * Entity thread group
     */
    final ThreadGroup entityThreadGroup;

    /**
     * @internal
     * Constructor
     * @param a - entity to run
     * @param tg ThreadGroup - run in specified thread group
     */
    public EntityRunner(final ElementaryEntity e, final ThreadGroup tg) {
        entity = e;
        entityThreadGroup = tg;
        entity.myEntityRunner = this;
    }

    /**
     * @internal
     * Run method
     */
    @Override
	public final void run() {
        if (!entity.run()) {
            // release assigned thread to agent without finishing agent
            return;
        }
        entity.hideGUI();
        if (entity.getState() != Agent.MIGRATING) {
            entity.destroyGUI();
            entity.finish();
        } else {
            entity.hideGUI();
        }
        entity.sysFinish();

        entityFinished();
    }

    abstract protected void entityFinished();
}
