package aglobe.container;

import aglobe.ontology.*;
import aglobe.container.transport.InvisibleContainerException;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: Interface implemented by every entity able to sent messages.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.12 $ $Date: 2009/06/15 13:38:01 $
 */
public interface MessageSender
{
  /**
   * Send message. The message is cloned during transmission. The
   * size of the successfully transmitted message can be retrieved by the subsequent
   * call of the getLastMessageSize method.
   * @param m Message - message to send
   * @throws InvisibleContainerException - thrown when target agent container is not visible
   */
  public void sendMessage(Message m) throws InvisibleContainerException;

  /**
   * The message is passed as a reference. It is not duplicated. The
   * size of the successfully transmitted message can be retrieved by the subsequent
   * call of the getLastMessageSize method. If it is not possible to pass message as reference,
   * the object is transmitted as normal message, but on the destination JVM the instance of
   * the message can be shared by more receivers again.
   *
   * @param m is a message to send
   * @throws InvisibleContainerException
   */
  public void sendMessageAsReference(Message m)  throws InvisibleContainerException;


  /**
   * Get Agent container of the entity
   * @return AgentContainer
   */
  public AgentContainer getContainer();
}
