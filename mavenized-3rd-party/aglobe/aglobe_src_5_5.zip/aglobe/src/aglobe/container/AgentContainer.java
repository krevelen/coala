package aglobe.container;

import java.io.File;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.lang.management.ManagementFactory;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Logger;

import javax.swing.SwingUtilities;

import aglobe.container.agent.AgentManager;
import aglobe.container.gui.AgentContainerGUI;
import aglobe.container.library.LibraryManager;
import aglobe.container.service.Service;
import aglobe.container.service.ServiceManager;
import aglobe.container.service.ServiceShell;
import aglobe.container.service.ShellOwner;
import aglobe.container.sharedobjects.SharedObjectsManager;
import aglobe.container.sysservice.DeployService;
import aglobe.container.transport.Address;
import aglobe.container.transport.InvisibleContainerException;
import aglobe.container.transport.MessageTransport;
import aglobe.ontology.AgentInfo;
import aglobe.ontology.AgentList;
import aglobe.ontology.Command;
import aglobe.ontology.ContainerStartup;
import aglobe.ontology.Message;
import aglobe.ontology.MessageConstants;
import aglobe.ontology.ServiceInfo;
import aglobe.ontology.ServiceList;
import aglobe.platform.Platform;
import aglobe.platform.thread.AglobeThreadPool;
import aglobe.platform.transport.RecepientNotFound;
import aglobe.service.directory.DirectoryService;
import aglobe.service.link.LinkService;
import aglobe.service.sniffer.SnifferService;
import aglobe.service.topics.TopicsHandler;
import aglobe.service.topics.TopicsService;
import aglobe.service.visibility.RangeVisibilityService;
import aglobe.service.visibility.VisibilityService;
import aglobe.util.AglobeXMLtools;
import aglobe.util.ExceptionPrinter;
import aglobe.util.GUIUtils;
import aglobex.service.agentmonitor.AgentMonitorService;
import aglobex.web.server.WebServerService;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: The agent container core. In the container runs services
 * and agents.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.125 $ $Date: 2010/12/03 12:29:26 $
 *
 */
public final class AgentContainer {
    /**
     * @internal
     * Name of the command service.
     */
    public static final String COMMANDSERVICE = "container/command";

    /**
     * @internal
     * Name of the directory service.
     */
    public static final String SERVICEDIR = "container/service/directory";

    /**
     * @internal
     * Name of the agent directory service.
     */
    public static final String AGENTDIR = "container/agent/directory";

    /**
     * @internal
     * Name of the library directory service.
     */
    public static final String LIBDIR = "container/library/directory";

    /**
     * A default name of the container.
     */
    private static String DEFAULTNAME = "Container";

    /**
     * @internal
     * A default system name
     */
    public static final String DEFAULT_SYSTEM_NAME = "default";

    /**
     * Time in mills to stop agents and services.
     */
    private static final int SHUTDOWNTIMEOUT = 5000;

    /**
     * Name of the container.
     */
    private String name = null;

    /**
     * Root directory of store of the container.
     */
    private String storeRootDir = null;

    /**
     * false if in store are folders for each container
     */
    private boolean useDirectlyStoreRootDir = false;

    /**
     * true if stores are read only
     */
    private boolean readOnlyStores = false;

    /**
     * Manager of services in the container.
     */
    private LibraryManager lm = null;

    /**
     * <code>ClassFinder</code> of the container
     */
    private ClassFinder cf = null;

    private static final ClassLoader systemClassLoader = Platform.class.getClassLoader();

    /**
     * <code>MesageTransport</code> of the container.
     */
    private MessageTransport mt = null;

    /**
     * Manager of services in container.
     */
    private ServiceManager sm = null;

    /**
     * Manager of agents in container.
     */
    private AgentManager am = null;

    /**
     * GUI of the container.
     */
    private AgentContainerGUI gui = null;

    /**
     * Properties of the container.
     */
    private Properties properties = new Properties();

    /**
     * Properties which has more values.
     */
    private HashMap<String,LinkedList<String>> multipleProperties = new HashMap<String,LinkedList<String>>();

    /**
     * Convenience timer for scheduling timeouts etc. Could be used by all
     * container components.
     */
    public final Timer TIMER = Platform.TIMER;

    /**
     * The logging levels
     * SEVERE (highest)- fatal errors+singleton errors
     * WARNING         -
     * INFO            -
     * CONFIG          -
     * FINE            -
     * FINER           -
     * FINEST (lowest) -
     */
    private Logger logger = null;

    {
        logger = Logger.getLogger("AgentContainer");
    }

    /**
     * Thread group of the container.
     */
    private ThreadGroup containerThreadGroup;

    /**
     * How many thread can go into finalization
     */
    private static AtomicInteger canGoInFinalization = new AtomicInteger(ManagementFactory.getOperatingSystemMXBean().getAvailableProcessors());

    private AtomicInteger shutdownCnt = new AtomicInteger(0);

    private boolean hasTopics = false;
    private boolean topicsNoKeepAlive = false;
    private boolean hasLink = false;

    private String visibilityServiceAttribute = null;

    /**
     * Shared objects manager
     */
    private SharedObjectsManager containerSharedObjectsManager = new
            SharedObjectsManager();

    /**
     * @internal
     * Get container shared objects manager
     * @return SharedObjectsManager
     */
    public SharedObjectsManager getContainerSharedObjectsManager() {
        return containerSharedObjectsManager;
    }

    /**
     * This method returns the name of the container.
     * @return the name of the container
     */
    public String getContainerName() {
        return name;
    }

    /**
     * @internal
     * This method returns the container thread group
     * @return ThreadGroup
     */
    public ThreadGroup getContainerThreadGroup() {
        return containerThreadGroup;
    }

    /**
     * @internal
     * This method returns the LibraryManager from the container
     * @return LibraryManager
     */
    public LibraryManager getLibraryManager() {
        return lm;
    }

    /**
     * @internal
     * This method return the ClassFinder from the container
     * @return ClassFinder
     */
    public ClassFinder getClassFinder() {
        return cf;
    }

    /**
     * This method returns the AgentManager at the container.
     * @return <code>AgentManager</code>
     */
    public AgentManager getAgentManager() {
        return am;
    }

    /**
     * This method returns the <code>ServiceManager</code> at the container.
     * @return <code>ServiceManager</code>
     */
    public ServiceManager getServiceManager() {
        return sm;
    }

    /**
     * This method returns the <code>MesssageTransport</code> at the container.
     * @return <code><MessageTransport></code>
     */
    public MessageTransport getMessageTransport() {
        return mt;
    }

    /**
     * The method returns the value of the property.
     * @param key String - the name of the property
     * @return String - value of that property. If there is no property with requested name, null is returned.
     */
    public String getProperty(String key) {
        return properties.getProperty(key, null);
    }

    /**
     * The method returns all values of the property
     * @param key String - the name of the property
     * @return LinkedList - all values as defined in startup attributes. If there is no property with requested name,
     * null is returned.
     */
    public LinkedList<String> getMultipleProperty(String key) {
        return multipleProperties.get(key);
    }

    /**
     * The method returns the agent's <code>Store</code>.
     * @param name is the agent' name.
     * @return <code>Store</code>
     */
    public Store getAgentStore(String name) {
        Store store = new Store(this.name, storeRootDir, readOnlyStores, useDirectlyStoreRootDir);
        store.setAsAgentStore(name);
        return store;
    }

    /**
     * The method returns <code>Store</code> of the service.
     * @param name is the name of the service.
     * @return <code>Store</code>
     */
    public Store getServiceStore(String name) {
        Store store = new Store(this.name, storeRootDir, readOnlyStores, useDirectlyStoreRootDir);
        store.setAsServiceStore(name);
        return store;
    }

    /**
     * This method returns <code>Store</code> of the container.
     * @return <code>Store</code>
     */
    public Store getLibraryStore() {
        Store store = new Store(this.name, storeRootDir, readOnlyStores, useDirectlyStoreRootDir);
        store.setAsLibraryStore();
        return store;
    }

    /**
     * This method returns <code>Store</code> of the container that is set as
     * a global store.
     * @return <code>Store</code>
     */
    public Store getGlobalStore() {
        Store store = new Store(this.name, storeRootDir, readOnlyStores, useDirectlyStoreRootDir);
        store.setAsGlobalStore();
        return store;
    }

    /**
     * @internal
     * See the parameter description in the <code>Platform</code> constructor.
     *
     * @param args String[] - the command line arguments (see help)
     * @param agentList AgentList - start agent list, starts agents from store
     *   iff null
     * @param serviceList ServiceList - start service list, start services from
     *   store iff null
     * @param librarySourceContainer Address - source container for the libraries. Can be null
     * @throws Exception
     */
    public AgentContainer(String[] args, AgentList agentList,
                          ServiceList serviceList,
                          Address librarySourceContainer) throws Exception {
        List<String> params = Arrays.asList(args);

        int i;

        name = DEFAULTNAME;
        boolean noCommand = false;
        boolean noDirectory = false;
        boolean noMigration = false;
        boolean startWebService = false;
        boolean startAgentMonitorService = false;

        ArrayList<Address> topicsNeighbors = null;

        // if it is set the link service is started
        String linkName = null;
        ArrayList<String> agentListPath = null;

        // read name of container
        if ((i = params.indexOf("-name")) != -1) {
            name = params.get(i + 1);
            logger.fine(getContainerName() + ": Use conatiner name: " + name);
        }

        // read no store change attribute
        if ((i = params.indexOf("-noStoreChange")) != -1) {
            readOnlyStores = true;
            logger.info(getContainerName() + ": store is read only !!!");
        }

        // read no command attribute
        if ((i = params.indexOf("-noCommand")) != -1) {
            noCommand = true;
        }

        // read noDirectory attribute
        if ((i = params.indexOf("-noDirectory")) != -1) {
            noDirectory = true;
        }

        // read noMigration attribute
        if ((i = params.indexOf("-noMigration")) != -1) {
            noMigration = true;
        }
        // read store parameter
        if ((i = params.indexOf("-store")) != -1) {
            storeRootDir = params.get(i + 1);
            logger.fine(getContainerName() + ": Setting Store root to: " +
                        storeRootDir);
        }//read container store attribute
        if ((i = params.indexOf("-containerStore")) != -1) {
            useDirectlyStoreRootDir = true;
        }else {
            logger.fine(getContainerName() + ": Using default Store root.");
        }

        // read all other parameters
        for (Iterator<String> j = params.iterator(); j.hasNext(); ) {
            String item = j.next();
            if (item.equals("-p")) {
                try {
                    if (j.hasNext()) {
                        item = j.next();
                        String[] k = item.split("=");
                        String val="";
                        if (k.length>1) {
                        	val = k[1];
                        }
                        properties.setProperty(k[0], val);
                        LinkedList<String> vals = multipleProperties.get(k[0]);
                        if (vals == null) {
                            vals = new LinkedList<String>();
                            multipleProperties.put(k[0],vals);
                        }
                        vals.add(val);
                    }
                } catch (Exception ex) {
                    logger.warning(getContainerName() + ": Bad param: " + item);
                }
            }
        }

        // read topicsPlatforms addresses
        if ((i = params.indexOf("-topicsPlatforms")) != -1) {
            String[] addresses = params.get(i+1).split(",");
            topicsNeighbors = new ArrayList<Address>(addresses.length);
            for (int j=0; j<addresses.length; j++) {
                try {
                    Address a = Address.getAddress(addresses[j].trim());
                    topicsNeighbors.add(a.derivePlatformAddress());
                } catch (Exception e) {
                    logger.warning(getContainerName()+": Wrong format of -topicsPlatforms\n"+e+
                            "\nTopics platforms will be found automatically if possible.");
                    topicsNeighbors = null;
                    break;
                }
            }

        }

        // read topics
        if ((params.indexOf("-topics")) != -1) {
            hasTopics = true;
        }

        // read topics no keep alive
        if ((params.indexOf("-topicsNoKeepAlive")) != -1) {
            topicsNoKeepAlive = true;
        }

        // link name
        if ((i = params.indexOf("-linkName")) != -1) {
           linkName = params.get(i+1);
        }

        // check web attribute
        if ((params.indexOf("-web") != -1)) {
            startWebService = true;
        }

        // check agent monitor attribute
        if ((params.indexOf("-agentMonitor") != -1)) {
            startAgentMonitorService = true;
        }

        boolean useUniqueNames = false;
        if ((params.indexOf("-uniqueNames") != -1)) {
            useUniqueNames = true;
        }

        // if there is specified that topics should be used, all others options are disabled
        if (hasTopics) {
            linkName = null;
        }

        // try to read system name from the starting parameters
        String systemName = DEFAULT_SYSTEM_NAME;
        if ((i = params.indexOf("-systemName")) != -1) {
            systemName = params.get(i + 1);
            logger.fine(getContainerName() + ": Using system name: " + systemName);
        } else {
           if (hasTopics) {
             logger.info(getContainerName() + ": The system name is not specified. The default one will be used.");
           }
        }

        // find the first occurrence of agent list
        if (( i = params.indexOf("-agentList")) != -1) {
            agentListPath = new ArrayList<String>();
            agentListPath.add(params.get(i+1));
        }
        // find other occurrences of agent list after the first one - allows to join several lists of agents
        for (int j = i+2; j < args.length; j++) {
            if("-agentList".equals(args[j]) && j < args.length - 1){
                agentListPath.add(args[j+1]);
            }
        }

        try {
            // Create container ThreadGroup
            containerThreadGroup = new ThreadGroup(Platform.getPlatformThreadGroup(), "Container: " + name);

            // Initialize the LibraryManager
            lm = new LibraryManager(this);

            // initialize class finder for the container
            cf = new ClassFinder(this);

            // Initialize the MessageTransport
            mt = new MessageTransport(this);
            mt.afterInit();

            // Initialize the ServiceManager
            Map<String,Service> services = new LinkedHashMap<String,Service>();

            if (!noMigration) {
            	// start library directory service
            	services.put(LIBDIR, new LibraryManager.LibraryDir());
            	// start deploy service
            	services.put(DeployService.SERVICENAME, new DeployService());
            }

            // should be topics started?
            final TopicsService topicsService;
            if (hasTopics) {
                topicsService = new TopicsService(systemName, topicsNeighbors, topicsNoKeepAlive);
                services.put(TopicsService.SERVICENAME, topicsService);
            } else {
                topicsService = null;
            }

            LinkService linkService = null;
            if (linkName != null) {
              hasLink = true;
              // start link service
              linkService = new LinkService(linkName, new Shutdown() {
                @Override
				public void shutdownContainer() {
                  AgentContainer.this.shutdown();
                }
              }
              );
              services.put(LinkService.SERVICENAME, linkService);
            }

            if (!noCommand) {
                // create command service after Topics or GIS services, because it uses it
                services.put(COMMANDSERVICE, new CommandService());
            }

            // start service manager
            sm = new ServiceManager(this);

            // initialize the AgentManager
            am = new AgentManager(this);

            // Call the afterContainerInit methods of library manager, message transport, service manager
            if (!noMigration) {
                lm.aferContainerInit(this);
            }
            mt.aferContainerInit();

            // start all system services first
            sm.startSystemServices(services);

            // publish information about initialized container
            Platform.containerInitialized(this);

            // start the Directory Service before other services
            final DirectoryService ds;
            if ((hasTopics | hasLink) && (!noDirectory)) {
                // if this is not master container, start directory service (YP service)
                ds = new DirectoryService();
                sm.startService(DirectoryService.SERVICENAME, ds);
            } else {
                ds = null;
            }

            // the message transport must be the first subscriber of the visibility update
            mt.afterServicesInit();

            // start sniffer service that cares about sending info about the messages and
            // message copy topics. It needs a GIS shell, so needs to be started afterwards.
            SnifferService snifferService = new SnifferService();
            sm.startService(SnifferService.SERVICENAME, snifferService);

            // instead of message transport, VisibilityService is providing the functionality,
            // so we start it here (and it subscribes visibility info updates)
            if (hasTopics | hasLink) {
                VisibilityService visibilityService = null;
                // try to read VisibilityService implementation
                if (( i = params.indexOf("-visibilityService")) != -1) {
                    final Class<?> cl = systemClassLoader.loadClass(params.get(i+1));
                    visibilityServiceAttribute = params.get(i+1);

                    final Constructor<?> con = cl.getConstructor(new Class[] {});
                    Object o = con.newInstance(new Object[] {});
                    if(o instanceof VisibilityService){
                            visibilityService = (VisibilityService)o;
                    }
                    else{
                        logger.severe(getContainerName() + ": Wrong VisibilityService name specified.");
                        shutdown();
                        throw new Exception("Wrong VisibilityService name specified.");
                    }
                }
                else {
                    visibilityService = new RangeVisibilityService();
                }
                sm.startService(VisibilityService.SERVICENAME, visibilityService);
                if (ds != null) {
                    //we need wait till startService is finalized, to be sure that all subscriptions via GIS are registered
                    //  as the first subscriber
                    visibilityService.waitForProcessingAllEvents();
                }
            }

            // then Directory Service should subscribe for visibility info
            if (ds != null) {
                // DS is present, we need subscribe for Visibility information after subscription of VisibilityService
                // which does filtering. Otherwise, messages causing initiation between directory services will be dispatched
                // faster than new visibility restrictions will be applied in VisibilityService
                ds.addEvent(new Runnable() {

                    @Override
                    public void run() {
                        ds.afterMTvisibilitySubscription();
                    }
                });
            }

            if (startWebService) {
                // start web service
                WebServerService wss = new WebServerService();
                sm.startService(WebServerService.SERVICENAME, wss);
                // initialize web server
                wss.initWebServer();
            }

            if (startAgentMonitorService) {
                // start agent monitor service
                AgentMonitorService ams = new AgentMonitorService();
                sm.startService(AgentMonitorService.SERVICENAME, ams);
            }

            // load services as specified in store now
            sm.aferContainerInit(serviceList, librarySourceContainer);

            // build the agent list from the agents in the parameters and the xml-based list in the parameters
            if (null != agentListPath) {
                for (String agList : agentListPath) {
                    // de-serialize each agent list
                    AgentList currentList = (AgentList) AglobeXMLtools.unmarshallJAXBObject(AgentList.class,new File(agList));
                    // append the agent descriptions to the list
                    if (null == agentList){
                        agentList = currentList;
                    } else {
                        agentList.getAgentInfo().addAll(currentList.getAgentInfo());
                    }
                }
            }
            // initialize all agents and start mover service
            am.afterContainerInit(agentList, noMigration, librarySourceContainer,useUniqueNames);

            // call after container initialize method of link service after container initialization is finished
            if (null != linkService) {
                final LinkService lSer = linkService;
                lSer.addEvent(new Runnable() {
                    @Override
					public void run() {
                        lSer.afterContainerInit();
                    }
                }
                );
            }

            // call after container initialize method of TopicsService
            if (null != topicsService) {
                topicsService.addEvent(new Runnable() {

                    @Override
                    public void run() {
                        topicsService.afterContainerInitialization();
                    }

                });
            }

            // Initialize the GUI
            if ((i = params.indexOf("-gui")) != -1) {
                showGUI();
            }

            logger.info(getContainerName() + ": started - " + Address.getLocalContainerAddress(this).toString());
        } catch (Exception ex) {
            logger.severe(getContainerName() + ": Error occured while initialising the container:\n" + ExceptionPrinter.toStringWithStackTrace(ex));
            // shutdown all initialized components
            shutdown();
            throw new Exception("Error occured while initialising the container:\n" + ex);
        }
    }

    /**
     * @internal
     * Return true iff this container has topics enabled
     * @return
     */
    public boolean hasTopics() {
        return hasTopics;
    }

    /**
     * @internal
     * Return true iff this container has link enabled
     * @return
     */
    public boolean hasLink() {
        return hasLink;
    }

    /**
     * Return the class of used VisibilityService
     * @return complete class name of used {@link VisibilityService}
     */
    public String getVisibilitySeviceClassAttribute(){
        return visibilityServiceAttribute;
    }

    /**
     * Container finished, notify platform about container removal
     */
    private void containerFinished() {
        logger.info(getContainerName()+": finished");
        // notify platform runner about container finish
        Platform.containerFinishedNotify(getContainerName());
    }

    /**
     * @internal
     * Shutdown agent container
     */
    public void shutdown() {
        int can = canGoInFinalization.decrementAndGet();
        if (can < 0) {
            canGoInFinalization.incrementAndGet();
            TIMER.schedule(new TimerTask() {
                @Override
                public void run() {
                    shutdown();
                }
            }, 100);
            return;
        }
        if (shutdownCnt.incrementAndGet() != 1) {
            return;
        }

        // create shutdown thread
        AglobeThreadPool.startInNewThread(Platform.
                getPlatformThreadGroup(), new Runnable() {
            @Override
			public void run() {
                // stop AgentManager
                if (am != null) {
                    am.stopAgentManager(SHUTDOWNTIMEOUT);
                }

                // notify about shut down before services will go down
                Platform.containerShuttingDown(AgentContainer.this);

                if (sm != null) {
                    // stop ServiceManager
                    sm.stopServiceManager();
                }

                if (mt != null) {
                    // stop MessageTransport fine
                    mt.stopMessageTransport();
                }

                // hide gui if necessary
                hideGUI();

                // wait for finish
                synchronized (this) {
                    while (containerThreadGroup.activeCount() > 0) {
                        try {
                            this.wait(100);
                        } catch (InterruptedException ex) {
                        }
                    }
                }

                containerFinished();

                try {
                    containerThreadGroup.destroy();
                } catch (Exception ex1) {
                    ex1.printStackTrace();
                }

                canGoInFinalization.incrementAndGet();
            }
        }, "container shutdown thread : " + getContainerName());
    }

    /**
     * Show agent container gui
     */
    private void showGUI() {
        if (gui == null) {
            try {
                SwingUtilities.invokeLater(new Runnable() {
                    @Override
					public void run() {
                        try {
                            gui = new AgentContainerGUI(AgentContainer.this);
                            gui.pack();
                            GUIUtils.positionOnScreen(gui, GUIUtils.hLEFT, GUIUtils.vTOP);
                            gui.setVisible(true);
                        } catch (Exception ex) {
                            logger.warning(getContainerName() +
                                           ": Container GUI cannot be created\n"+ExceptionPrinter.toStringWithStackTrace(ex));
                        }
                    }
                });
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } else {
            javax.swing.SwingUtilities.invokeLater(new Runnable() {
                @Override
				public void run() {
                    gui.setVisible(true);
                }
            });
        }
    }

    /**
     * Hide agent container gui
     */
    private void hideGUI() {
        if (gui != null) {
            javax.swing.SwingUtilities.invokeLater(new Runnable() {
                @Override
				public void run() {
                    gui.setVisible(false);
                }
            });
        }
    }

    /**
     * @internal
     * <p>Title: A-Globe</p>
     * <p>Description: CommandService is a system service that allows
     * execute a command (e.g. show/hide container gui, shutdown container) from other service or agent.</p>
     * <p>Copyright: Copyright (c) 2004</p>
     * <p>Company: Gerstner Laboratory</p>
     * @author David Sislak     * @version $Revision: 1.125 $ $Date: 2010/12/03 12:29:26 $

     */
    public static class CommandService extends aglobe.container.service.Service implements
            MessageConstants {
        private final static String TOPICS_PREFIX = "!^";
        private static int TOPICS_CNT = 1;

        /**
         * Topic identifier used for the implementor prefix
         */
        public final static String TOPIC_COMMAND_IMPLEMENTOR_PREFIX = TOPICS_PREFIX + (TOPICS_CNT++) + "_";

        /**
         * Topic identifier subscribed by all command services
         */
        public final static String TOPIC_COMMAND_IMPLEMENTOR_ALL = TOPICS_PREFIX + (TOPICS_CNT++);

        /**
         * Topic used for sending command service responses
         */
        public final static String TOPIC_COMMAND_RESPONSE_PREFIX = TOPICS_PREFIX + (TOPICS_CNT++) + "_";

        /**
         * Request agent and service list of running entities on the container
         */
        public final static String REQUEST_LIST = "REQUEST_LIST";

        /**
         * Response list of running agents and services in the container
         */
        public final static String RESPONSE_LIST = "RESPONSE_LIST";

        /**
         * Command that shuts down the container.
         */
        public final static String QUIT = "QUIT";

        /**
         * Command that shuts down all containers on platform.
         */
        public final static String KILL_PLATFORM = "KILL_PLATFORM";
        
        /**
         * Command that kills agents specified in parameters with key AGENT key
         */
        public final static String KILL_AGENT = "KILL_AGENT";

        /**
         * Visibility container GUI changing command.
         */
        public final static String GUI = "GUI";

        /**
         * Visibility agent/service GUI changing command
         */
        public final static String ENTITY_GUI = "ENTITY_GUI";

        /**
         * Identifier of visible container GUI.
         */
        public final static String VISIBLE = "Visible";

        /**
         * 'true' constant
         */
        public final static String TRUE = "true";

        /**
         * Agent constant
         */
        public final static String AGENT = "Agent";

        /**
         * Service constant
         */
        public final static String SERVICE = "Service";

        private TopicsService.Shell topicsShell = null;

        /**
         * Constructor
         */
        private CommandService() {
        }

        /**
         * This method returns <code>ServiceShell</code> of the service.
         *
         * @return <code>ServiceShell</code>
         * @param shellOwner ElementaryEntity - agent/service
         */
        @Override
        public ServiceShell getServiceShell(ShellOwner shellOwner) {
            return new Shell(shellOwner, this);
        }

        /**
         * This method starts the service.
         */
        @SuppressWarnings("serial")
        @Override
        public void init() {
            topicsShell = (TopicsService.Shell) getContainer().getServiceManager().getService(this, TopicsService.SERVICENAME);
            if (topicsShell != null) {
                final TopicsHandler handler = new TopicsHandler() {

                    @Override
                    public void handleIncomingTopic(final String topic, final Object content, final String reason) {
                        if (content instanceof Command) {
                            final Responser responser;
                            if (reason != null) {
                                responser = new Responser() {

                                    @Override
                                    public void sendResponse(final Object reply) {
                                        topicsShell.sendTopic(reason, reply);
                                    }

                                };
                            } else {
                                responser = null;
                            }
                            execute((Command) content, responser);
                        } else if (content instanceof ContainerStartup) {
                            startNewContainer((ContainerStartup) content);
                        } else {
                            logWarning("Wrong command ontology: " + content.getClass().getName() + " Topic: "+topic);
                        }
                    }

                    @Override
                    public void addEvent(final Runnable e) {
                        CommandService.this.addEvent(e);
                    }

                };
                topicsShell.subscribeHandlerAsync(TOPIC_COMMAND_IMPLEMENTOR_ALL, handler);
                topicsShell.subscribeHandlerAsync(TOPIC_COMMAND_IMPLEMENTOR_PREFIX+getContainer().getContainerName(), handler);
            }
        }

        /**
         * This method stops the service.
         */
        @Override
        public void finish() {
            if (topicsShell != null) {
                topicsShell.dispose();
                topicsShell = null;
            }
        }

        /**
         * This method handles incoming messages into the service.
         * @param m Message
         * @throws RecepientNotFound
         */
        @Override
		public void handleIncomingMessage(final Message m) throws
                RecepientNotFound {
            if (!m.getPerformative().equalsIgnoreCase(REQUEST)) {
                String msg = "Wrong COMMAND performative (" + m.getPerformative() +
                             ") - message: "+m;
                sendNotUnderstood(m, msg);
                getContainer().logger.warning(msg);
            } else if (m.getContent() instanceof Command) {
                Command c = (Command) m.getContent();
                Message re = m.getReply();

                if (execute(c, new Responser() {
                                @Override
								public void sendResponse(Object reply) {
                                    Message re = m.getReply();
                                    re.setPerformative(MessageConstants.INFORM_RESULT);
                                    re.setContent(reply);
                                    try {
                                        sendMessage(re);
                                    } catch (InvisibleContainerException ex) {
                                        // do nothing
                                    }
                                    re.release();
                                }
                              })
                   ) {
                        re.setPerformative(INFORM_DONE);
                } else {
                    re.setPerformative(FAILURE);
                }
                re.setContent(c);
                try {
                    sendMessage(re);
                } catch (InvisibleContainerException ex) {
                }
                re.release();
            } else if (m.getContent() instanceof ContainerStartup) {
                startNewContainer((ContainerStartup) m.getContent());
            } else {
                String msg = "Wrong COMMAND ontology (" + m.getOntology() + ")";
                sendNotUnderstood(m, msg);
                getContainer().logger.warning(msg);
            }
            m.release();
        }

        /**
         * Execute a command c
         *
         * @param c Command
         * @param responser Responser - can be null,
         * @return boolean - true iff execution was successful
         */
        private boolean execute(Command c, Responser responser) {
            String name = c.getName();
            boolean success = true;

            if (QUIT.equals(name)) {
                getContainer().shutdown();
            } else if (KILL_PLATFORM.equals(name)) {
                Platform.killPlatform();
            } else if (KILL_AGENT.equals(name)) {
            	if (!c.getAglobeParam().isEmpty() && AGENT.equals(c.getAglobeParam().get(0).getName())) {
            		getContainer().getAgentManager().killAgent(c.getAglobeParam().get(0).getValue());
            	} else {
            		return false;
            	}
            } else if (GUI.equals(name)) {
                if (!c.getAglobeParam().isEmpty() &&
                    VISIBLE.equals(c.getAglobeParam().get(0).
                                   getName()))
                    if (c.getAglobeParam().get(0).getValue().
                        equalsIgnoreCase(TRUE)) {
                        getContainer().showGUI();
                    } else if (getContainer().gui != null) {
                        getContainer().hideGUI();
                    }
            } else if (ENTITY_GUI.equals(name)) {
                if ((c.getAglobeParam().size() >= 2) && (AGENT.equals(c.getAglobeParam().get(0).getName())) &&
                (VISIBLE.equals(c.getAglobeParam().get(1).getName()))) {
                    if (TRUE.equals(c.getAglobeParam().get(1).getValue())) {
                        getContainer().getAgentManager().showAgent(c.getAglobeParam().get(0).getValue());
                    } else {
                        getContainer().getAgentManager().hideAgent(c.getAglobeParam().get(0).getValue());
                    }
                } else if ((c.getAglobeParam().size() >= 2) && (SERVICE.equals(c.getAglobeParam().get(0).getName())) &&
                (VISIBLE.equals(c.getAglobeParam().get(1).getName()))) {
                    if (TRUE.equals(c.getAglobeParam().get(1).getValue())) {
                        getContainer().getServiceManager().showService(c.getAglobeParam().get(0).getValue());
                    } else {
                        getContainer().getServiceManager().hideService(c.getAglobeParam().get(0).getValue());
                    }
                }
            } else if (REQUEST_LIST.equals(name)) {
                if (responser == null) {
                    return false;
                }
                Command resp = new Command();
                resp.setName(RESPONSE_LIST);
                // gets list of running agents
                List<AgentInfo> agents = getContainer().getAgentManager().getRunningAgents();
                for (Iterator<AgentInfo> iter = agents.iterator(); iter.hasNext(); ) {
                    AgentInfo item = iter.next();
                    resp.getAglobeParam().add(AglobeXMLtools.makeAglobeParam(
                            AGENT, item.getName()));
                }
                // get list of running services
                List<ServiceInfo> services = getContainer().getServiceManager().
                                getRunningServices();
                for (Iterator<ServiceInfo> iter = services.iterator(); iter.hasNext(); ) {
                    ServiceInfo item = iter.next();
                    resp.getAglobeParam().add(AglobeXMLtools.makeAglobeParam(
                            SERVICE, item.getName()));
                }
                responser.sendResponse(resp);
            } else {
                String result = "Wrong COMMAND name (" + name + ")";
                c.setResult(result);
                getContainer().logger.warning(result);
                success = false;
            }

            return success;
        }

        /**
         * Try start new container
         * @param containerStartupRecord ContainerStartup
         */
        private void startNewContainer(ContainerStartup containerStartupRecord) {
            AgentList al = containerStartupRecord.getAgentList();
            ServiceList sl = containerStartupRecord.getServiceList();
            String attribs[] = containerStartupRecord.getAttribute().
                               toArray(new String[containerStartupRecord.
                                       getAttribute().size()]);
            try {
                aglobe.platform.Platform.startNewContainer(attribs, al, sl,
                        containerStartupRecord.getLibrarySourceContainer());
            } catch (Exception ex) {
                logSevere("Exception during starting new A-globe container: " +
                          ex.toString());
            }

        }

        /**
         *
         * <p>Title: A-globe</p>
         *
         * <p>Description: Shell of the command service. It allows
         * execute a command from other service or agent. </p>
         *
         * <p>Copyright: Copyright (c) 2006</p>
         *
         * <p>Company: Agent Technology Center, Gerstner Laboratory</p>
         *
         * @author David Sislak         * @version $Revision: 1.125 $ $Date: 2010/12/03 12:29:26 $

         */
        public static class Shell extends ServiceShell {
            transient CommandService theservice = null;

            /**
             * Constructor used for serialization purposes. DO NOT USE THIS constructor.
             */
            public Shell() {
                super();
            }

            /**
             * Constructor. It is used by the Command service for returning its shell
             * @param shellOwner ElementaryEntity - agent/service
             * @param _theservice CommandService
             */
            private Shell(ShellOwner shellOwner,
                          CommandService _theservice) {
                super(shellOwner);
                theservice = _theservice;
            }

            /**
             * The method executes a command of the command service.
             * @param c Command - command which will be executed
             * @return boolean - true, if command was executed with ok status
             */
            public boolean execute(Command c) {
                return theservice.execute(c, null);
            }

            /**
             * Returns true if <code>Shell</code> it is possible to execute commands.
             * @return boolean
             */
            @Override
            public boolean isValid() {
                return theservice != null;
            }

            /**
             * Externalizable method
             * @param out ObjectOutput
             * @throws IOException
             */
            @Override
            public void writeExternal(ObjectOutput out) throws IOException {
                super.writeExternal(out);
            }

            /**
             * Externalizable method
             * @param in ObjectInput
             * @throws IOException
             * @throws ClassNotFoundException
             */
            @Override
            public void readExternal(ObjectInput in) throws IOException,
                    ClassNotFoundException {
                super.readExternal(in);
            }

            /**
             * The method sets container to Shell of the command service. After that
             * is possible to execute commands.
             *
             * @param container AgentContainer
             * @throws Exception
             */
            @Override
            public void setContainer(AgentContainer container) throws Exception {
                Service s = container.getServiceManager().getServiceInstance(AgentContainer.COMMANDSERVICE);
                if ((s != null) && (s instanceof AgentContainer.CommandService)) {
                    theservice = (CommandService) s;
                } else {
                    throw new Exception(container.getContainerName() +
                                        ": Cannot reconect to the Command Service");
                }
            }

            /**
             * Called after init of the owner agent
             */
            @Override
            public void postInit() {

            }
        }


        /**
         *
         * <p>Description: Sending responser interface is used for sending
         * asynchronous responses to the requester.</p>
         *
         * <p>Copyright: Copyright (c) 2006</p>
         *
         * <p>Company: Agent Technology Center, Gerstner Laboratory</p>
         *
         * @author David Sislak         * @version $Revision: 1.125 $ $Date: 2010/12/03 12:29:26 $

         */
        private interface Responser {
            /**
             * Send response to the requester
             * @param reply Object
             */
            void sendResponse(Object reply);
        }
    }


    /**
     * @internal
     * <p>Title: A-Globe</p>
     *
     * <p>Description: Shutdown interface provided to specified A-globe
     * container components.</p>
     *
     * <p>Copyright: Copyright (c) 2006</p>
     *
     * <p>Company: Gerstner Laboratory</p>
     *
     * @author David Sislak     * @version $Revision: 1.125 $ $Date: 2010/12/03 12:29:26 $

     */
    public interface Shutdown {
        /**
         * Shutdown A-globe container
         */
        public void shutdownContainer();
    }

}
