package aglobe.container;

import aglobe.ontology.Message;

/**
 * <p>Title: A-Globe<</p>
 *
 * <p>Description: Interface implemented by every entity able to handle incoming messages.</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Agent Technology Center, Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.5 $ $Date: 2009/02/12 07:47:47 $
 */
public interface MessageHandler {
    /**
     * This method must use implementor for handling incoming messages.
     *
     * @param m The message.
     */
     public void handleIncomingMessage(Message m);
}
