package aglobe.container.task;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.TimerTask;
import java.util.logging.Level;

import aglobe.container.AgentContainer;
import aglobe.container.MessageHandler;
import aglobe.container.transport.Address;
import aglobe.container.transport.InvisibleContainerException;
import aglobe.ontology.Message;
import aglobe.util.logging.LogProvider;

/**
 * <p>
 * This class can be registered in an Agent as idle task. DynamicIdleTask
 * supports dynamic adding and removing of MessageHandlers. Using
 * DynamicIdleTask you can create something like nested if-then-else structure
 * or nested switch structure which can be dynamically changed. This
 * decision-structure is than applied on each incoming message, the appropriate
 * handler is selected and this handler's handleIncomingMessage method is
 * called. DynamicIdleTask is optimized for fast message handling which has
 * constant time complexity against number of registered MessageHandlers. A
 * registration of a message handler has also constant time complexity, but the
 * deregistration has linear complexity.
 * </p>
 * <p>
 * You can get instance of this class by using newInstance method. When you do
 * so you have to specify a type of a key (e.g. PROTOCOL, PERFORMATIVE), that
 * will be used for sorting of incoming messages. See class {@link KEYTYPE} for
 * available types. DynamicIdleTask implements MessageHandler, so one
 * DynamicIdleTask can be registered in another. This way complex
 * decision-making structure can be created.
 * </p>
 *
 * <p>
 * Structure of DynamicIdleTask is created automatically according to (@link
 * RegistrationData} passed in a registration. User of DynamicIdleTask has to
 * create an instance of RegistrationData for each MessageHandler that he want
 * to register in DynamicIdleTask structure. @see RegistrationData for how you can
 * specify when the handleIncomingMessage method of the instance of MessageHandler
 * should be called.
 * </p>
 *
 * <p>
 * Here is an example of structure that can be simply created and than print out
 * by toString method of DyanmicIdleTask:
 * </p>
 *
 * <pre>
 *    (PROTOCOL)
 *     |--ACTIVE_TRANSPONDER_PROTOCOL
 *     |  (PERFORMATIVE)
 *     |   |--INITIATE--&gt;aglobex.entitycontrol.deconfliction.cooperative.CooperativeCollisionSolver$CooperativeCollisionSolverIdleTask@301bf5
 *     |   D
 *     |--UTILITY_BASED_DECONFLICTION
 *     |  (PERFORMATIVE)
 *     |   |--CHANGE_PLAN--&gt;aglobex.entitycontrol.deconfliction.cooperative.utilitybased.UtilityBasedCollisionSolver$UtilityBasedSolverIdleTask@c11557
 *     |   |--CANCEL_MASTER_DECONFLICTION--&gt;aglobex.entitycontrol.deconfliction.cooperative.utilitybased.UtilityBasedCollisionSolver$UtilityBasedSolverIdleTask@c11557
 *     |   D
 *     D
 * </pre>
 *
 * <p>
 * In hooks is a type of a key.<br>
 * After "--" is specific value of that type. <br>
 * After this concrete key value (e.g. ACTIVE_TRANSPONDER_PROTOCOL)is an arrow
 * pointing on some MessageHandler or there is another key type under it, which
 * means there is another instance of DynamicIdleTask that sort messages
 * according to this type of a key.<br>
 * In this particular example are used three DynamicIdleTask instances. The top
 * level instance has KEYTYPE PROTOCOL, the others has PERFORMATIVE.
 * </p>
 *
 * <p>
 * Structure of DynamicIdleTask consists of nested instances of DynamicIdleTask.
 * Each instance of DynamicIdleTask can have a default message handler which is used when
 * incoming message doesn't match any "branch" originating from this task. This
 * default message handler can be also another instance of DynamicIdleTask.
 * Before default message handler is a sign "|D-
 * </p>
 *
 * <p>
 * Note that the structure of DynamicIdleTask depends on order of registrations
 * of MessageHandlers and also on KEYTYPE of the top level DynamicIdleTask. The
 * sub-DynamicIdleTask are created automatically by registration process and
 * automatically is set also their KEYTYPE. For more details about registration
 * see {@link #register(aglobe.container.task.DynamicIdleTask.RegistrationData)}
 * </p>
 *
 * <p>
 * For an example how to use this class see the code of the method
 * {@link #simpleTest()}.
 * </p>
 *
 * <p>
 * Copyright: Copyright (c) 2007
 * </p>
 * <p>
 * Company: Gerstner Laboratory
 * </p>
 *
 * @author Jiri Samek
 * @version 1.0
 * @see aglobe.container.task.Task
 * @see aglobe.container.agent.CMAgent#setIdleTask(Task)
 * @see aglobe.container.MessageHandler
 * @see RegistrationData
 */
abstract public class DynamicIdleTask
      extends Task {

    private final ConversationUnit ownerConversationUnit;

    private LinkedHashMap<Object, MessageHandler> handlers = new LinkedHashMap<Object, MessageHandler> ();

    private MessageHandler defaultHandler;


    /**
     * Return DynamicIdleTask with root decision key type PROTOCOL.
     *
     * @param cu ConversationUnit
     * @return DynamicIdleTask
     */
    public static DynamicIdleTask newInstance(ConversationUnit cu) {
        return newInstance(cu, false);
    }

    /**
     * Return DynamicIdleTask with root decision key type PROTOCOL.
     *
     * @param cu ConversationUnit
     * @param messageAsReference boolean
     * @return DynamicIdleTask
     */
    public static DynamicIdleTask newInstance(ConversationUnit cu, boolean messageAsReference) {
        return newInstance(cu, KEYTYPE.PROTOCOL, messageAsReference);
    }



    /**
     * Return DynamicIdleTask for specific KEYTYPE.
     *
     * @param cu ConversationUnit
     * @param keyType KEYTYPE
     * @return DynamicIdleTask
     */
    public static DynamicIdleTask newInstance(ConversationUnit cu,
                                              KEYTYPE keyType) {
        return newInstance(cu, keyType, false);
    }

    /**
     * Return DynamicIdleTask for specific KEYTYPE.
     *
     * @param cu ConversationUnit
     * @param keyType KEYTYPE
     * @param messageAsReference boolean
     * @return DynamicIdleTask
     */
    public static DynamicIdleTask newInstance(ConversationUnit cu,
            KEYTYPE keyType, boolean messageAsReference) {
        switch (keyType) {
        case PROTOCOL:
            return new DynamicIdleTask(cu, messageAsReference) {
                @Override
                String getKey(Message m) {
                    return m.getProtocol();
                }

                @Override
                KEYTYPE keyType() {
                    return KEYTYPE.PROTOCOL;
                }
            };
        case PERFORMATIVE:
            return new DynamicIdleTask(cu, messageAsReference) {
                @Override
                String getKey(Message m) {
                    return m.getPerformative();
                }

                @Override
                KEYTYPE keyType() {
                    return KEYTYPE.PERFORMATIVE;
                }

            };
        case REASON:
            return new DynamicIdleTask(cu, messageAsReference) {
                @Override
                String getKey(Message m) {
                    return m.getReason();
                }

                @Override
                KEYTYPE keyType() {
                    return KEYTYPE.REASON;
                }

            };
        case ONTOLOGY:
            return new DynamicIdleTask(cu, messageAsReference) {
                @Override
                String getKey(Message m) {
                    return m.getOntology();
                }

                @Override
                KEYTYPE keyType() {
                    return KEYTYPE.ONTOLOGY;
                }

            };
        case SENDER:
            return new DynamicIdleTask(cu, messageAsReference) {
                @Override
                Address getKey(Message m) {
                    return m.getSender();
                }

                @Override
                KEYTYPE keyType() {
                    return KEYTYPE.SENDER;
                }

            };
        case CONTENT:
            return new DynamicIdleTask(cu, messageAsReference) {
                @Override
                Object getKey(Message m) {
                    return m.getContent();
                }

                @Override
                KEYTYPE keyType() {
                    return KEYTYPE.CONTENT;
                }

            };
    }
    throw new AssertionError("Unknown KEYTYPE?!");
    }


    private DynamicIdleTask(ConversationUnit cu, boolean messageAsReference) {
        super(cu, messageAsReference);
        this.ownerConversationUnit = cu;
    }

    /**
     * The algorithm goes from the top and tries to match properties like protocol
     * or performative from message to the structure. If the match is successful,
     * than it returns the corresponding MessageHandler.
     *
     * @param m Message
     */
    @Override
	public void handleIncomingMessage(Message m) {
        handleMessage(m);
    }

    private boolean handleMessage(Message m) {
        Object key = getKey(m);
        MessageHandler handler = handlers.get(key);
        if (handleMessage(m, handler))
            return true;

        return handleMessage(m, defaultHandler);
    }

    private boolean handleMessage(Message m, MessageHandler handler) {
        if (handler == null)
            return false;
        if (handler instanceof DynamicIdleTask)
            return ( (DynamicIdleTask) handler).handleMessage(m);
        handler.handleIncomingMessage(m);
        return true;
    }

    abstract Object getKey(Message m);

    abstract KEYTYPE keyType();

    /**
     * Registers MessageHadler contained in registrationData. <br>
     *
     * Each property (KEYTYPE and value) in registration data has to match one
     * instance of DynamicIdleTask. If a new instance is needed then it is
     * created for the first property in registrationData.
     *
     * When first property in registrationData doesn't match KEYTYPE of actual
     * DynamicIdleTask, then the property sequence is searched for the property
     * with this KEYTYPE. If it is not found than the same thing is recursively
     * done for default handler (if it is set and is instance of
     * DynamicIdleTask). If this is also unsuccessful then new DynamicIdleTask
     * is created and used as a default handler (now it is the lower-most
     * default handler).
     *
     * @param registrationData
     *            this object contains MessageHandler to register and sequence
     *            of pairs of KEYTYPE and a value
     *
     * @return <tt>null</tt> if there was no mapping for properties sequence
     *         of this handler, or the previous handler registered in
     *         DynamicIdleTask structure
     *
     */
    public MessageHandler register(RegistrationData registrationData) {

        Object value = registrationData.remove(this.keyType());

        if (value != null) { //if there was property for KEYTYPE of this DynamicIdleTask

            MessageHandler handler = handlers.get(value);
            if (handler != null) {
                if (handler instanceof DynamicIdleTask) {
                    return ( (DynamicIdleTask) handler).register(
                          registrationData);
                }

                //something is already there but we need to put there new
                this.deregister(handler);

            }
            //handler == null or was deregistered right now
            if (registrationData.isEmpty()) {
                handlers.put(value, registrationData.getMessageHandler());
                return handler;
            }
            //properties of registrationData are not empty
            DynamicIdleTask subTask = DynamicIdleTask.newInstance(ownerConversationUnit,
                  registrationData.getFirstKEYTYPE());
            handlers.put(value, subTask);
            subTask.register(registrationData);
            return handler;
        }

        //not compatible key type,use defaultHandler
        if (defaultHandler != null) {
            if (defaultHandler instanceof DynamicIdleTask) {
                return ( (DynamicIdleTask) defaultHandler).register(
                      registrationData);
            }

            // defaultHandler is not instance of DynamicIdleTask
            DynamicIdleTask subTask = DynamicIdleTask.newInstance(ownerConversationUnit,
                  registrationData.getFirstKEYTYPE());
            subTask.setDefaultHandler(defaultHandler);
            defaultHandler = subTask;
            subTask.register(registrationData);
            return null;
        }
        //defaultHandler == null
        DynamicIdleTask subTask = DynamicIdleTask.newInstance(ownerConversationUnit,
              registrationData.getFirstKEYTYPE());
        defaultHandler = subTask;
        subTask.register(registrationData);
        return null;
    }

    /**
     * Removes the mapping.
     *
     * @return the MessageHandler or <tt>null</tt> if there was no mapping for
     *   this handler.
     * @param messageHandler MessageHandler
     */
    public MessageHandler deregister(MessageHandler messageHandler) {

        Iterator<MessageHandler> i = handlers.values().iterator();
        while (i.hasNext()) {
            MessageHandler handler = i.next();
            if (handler == messageHandler) {
                i.remove();
                return messageHandler;
            }

            if (handler instanceof DynamicIdleTask) {
                MessageHandler deregistered = ( (DynamicIdleTask) handler).
                      deregister(messageHandler);
                if (deregistered != null) { //if some handler was deregistered, you can return
                    ( (DynamicIdleTask) handler).isEmpty();
                    deregister(handler);
                    return handler;
                }
            }
        }
        return null;
    }

    /**
     * If there is no map for incoming message, then it will be passed to the
     * default message handler.
     *
     * @return MessageHandler
     */
    public MessageHandler getDefaultHandler() {
        return defaultHandler;
    }

    /**
     * If there is no map for incoming message, then it will be passed to the
     * default message handler. Default handler can be already set by register
     * function and can contain a lot of logic, be aware that this will erase it.
     *
     * @param defaultHandler MessageHandler
     */
    public void setDefaultHandler(MessageHandler defaultHandler) {
        this.defaultHandler = defaultHandler;
    }

    private boolean isEmpty() {
        if (handlers.isEmpty()) {
            if (defaultHandler == null)
                return true;
            if (defaultHandler instanceof DynamicIdleTask) {
                if ( ( (DynamicIdleTask) defaultHandler).isEmpty())
                    return true;
            }
        }
        return false;
    }

    /**
     * <p>
     * Prints a DynamicIdleTask structure to a String.
     * </p>
     * Example:
     *
     * <pre>
     *   (PROTOCOL)
     *    |--ACTIVE_TRANSPONDER_PROTOCOL
     *    |  (PERFORMATIVE)
     *    |	 |
     *    |  |--INITIATE--&gt;aglobex.entitycontrol.deconfliction.cooperative.CooperativeCollisionSolver$CooperativeCollisionSolverIdleTask@301bf5
     *    |  D
     *    |--UTILITY_BASED_DECONFLICTION
     *    |  (PERFORMATIVE)
     *    |	 |
     *    |	 |--CHANGE_PLAN--&gt;aglobex.entitycontrol.deconfliction.cooperative.utilitybased.UtilityBasedCollisionSolver$UtilityBasedSolverIdleTask@c11557
     *    |	 |
     *    |  |--CANCEL_MASTER_DECONFLICTION--&gt;aglobex.entitycontrol.deconfliction.cooperative.utilitybased.UtilityBasedCollisionSolver$UtilityBasedSolverIdleTask@c11557
     *    |  D
     *    D
     * </pre>
     *
     * Supposes that contained messageHandlers has "nice" toString function.
     *
     * @return String
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("\n");
        print("", builder);
        return builder.toString();
    }

    /**
     * Prints a DynamicIdleTask structure to a StringBuilder.
     *
     * @param indent String
     * @param sb StringBuilder
     * @see #toString()
     */
    public void print(String indent, StringBuilder sb) {
        sb.append(indent).append("(").append(keyType()).append(")").append("\n");
        Iterator<Object> iterator = handlers.keySet().iterator();
        while (iterator.hasNext()) {
            Object o = iterator.next();
            sb.append(indent).append(" |--").append(o);
            MessageHandler handler = handlers.get(o);
            if (handler instanceof DynamicIdleTask) {
                sb.append("\n");
                ( (DynamicIdleTask) handler).print(indent + " |  ", sb);
            }
            else {
                sb.append(" --> ").append(printMessageHandler(handler)).append(
                      "\n");
            }
        }
        if (defaultHandler != null) {
            sb.append(indent).append(" D--").append("<default handler>");
            if (defaultHandler instanceof DynamicIdleTask) {
                sb.append("\n");
                ( (DynamicIdleTask) defaultHandler).print(indent + "    ", sb);
            }
            else {
                sb.append("-->").append(printMessageHandler(defaultHandler)).
                      append("\n");
            }
        }
        else {
            sb.append(indent).append(" D\n");
        }
    }

    /**
     * Used in print method, here you can simply change how to print names of
     * MessageHandlers.
     *
     * @param messageHandler MessageHandler
     * @return String
     */
    private String printMessageHandler(MessageHandler messageHandler) {
        return messageHandler.toString();
    }

    /**
     * Only for running of tests of functionality of this class.
     *
     * @param args String[]
     */
    public static void main(String[] args) {
        simpleTest();
    }

    /**
     * A simple test of DynamicIdleTask.
     */
    public static void simpleTest() {
        DynamicIdleTask task = newInstance(new ConversationUnit() {
            @Override
			public ConversationManager getConversationUnit() {
                return null;
            }

            @Override
			public Address getAddress() {
                return null;
            }

            @Override
            public AgentContainer getContainer() {
                return null;
            }

            @Override
            public void sendMessage(Message m) throws InvisibleContainerException {
            }

            @Override
            public void sendMessageAsReference(Message m) throws InvisibleContainerException {
            }

            @Override
            public boolean isLoggable(Level level) {
                return false;
            }

            @Override
            public boolean isLoggable(Level level, int callsBack) {
                return false;
            }

            @Override
            public void log(Level level, LogProvider logProvider) {

            }

            @Override
            public void log(Level level, LogProvider logProvider, int callsBack) {

            }

            @Override
            public void logFine(String message) {

            }

            @Override
            public void logFine(String message, Throwable e) {

            }

            @Override
            public void logFine(String message, int callsBack) {

            }

            @Override
            public void logFine(String message, Throwable e, int callsBack) {

            }

            @Override
            public void logFinest(String message) {

            }

            @Override
            public void logFinest(String message, Throwable e) {

            }

            @Override
            public void logFinest(String message, int callsBack) {

            }

            @Override
            public void logFinest(String message, Throwable e, int callsBack) {

            }

            @Override
            public void logInfo(String message) {

            }

            @Override
            public void logInfo(String message, Throwable e) {

            }

            @Override
            public void logInfo(String message, int callsBack) {

            }

            @Override
            public void logInfo(String message, Throwable e, int callsBack) {

            }

            @Override
            public void logSevere(String message) {

            }

            @Override
            public void logSevere(String message, Throwable e) {

            }

            @Override
            public void logSevere(String message, int callsBack) {

            }

            @Override
            public void logSevere(String message, Throwable e, int callsBack) {

            }

            @Override
            public void logWarning(String message) {

            }

            @Override
            public void logWarning(String message, Throwable e) {

            }

            @Override
            public void logWarning(String message, int callsBack) {

            }

            @Override
            public void logWarning(String message, Throwable e, int callsBack) {

            }

            @Override
            public void addEvent(Runnable e) {

            }

            @Override
            public void handleIncomingMessage(Message m) {

            }

            @Override
            public TimerTask scheduleEvent(Runnable event, long delay) {
                return null;
            }

            @Override
            public TimerTask scheduleEvent(Runnable event, long delay, long period) {
                return null;
            }

            @Override
            public String getName() {
                return null;
            }
        }, KEYTYPE.PROTOCOL);
        MessageHandler handler = new MessageHandler() {
            @Override
			public void handleIncomingMessage(Message m) {}
        };
        RegistrationData data = new RegistrationData(handler,
              DynamicIdleTask.KEYTYPE.PROTOCOL, "protocol1");
        data.add(KEYTYPE.PERFORMATIVE, "performative1");
        task.register(data);
        System.out.println(task.toString());
        data = new RegistrationData(handler,
                                    DynamicIdleTask.KEYTYPE.PERFORMATIVE,
                                    "protocol2");
        task.register(data);
        System.out.println(task.toString());
        task.deregister(handler);
        System.out.println(task.toString());
    }

    static public enum KEYTYPE {
        PROTOCOL,
        PERFORMATIVE,
        TYPE,
        REASON,
        ONTOLOGY,
        SENDER,
        CONTENT;
    }

    /**
     * <p>
     * Instance of this class has information which MessageHandler should be
     * registered and what rules must incoming message satisfy to be redirected to
     * this MessageHandler. Registration data can contain more rules.
     * <p>
     *
     * </p>
     * Each rule consists of <code>keyType</code> and <code>value</code>. KeyType denotes which parameter of
     * message should be checked for specified <code>value</code>.
     * </p>
     *
     * You can create instance of this class with public constructor.
     *
     * @author Jiri Samek
     */
    public static final class RegistrationData {

        private LinkedHashMap<DynamicIdleTask.KEYTYPE, Object> properties =
              new LinkedHashMap<DynamicIdleTask.KEYTYPE,
              Object> (KEYTYPE.values().length);
        private MessageHandler handler;

        /**
         *
         * @param messageHandler
         *            message handler to register in a DynamicIdleTask structure
         * @param keyType
         *            type of key according to which the DynamicIdleTask will
         *            sort incoming messages (e.g. PROTOCOL, PERFORMATIVE, ...).
         * @param value
         *            the value which must the key have ("REQUEST", ...)
         */
        public RegistrationData(MessageHandler messageHandler, KEYTYPE keyType,
                                Object value) {
            add(keyType, value);
            handler = messageHandler;
        }

        /**
         * Adds another rule that specific the sorting of incoming messages in
         * a DynamicIdleTask structure.
         *
         * @param keyType
         *            type of key according to which the DynamicIdleTask will
         *            sort incoming messages (e.g. PROTOCOL, PERFORMATIVE, ...).
         * @param value
         *            the value which must the key have ("REQUEST", ...)
         * @return this registratinData object. Useful for easy adding of
         *         multiple entries.
         */
        public RegistrationData add(KEYTYPE keyType, Object value) {
            properties.put(keyType, value);
            return this;
        }

        private MessageHandler getMessageHandler() {
            return handler;
        }

        /**
         * Retrieves, but does not remove, the first property, or returns
         * <tt>null</tt> if the property list is empty.
         *
         * @return KEYTYPE
         */
        private KEYTYPE getFirstKEYTYPE() {
            return properties.keySet().iterator().next();
        }

        /**
         * Removes the mapping for this key if present.
         *
         * @param keyType
         *            key whose mapping is to be removed.
         * @return previous value associated with specified key, or
         *         <tt>null</tt> if there was no mapping for key. A
         *         <tt>null</tt> return can also indicate that the map
         *         previously associated <tt>null</tt> with the specified key.
         */
        private Object remove(KEYTYPE keyType) {
            return properties.remove(keyType);
        }

        /**
         * Returns <tt>true</tt> if this map contains no key-value mappings.
         *
         * @return <tt>true</tt> if this map contains no key-value mappings.
         */
        private boolean isEmpty() {
            return properties.isEmpty();
        }
    }
}
