package aglobe.container.task;

import aglobe.container.ContainerOwner;
import aglobe.container.EventReceiver;
import aglobe.container.LoggerOwner;
import aglobe.container.MessageHandler;
import aglobe.container.MessageSender;
import aglobe.container.TimerOwner;
import aglobe.container.transport.Address;



/**
 * <p>Title: A-Globe</p>
 * <p>Description: Conversation unit interface. It specifies that the implementor
 * will have its own conversation manager module for handling messages by tasks.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.10 $ $Date: 2009/06/15 13:38:02 $
 */
public interface ConversationUnit extends ContainerOwner, MessageSender, LoggerOwner, EventReceiver, MessageHandler, TimerOwner
{
    /**
     * Gets conversation manager of the implementor entity
     * @return ConversationManager
     */
    public ConversationManager getConversationUnit();

    /**
     * Gets the address of the ConversationUnit
     * @return ConversationManager
     */
    public Address getAddress();

}
