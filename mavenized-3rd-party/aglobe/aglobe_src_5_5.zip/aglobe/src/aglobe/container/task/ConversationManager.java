package aglobe.container.task;


import aglobe.ontology.*;
import aglobe.container.transport.MessageTransport;
import aglobe.container.transport.InvisibleContainerException;

import aglobe.container.*;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @internal
 * <p>Title: A-Globe</p>
 * <p>Description: The conversation manager monitors incoming and outgoing messages of agent/service
 * and groups them into threads by ConversationID.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.27 $ $Date: 2009/06/15 13:38:02 $
 */
public final class ConversationManager implements MessageHandler {

    /**
     * Sender of a message.
     */
    protected ConversationUnit conversationEntityOwner;

    /**
     * Message transport
     */
    private MessageTransport messageTransport = null;

    /**
     * List of tasks.
     */
    private ConcurrentHashMap<String, Task> taskMap = new ConcurrentHashMap<String, Task>();

    /**
     * Registered conversation for the task
     */
    private ConcurrentHashMap<Task,ConcurrentLinkedQueue<String>> registeredConversationsForTaskMap = new ConcurrentHashMap<Task,ConcurrentLinkedQueue<String>>();

    /**
     * Idle task of the conversation manager.
     */
    Task idletask = null;

    /**
     * true iff the conversation manager is being finalized
     */
    private boolean isFinalized = false;


    /**
     * Private constructor of the message manager.
     * @param sender sender of a message
     */
    public ConversationManager(final ConversationUnit sender) {
        conversationEntityOwner = sender;
    }

    /**
     * The method returns container
     * @return AgentContainer
     */
    public AgentContainer getContainer() {
        return conversationEntityOwner.getContainer();
    }

    /**
     * Gets elementary conversation entity of the conversation manager
     * @return ElementaryConversationEntity
     */
    public ConversationUnit getConversationUnit() {
        return conversationEntityOwner;
    }

    /**
     * Registers new task with specified conversation ID
     * @param convID String - conversation ID
     * @param t Task - task for specified conversation ID
     */
    public void registerTask(final String convID, final Task t) {
        if (isFinalized) {
            return;
        }
        taskMap.put(convID, t);
        ConcurrentLinkedQueue<String> clq = registeredConversationsForTaskMap.get(t);
        if (clq == null) {
            clq = new ConcurrentLinkedQueue<String>();
            registeredConversationsForTaskMap.put(t, clq);
        }
        clq.add(convID);
    }

    /**
     * Remove task
     * @param t Task
     */
    public void removeTask(final Task t) {
        if (isFinalized) {
            return;
        }
        ConcurrentLinkedQueue<String> clq = registeredConversationsForTaskMap.remove(t);
        if (clq != null) {
            for (String elem : clq) {
                taskMap.remove(elem);
            }
        }
    }

    /**
     * Set idle task for handling all unsorted messages to any registred task.
     * @param t Task
     */
    public void setIdleTask(final Task t) {
        idletask = t;
    }

    /**
     * Fills all message IDs
     * @param m Message
     */
    public void ensureMessageIDs(final Message m) {
        if (messageTransport == null) {
            messageTransport = conversationEntityOwner.getContainer().getMessageTransport();
        }
        messageTransport.ensureMessageIDs(m);
    }

    /**
     * Sends message from the task.
     * @param m Message
     * @param t Task
     * @throws InvisibleContainerException
     */
    public void sendMessage(final Message m, final Task t) throws InvisibleContainerException {
        ensureMessageIDs(m);

        if (t != idletask) {
            registerTask(m.getConversationID(), t);
        }

        conversationEntityOwner.sendMessage(m);
    }

    /**
     * The message is passed as a reference. It is not duplicated. If it is not possible to pass message as reference, the object is transmitted as normal
     * message, but on the destination JVM the instance of the message can be shared by more receivers again.
     *
     * @param m is a message to send
     * @param t Task
     * @throws InvisibleContainerException
     */
    public void sendMessageAsReference(final Message m, final Task t) throws InvisibleContainerException {
        if (messageTransport == null) {
            messageTransport = conversationEntityOwner.getContainer().getMessageTransport();
        }
        messageTransport.ensureMessageIDs(m);

        if (t != idletask) {
            registerTask(m.getConversationID(), t);
        }

        conversationEntityOwner.sendMessageAsReference(m);
    }


    /**
     * Handles incoming message by the entity owner
     * @param m Message
     */
    @Override
    public void handleIncomingMessage(final Message m) {
        if (isFinalized) {
            m.release();
            return;
        }
        final String convId = m.getConversationID();
        if (convId == null) {
            conversationEntityOwner.logWarning("Parsing message without conversation ID: "+m.toString());
            m.release();
            return;
        }
        final Task t = taskMap.get(convId);
        if ((t != null) && (!t.isCancelled())) {
            t.handleIncomingMessage(m);
            return;
        }
        if ((idletask != null) && (!idletask.isCancelled())) {
            idletask.handleIncomingMessage(m);
            return;
        }
        // no receiver
        m.release();
    }

    /**
     * The owner entity is finished
     */
    public void sysFinish() {
        isFinalized = true;
        if (idletask != null) {
            idletask.cancelTask();
            idletask = null;
        }
        for (Task elem : taskMap.values()) {
            elem.cancelTask();
        }
        taskMap.clear();
        registeredConversationsForTaskMap.clear();
    }

}
