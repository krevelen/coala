package aglobe.container.task;

import aglobe.ontology.Message;
import aglobe.ontology.MessageConstants;
import aglobe.container.MessageHandler;
import aglobe.container.transport.InvisibleContainerException;
import aglobe.container.transport.Address;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: Part of agents/service behavior. Task handles one conversation.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.31 $ $Date: 2010/08/04 11:48:05 $
 *
 */
public abstract class Task implements MessageHandler
{

    /**
     * <code>ConversationManager</code> of the <code>Task</code>
     */
    private ConversationManager cm = null;

    /**
     * true iff task is canceled (do not handle any other incoming messages and timeouts)
     */
    private boolean cancelledTask = false;

    /**
     * Local task receiver
     */
    private Task localTaskReceiver = null;

    /**
     * Send message as reference
     */
    private boolean messageAsReference = false;

    /**
     * The constructor of the <code>Task</code>.
     * @param cu is <code>ConversationUnit</code>
     */
    public Task(final ConversationUnit cu)
    {
        this.cm= cu.getConversationUnit();
    }

    public Task(final ConversationUnit cu, final boolean messageAsReference){
        this.cm = cu.getConversationUnit();
        this.messageAsReference = messageAsReference;
    }

    /**
     * This method cancels this task.
     * This method is public due to cooperation of several tasks
     */
    public void cancelTask()
    {
        if (!cancelledTask) {
            cancelledTask = true;
            cm.removeTask(this);
        }
    }

    /**
     * Is this task canceled ? Canceled task doesn't receive any new message.
     * @return boolean - true if it is canceled
     */
    public boolean isCancelled() {
        return cancelledTask;
    }

    /**
     * Register local task receiver
     * @param localReceiver Task
     */
    protected final void registerLocalReceiverTask(final Task localReceiver) {
        localTaskReceiver = localReceiver;
        localReceiver.localTaskReceiver = this;
    }


    /**
     * This method sends a message through the conversation manager.
     * @param m a message
     * @throws InvisibleContainerException
     */
    public void sendMessage(final Message m) throws InvisibleContainerException
    {
        if (cancelledTask) {
            throw new RuntimeException("Task is cancelled.");
        }
        if ((localTaskReceiver != null) &&
                (cm.getConversationUnit().getAddress() == m.getReceiver())) {
            // redirect to the local task receiver
            cm.ensureMessageIDs(m);
            // register new holder
            m.registerHolder();
            cm.getConversationUnit().addEvent(new Runnable() {
                @Override
				public void run() {
                    if (!localTaskReceiver.isCancelled()) {
                        localTaskReceiver.handleIncomingMessage(m);
                    }
                }
            });
        } else {
            // send remote message
            if (messageAsReference) {
                cm.sendMessageAsReference(m, this);
            } else {
                cm.sendMessage(m, this);
            }
        }
    }

    /**
     * The message is passed as a reference. It is not duplicated.
     * If it is not possible to pass message as reference,
     * the object is transmitted as normal message, but on the destination JVM the instance of
     * the message can be shared by more receivers again.
     *
     * @param m is a message to send
     * @throws InvisibleContainerException
     */
    public void sendMessageAsReference(final Message m)  throws InvisibleContainerException {
        if (cancelledTask) {
            throw new RuntimeException("Task is cancelled.");
        }
        if ((localTaskReceiver != null) &&
                (cm.getConversationUnit().getAddress() == m.getReceiver())) {
            // redirect to the local task receiver
            cm.ensureMessageIDs(m);
            // register new holder
            m.registerHolder();
            cm.getConversationUnit().addEvent(new Runnable() {
                @Override
				public void run() {
                    if (!localTaskReceiver.isCancelled()) {
                        localTaskReceiver.handleIncomingMessage(m);
                    }
                }
            });
        } else {
            // send remote message
            cm.sendMessageAsReference(m, this);
        }
    }

    /**
     * Sends a reply to the message with the same content and NOT_UNDERSTOOD
     * performative.
     *
     * @param m Message
     * @param reason String - can be null
     */
    protected final void sendNotUnderstood(final Message m, final String reason) {
        if (m.getPerformative() == null || !m.getPerformative().equalsIgnoreCase(MessageConstants.NOT_UNDERSTOOD)) { // Never reply NOT_UNDERSTOOD to NOT_INDERSTOOD
            final Message re = m.getReply();
            if (m.getContent() != null)
                re.setContent(m.getContent());
            re.setPerformative(MessageConstants.NOT_UNDERSTOOD);
            if (reason != null) {
                re.setReason(reason);
            }
            try {
                sendMessage(re);
            } catch (InvisibleContainerException ex) {
                // do nothing
            }
            re.release();
        }
    }

    /**
     * This method returns <code>ConversationManager</code> of the task.
     * @return <code>ConversationManager</code>
     */
    public final ConversationManager getConversationManager() {
        return cm;
    }

    /**
     * This method returns ElementaryConversationEntity of the task.
     * @return ElementaryConversationEntity
     */
    public final ConversationUnit getConversationUnit() {
        return cm.getConversationUnit();
    }

    /**
     * Get Address of the task owner
     * @return Address
     */
    public final Address getAddress() {
        return cm.getConversationUnit().getAddress();
    }
}
