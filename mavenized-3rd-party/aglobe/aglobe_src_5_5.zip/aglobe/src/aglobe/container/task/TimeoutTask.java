package aglobe.container.task;

import java.util.TimerTask;

import aglobe.container.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.ReentrantLock;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: Part of agents/service behavior. Task handles one conversation.
 * TimeoutTask adds a timeout facility to the standard task; communication is
 * secured by timeouts.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.26 $ $Date: 2010/08/04 11:48:05 $
 *
 */
public abstract class TimeoutTask extends Task
{
    /**
     * Timer task for the running timer
     */
    protected AtomicReference<TimerTaskEnv> tt = null;

    /**
     * Constructor of the <code>TimeoutTask</code>
     * @param cu is a <code>ConversationUnit</code>
     * @param msec is time in mills when is sheduled method <code>Timeout()</code>
     */
    public TimeoutTask(ConversationUnit cu, int msec) {
        this(cu, msec, false);
    }

    /**
     * Constructor of the <code>TimeoutTask</code>
     * @param cu is a <code>ConversationUnit</code>
     * @param msec is time in mills when is sheduled method <code>Timeout()</code>
     * @param messageAsReference - is message send by reference
     */
    public TimeoutTask(ConversationUnit cu, int msec, boolean messageAsReference) {
        super(cu, messageAsReference);
        tt = new AtomicReference<TimerTaskEnv>();
        rescheduleTimer(msec);
    }

    /**
     * Constructor of the <code>TimeoutTask</code>
     *
     * @param cu is a <code>ConversationUnit</code>
     * @param msec is time in mills when is sheduled method <code>Timeout()</code>
     * @param timeoutThreadReceiver EventReceiver - specify thread where the timeout will be started
     */
    public TimeoutTask(ConversationUnit cu, int msec, EventReceiver timeoutThreadReceiver) {
        this(cu, msec, timeoutThreadReceiver, false);
    }

    /**
     * Constructor of the <code>TimeoutTask</code>
     *
     * @param cu is a <code>ConversationUnit</code>
     * @param msec is time in mills when is scheduled method <code>Timeout()</code>
     * @param timeoutThreadReceiver EventReceiver - specify thread where the timeout will be started
     * @param messageAsReference - is message send by reference
     */

    public TimeoutTask(ConversationUnit cu, int msec, EventReceiver timeoutThreadReceiver, boolean messageAsReference) {
        super(cu, messageAsReference);
        tt = new AtomicReference<TimerTaskEnv>();
        rescheduleTimer(msec, timeoutThreadReceiver);
    }


    /**
     * This method cancels the <code>TimeoutTask</code>
     */
    @Override
    public void cancelTask() {
        for (;;) {
            TimerTaskEnv t = tt.get();
            if (t != null) {
                t.cancelSync.lock();
                try {
                    if (tt.compareAndSet(t, null)) {
                        // got it
                        t.cancel();
                        break;
                    }
                } finally {
                    t.cancelSync.unlock();
                }
            } else {
                break;
            }
        }
        super.cancelTask();
    }

    /**
     * This method is called, when Timeout scheduled by the <code>addTimeout</code>
     * method expires. The system ensures, that the <code>timout</code> method is
     * always called in the Agent message handling thread and therefore it can
     * safely share variables with <code>handleXXX</code> methods.
     */
    abstract protected void timeout();

    /**
     * Reschedules or cancels the timer of this task.
     * It cancels current timer and if the task was not canceled in the meantime, it schedules a new timout.
     * Timeout will be started in the conversation manager owner thread.
     * @param newTimeout new timeout if == 0, timeout is canceled
     */
    protected void rescheduleTimer(long newTimeout) {
        EventReceiver er = getConversationUnit();
        rescheduleTimer(newTimeout, er);
    }

    /**
     * Reschedules or cancels the timer of this task. It cancels current timer and
     * if the task was not canceled in the meantime, it schedules a new timeout.
     *
     * @param newTimeout new timeout if == 0, timeout is canceled
     * @param timeoutEventReceiver EventReceiver - specify thread where the timeout call will be performed
     */
    protected void rescheduleTimer(long newTimeout, final EventReceiver timeoutEventReceiver) {
        TimerTaskEnv newtt = null;
        if (0 != newTimeout) {
            final Timeout timeout = new Timeout();
            newtt = new TimerTaskEnv() {
                @Override
                public void run() {
                    timeoutEventReceiver.addEvent(timeout);
                }
            };
            timeout.setOwnerTask(newtt);
        }
        for (;;) {
            TimerTaskEnv t = tt.get();
            if (newtt != null) {
                newtt.cancelSync.lock();
            }
            try {
                if (tt.compareAndSet(t, newtt)) {
                    if (t != null) {
                        // cancel previous
                        t.cancelSync.lock();
                        try {
                            t.cancel();
                        } finally {
                            t.cancelSync.unlock();
                        }
                    }
                    if (newtt != null) {
                        // schedule new
                        try {
                            getConversationManager().getContainer().TIMER.schedule(newtt, newTimeout);
                        } catch (Exception e) {
                            // timer is already canceled
                        }
                    }
                    return;
                }
            } finally {
                if (newtt != null) {
                    newtt.cancelSync.unlock();
                }
            }
        }
    }

    /**
     *
     * <p>Title: A-Globe</p>
     * <p>Description: Internal task of the timeout task. It is used as a timer
     * timout invocator.</p>
     *
     */
    private class Timeout implements Runnable {
        private TimerTaskEnv forTask;

        private void setOwnerTask(TimerTaskEnv forTask) {
            this.forTask = forTask;
        }

        @Override
		public void run() {
            for (;;) {
                TimerTaskEnv current = tt.get();
                if (current != forTask) {
                    return;
                }
                if (tt.compareAndSet(current, null)) {
                    if (!isCancelled()) {
                        timeout();
                    }
                    return;
                }
            }
        }
    }

    protected abstract class TimerTaskEnv extends TimerTask {
        public ReentrantLock cancelSync = new ReentrantLock();
    }
}
