
package aglobe.container;

import java.util.regex.Pattern;
import java.util.LinkedList;
import java.util.HashSet;
import java.util.Enumeration;
import java.net.URL;
import java.io.File;
import java.util.regex.Matcher;
import java.lang.reflect.Modifier;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.*;
import java.util.jar.JarFile;
import java.util.jar.Manifest;
import java.util.jar.Attributes;
import java.util.jar.JarEntry;
import aglobe.container.library.LibraryManager;
import java.net.URLClassLoader;
import aglobe.util.Logger;

/**
 * @internal
 * <p>Title: A-Globe</p>
 * <p>Description: Internal A-Globe class used for finding all public classes compatible with Agent and Service.</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.18 $ $Date: 2009/05/15 08:46:58 $
 */
public class ClassFinder extends ClassLoader {

  /**
   *   every class except subclasses
   */
  private static Pattern classFilter = Pattern.compile("^([^$]*)\\.class$");

  /**
   * jdk filter
   */
  private static Pattern jdkjarFilter = Pattern.compile("\\\\jdk");

  /**
   * Owner container
   */
  private final AgentContainer container;

  /**
   * Agent class
   */
  private Class<?> agent;

  /**
   * Service class
   */
  private Class<?> service;

  /**
   * Current list of agents. Contains String
   */
  private LinkedList<String> agents_result = new LinkedList<String>();

  /**
   * Hash set of agents. Contains String
   */
  private HashSet<String> agents_test = new HashSet<String>();

  /**
   * Current list of services. Contains String
   */
  private LinkedList<String> services_result = new LinkedList<String>();

  /**
   * Hash set of services. Contains String
   */
  private HashSet<String> services_test = new HashSet<String>();

  /**
   * true iff this class is initialized
   */
  private boolean initialized = false;

  /**
   * true means that list in the cache is still valid. If you load new library set this to false !
   */
  private boolean valid = false;

  /**
   * Constructor
   * @param container AgentContainer - owner agent container
   */
  public ClassFinder(AgentContainer container) {
    this.container = container;
    try {
      agent = Class.forName("aglobe.container.agent.Agent");
      service = Class.forName("aglobe.container.service.Service");
      initialized = true;
    }
    catch (ClassNotFoundException ex) {
    }
    catch (NoClassDefFoundError ex) {
    }
  }

  /**
   * Check if this class is initialized and current cache is valid.
   */
  private  void check() {
    if (!initialized) {
      return;
    }
    if (!valid) {
      try {
          // refresh the list
          refreshLists();
      }
      catch (Exception e) { // ?!?!?!
          e.printStackTrace();
      }
      valid = true;
    }
  }

  /**
   * Recursive method for finding all public and non abstract classes inheried
   * from Agent or Service
   *
   * @param path String - find classes in specified path
   * @param pkg String - current package
   */
  private void refreshDirectory(File path,String pkg) {
    String[] fs = path.list();
    if (fs != null) {
      for (int i = 0; i < fs.length; i++) {
        String cname = (pkg.equals("") ? "": pkg+".") + fs[i];
        Matcher m = classFilter.matcher(cname);
        if (m.find()) {
          String clname = m.group(1);
          testClass(clname);
        } else {
          File nf = new File(path,fs[i]);
          refreshDirectory(nf,cname);
        }
      }
    }
  }

  /**
   * Refresh agent and service list
   */
  private void refreshLists() {
   agents_test.clear();
   services_test.clear();

   Set<String> browsed = new HashSet<String>();
   String cp = System.getProperty("java.class.path");
   String pathseparator = System.getProperty("path.separator");
   String[] cps = cp.split(pathseparator);
   while (cps.length > 0) {
     Set<String> newToSearch = new HashSet<String>();
     for (int i = 0; i < cps.length; i++) {
       File fp = new File(cps[i]);
       browsed.add(fp.getPath());
       if (fp.isDirectory()) {
//         System.out.println(cps[i] + " is Directory");
           refreshDirectory(fp,"");
       }
       else {
         Matcher mJdk = jdkjarFilter.matcher(cps[i]);
         if (!mJdk.find()) {
//           System.out.println(cps[i] + ": Jar file");
           try {
             JarFile jf = new JarFile(cps[i]);
             // go through jar file
             Enumeration<JarEntry> je = jf.entries();
             while (je.hasMoreElements()) {
               JarEntry el = je.nextElement();
               Matcher m = classFilter.matcher(el.getName());
               if (m.find()) {
                 String cname = m.group(1);
                 cname = cname.replace('/', '.');
                 testClass(cname);
               }
             }

             // test if there are some other references to the other jar libraries
             Manifest mf = jf.getManifest();
             if (mf != null) {
               String newCP = mf.getMainAttributes().getValue(Attributes.Name.
                   CLASS_PATH);
               if (newCP != null) {
                 String[] newCPs = newCP.split(" ");
                 for (int j = 0; j < newCPs.length; j++) {
                   File nf = new File(newCPs[j]);
                   if (!nf.isAbsolute()) {
                     nf = new File(fp.toURI().resolve(newCPs[j]));
                   }
                   String nfs = nf.getAbsolutePath();
                   if (!browsed.contains(nfs)) {
                     newToSearch.add(nfs);
//                     System.out.println("Added to search: " + nfs);
                   }
                 }
               }
             }
           }
           catch (IOException ex2) {
               Logger.logWarning("Cannot find library: "+cps[i]);
//               ex2.printStackTrace();
           }
         }
       }
     }
     cps = newToSearch.toArray(new String[newToSearch.size()]);
   }

   if (container != null) {
     LibraryManager.LibraryRecord[] lmlibs = container.getLibraryManager().
         getLibraryList();
     if (lmlibs != null) {
       for (int i = 0; i < lmlibs.length; i++) {
//          System.out.println(lmlibs[i].absolutePathToTheLibrary+": user library");
         try {
           JarFile jf = new JarFile(lmlibs[i].absolutePathToTheLibrary);

           URLClassLoader ccc = new URLClassLoader(new URL[] {new File(lmlibs[i].
               absolutePathToTheLibrary).toURI().toURL()});
           // go through jar file
           Enumeration<JarEntry> je = jf.entries();
           while (je.hasMoreElements()) {
             JarEntry el = je.nextElement();
             Matcher m = classFilter.matcher(el.getName());
             if (m.find()) {
               String cname = m.group(1);
               cname = cname.replace('/', '.');
               String name = new StringBuilder(cname).append('@').append(lmlibs[i].
                   toString()).toString();
//               System.out.println(cname+":"+lmlibs[i].absolutePathToTheLibrary);
               try {
                 Class<?> obj = ccc.loadClass(cname);
                 if (agent.isAssignableFrom(obj)) {
                   if (!agents_test.contains(name)) {
                     if ( (obj.getModifiers() &
                           (Modifier.ABSTRACT | Modifier.INTERFACE |
                            Modifier.PRIVATE | Modifier.PROTECTED)) == 0) {
                       agents_test.add(name);
                     }
                   }
                 }
                 else if (service.isAssignableFrom(obj)) {
                   if (!services_test.contains(name)) {
                     if ( (obj.getModifiers() &
                           (Modifier.ABSTRACT | Modifier.INTERFACE |
                            Modifier.PRIVATE | Modifier.PROTECTED)) == 0) {
                       services_test.add(name);
                     }
                   }
                 }
               }
               catch (Exception ex) {
                   Logger.logWarning("Problem with loading class: "+cname);
//                 ex.printStackTrace();
               }
             }
           }
         }
         catch (IOException ex2) {
             Logger.logWarning("Cannot find library: "+lmlibs[i].absolutePathToTheLibrary);
//              ex2.printStackTrace();
         }
       }
     }
   }
   // sort result
   agents_result = new LinkedList<String>(new TreeSet<String>(agents_test));
   services_result = new LinkedList<String>(new TreeSet<String>(services_test));
  }

  /**
   * Test if cname is class extending Agent or Service and put it to appropriate list
   * @param cname String
   */
  private void testClass(String cname) {
    try {
      Class<?> obj = Class.forName(cname);
      if (agent.isAssignableFrom(obj)) {
        if (!agents_test.contains(cname)) {
          if ( (obj.getModifiers() &
                (Modifier.ABSTRACT | Modifier.INTERFACE |
                 Modifier.PRIVATE | Modifier.PROTECTED)) == 0) {
            agents_test.add(cname);
          }
        }
      }
      else if (service.isAssignableFrom(obj)) {
        if (!services_test.contains(cname)) {
          if ( (obj.getModifiers() &
                (Modifier.ABSTRACT | Modifier.INTERFACE |
                 Modifier.PRIVATE | Modifier.PROTECTED)) == 0) {
            services_test.add(cname);
          }
        }
      }
    }
    catch (Throwable er) {
    }
  }

  /**
   * Invalidate ClassFinder internal cache.
   */
  public void invalidate() {
    valid = false;
  }

  /**
   * Returns list of the Agent class names
   * @return List
   */
  public List<String> getAgentList() {
    check();
    return agents_result;
  }

  /**
   * Returns list of the Service class names
   * @return List
   */
  public List<String> getServiceList() {
    check();
    return services_result;
  }

  /**
   * Test
   * @param args String[]
   */
  public static void main(String[] args) {
    ClassFinder cf = new ClassFinder(null);

    cf.check();
    System.out.println("Agents:");
    for (Iterator<String> iter = cf.agents_result.iterator(); iter.hasNext(); ) {
      String item = iter.next();
      System.out.println(item);
    }
    System.out.println("\n\nServices:");
    for (Iterator<String> iter = cf.services_result.iterator(); iter.hasNext(); ) {
      String item = iter.next();
      System.out.println(item);
    }
  }
}
