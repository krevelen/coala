package aglobe.container.service;

import aglobe.container.task.*;
import aglobe.ontology.*;

/**
 * <p>Title: A-Globe</p>
 * <p>Description:
 * Implements the Service which uses <code>ConversationManager</code> to handle
 * messages. Tasks in the service receive only reply messages.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.19 $ $Date: 2010/08/04 11:48:06 $
 *
 */
public abstract class CMService extends Service implements ConversationUnit
{
    /**
     * It is the conversation manager of the service.
     */
    private ConversationManager cm = new ConversationManager(this);

    /**
     * @internal
     * This final method guarantees that incoming messages are sent into the
     * conversation manager.
     * @param m is incoming message.
     */
    @Override
	final public void handleIncomingMessage(final Message m)
    {
        cm.handleIncomingMessage(m);
    }

    /**
     * @internal
     * Sets a task for handling all unsorted messages to any registered task.
     * @param t is an idle task.
     */
    final protected void setIdleTask(final Task t) {
        cm.setIdleTask(t);
    }

    /**
     * @internal
     * This method returns the conversation manager of the agent.
     * @return ConversationManager
     */
    @Override
	final public ConversationManager getConversationUnit() {
        return cm;
    }

    /**
     * @internal
     * Finish service
     */
    @Override
    protected void sysFinish() {
        if (cm != null) {
            cm.sysFinish();
            cm = null;
        }
        super.sysFinish();
    }

}
