package aglobe.container.service;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import aglobe.container.AgentContainer;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: this interface serves just as a marker for ServiceShells and
 * as a reminder, that ServiceShell must be Serializable. </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.21 $ $Date: 2010/08/04 11:48:06 $
 */
public abstract class ServiceShell implements Externalizable {

    /**
     * Shell owner agent/service
     */
    protected ShellOwner shellOwner = null;

    /**
     * Constructor used for serialization purposes.DO NOT USE THIS constructor.
     */
    protected ServiceShell() {
    }

    /**
     * Constructor. It is used by the service holder itself. Do not call this constructor.
     * @param shellOwner ElementaryEntity - owner of the service shell agent/service
     */
    protected ServiceShell(final ShellOwner shellOwner) {
        if (shellOwner == null) {
            return;
        }
        this.shellOwner = shellOwner;
        shellOwner.addServiceShell(this);
    }

    /**
     * Returns whether this service shell is binded to the real service. When
     * false is returned, calls to service methods will probably result in
     * <code>nullPointerException</code>
     *
     * @return boolean
     */
    public abstract boolean isValid();

    /**
     * @internal
     * Used for connection to the appropriate service after agent migration with
     * service shell
     *
     * @param container AgentContainer
     * @throws Exception
     */
    public abstract void setContainer(AgentContainer container) throws Exception;

    /**
     * Called after initialization of the owner agent
     */
    public abstract void postInit();

    /**
     * Dispose the service shell
     */
    public void dispose() {
        if (shellOwner != null) {
            shellOwner.removeServiceShell(this);
        }
    }

    /**
     * @internal
     * Used for externalization purposes
     * @param out ObjectOutput
     * @throws IOException
     */
    @Override
	public void writeExternal(final ObjectOutput out) throws IOException {
        out.writeObject(shellOwner);
    }

    /**
     * @internal
     * Used for externalization purposes
     *
     * @param in ObjectInput
     * @throws IOException
     * @throws ClassNotFoundException
     */
    @Override
	public void readExternal(final ObjectInput in) throws IOException, ClassNotFoundException {
        shellOwner = (ShellOwner) in.readObject();
    }

}
