package aglobe.container.service;

import aglobe.container.ElementaryEntity;
import aglobe.container.EntityRunner;
import aglobe.util.ExceptionPrinter;

/**
 * @internal
 * <p>Title: AGlobe</p>
 * <p>Description: Takes care about running service in separate thread. It also catch all uncatched exception
 * by services. </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.17 $ $Date: 2009/06/15 13:38:02 $
 */
public final class ServiceRunner extends EntityRunner {

    /**
     * @internal
     * @param e
     * @param tg
     */
    public ServiceRunner(final ElementaryEntity e, final ThreadGroup tg) {
        super(e, tg);
    }

    /* @internal
     * (non-Javadoc)
     * @see aglobe.container.EntityRunner#entityFinished()
     */
    @Override
    protected void entityFinished() {
        try {
            entity.getContainer().getServiceManager().serviceFinished((Service)entity);
        } catch (Exception ex) {
            entity.logSevere("Exception from serviceFinished: " + ExceptionPrinter.toStringWithStackTrace(ex));
        }
    }
}
