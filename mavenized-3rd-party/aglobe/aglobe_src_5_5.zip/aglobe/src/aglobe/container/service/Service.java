package aglobe.container.service;

import aglobe.container.*;
import aglobe.container.transport.*;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: After creation, the service should be able to handle only
 * <code>getService</code> calls. All the other functionality, including lookup
 * of other services should be done in <code>startService</code>.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.61 $ $Date: 2010/08/04 11:48:06 $
 */
public abstract class Service extends ElementaryEntity
{
    /**
     * Current service address
     */
    private Address serviceAddress = null;

    /**
     * @internal
     * Method returns ServiceShell if service is still active
     * @param shellOwner ElementaryEntity
     * @return ServiceShell
     */
    public final ServiceShell getServiceShellSys(final ShellOwner shellOwner) {
        if (!isActive()) {
            return null;
        }
        return getServiceShell(shellOwner);
    }

    /**
     * Method has to be overridden. This method return ServiceShell of the service.
     *
     * @return ServiceShell
     * @param shellOwner ElementaryEntity - agent/service
     */
    protected abstract ServiceShell getServiceShell(final ShellOwner shellOwner);

    /**
     * Initialization of the service. The implementor can override this method if it requires
     * to perform initialization
     *
     */
    public void init() {
    }

    /**
     * The method returns address of the service.
     * @return Address
     */
    @Override
    final public Address getAddress() {
        if (serviceAddress != null) {
            return serviceAddress;
        }
        if (name == null) {
            throw new RuntimeException("Service is not initialized yet, there is no address.");
        }
        serviceAddress = Address.getLocalServiceAddress(this, name);
        return serviceAddress;
    }

    /**
     * Get service store
     *
     * @return Store - service store
     */
    @Override
	final public Store getStore() {
        return container.getServiceStore(name);
    }
}
