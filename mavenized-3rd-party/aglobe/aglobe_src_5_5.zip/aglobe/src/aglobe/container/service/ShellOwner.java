package aglobe.container.service;

import aglobe.container.transport.Address;

/**
 * Implemented by those that own a shell of some service. All the agents implement
 * this interface.
 */
public interface ShellOwner {

	Address getAddress();
	
	void addServiceShell(ServiceShell shell);
	void removeServiceShell(ServiceShell shell);
}
