package aglobe.container.service;

import java.lang.reflect.Constructor;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Logger;

import javax.swing.SwingUtilities;

import aglobe.container.AgentContainer;
import aglobe.container.DuplicateNameException;
import aglobe.container.Store;
import aglobe.container.agent.Agent;
import aglobe.container.gui.ListListener;
import aglobe.container.gui.ListSource;
import aglobe.container.library.EntityClassLoader;
import aglobe.container.library.LibraryManager;
import aglobe.container.library.LibraryRequesterCallback;
import aglobe.container.transport.Address;
import aglobe.ontology.ServiceInfo;
import aglobe.ontology.ServiceList;
import aglobe.platform.Platform;
import aglobe.platform.thread.AglobeThreadPool;
import aglobe.platform.transport.MessageReceiver;
import aglobe.platform.transport.MessageReceiverSplitter;
import aglobe.platform.transport.RecepientNotFound;
import aglobe.util.AglobeXMLtools;
import aglobe.util.ExceptionPrinter;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: This class manage services in the container.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.62 $ $Date: 2010/12/01 12:36:10 $
 */
public final class ServiceManager implements MessageReceiverSplitter, ListSource {
    /**
     * Service store key
     */
    private static final String SERVICESTORE = "service/autorun.xml";

    /**
     * @internal
     * Thread group name.
     */
    public static final String SERVICETHREAD = "Services";

    /**
     * @internal
     * Main service thread name
     */
    public static final String MAIN_SERVICE_THREAD_NAME = "main service thread";

    private static final ClassLoader systemClassLoader = Platform.class.getClassLoader();

    /**
     * Link to the agent container
     */
    private final AgentContainer container;

    /**
     * All running services thread group
     */
    private ThreadGroup _servicethreads = null;

    /**
     *  Map of running services.
     */
    private ConcurrentHashMap<String,Service> serviceMap = new ConcurrentHashMap<String,Service>(16, 0.75f, 1);
    
    /**
     * Queue of running services, used for correct service stopping
     */
    private ConcurrentLinkedQueue<Service> serviceQueue = new ConcurrentLinkedQueue<Service>();

    /**
     * Map of running services information
     */
    private ConcurrentHashMap<String, ServiceInfo> serviceInfoMap = new ConcurrentHashMap<String,ServiceInfo>(16, 0.75f, 1);

    /**
     * true if manager should be finished
     */
    private boolean managerShutDown = false;

    /**
     * Listener for watching changes in the list of services.
     */
    private ListListener listListener = null;

    /**
     * Logger of the service
     */
    private Logger logger = Logger.getLogger("container.ServiceManager");

    /**
     * Waits for library?
     */
    private boolean libraryWait = false;

    /**
     * Library loading failed?
     */
    private boolean libraryFailed = false;

    private ReentrantLock libraryLock = new ReentrantLock();
    private Condition libraryCondition = libraryLock.newCondition();


    private ReentrantLock finalizerLock = new ReentrantLock();
    private Condition finalizerCondition = finalizerLock.newCondition();
    
    /**
     * @internal
     * Constructor
     * @param container AgentContainer - instance of the AgentContainer which creates ServiceManager
     */
    public ServiceManager(final AgentContainer container) {
        this.container = container;

        _servicethreads = new ThreadGroup(container.getContainerThreadGroup(), SERVICETHREAD);
    }

    /**
     * @internal
     * This method initializes services.
     *
     * @param _serviceList ServiceList - iff null services are started from autorun, otherwise use this service list
     * @param librarySourceContainer Address - library source container for the service list, can be null
     * @throws Exception - if some service initialization failed
     */
    public void aferContainerInit(final ServiceList _serviceList,
                                  final Address librarySourceContainer) throws
            Exception {
        initServices(_serviceList, librarySourceContainer);
    }

    /**
     * @internal
     * Start all system services
     *
     * @param services Map
     * @throws Exception
     */
    public void startSystemServices(final Map<String,Service> services) throws Exception {
        // register the system services passed as parameter
        for (final Map.Entry<String,Service> elem : services.entrySet()) {
            if (elem.getValue() != null) {
                // system service use default class loader
                startService(elem.getKey(), elem.getValue());
            } else {
                throw new IllegalArgumentException("null service: " + elem.getKey());
            }
        }
    }

    /**
     * @internal
     * The method stops the service manager.
     */
    public void stopServiceManager() {
        managerShutDown = true;
        // quit running services
        Service rem;
        finalizerLock.lock();
        try {
            while ((rem = serviceQueue.poll())!=null) {
                rem.stop();
                try {
                    finalizerCondition.await();
                } catch (InterruptedException ex) {
                }
            }
        } finally {
            finalizerLock.unlock();
        }

        logger.fine("ServiceManager shutdown: All services finished.");
    }

    /**
     * Returns <code>ServiceShell</code> of the service.
     *
     * @param shellOwner ElementaryEntity - agent/service
     * @param _name is name of the service
     * @return <code>ServiceShell</code>
     */
    public ServiceShell getService(final ShellOwner shellOwner, final String _name) {
        final Service ser = serviceMap.get(_name);
        if (ser != null)
            return ser.getServiceShellSys(shellOwner);
        else
            return null;
    }

    /**
     * Returns <code>ServiceInfo</code> of the service.
     * @param _name is name of the service
     * @return <code>ServiceInfo</code>
     */
    public ServiceInfo getServiceInfo(final String _name) {
        if (_name == null) {
            return null;
        }
        ServiceInfo si = serviceInfoMap.get(_name);
        if (si != null) {
            return (ServiceInfo) AglobeXMLtools.cloneSerializable(si);
        } else {
            final Service s = serviceMap.get(_name);
            if (s != null) {
                si = new ServiceInfo();
                si.setName(_name);
                si.setMainClass("");
                si.setDescription("This service is part of the container infrastructure.\nIt should not be stopped.");
                return si;
            } else {
                return null;
            }
        }
    }

    /**
     * Returns true if service exists.
     * @param _name String - name of the service
     * @return boolean
     */
    public boolean existsService(final String _name) {
        return serviceMap.containsKey(_name);
    }

    /**
     * This method registers (creates) a new service on the container.
     * @param si ServiceInfo
     * @throws java.lang.Exception
     */
    public void registerService(final ServiceInfo si, boolean saveAutorun) throws Exception {
        if (si.getName().length() == 0) {
            throw new Exception("Requested service name is empty!");
        }

        if (serviceMap.containsKey(si.getName())) {
            throw new DuplicateNameException("Service with name " + si.getName() +
                                             " already exists!");
        }
        loadService(si);

        // put service to the auto start
        serviceInfoMap.put(si.getName(),si);
        
        if (saveAutorun) {
            final ServiceList sl = new ServiceList();
            sl.getServiceInfo().addAll(serviceInfoMap.values());
            container.getGlobalStore().putXML(SERVICESTORE, sl);
        }

        fireListListener();
    }

    /**
     * @internal
     * Invoke service <code>GUI</code> method in the AWT Event handling thread.
     * @param name String - service name
     */
    public void showService(final String name) {
        final Service s = serviceMap.get(name);
        if (s != null) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
				public void run() {
                    s.showGUI();
                }
            });
        }
    }

    /**
     * @internal
     * Invoke service <code>GUI</code> method in the AWT Event handling thread.
     * @param name String - service name
     */
    public void hideService(final String name) {
        final Service s = serviceMap.get(name);
        if (s != null) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
				public void run() {
                    s.hideGUI();
                }
            });
        }
    }

    /**
     * @internal
     * Called by the <code>ServiceRunner</code> when the Service's <code>run</code>
     * method returns.
     *
     * @param agent The finished agent.
     */
    void serviceFinished(final Service service) {
        switch (service.getState()) {
        case Agent.DONE:
            stopService(service.getName());
            break;
        case Agent.DEAD:
            deregisterService(service.getName());
            break;
        default:
            throw new RuntimeException("Bad service state");
        }
        fireListListener();
    }


    /**
     * Finish specified service by its service name.
     * @param _name String
     * @param remove boolean - iff true service should be removed from the service autorun.xml
     * store record
     */
    private void finishService(final String _name, final boolean remove) {
        // remove the service from the active services
        final Service ser = serviceMap.remove(_name);
        // let the service do the necessary task on shutdown
        if (ser != null) {
            // deregister class owner
            ser.setClassLoader(null, null, false);
        }

        finalizerLock.lock();
        try {
            serviceQueue.remove(ser);
            final ServiceInfo si = serviceInfoMap.remove(_name);
            if (si != null) {
                if (remove) {
                    final ServiceList sl = new ServiceList();
                    sl.getServiceInfo().addAll(serviceInfoMap.values());
                    container.getGlobalStore().putXML(SERVICESTORE, sl);
                }

                fireListListener();
            }

            // and if we are shutting down the whole container, let the waiting thread know
            // that the service finished
            if (managerShutDown) {
                finalizerCondition.signal();
            }
        } finally {
            finalizerLock.unlock();
        }
    }

    /**
     * Stop the service.
     * @param _name of the service to stop
     */
    private void stopService(final String _name) {
        finishService(_name, false);
    }

    /**
     * @internal
     * Stop the service and remove it from the autorun.xml file.
     * @param _name of the service to deregister
     */
    public void deregisterService(final String _name) {
        finishService(_name, true);
    }

    /**
     * Start the given service object as a service, register its name. The service
     * persists only until container shutdown.
     *
     * @param name String - new service name
     * @param service Service - service instance
     * @throws DuplicateNameException - thrown when same service name already
     *   exists
     */
    public void startService(final String name, final Service service) throws DuplicateNameException {
        if (serviceMap.containsKey(name)) {
            throw new DuplicateNameException(name);
        }
        try {
            service.setContainer(container);
            service.addEvent(new Runnable() {
                @Override
				public void run() {
                    service.sysInit(name);
                    service.init();
                    service.sysPostInit();
                }
            });
            serviceMap.put(name, service);
            serviceQueue.add(service);
            // create service group
            final ThreadGroup stg = new ThreadGroup(_servicethreads, service.getName());
            // create service thread
            AglobeThreadPool.startInNewThread(stg, new ServiceRunner(service, stg),
                                              container.getContainerName() + ": " + service.getName() + ": " + ServiceManager.MAIN_SERVICE_THREAD_NAME);

            fireListListener();
        } catch (Exception e) {
            logger.severe("Error loading service:\n" + ExceptionPrinter.toStringWithStackTrace(e));
        }
    }

    /**
     * Initialize specified services
     *
     * @param _StartingServiceList ServiceList
     * @param librarySourceContainer Address
     * @throws Exception
     */
    private void initServices(final ServiceList _StartingServiceList,
                              final Address librarySourceContainer) throws Exception {
        final Store s = container.getGlobalStore();
        ServiceList toStart = null;

        try {
            boolean checkLibrary = false;
            boolean saveChanges = false;
            if (_StartingServiceList == null) {
                if (s.exist(SERVICESTORE))
                    toStart = (ServiceList) s.getXML(SERVICESTORE, ServiceList.class);
                else {
                    toStart = new ServiceList();
                }
            } else {
                checkLibrary = true;
                toStart = _StartingServiceList;
            }
            final LibraryManager lm = container.getLibraryManager();

            // Register the services from autorun.xml or starting parameters services
            libraryFailed = false;

            for (ServiceInfo elem : toStart.getServiceInfo()) {
                if (checkLibrary) {
                    // check if libraries already are present
                    if (elem.getLibraries().getLibrary().size() > 0) {
                        if (librarySourceContainer == null) {
                            logger.severe("Libary source container is not specified.");
                            throw new Exception("Library source container is not specified.");
                        }

                        for (String elem2 : elem.getLibraries().getLibrary()) {
                            libraryLock.lock();
                            try {
                                libraryWait = true;
                                lm.obtainLibrary(container, librarySourceContainer,
                                        elem2, new LibraryRequesterCallback() {
                                    @Override
									public void libraryRequestFinished(Result
                                            result) {
                                        libraryLock.lock();
                                        try {
                                            if (result ==
                                                    LibraryRequesterCallback.FAILED) {
                                                libraryFailed = true;
                                            }
                                            libraryWait = false;
                                            libraryCondition.signal();
                                        } finally {
                                            libraryLock.unlock();
                                        }
                                    }
                                });
                                while (libraryWait) {
                                    try {
                                        libraryCondition.await();
                                    } catch (InterruptedException ex1) {
                                    }
                                    if (libraryFailed) {
                                        logger.severe("Library: " + elem2 + " for: "+ elem + " cannot be loaded from: " + librarySourceContainer);
                                        throw new Exception("Library: " + elem2 + " for: "+ elem + " cannot be loaded from: " + librarySourceContainer);
                                    }
                                }

                            } finally {
                                libraryLock.unlock();
                            }
                        }
                    }
                }
                // all libraries are loaded
                try {
                    loadService(elem);
                    serviceInfoMap.put(elem.getName(), elem);
                } catch (Exception ex) {
                    saveChanges = true;
                    logger.severe("Error while restarting the Service: " + elem.getName() + "\nThe service has been removed from autostart configuration.\n"+ExceptionPrinter.toStringWithStackTrace(ex));
                }

            }

            if (saveChanges) {
                // store new autostart configuration
                ServiceList sl = new ServiceList();
                sl.getServiceInfo().addAll(serviceInfoMap.values());
                s.putXML(SERVICESTORE, sl);
            }

            fireListListener();
        } catch (Exception ex) {
            logger.severe("Cannot start the default services! " + ExceptionPrinter.toStringWithStackTrace(ex));
            throw ex;
        }
    }

    /**
     * Load service from the ServiceInfo record.
     * @param si ServiceInfo
     * @return Service
     * @throws Exception
     */
    private Service loadService(final ServiceInfo si) throws Exception {
        final LibraryManager lm = container.getLibraryManager();

        final List<String> libs = si.getLibraries().getLibrary();
        EntityClassLoader classLoader = null;
        if (libs.size() != 0) {
            classLoader = EntityClassLoader.getInstance(lm, libs.toArray(new String[libs.size()]));
        }


        final Class<?> cl = (classLoader != null) ? classLoader.loadClass(si.getMainClass()) : systemClassLoader.loadClass(si.getMainClass());
        final Constructor<?> con = cl.getConstructor(new Class<?>[] {});
        final Service service = (Service) con.newInstance(new Object[] {});

        service.setClassLoader(classLoader, si.getName(), false);

        service.setContainer(container);
        // schedule start service method
        service.addEvent(new Runnable() {
            @Override
			public void run() {
                service.sysInit(si.getName());
                service.init();
                service.sysPostInit();
            }
        });

        // put service to the list of services
        serviceMap.put(si.getName(), service);
        serviceQueue.add(service);
        // create service group
        final ThreadGroup stg = new ThreadGroup(_servicethreads, si.getName());
        // create service thread
        AglobeThreadPool.startInNewThread(stg, new ServiceRunner(service, stg),
                                  container.getContainerName() + ": " + service.getName() + ": " + ServiceManager.MAIN_SERVICE_THREAD_NAME);

        return service;
    }

    /**
     * Returns list of running services alphabetically ordered
     * @return List - list contains ServiceInfo objects
     */
    public List<ServiceInfo> getRunningServices() {
        final LinkedList<ServiceInfo> retVal = new LinkedList<ServiceInfo>();
        final Set<String> collection = new TreeSet<String>(serviceMap.keySet());
        ServiceInfo si;
        for (Iterator<String> iter = collection.iterator(); iter.hasNext(); ) {
            final String item = iter.next();
            si = getServiceInfo(item);
            if (si != null)
                retVal.add(si);
        }
        return retVal;
    }

    /**
     * Returns instance of the running service.
     *
     * @param serviceName String - name of the service.
     * @return Service - instance of the requested service
     */
    public Service getServiceInstance(final String serviceName) {
        return serviceMap.get(serviceName);
    }

    /**
     * @internal
     * Get message receiver
     *
     * @param receiver String - agent name
     * @return MessageReceiver
     * @throws RecepientNotFound
     */
    @Override
    public MessageReceiver getMessageReceiver(final Address receiver) throws RecepientNotFound {
        if (!receiver.isService()) {
            throw new RecepientNotFound();
        }
        final Service service = serviceMap.get(receiver.getName());
        if (service == null) {
            throw new RecepientNotFound();
        }
        return service;
    }

    /**
     * @internal
     * The method adds ListListener to the <code>ServiceManager</code>.
     * @param ll <code>ListListener</code>
     */
    @Override
	public void addListListener(final ListListener ll) {
        if (listListener != null)
            throw new UnsupportedOperationException("Just a single ListListener supported with AgentManager.");

        listListener = ll;
        fireListListener();
    }

    /**
     * Fire list listeners
     */
    private void fireListListener() {
        if (listListener != null) {
            final Set<String> services = serviceMap.keySet();
            listListener.ListChanged(ListListener.ListType.SERVICES, services);
        }
    }
}
