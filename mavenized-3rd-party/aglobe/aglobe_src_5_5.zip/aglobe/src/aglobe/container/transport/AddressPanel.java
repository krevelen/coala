package aglobe.container.transport;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

/**
 * @internal
 * <p>Title: A-Globe</p>
 * <p>Description: GUI panel for input aglobe address by the user</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.11 $ $Date: 2009/05/15 08:46:58 $
 */
public final class AddressPanel extends JPanel {
    private static final long serialVersionUID = -7753628563594739737L;

    /**
     * Agent string
     */
    private static final String AGENT = "A";

    /**
     * Service string
     */
    private static final String SERVICE = "S";

    private GridBagLayout gridBagLayout1 = new GridBagLayout();
    private JLabel containerLabel = new JLabel();
    private JLabel nameLabel = new JLabel();
    private JTextField hostTextField = new JTextField();
    private JTextField containerTextField = new JTextField();
    private JTextField nameTextField = new JTextField();
    private JLabel semincolonLabel = new JLabel();
    private JLabel slashLabel = new JLabel();
    private JLabel slashLabel2 = new JLabel();
    private JTextField portTextField = new JTextField();
    private JComboBox typeCombo = new JComboBox(new Object[] {AGENT, SERVICE});
    private Border border1;
    private TitledBorder titledBorder1;
    private Border border2;

    /**
     * Creates standard panel
     */
    public AddressPanel() {
        try {
            jbInit();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Creates panel with the title
     * @param title String
     */
    public AddressPanel(String title) {
        init();
        setTitle(title);
    }

    /**
     * Creates panel with the title and pre-inserted address in the fields
     * @param title String
     * @param a Address
     */
    public AddressPanel(String title, Address a) {
        init();
        setTitle(title);
        setAddress(a);
    }

    /**
     * Set new title of the panel
     * @param title String
     */
    public void setTitle(String title) {
        titledBorder1.setTitle(title);
    }

    /**
     * Pre-insert the address into the appropriate fields
     * @param a Address
     */
    public void setAddress(Address a) {
        hostTextField.setText(a.getHost());
        portTextField.setText(String.valueOf(a.getPort()));
        containerTextField.setText(a.getContainerName());
        nameTextField.setText(a.getName());
        if (a.isAgent())
            typeCombo.setSelectedItem(AGENT);
        else
            typeCombo.setSelectedItem(SERVICE);
    }

    /**
     * Gets current address inserted in the panel
     * @return Address
     */
    public Address getAddress() {
        String host = hostTextField.getText();
        int port = 1024;

        try {
            port = Integer.parseInt(portTextField.getText());
        } catch (NumberFormatException ex) {
            portTextField.setText("1024");
        }
        String containerName = containerTextField.getText();

        String name = nameTextField.getText();
        Address a;
        if (typeCombo.getSelectedItem() == AGENT)
            a = Address.getAgentAddress(host, port, containerName, name);
        else
            a = Address.getServiceAddress(host, port, containerName, name);
        return a;
    }

    /**
     * Sets only the new container part
     * @param container String
     */
    public void setHost(String container) {
        hostTextField.setText(container);
    }

    /**
     * Sets only the new port part
     * @param port int
     */
    public void setPort(int port) {
        portTextField.setText(String.valueOf(port));
    }

    /**
     * Sets only the container name part
     * @param containerName String
     */
    public void setContainerName(String containerName) {
        containerTextField.setText(containerName);
    }

    /**
     * Convinience method with the same content as the automatically generated
     * constructor
     */
    private void init() {
        try {
            jbInit();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Construct the swing GUI panel. Called from the init method
     * @throws Exception
     */
    void jbInit() throws Exception {
        border1 = new EtchedBorder(EtchedBorder.RAISED, Color.white, new Color(165, 163, 151));
        titledBorder1 = new TitledBorder(border1, "Address");
        border2 = BorderFactory.createCompoundBorder(titledBorder1, BorderFactory.createEmptyBorder(3, 3, 3, 3));
        containerLabel.setText("Container:");
        this.setLayout(gridBagLayout1);
        nameLabel.setText("Name:");
        hostTextField.setColumns(20);
        nameTextField.setColumns(20);
        containerTextField.setColumns(20);
        semincolonLabel.setText(":");
        slashLabel.setText("/");
        slashLabel2.setText("/");
        portTextField.setText("1024");
        portTextField.setColumns(5);
        this.setBorder(border2);
        this.add(containerLabel, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.1
                , GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(3, 3, 3, 3), 0, 0));
        this.add(nameLabel, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.1
                , GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(0, 3, 3, 3), 0, 0));
        this.add(hostTextField, new GridBagConstraints(1, 0, 1, 1, 0.1, 0.0
                , GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(3, 0, 3, 3), 0, 0));
        this.add(nameTextField, new GridBagConstraints(1, 2, 1, 1, 0.1, 0.0
                , GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 3, 3), 0, 0));
        this.add(semincolonLabel, new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
                , GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(3, 0, 3, 3), 0, 0));
        this.add(portTextField, new GridBagConstraints(3, 0, 1, 1, 0.0, 0.0
                , GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(3, 0, 3, 3), 0, 0));
        this.add(slashLabel, new GridBagConstraints(4, 0, 1, 1, 0.0, 0.0
                , GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(3, 0, 3, 3), 0, 0));
        this.add(containerTextField, new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0
                , GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(3, 0, 3, 3), 0, 0));
        this.add(slashLabel2, new GridBagConstraints(2, 1, 1, 1, 0.0, 0.0
                , GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(3, 0, 3, 3), 0, 0));
        this.add(typeCombo, new GridBagConstraints(3, 2, 1, 1, 0.0, 0.0
                , GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 3, 3), 0, 0));
    }
}
