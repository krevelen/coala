package aglobe.container.transport;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: Invisible container exception is thrown when agent or service
 * calls sendMessage method. The exception is thrown when target container is not
 * reachable from the current one. The exception is thrown in the simulation mode and
 * also in the real network mode, when message cannot be sent via underlying
 * message transport protocol.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.9 $ $Date: 2008/11/23 09:14:11 $
 */
public final class InvisibleContainerException extends Exception {
    private static final long serialVersionUID = -3784397625198755682L;
    /**
     * if true problem was caused due to invisible target platform
     */
    public final boolean invisibleTargetPlatform;

    /**
     * Constructor
     */
    public InvisibleContainerException() {
        super();
        this.invisibleTargetPlatform = false;
    }

    /**
     * Constructor
     * @param message String - exception message
     */
    public InvisibleContainerException(String message) {
        this(message,false);
    }

    /**
     * Constructor
     * @param message String - exception message
     * @param invisibleTargetPlatform boolean - true if exception is thrown due to
     * invisible target platform
     */
    public InvisibleContainerException(String message, boolean invisibleTargetPlatform) {
        super(message);
        this.invisibleTargetPlatform = invisibleTargetPlatform;
    }

    /**
     * Constructor
     * @param message String - exception message
     * @param invisibleTargetPlatform boolean - true if exception is thrown due to
     * invisible target platform
     */
    public InvisibleContainerException(String message, boolean invisibleTargetPlatform, Throwable cause) {
        super(message, cause);
        this.invisibleTargetPlatform = invisibleTargetPlatform;
    }
}
