package aglobe.container.transport;

import java.io.*;
import java.util.Arrays;
import java.util.logging.*;

import aglobe.container.*;
import aglobe.ontology.*;
import aglobe.platform.MessageTransportComponent;
import aglobe.platform.transport.MessageReceiver;
import aglobe.platform.transport.MessageReceiverSplitter;
import aglobe.platform.transport.RecepientNotFound;
import aglobe.util.IDGenerator;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: This class takes care about sending and receiving all messages in one AgentContainer.
 * If there is GISClientService running on this container, it also applies visibility restriction to the
 * outgoing messages.</p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.117 $ $Date: 2010/12/01 14:59:41 $
 *
 */
public final class MessageTransport implements MessageTransportComponent {
    /**
     * Name for the logger used by the MessageTransport layer
     */
    private static final String LOGGER = "container.MessageTransport";

    /**
     * Reference to the AgentContainer which creates this MessageTransport
     */
    private final AgentContainer container;

    /**
     * Local container address
     */
    private Address containerAddress;

    /**
     * Logger for the MessageTransport layer
     */
    @SuppressWarnings("unused")
    private Logger logger = Logger.getLogger(LOGGER);

    /**
     * true iff message transport is registered in the platform message transport
     */
    private boolean registered = false;

    /**
     * Id generator
     */
    private IDGenerator idGenerator;

    /**
     * Registered outgoing message hooks.
     * These are called in the order from the highest index to the lower ones.
     */
    private SendMessageHookInterface sendMessageHooks[] = new SendMessageHookInterface[MAX_MESSAGE_HOOKS+1];

    private int nextSendMessageHooks[] = new int[MAX_MESSAGE_HOOKS+1];

    /**
     * Registered incoming message hooks.
     * These are called in the order from the lowest index to the higher ones.
     */
    private ReceiveMessageHookInterface receiveMessageHooks[] = new ReceiveMessageHookInterface[MAX_MESSAGE_HOOKS+1];

    private int nextReceiveMessageHooks[] = new int[MAX_MESSAGE_HOOKS+1];

    /**
     * Registered receiver translator message hooks.
     * These are called in the order from the highest index to the lower ones.
     */
    private TranslateMessageReceiverHookInterface translateReceiverHooks[] = new TranslateMessageReceiverHookInterface[MAX_MESSAGE_HOOKS+1];
    private int nextTranslateMessageReceiverHooks[] = new int[MAX_MESSAGE_HOOKS+1];

    /**
     * A locking object used while modifying the <code>sendMessageHooks</code> or
     * <code>receiveMessageHooks</code> arrays.
     */
    private Object messageHookLock = new Object();

    /**
     * Maximum count of the message hooks. Specifies the size of the messageHooks array.
     */
    private static final int MAX_MESSAGE_HOOKS = 30;

    /**
     * @internal
     * This method is called by the AgentContainer after initializing all main AgentContainer's modules.
     */
    public final void aferContainerInit() {
    }

    /**
     * @internal
     * Starts MessageTransport layer of the AgentContainer
     *
     * @param container AgentContainer - owner of this MessageTransport
     * @throws IOException - throws if there is some problem with binding
     *   listening port
     */
    public MessageTransport(final AgentContainer container) throws
            IOException {
        this.container = container;

        // initialize string which will be added to all generated IDs from the local address and actual time
        idGenerator = new IDGenerator(container.getContainerName() + "-");

        Arrays.fill(nextSendMessageHooks, -1);
        Arrays.fill(nextReceiveMessageHooks, -1);
        Arrays.fill(nextTranslateMessageReceiverHooks, -1);
    }

    /**
     * Returns container address
     * @return Address
     */
    public final Address getContainerAddress() {
        return containerAddress;
    }

    /**
     * @internal
     * This method is called by AgentContainer after Message Transport init. It is
     * used for registering to the platform MT
     *
     * @throws Exception
     */
    public final void afterInit() throws Exception {
        containerAddress = Address.getLocalContainerAddress(this.container);
        // register container MT to the platform MT !!!
        aglobe.platform.transport.MessageTransport.registerMessageTransport(
                container.getContainerName(), this);
        registered = true;
    }

    /**
     * @internal
     * This method is called after all services are initialized. Message transport tries
     * to connect to the GISClientService.
     */
    public final void afterServicesInit() {
    }

    /**
     * @internal
     * get Message receiver for destination address receiver
     * @param receiver Address
     * @return MessageReceiver - null iff receiver not found
     */
    @Override
	public final MessageReceiver getMessageReceiver(final Address receiver) {
        MessageReceiverSplitter mr;
        if (receiver.isAgent())
            mr = container.getAgentManager();
        else
            mr = container.getServiceManager();

        try {
            return mr.getMessageReceiver(receiver);
        } catch (RecepientNotFound ex) {
            return null;
        }
    }

    /**
     * Called by the hooks registered by registerHook call to pass the message further down. Allows to
     * specify which hook should be next in processing.
     *
     * @param msgInfo A message holder class providing some additional information about the message.
     * @param myHook A current hook number of the caller.
     * @throws InvisibleContainerException
     */
    public final void forwardOutgoingMessage(final Message msg, final int myHook) throws InvisibleContainerException {

        if (msg == null) {
            throw new IllegalArgumentException("Message cannot be null");
        }
        if (myHook < 0 || myHook > MAX_MESSAGE_HOOKS) {
            throw new IllegalArgumentException(String.format("Invalid next hook number: %d", myHook));
        }

        final int nextHook = nextSendMessageHooks[myHook];
        if (nextHook >= 0) {
            final SendMessageHookInterface smhi = sendMessageHooks[nextHook];
            if (smhi != null) {
                smhi.processOutgoingMessage(msg);
                return;
            }
        }

        // no next hook => we should send the message out
        this.sendMessageDirectly(msg);
    }

    /**
     * @internal
     * Called by the hooks registered by registerHook call to pass the incoming message
     * further up on the way to the receiver.
     *
     * @param msg A message itself.
     * @param receiver The receiver of the message. Is required, since the message might be
     *                 multicast and we leave those messages untouched; a receiver is one
     *                 of the receivers that will get this copy.
     * @param myHook The hook number where the processing was.
     */
    public final void forwardIncomingMessage(final Message msg, final MessageReceiver receiver, final int myHook) {

        if (msg == null) {
            throw new IllegalArgumentException("Message cannot be null");
        }
        if (receiver == null) {
            throw new IllegalArgumentException("Receiver cannot be null");
        }
        if (myHook < 0 || myHook > MAX_MESSAGE_HOOKS) {
            throw new IllegalArgumentException(String.format("Invalid next hook number: %d", myHook));
        }

        final int nextHook = nextReceiveMessageHooks[myHook];
        if (nextHook >= 0) {
            final ReceiveMessageHookInterface rmhi = receiveMessageHooks[nextHook];
            if (rmhi != null) {
                rmhi.processIncomingMessage(msg, receiver);
                return;
            }
        }

        // no next hook => we should send the message to the receiver directly
        receiver.incomingMessage(msg);
    }

    /**
     * @internal
     * Sends a message. Called by the agent/service. Allows for specifying a callback that
     * provides information about the sending result.
     *
     * @param msg Message to send.
     * @param onlyReference true if should be sent by reference.
     * @throws InvisibleContainerException Target container is not visible.
     */
    public final void sendMessage(final Message msg) throws InvisibleContainerException
    {
        if (msg.getSender() == null) {
            throw new IllegalArgumentException("Message has no sender: "+msg);
        }
        if (msg.isMulticast()) {
            if (msg.getReceivers() == null) {
                throw new IllegalArgumentException("Message has no receiver: "+msg);
            }
        } else {
            if (msg.getReceiver() == null) {
                throw new IllegalArgumentException("Message has no receiver: "+msg);
            }
        }
        
        if (msg.getDoNotSniff() || (nextSendMessageHooks[MAX_MESSAGE_HOOKS] < 0)) {
            // no hook, send directly
            sendMessageDirectly(msg);
        } else {
            forwardOutgoingMessage(msg, MAX_MESSAGE_HOOKS);
        }
    }

    /**
     * @internal
     * Called when all the hooks are processed and the message should be really sent.
     * Performs a user callback invocation after the message is sent out.
     *
     * @param m Message - message to send
     * @param onlyReference boolean - if true message will be sent as a reference
     *   only if it is possible
     * @param currentHookNumber
     * @throws InvisibleContainerException - throws if the target container is
     *   not visible or cannot connect to its listening port
     */
    private final void sendMessageDirectly(final Message msg) throws InvisibleContainerException
    {
        if (msg.isUndeliverable()) {
            if (msg.isMessageSizeRequired()) {
                // fill message size
                msg.setMessageSize(aglobe.platform.transport.MessageTransport.getSimulatedMessageSize(msg));
            }
            return;
        }
        // check ConversationID and ReplyWith message slot
        ensureMessageIDs(msg);

        if (msg.isMulticast()) {
            aglobe.platform.transport.MessageTransport.sendMulticastMessage(msg);
        } else {
            aglobe.platform.transport.MessageTransport.sendStandardMessage(msg);
        }
    }

    /**
     * @internal
     * Processes a message that was just received. Called by the underlying transport layer.
     * The message should be passed to the receiver specified; the receiver field is necessary
     * for the
     * @return
     */
    @Override
	public final void processReceivedMessage(final Message msg, final MessageReceiver receiver) {
        if (msg.getDoNotSniff() || (nextReceiveMessageHooks[MAX_MESSAGE_HOOKS] < 0)) {
            // no hook, send directly to the receiver
            receiver.incomingMessage(msg);
        } else {
            forwardIncomingMessage(msg, receiver, MAX_MESSAGE_HOOKS);
        }
    }

    /*
     * (non-Javadoc)
     * @see aglobe.platform.MessageTransportComponent#translateMessageReceiver(aglobe.container.transport.Address)
     * 
     * Processes registered translate message hooks.
     * 
     * @param receiver address of the receiver to be translated
     * @return translated receiver address
     */
    @Override
    public Address translateMessageReceiver(Address receiver) {
        int nextHook = nextTranslateMessageReceiverHooks[MAX_MESSAGE_HOOKS];
        while (nextHook >= 0) {
            final TranslateMessageReceiverHookInterface tmrhi = translateReceiverHooks[nextHook];
            if (tmrhi != null) {
                receiver = tmrhi.translateMessageReceiver(receiver);
            }
            nextHook = nextTranslateMessageReceiverHooks[nextHook];
        }
        return receiver;
    }




    /**
     * @internal
     * Check if message contains ConversationID and ReplyWith fields. If there is missing one, it fill it new unique value
     * @param m Message
     */
    public final void ensureMessageIDs(final Message m) {
        if (m.getReplyWith() == null) {
            m.setReplyWith(idGenerator.getNextID());
        }

        if (m.getConversationID() == null) {
            m.setConversationID(idGenerator.getNextID());
        }
    }

    /**
     * @internal
     * Stop the MessageTransport layer. It is called by AgentManager before shutdown the agent container. Do not call this
     * method from the agent !!!
     */
    public final void stopMessageTransport() {
        if (registered) {
            // deregister container MT from the platform MT
            aglobe.platform.transport.MessageTransport.deregisterMessageTransport(container.getContainerName());

            registered = false;
        }
    }

    /**
     * @internal
     * Needed for handling incoming topic
     * @param r Runnable
     */
    public final void addEvent(final Runnable r) {
        // just start, and do as quick as possible
        r.run();
    }

    /**
     * Registers hooks that will be intercepting messages. Two separate hooks might be registered -
     * one for outgoing messages (sendHook) and one for incoming (receiveHook).
     *
     * @param sendHook An outgoing hook to register.
     * @param priority Hook priority. It needs to be unique, no two hooks with the same priority
     *                 are allowed.
     */
    public final void registerMessageHook(
                        final SendMessageHookInterface sendHook,
                        final ReceiveMessageHookInterface receiveHook,
                        final TranslateMessageReceiverHookInterface translateHook,
                        final int priority)
    {
        if (priority < 0)
            throw new IllegalArgumentException("MessageHook priority needs to be >= 0");
        if (priority >= MAX_MESSAGE_HOOKS)
            throw new IllegalArgumentException(String.format("Only hooks with priority < %d are allowed", MAX_MESSAGE_HOOKS));
        if (sendHook == null && receiveHook == null && translateHook == null)
            throw new IllegalArgumentException("All message hooks are null - nothing to register.");

        synchronized (messageHookLock) {
            // priorities are unique - there cannot exist the same one. Even if someone
            // registers just a receive hook, no one else can register the send hook with
            // the same priority
            if (sendMessageHooks[priority] != null || receiveMessageHooks[priority] != null || translateReceiverHooks[priority] != null )
                throw new IllegalArgumentException(String.format("MessageHook of priority %d already registered", priority));

            if (sendHook != null) {
                sendMessageHooks[priority] = sendHook;
                if (priority > nextSendMessageHooks[MAX_MESSAGE_HOOKS]) {
                    nextSendMessageHooks[priority] = nextSendMessageHooks[MAX_MESSAGE_HOOKS];
                    nextSendMessageHooks[MAX_MESSAGE_HOOKS] = priority;
                } else {
                    int i = priority+1;
                    while (sendMessageHooks[i] == null) {
                        i++;
                    }
                    nextSendMessageHooks[priority] = nextSendMessageHooks[i];
                    nextSendMessageHooks[i] = priority;
                }
            }

            if (receiveHook != null) {
                receiveMessageHooks[priority] = receiveHook;
                if ((nextReceiveMessageHooks[MAX_MESSAGE_HOOKS] < 0) || (priority < nextReceiveMessageHooks[MAX_MESSAGE_HOOKS])) {
                    nextReceiveMessageHooks[priority] = nextReceiveMessageHooks[MAX_MESSAGE_HOOKS];
                    nextReceiveMessageHooks[MAX_MESSAGE_HOOKS] = priority;
                } else {
                    int i = priority-1;
                    while (receiveMessageHooks[i] == null) {
                        i--;
                    }
                    nextReceiveMessageHooks[priority] = nextReceiveMessageHooks[i];
                    nextReceiveMessageHooks[i] = priority;
                }
            }
            
            if (translateHook != null) {
                translateReceiverHooks[priority] = translateHook;
                if ((nextTranslateMessageReceiverHooks[MAX_MESSAGE_HOOKS] < 0) || (priority < nextTranslateMessageReceiverHooks[MAX_MESSAGE_HOOKS])) {
                    nextTranslateMessageReceiverHooks[priority] = nextTranslateMessageReceiverHooks[MAX_MESSAGE_HOOKS];
                    nextTranslateMessageReceiverHooks[MAX_MESSAGE_HOOKS] = priority;
                } else {
                    int i = priority-1;
                    while (translateReceiverHooks[i] == null) {
                        i--;
                    }
                    nextTranslateMessageReceiverHooks[priority] = nextTranslateMessageReceiverHooks[i];
                    nextTranslateMessageReceiverHooks[i] = priority;
                }
            }
        }
    }

    /**
     * Unregisters a previously registered hook for outgoing messages.
     *
     * @param hook The hook to be unregistered.
     * @return true if a hook was unregistered, false if there is no such hook.
     */
    public final boolean unregisterMessageHook(final SendMessageHookInterface hook)
    {
        boolean found = false;

        synchronized (messageHookLock) {
            int i = MAX_MESSAGE_HOOKS;
            int prev = -1;
            while (i >= 0) {
                if (sendMessageHooks[i] == hook) {
                    found = true;
                    nextSendMessageHooks[prev] = nextSendMessageHooks[i];
                    // remove hook registration
                    sendMessageHooks[i] = null;
                    nextSendMessageHooks[i] = -1;
                    break;
                }
                prev = i;
                i = nextSendMessageHooks[i];
            }
        }
        return found;
    }

    /**
     * Unregisters a previously registered hook for incoming messages.
     *
     * @param hook The hook to be unregistered.
     * @return true if a hook was unregistered, false if there is no such hook.
     */
    public final boolean unregisterMessageHook(final ReceiveMessageHookInterface hook)
    {
        boolean found = false;

        synchronized (messageHookLock) {
            int i = MAX_MESSAGE_HOOKS;
            int prev = -1;
            while (i >= 0) {
                if (receiveMessageHooks[i] == hook) {
                    found = true;
                    nextReceiveMessageHooks[prev] = nextReceiveMessageHooks[i];
                    // remove hook registration
                    receiveMessageHooks[i] = null;
                    nextReceiveMessageHooks[i] = -1;
                    break;
                }
                prev = i;
                i = nextReceiveMessageHooks[i];
            }
        }
        return found;
    }

    /**
     * Unregisters a previously registered hook for incoming messages.
     *
     * @param hook The hook to be unregistered.
     * @return true if a hook was unregistered, false if there is no such hook.
     */
    public final boolean unregisterMessageHook(final TranslateMessageReceiverHookInterface hook)
    {
        boolean found = false;

        synchronized (messageHookLock) {
            int i = MAX_MESSAGE_HOOKS;
            int prev = -1;
            while (i >= 0) {
                if (translateReceiverHooks[i] == hook) {
                    found = true;
                    nextTranslateMessageReceiverHooks[prev] = nextTranslateMessageReceiverHooks[i];
                    // remove hook registration
                    translateReceiverHooks[i] = null;
                    nextTranslateMessageReceiverHooks[i] = -1;
                    break;
                }
                prev = i;
                i = nextTranslateMessageReceiverHooks[i];
            }
        }
        return found;
    }

}
