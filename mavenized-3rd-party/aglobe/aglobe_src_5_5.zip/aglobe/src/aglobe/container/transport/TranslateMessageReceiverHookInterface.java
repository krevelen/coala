package aglobe.container.transport;

/**
 * Interface to implement when you want to translate the message receiver address.
 * With an object implementing this interface, you need to call 
 * MessageTransport.registerHook() to actually receive the messages.
 * 
 * @author Honza
 */
public interface TranslateMessageReceiverHookInterface {

	/**
	 * Called on the hook to let it change the message receiver.
	 * 
	 * @param receiver The receiver address.
	 * @return new receiver address
	 */
	public Address translateMessageReceiver(Address receiver);
}
