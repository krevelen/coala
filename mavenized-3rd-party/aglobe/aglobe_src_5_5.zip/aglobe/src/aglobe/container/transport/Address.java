package aglobe.container.transport;

import java.io.Externalizable;
import java.io.IOException;
import java.io.NotActiveException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.ObjectStreamException;
import java.io.Serializable;
import java.lang.ref.PhantomReference;
import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;
import java.lang.ref.SoftReference;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;

import aglobe.container.AgentContainer;
import aglobe.container.agent.Agent;
import aglobe.container.library.LibraryObjectInputStream;
import aglobe.container.service.Service;
import aglobe.platform.transport.AddressReader;
import aglobe.platform.transport.AddressWriter;
import aglobe.platform.transport.MessageObjectOutputStream;
import aglobe.platform.transport.MessageTransport;
import aglobe.util.ConversionTools;
import aglobe.util.ExceptionPrinter;
import aglobe.util.Logger;
import aglobe.util.concurrent.NonblockingPoolArrayFIFO;

/**
 * <p>
 * Title: A-Globe
 * </p>
 * <p>
 * Description: Class representing agent, service and container address. It is
 * used for Message as a sender and receiver. String address format is
 * following: agent/service address -
 * aglobe://host:port/container_name/[service|agent]/name container address -
 * aglobe://host:port/container_name/ or aglobe://host:port/container_name
 * platform address - aglobe://host:port/ or aglobe://host:port
 * </p>
 *
 * <p>
 * Copyright: Copyright (c) 2004
 * </p>
 * <p>
 * Company: Gerstner Laboratory
 * </p>
 *
 * @author David Sislak
 * @version $Revision: 1.48 $ $Date: 2010/11/30 09:12:27 $
 *
 */
public final class Address implements Comparable<Address>, Serializable {
    private static final boolean DEBUG = false;

    /**
     * Keep it for at least 30 seconds after sent
     */
    private static final long KEEP_AFTER_SENT_MILLIS = 30000;

    /**
     * @internal This string is set to 'aglobe'. Address is resolved from this
     *           form 'aglobe://host:port/container_name/[service|agent]/name'.
     */
    private static final String PROTOCOL = "aglobe";

    /**
     * @internal This string is set to 'service'. Address is resolved from this
     *           form 'aglobe://host:port/container_name/[service|agent]/name'.
     */
    private static final String SERVICEPREFIX = "service";

    /**
     * @internal This string is set to 'agent'. Address is resolved from this
     *           form 'aglobe://host:port/container_name/[service|agent]/name'.
     */
    private static final String AGENTPREFIX = "agent";

    /**
     * Protocol prefix
     */
    private static final String PROTPREFIX = PROTOCOL + "://";

    /**
     * Protocol prefix length
     */
    private static final int PROTPREFIX_LENGTH = Address.PROTPREFIX.length();

    /**
     * Port delimiter
     */
    private static final char PORTDELIMITER = ':';

    /**
     * Slash char
     */
    private static final char SLASH = '/';

    private static final long platformAddressBase;

    private static final AtomicInteger addressIDgenerator;

    // initialize platform address base and addressID
    static {
        final InetSocketAddress localAddress = MessageTransport.localAddress;
        if (localAddress == null) {
            platformAddressBase = 0;
            addressIDgenerator = new AtomicInteger(0);
        } else {
            final int port = localAddress.getPort();
            final byte[] ip = localAddress.getAddress().getAddress();
            if (ip.length == 16) {
                // compute mask for IPv6 address
                ip[0] ^= (ip[4] ^ ip[8] ^ ip[12]);
                ip[1] ^= (ip[5] ^ ip[9] ^ ip[13]);
                ip[2] ^= (ip[6] ^ ip[10] ^ ip[14]);
                ip[3] ^= (ip[7] ^ ip[11] ^ ip[15]);
            }
            int basePart = (port << 16) | ((ip[2] & 0xff) << 8) | (ip[3] & 0xff);
            final int mux = ((ip[0] & 0xff) << 8) | (ip[1] & 0xff);
            int basePos = 1 << 16;
            int muxPos = 1 << 15;
            for (int i = 0; i < 16; i++) {
                if ((mux & muxPos) != 0) {
                    basePart ^= basePos;
                }
                muxPos >>= 1;
            basePos <<= 1;
            }

            platformAddressBase = (basePart & 0xFFFFFFFFL) << 32;
            addressIDgenerator = new AtomicInteger((port << 16) | ((ip[0] & 0xff) << 8) | (ip[1] & 0xff));
        }
    }

    private static final Address myLocalPlatformAddress;

    private static final NonblockingPoolArrayFIFO<Address> pool = new NonblockingPoolArrayFIFO<Address>(1024);

    /**
     * There are stored all known addresses.
     */
    private static final ConcurrentHashMap<AddressSoftReference, AddressSoftReference> addressesCache = new ConcurrentHashMap<AddressSoftReference, AddressSoftReference>();

    private static final ConcurrentHashMap<Long, AddressSoftReference> addressesById = new ConcurrentHashMap<Long, AddressSoftReference>();

    private static final AddressReferenceQueue refQueue = new AddressReferenceQueue();

    // this initialization has to be the last one after all static fields
    static {
        if (MessageTransport.localAddress == null) {
            myLocalPlatformAddress = null;
        } else {
            myLocalPlatformAddress = getAddress(MessageTransport.localHostAddress, MessageTransport.localPort, null, false, null);
        }
    }

    private AddressSoftReference myAddressSoftReference = new AddressSoftReference(this, refQueue);

    /**
     * true iff this address represents platform
     */
    private boolean isPlatform;

    /**
     * true iff this address represents container
     */
    private boolean isContainer;

    /**
     * true iff this address represents agent
     */
    private boolean isAgent;

    /**
     * entity (agent or service) name part of the address
     */
    private String name;

    /**
     * container name part of the address
     */
    private String containerName;

    /**
     * port number part of the address
     */
    private int port;

    /**
     * host part of the address
     */
    private String host;

    /**
     * Hash code of the address
     */
    private int _hashCode;

    /**
     * String value of the address
     */
    private String _stringValue = null;

    /**
     * if hasContainerAddress is true, this contains derived container address
     * from this address
     */
    private Address derivedContainerAddress = null;

    /**
     * if hasPlatformAddress is true, this contains derived container address
     * from this address
     */
    private Address derivedPlatformAddress = null;

    private final static void clearReferences() {
        AddressSoftReference asr;
        while ((asr = (AddressSoftReference) refQueue.poll()) != null) {
            // remove from the cache
            addressesCache.remove(asr);
            // remove primary address id
            addressesById.remove(asr.addressId, asr);

            // remove all secondary address IDs
            if (asr.secondaryAddressIds != null) {
                Long secId;
                while ((secId = asr.secondaryAddressIds.poll()) != null) {
                    addressesById.remove(secId, asr);
                }
                asr.secondaryAddressIds = null;
            }

            if (DEBUG) {
                try {
                    System.out.println("Finalized the address: " + asr.getFinalizedObject().toString()+" ("+asr.addressId+")");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            asr.addressId = null;
        }
    }

    private final static Address getTempAddress() {
        final Address candidate = pool.pop();
        if (candidate == null) {
            return new Address();
        }
        return candidate;
    }

    /**
     * Instance cannot be created from outside
     */
    private Address() {
    }

    private final void release() {
        name = null;
        containerName = null;
        host = null;
        _stringValue = null;
        derivedPlatformAddress = null;
        derivedContainerAddress = null;

        myAddressSoftReference.addressId = null;
        myAddressSoftReference.secondaryAddressIds = null;

        pool.push(this);
    }

    private final static Address checkExistence(final Address candidate) {
        clearReferences();
        final AddressSoftReference myAddressSoftReference = candidate.myAddressSoftReference;
        for (;;) {
            final AddressSoftReference existingObject = addressesCache.get(myAddressSoftReference);
            if (existingObject == null) {
                // prepare string value
                candidate.initializeStringValueAndId();
                final AddressSoftReference old = addressesCache.putIfAbsent(myAddressSoftReference, myAddressSoftReference);
                if (old == null) {
                    for (;;) {
                        final AddressSoftReference old2 = addressesById.putIfAbsent(myAddressSoftReference.addressId, myAddressSoftReference);
                        if (old2 == null) {
                            return candidate;
                        }
                        final Address alternativeVal = old2.get();
                        if (alternativeVal == null) {
                            // instead of old2.addressId use myAddressSoftReference.addressId directly because the old2 can be registered as secondary IDs here and not primary one
                            addressesById.replace(myAddressSoftReference.addressId, old2, myAddressSoftReference);
                            continue;
                        }
                        if (candidate == alternativeVal) {
                            // inserted by other thread
                            return candidate;
                        }
                        final String err = "Address ID collision !!! Both have the same addressId:\n" + candidate.toString() + "\n" + alternativeVal.toString();
                        Logger.logSevere(err);
                        throw new IllegalArgumentException(err);
                    }
                }
            } else {
                final Address alternativeVal = existingObject.get();
                if (alternativeVal == null) {
                    addressesCache.remove(existingObject, existingObject);
                    continue;
                }
                // ensure that existing address is stored already in Id map
                final AddressSoftReference old2 = addressesById.putIfAbsent(existingObject.addressId, existingObject);
                if ((old2 == null) || (old2 == existingObject)) {
                    if (DEBUG) {
                        System.out.println("Address hit: " + addressesCache.size() + "(" + addressesById.size() + ")");
                    }
                    candidate.release();
                    return alternativeVal;
                }
                // wait for the replacement solution
                Thread.yield();
            }
        }
    }

    /**
     * This method resolves an AGLOBE address into instance of A-Globe Address
     * object.
     *
     * @param str is in form
     *            'aglobe://host:port/container_name/[service|agent]/name'
     * @return Address
     */
    public final static Address getAddress(final String str) {
        Address candidate = getTempAddress();
        candidate.prepareAddress(str);
        return checkExistence(candidate);
    }

    public final static Address getAddress(final String _host, final int _port, final String _containerName, final boolean _isagent, final String _name) {
        Address candidate = getTempAddress();
        candidate.prepareAddress(_host, _port, _containerName, _isagent, _name);
        return checkExistence(candidate);
    }

    /**
     * @internal
     * Get address with specified address Id.
     * @param addressId
     * @return - can be null if the address is not found
     */
    public final static Address getAddress(final Long addressId) {
        clearReferences();
        final AddressSoftReference awr = addressesById.get(addressId);
        Address adr;
        if ((awr != null) && ((adr = awr.get()) != null)) {
            return adr;
        }
        return null;
    }

    /**
     * @internal
     * Get address with specified address id for platform message transport purposes
     * @param addressId
     * @return
     */
    public final static Address getAddressDefinitionForTransport(final Long addressId) {
        final AddressSoftReference awr = addressesById.get(addressId);
        if (awr == null) {
            return null;
        }
        final Address adr = awr.get();
        if (adr != null) {
            return adr;
        }
        return awr.getFinalizedObject();
    }

    /**
     * @internal Returns required address object and assign specified addressId
     *           to it.
     *
     * @param addressId
     * @param str
     * @return
     */
    public final static Address ensureSpecificAddress(final Long addressId, final String str) {
        final Address candidate = getTempAddress();
        candidate.prepareAddress(str);
        clearReferences();
        out:
        for (;;) {
            Address retVal;
            final AddressSoftReference existingObject = addressesCache.get(candidate.myAddressSoftReference);
            if ((existingObject != null) && ((retVal = existingObject.get()) != null)) {
                if (existingObject.secondaryAddressIds == null) {
                    existingObject.secondaryAddressIds = new ConcurrentLinkedQueue<Long>();
                }
                // add new reference for the same address
                existingObject.secondaryAddressIds.add(addressId);
                for (;;) {
                    final AddressSoftReference old = addressesById.putIfAbsent(addressId, existingObject);
                    if (old == null) {
                        candidate.release();
                        return retVal;
                    } else {
                        final Address alternativeVal = old.get();
                        if (alternativeVal == null) {
                            final AddressSoftReference secondReplacement = addressesCache.get(existingObject);
                            if ((secondReplacement == null) || (secondReplacement == existingObject)) {
                                // instead of old.addressId is used addressId directly because the old can be registered as secondary IDs here and not primary one
                                addressesById.replace(addressId, old, existingObject); // here was wrong candidate.myAddressSoftReference
                            } else {
                                continue out;
                            }
                            continue;
                        }
                        if (alternativeVal == retVal) {
                            // it is the same address
                            candidate.release();
                            return retVal;
                        }
                        final String err = "Address ID collision !!! Both have the same addressId:\n" + retVal.toString() + "\n" + alternativeVal.toString();
                        Logger.logSevere(err);
                        throw new IllegalArgumentException(err);
                    }
                }
            }
            // initialize string and ID
            candidate._stringValue = candidate.myToString();
            candidate.myAddressSoftReference.addressId = addressId;
            final AddressSoftReference old = addressesCache.putIfAbsent(candidate.myAddressSoftReference, candidate.myAddressSoftReference);
            if (old == null) {
                for (;;) {
                    final AddressSoftReference old2 = addressesById.putIfAbsent(addressId, candidate.myAddressSoftReference);
                    if (old2 == null) {
                        // properly inserted
                        return candidate;
                    }
                    final Address alternativeVal = old2.get();
                    if (alternativeVal == null) {
                        // instead of old2.addressId is used addressId directly because the old2 can be registered as secondary IDs here and not primary one
                        addressesById.replace(addressId, old2, candidate.myAddressSoftReference);
                        continue;
                    }
                    if (alternativeVal == candidate) {
                        // inserted by other thread
                        return candidate;
                    }
                    final String err = "Address ID collision !!! Both have the same addressId:\n" + candidate.toString() + "\n" + alternativeVal.toString();
                    Logger.logSevere(err);
                    throw new IllegalArgumentException(err);
                }
            }
        }
    }

    /**
     * @internal
     * Called from platform message transport to notify that the address should not be removed
     * for a while as it can be requested by the target platform.
     */
    public final void keepAfterSent() {
        myAddressSoftReference.canBeReleasedAfter = System.currentTimeMillis() + KEEP_AFTER_SENT_MILLIS;
    }


    /**
     * Parse the String in form
     * aglobe://host:port/container_name/[service|agent]/name.
     *
     * @param str
     *            String
     */
    private void prepareAddress(final String str) {
        final String strLow = str; // address is the case sensitive
        // test if address has correct prefix
        if (!strLow.startsWith(Address.PROTPREFIX))
            throw new IllegalArgumentException("An address does not start with " + Address.PROTPREFIX + "\n" + str);

        // find index of port delimiter
        int portIndex, containerNameIndex, typeIndex, nameIndex;
        if ((portIndex = strLow.indexOf(Address.PORTDELIMITER, Address.PROTPREFIX_LENGTH)) < 0) {
            throw new IllegalArgumentException("Invalid address: " + str);
        }
        if (((containerNameIndex = strLow.indexOf(Address.SLASH, portIndex + 1)) > 0) && (containerNameIndex < (strLow.length() - 1))) {
            typeIndex = strLow.indexOf(Address.SLASH, containerNameIndex + 1);
            // resolve type of the address
            boolean isAgent = false, isService = false;
            if (typeIndex != -1) {
                if (!(isAgent = strLow.startsWith(Address.AGENTPREFIX, typeIndex + 1))) {
                    this.isAgent = false;
                    isService = strLow.startsWith(Address.SERVICEPREFIX, typeIndex + 1);
                } else {
                    this.isAgent = true;
                }
            } else {
                this.isAgent = false;
            }
            this.isPlatform = false;
            this.isContainer = (!isAgent) && (!isService);
        } else {
            typeIndex = strLow.length();
            this.isPlatform = true;
            this.isContainer = false;
            this.isAgent = false;
        }

        // test name part of the address
        nameIndex = strLow.indexOf(Address.SLASH, typeIndex + 1);
        if ((!this.isContainer) && (!this.isPlatform)) {
            if (nameIndex < 0) {
                throw new IllegalArgumentException("Invalid address: " + str);
            } else {
                // read name part of the address and remove trailing white
                // spaces
                this.name = str.substring(nameIndex + 1).trim();
            }
        } else {
            this.name = "";
        }

        // read host part of the address
        this.host = str.substring(Address.PROTPREFIX_LENGTH, portIndex);

        // read port part of the address
        try {
            this.port = Integer.parseInt(str.substring(portIndex + 1, containerNameIndex));
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Invalid address: " + str);
        }

        if (!this.isPlatform) {
            // read container name part of the address
            if (typeIndex < 0) {
                this.containerName = str.substring(containerNameIndex + 1);
            } else {
                this.containerName = str.substring(containerNameIndex + 1, typeIndex);
            }
        } else {
            this.containerName = "";
        }
        // prepare hash code value
        _hashCode = myToHashCode();
        myAddressSoftReference.hashCode = _hashCode;
    }

    private void prepareAddress(final String _host, final int _port, final String _containerName, final boolean _isagent, final String _name) {
        this.host = _host;
        this.port = _port;
        this.isAgent = _isagent;

        if ((_name == null) || _name.length() == 0) {
            this.name = "";
            if ((_containerName == null) || (_containerName.length() == 0)) {
                this.isPlatform = true;
                this.isContainer = false;
                this.containerName = "";
            } else {
                this.isPlatform = false;
                this.isContainer = true;
                this.containerName = _containerName;
            }
        } else {
            this.containerName = _containerName;
            this.name = _name;
            this.isPlatform = false;
            this.isContainer = false;
        }

        // prepare hash code value
        _hashCode = myToHashCode();
        myAddressSoftReference.hashCode = _hashCode;
    }

    private final void initializeStringValueAndId() {
        if (_stringValue == null) {
            _stringValue = myToString();
        }
        if (myAddressSoftReference.addressId == null) {
            myAddressSoftReference.addressId = Address.platformAddressBase | (Address.addressIDgenerator.incrementAndGet() & 0xFFFFFFFFL);
        }
    }

    /**
     * Count hash code of the address
     *
     * @return int
     */
    private final int myToHashCode() {
        int retVal = 19;
        retVal = 37 * retVal + host.hashCode();
        retVal = 37 * retVal + port;
        if (isPlatform) {
            retVal = 37 * retVal + 1;
        }
        retVal = 37 * retVal + containerName.hashCode();
        if (isContainer) {
            retVal = 37 * retVal + 1;
        }
        if (isAgent) {
            retVal = 37 * retVal + 1;
        }
        retVal = 37 * retVal + name.hashCode();
        return retVal;
    }

    /**
     * Returns hash code of this address instance.
     *
     * @return int
     */
    @Override
    public final int hashCode() {
        return _hashCode;
    }

    /**
     * @internal Returns unique address identifier
     * @return
     */
    public final Long getAddressId() {
        return myAddressSoftReference.addressId;
    }

    /**
     * Returns string representation of the address
     *
     * @return String
     */
    private final String myToString() {
        final StringBuilder sb = new StringBuilder();
        sb.append(Address.PROTPREFIX).append(host).append(Address.PORTDELIMITER).append(port).append(Address.SLASH);
        if (!isPlatform) {
            sb.append(containerName).append(Address.SLASH);
            if (!isContainer) {
                if (isAgent) {
                    sb.append(Address.AGENTPREFIX);
                } else {
                    sb.append(Address.SERVICEPREFIX);
                }
                sb.append(Address.SLASH).append(name);
            }
        }
        return sb.toString();
    }

    /**
     * Returns string representation of the address.
     *
     * @return String
     */
    @Override
    public final String toString() {
        return _stringValue;
    }

    /**
     * Returns port number from the Address instance
     *
     * @return int
     */
    public final int getPort() {
        return port;
    }

    /**
     * This method resolves name from Address instance. It can be name of Agent
     * or Service. Container address has this field filled with empty string.
     *
     * @return String
     */
    public final String getName() {
        return name;
    }

    /**
     * This method returns name of host machine from instance of Address object.
     *
     * @return String
     */
    public final String getHost() {
        return host;
    }

    /**
     * Returns container name from the address instance
     *
     * @return String
     */
    public final String getContainerName() {
        return containerName;
    }

    /**
     * This method tests if instance of Address object represents an agent.
     *
     * @return boolean - true iff it is agent address
     */
    public final boolean isAgent() {
        return isAgent && (!isContainer);
    }

    /**
     * This method tests if instance of Address object represents a service.
     *
     * @return boolean - true iff it is service address
     */
    public final boolean isService() {
        return (!isAgent) && (!isContainer);
    }

    /**
     * This method tests if instance of Address object represents a container.
     *
     * @return boolean - true iff it is container address
     */
    public final boolean isContainerAddress() {
        return isContainer;
    }

    /**
     * This method tests if instance of Address object represents a platform.
     *
     * @return boolean - true iff it is platform address
     */
    public final boolean isPlatformAddress() {
        return isPlatform;
    }

    /**
     * Provides host name comparison, which can deal with 'local host' host
     * name. Assuming, the current host has name 'Goblin', this method considers
     * 'local host' and 'Goblin' being the same host name.
     *
     * @param h1
     *            String - first address string
     * @param h2
     *            String - second address string
     * @return boolean - true if hosts are the same
     */
    private final static boolean isSameHost(final String h1, final String h2) {
        return h1.equals(h2);
    }

    /**
     * This method tests whether an Address points to the same platform as
     * current instance of Address object.
     *
     * @param a
     *            Address - address instance with which is current instance
     *            compared
     * @return boolean - true if both addresses points to the same platform
     */
    public final boolean isSamePlatform(final Address a) {
        return (a != null) && (a.port == port) && isSameHost(host, a.host);
    }

    /**
     * This method tests whether an Address points to the same container as
     * current instance of Address object.
     *
     * @param a
     *            Address - address instance with which is current instance
     *            compared
     * @return boolean - true if both addresses points to the same container
     */
    public final boolean isSameContainer(final Address a) {
        return (a != null) && (a.port == port) && isSameHost(host, a.host) && containerName.equals(a.containerName);
    }

    /**
     * Test if this is address assigned to some container, agent or service
     * running on local platform
     *
     * @return boolean - true iff this is local platform address
     */
    public final boolean isLocalPlatform() {
        return (port == MessageTransport.localPort) && (host.equals(MessageTransport.localHostAddress));
    }

    /**
     * This method returns the Address of a platform.
     *
     * @return Address - address of the platform
     */
    public final static Address getLocalPlatformAddress() {
        return myLocalPlatformAddress;
    }

    /**
     * This method returns the Address of a container.
     *
     * @param container
     *            AgentContainer - instance of the Address container
     * @return Address - address of the container
     */
    public final static Address getLocalContainerAddress(final AgentContainer container) {
        return getAddress(MessageTransport.localHostAddress, MessageTransport.localPort, container.getContainerName(), false, null);
    }

    /**
     * This method resolves address of a container from an agent instance.
     *
     * @param agent
     *            Agent
     * @return Address - address of the agent container
     */
    public final static Address getLocalContainerAddress(final Agent agent) {
        return getLocalContainerAddress(agent.getContainer());
    }

    /**
     * This method resolves address of container from service instance.
     *
     * @param service
     *            Service
     * @return Address - address of the container
     */
    public final static Address getLocalContainerAddress(final Service service) {
        return getLocalContainerAddress(service.getContainer());
    }

    /**
     * This method resolves agent's Address from his name and a container
     * instance.
     *
     * @param name
     *            agent's name
     * @param container
     *            container where the agent is.
     * @return Address of agent
     */

    public final static Address getLocalAgentAddress(final AgentContainer container, final String name) {
        return getAddress(MessageTransport.localHostAddress, MessageTransport.localPort, container.getContainerName(), true, name);
    }

    /**
     * This method returns the address of the agent.
     *
     * @param agent
     *            Agent - agent's instance
     * @param name
     *            String - agent's name
     * @return Address - address of the agent
     */
    public final static Address getLocalAgentAddress(final Agent agent, final String name) {
        return getLocalAgentAddress(agent.getContainer(), name);
    }

    /**
     * This method returns the address of the agent.
     *
     * @param name
     *            name of the agent
     * @param service
     *            is any service on the container where the agent is.
     * @return address address of the agent
     */
    public final static Address getLocalAgentAddress(final Service service, final String name) {
        return getLocalAgentAddress(service.getContainer(), name);
    }

    /**
     *
     * This method resolves address of service from the container instance and
     * name of the service.
     *
     * @param name
     *            name of service
     * @param container
     *            container where service is
     * @return address address of service
     */
    public final static Address getLocalServiceAddress(final AgentContainer container, final String name) {
        return getAddress(MessageTransport.localHostAddress, MessageTransport.localPort, container.getContainerName(), false, name);
    }

    /**
     * This method returns address of the service.
     *
     * @param name
     *            name of the service
     * @param agent
     *            any agent on container where the service is.
     * @return Address of the service
     */
    public final static Address getLocalServiceAddress(final Agent agent, final String name) {
        return getLocalServiceAddress(agent.getContainer(), name);
    }

    /**
     * This method returns address of the service.
     *
     * @param name
     *            name of service
     * @param service
     *            any service on container where the service is.
     * @return Address of service
     */
    public final static Address getLocalServiceAddress(final Service service, final String name) {
        return getLocalServiceAddress(service.getContainer(), name);
    }

    /**
     * This method resolves platform address from host name and port number
     *
     * @param host
     *            String - host IP address
     * @param port
     *            int - port number
     * @return Address - address of the platform
     */
    public final static Address getPlatformAddress(final String host, final int port) {
        return getAddress(host, port, null, false, null);
    }

    /**
     * This method resolves container address from host name, port number and
     * container name
     *
     * @param host
     *            String - host IP address
     * @param port
     *            int - port number
     * @param containerName
     *            String
     * @return Address - address of the container
     */
    public final static Address getContainerAddress(final String host, final int port, final String containerName) {
        return getAddress(host, port, containerName, false, null);
    }

    /**
     * The method returns address instance resolving from host, port and name of
     * the agent.
     *
     * @param host
     *            String
     * @param port
     *            int
     * @param containerName
     *            String
     * @param name
     *            String
     * @return Address
     */
    public final static Address getAgentAddress(final String host, final int port, final String containerName, final String name) {
        return getAddress(host, port, containerName, true, name);
    }

    /**
     * The method returns address instance resolving from host, port and name of
     * the service.
     *
     * @param host
     *            String
     * @param port
     *            int
     * @param containerName
     *            String
     * @param name
     *            String
     * @return Address
     */
    public final static Address getServiceAddress(final String host, final int port, final String containerName, final String name) {
        return getAddress(host, port, containerName, false, name);
    }

    /**
     * This method derives the address of platform form existing address
     * instance.
     *
     * @return address address of platform
     */
    public final Address derivePlatformAddress() {
        if (derivedPlatformAddress == null) {
            if (isPlatform) {
                // address is already platform address
                derivedPlatformAddress = this;
            } else {
                derivedPlatformAddress = getAddress(host, port, null, false, null);
            }
        }
        return derivedPlatformAddress;
    }

    /**
     * This method derives the address of container form existing address
     * instance.
     *
     * @return address address of container
     */
    public final Address deriveContainerAddress() {
        if (derivedContainerAddress == null) {
            if (isContainer) {
                // address is already container address
                derivedContainerAddress = this;
            } else {
                derivedContainerAddress = getAddress(host, port, containerName, false, null);
            }
        }
        return derivedContainerAddress;
    }

    /**
     * This method returns address of the agent with host and port derived from
     * existing address instance.
     *
     * @param name
     *            name of the agent
     * @return address of the agent
     */
    public final Address deriveAgentAddress(final String _name) {
        return getAddress(host, port, containerName, true, _name);
    }

    /**
     * This method returns address of the service with host and port derived
     * from existing address instance.
     *
     * @param name
     *            name of the service
     * @return address of the service
     */
    public final Address deriveServiceAddress(final String _name) {
        return getAddress(host, port, containerName, false, _name);
    }

    /**
     * The method returns true when 'other' address points to the same
     * agent/service/container.
     *
     * @param other
     *            Object
     * @return boolean
     */
    @Override
    public final boolean equals(final Object other) {
        return (this == other);
    }

    private final boolean perFieldEquals(final Address other) {
        if (this == other) {
            return true;
        }
        if (_hashCode != other.hashCode()) {
            return false;
        }
        return (host.equals(other.host)) && (port == other.port)
                 && (isPlatform == other.isPlatform) && (isPlatform || ((containerName.equals(other.containerName)) && (isContainer == other.isContainer)
                 && (isContainer || ((isAgent == other.isAgent) && (name.equalsIgnoreCase(other.name))))));

    }

    /**
     * This method implements <code>Comparable</code> interface for address
     * class.
     *
     * @param o
     *            Object
     * @return int
     */
    @Override
	public final int compareTo(final Address o) {
        if (this == o) {
            return 0;
        }
        return toString().compareToIgnoreCase(o.toString());
    }

    /**
     * Write address into given output
     *
     * @param _out
     * @throws IOException
     */
    public final void serialize(final ObjectOutput _out) throws IOException {
        if (_out instanceof MessageObjectOutputStream) {
            final AddressWriter aw = ((MessageObjectOutputStream) _out).adderessWriter;
            _out.writeShort(aw.writeAddress(this));
        } else {
            ConversionTools.writeString(_out, _stringValue);
        }
    }

    /**
     * Read address from given input
     *
     * @param _in
     * @return
     * @throws IOException
     */
    public static final Address deserialize(final ObjectInput _in) throws IOException {
        final Address retVal;
        if (_in instanceof LibraryObjectInputStream) {
            final AddressReader ar = ((LibraryObjectInputStream) _in).addressReader;
            if (ar != null) {
            	retVal = ar.readAddress(_in.readShort());
            } else {
            	retVal = Address.getAddress(ConversionTools.readString(_in));
            }
        } else {
            retVal = Address.getAddress(ConversionTools.readString(_in));
        }
        if (retVal == null) {
            throw new IOException("Cannot reslove address");
        }
        return retVal;
    }

    /**
     * Specific serialization of this class, it passed serialization handling to other class
     * @throws ObjectStreamException
     */
    private Object writeReplace() throws ObjectStreamException {
        return myAddressSoftReference;
    }

    /**
     * @param out
     * @throws IOException
     */
    private void writeObject(final ObjectOutputStream out) throws IOException {
        throw new RuntimeException("This should never be called due to used writeReplace() method");
    }

    /**
     * @param in
     * @throws IOException
     * @throws ClassNotFoundException
     */
    private void readObject(final ObjectInputStream in) throws IOException, ClassNotFoundException {
        throw new RuntimeException("This should never be called due to used writeReplace() method");
    }

    /**
     * @throws ObjectStreamException
     */
    @SuppressWarnings("unused")
    private void readObjectNoData() throws ObjectStreamException {
        throw new RuntimeException("This should never be called due to used writeReplace() method");
    }

    private static final class AddressSoftReference extends SoftReference<Address> implements Externalizable {
        /**
         * This number has to be changed, when Address's variables are changed
         */
        private static final long serialVersionUID = 5674439860146150149L;

        private static final Field phantomReferent;
        static {
            Field _phantomReferent = null;
            try {
                _phantomReferent = Reference.class.getDeclaredField("referent");
                _phantomReferent.setAccessible(true);
            } catch (Exception e) {
                System.err.println("Cannot refer necessary fields: "+ExceptionPrinter.toStringWithStackTrace(e));
            }
            phantomReferent = _phantomReferent;
        }

        private Long addressId = null;

        private int hashCode;

        private volatile long canBeReleasedAfter = -1;

        private ConcurrentLinkedQueue<Long> secondaryAddressIds = null;

        private PhantomReference<Address> phantomReference;

        /**
         * Has to be strong reference in order to keep it until read resolve call
         */
        private Address deserializationAddress = null;

        /**
         * @param referent
         */
        private AddressSoftReference(final Address referent, final ReferenceQueue<Address> q) {
            super(referent, q);
            phantomReference = new PhantomReference<Address>(referent, null);
        }

        /**
         * For de-externalization purposes only
         */
        public AddressSoftReference() {
            super(null);
        }

        /*
         * (non-Javadoc)
         *
         * @see java.lang.Object#equals(java.lang.Object)
         */
        @Override
        public final boolean equals(final Object obj) {
            if (this == obj) {
                return true;
            }
            final Address otherAddress = ((AddressSoftReference) obj).get();
            if (otherAddress == null) {
                return false;
            }
            final Address myAddress = get();
            if (myAddress == null) {
                return false;
            }
            return myAddress.perFieldEquals(otherAddress);
        }

        /*
         * @internal (non-Javadoc)
         *
         * @see java.lang.Object#hashCode()
         */
        @Override
        public final int hashCode() {
            return hashCode;
        }

        private final Address getFinalizedObject() {
            try {
                return (Address)phantomReferent.get(phantomReference);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

        /* (non-Javadoc)
         * @see java.io.Externalizable#readExternal(java.io.ObjectInput)
         */
        @Override
        public void readExternal(final ObjectInput in) throws IOException, ClassNotFoundException {
            deserializationAddress = Address.deserialize(in);
        }

        /* (non-Javadoc)
         * @see java.io.Externalizable#writeExternal(java.io.ObjectOutput)
         */
        @Override
        public void writeExternal(final ObjectOutput out) throws IOException {
            final Address adr = get();
            adr.serialize(out);
        }

        private Object readResolve() throws ObjectStreamException {
            if (deserializationAddress == null) {
                throw new NotActiveException("Object has not been previously initialized by readExternal");
            }
            final Address retVal = deserializationAddress;
            deserializationAddress = null;
            return retVal;
        }
    }

    private static class AddressReferenceQueue extends ReferenceQueue<Address> {
        private static final Field lockField;
        private static final Field headField;
        private static final Method reallyPollMethod;
        static {
            Field lockCand = null;
            Field headCand = null;
            Method reallyPollCand = null;
            try {
                lockCand = ReferenceQueue.class.getDeclaredField("lock");
                lockCand.setAccessible(true);
                headCand = ReferenceQueue.class.getDeclaredField("head");
                headCand.setAccessible(true);
                reallyPollCand = ReferenceQueue.class.getDeclaredMethod("reallyPoll");
                reallyPollCand.setAccessible(true);
            } catch (Exception e) {
                System.err.println("Cannot refer necessary fields: "+ExceptionPrinter.toStringWithStackTrace(e));
            }
            lockField = lockCand;
            headField = headCand;
            reallyPollMethod = reallyPollCand;
        }

        /* (non-Javadoc)
         * @see java.lang.ref.ReferenceQueue#poll()
         */
        @SuppressWarnings("unchecked")
        @Override
        public final Reference<? extends Address> poll() {
            try {
                synchronized (lockField.get(this)) {
                    final AddressSoftReference r = (AddressSoftReference) headField.get(this);
                    if (r == null) {
                        return null;
                    }
                    if (r.canBeReleasedAfter > System.currentTimeMillis()) {
                        if (DEBUG) {
                            System.out.println("Delayed keep for next "+(r.canBeReleasedAfter - System.currentTimeMillis())+" ms of: "+r.getFinalizedObject().toString() + " ("+r.addressId+")");
                        }
                        return null;
                    }
                    return (Reference<? extends Address>) reallyPollMethod.invoke(this, (Object[])null);
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

    }
}
