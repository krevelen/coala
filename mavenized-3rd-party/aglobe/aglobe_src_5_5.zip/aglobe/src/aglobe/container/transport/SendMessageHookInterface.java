package aglobe.container.transport;

import aglobe.ontology.Message;

/**
 * Interface to implement when you want to intercept messages that are
 * being sent on the client container. With an object implementing this
 * interface, you need to call MessageTransport.registerHook() to actually
 * receive the messages.
 * 
 * After the message is passed to this method, you should than call
 * MessageTransport.forwardOutgoingMessage() to continue the sending process.
 * 
 * @author Pavel
 */
public interface SendMessageHookInterface {

	/**
	 * Called on the hook to let it process the incoming message. It can be than
	 * passed further up (possibly modified/delayed) by calling
	 * MessageTransport.forwardOutgoingMessage().
	 * 
	 * @param m An outgoing message to intercept.
	 * @throws InvisibleContainerException 
	 */
	public void processOutgoingMessage(Message m) throws InvisibleContainerException;
}
