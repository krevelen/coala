package aglobe.container.transport;

import aglobe.ontology.Message;
import aglobe.platform.transport.MessageReceiver;

/**
 * Interface to implement when you want to intercept messages that are
 * being received on the client container. With an object implementing this
 * interface, you need to call MessageTransport.registerHook() to actually
 * receive the messages.
 * 
 * After the message is passed to this method, you should than call
 * MessageTransport.forwardIncomingMessage() to continue the sending process.
 * 
 * In some cases (routing) the service might need to send the receiving
 * message further. In such cases, calling <code>forwardOutgoingMessage()</code>
 * might be used.
 * 
 * @author Pavel
 */
public interface ReceiveMessageHookInterface {

	/**
	 * Called on the hook to let it process the message. It can be than
	 * passed further (possibly modified/delayed) by calling
	 * MessageTransport.forwardMessage().
	 * 
	 * @param m An outgoing message to intercept.
	 * @throws InvisibleContainerException 
	 */
	public void processIncomingMessage(Message m, MessageReceiver receiver);
}
