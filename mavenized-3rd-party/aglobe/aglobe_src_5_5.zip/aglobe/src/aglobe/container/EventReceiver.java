package aglobe.container;


/**
 * <p>Title: A-Globe</p>
 * <p>Description: Implementor of this interface can handle events in its chain.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.7 $ $Date: 2008/11/23 09:14:11 $
 */
public interface EventReceiver {
  /**
   * Add a runnable object to the queue of the implementor object
   * @param e Runnable
   */
  public void addEvent(Runnable e);
}
