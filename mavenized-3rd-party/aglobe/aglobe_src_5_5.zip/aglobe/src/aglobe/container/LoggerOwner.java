package aglobe.container;

import java.util.logging.*;
import aglobe.util.logging.LogProvider;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: Logger owner interface denotes that implementor provide
 * set of logging methods.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author David Sislak
 * @version $Revision: 1.13 $ $Date: 2009/06/15 13:38:01 $
 */
public interface LoggerOwner
{
    /**
     * Send finest log message to the logger. Automatically append container and entity
     * name to the output log message.
     *
     * @param message String - message
     */
    public void logFinest(String message);

    /**
     * Send fine log message to the logger. Automatically append container and entity
     * name to the output log message.
     *
     * @param message String - message
     */
    public void logFine(String message);

    /**
     * Send info log message to the logger. Automatically append container and entity
     * name to the output log message.
     *
     * @param message String - message
     */
    public void logInfo(String message);

    /**
     * Send warning log message to the logger. Automatically append container and entity
     * name to the output log message.
     *
     * @param message String - message
     */
    public void logWarning(String message);

    /**
     * Send severe log message to the logger. Automatically append container and entity
     * name to the output log message.
     *
     * @param message String - message
     */
    public void logSevere(String message);

    /**
     * Send finest log message to the logger. Automatically append container and entity
     * name to the output log message. Appends information about catch exception.
     *
     * @param message String - message
     * @param e Throwable - exception to be logged
     */
    public void logFinest(String message, Throwable e);

    /**
     * Send fine log message to the logger. Automatically append container and entity name to the output log message. Appends information about catch exception.
     *
     * @param message String - message
     * @param e Throwable
     */
    public void logFine(String message, Throwable e);

    /**
     * Send info log message to the logger. Automatically append container and entity
     * name to the output log message. Appends information about catch exception.
     *
     * @param message String - message
     * @param e Throwable - exception to be logged
     */
    public void logInfo(String message, Throwable e);

    /**
     * Send warning log message to the logger. Automatically append container and entity
     * name to the output log message. Appends information about catch exception.
     *
     * @param message String - message
     * @param e Throwable - exception to be logged
     */
    public void logWarning(String message, Throwable e);

    /**
     * Send severe log message to the logger. Automatically append container and entity
     * name to the output log message. Appends information about catch exception.
     *
     * @param message String - message
     * @param e Throwable - exception to be logged
     */
    public void logSevere(String message, Throwable e);

    /**
     * Send finest log message to the logger. Automatically append container and entity name to the output log message.
     *
     * @param message String - message
     * @param callsBack int
     */
    public void logFinest(String message, int callsBack);

    /**
     * Send fine log message to the logger. Automatically append container and entity name to the output log message.
     *
     * @param message String - message
     * @param callsBack int
     */
    public void logFine(String message, int callsBack);

    /**
     * Send info log message to the logger. Automatically append container and entity name to the output log message.
     *
     * @param message String - message
     * @param callsBack int
     */
    public void logInfo(String message, int callsBack);

    /**
     * Send warning log message to the logger. Automatically append container and entity name to the output log message.
     *
     * @param message String - message
     * @param callsBack int
     */
    public void logWarning(String message, int callsBack);

    /**
     * Send severe log message to the logger. Automatically append container and entity name to the output log message.
     *
     * @param message String - message
     * @param callsBack int
     */
    public void logSevere(String message, int callsBack);

    /**
     * Send finest log message to the logger. Automatically append container and entity name to the output log message. Appends information about catch
     * exception.
     *
     * @param message String - message
     * @param e Throwable - exception to be logged
     * @param callsBack int
     */
    public void logFinest(String message, Throwable e, int callsBack);

    /**
     * Send fine log message to the logger. Automatically append container and entity name to the output log message. Appends information about catch exception.
     *
     * @param message String - message
     * @param e Throwable
     * @param callsBack int
     */
    public void logFine(String message, Throwable e, int callsBack);

    /**
     * Send info log message to the logger. Automatically append container and entity name to the output log message. Appends information about catch exception.
     *
     * @param message String - message
     * @param e Throwable - exception to be logged
     * @param callsBack int
     */
    public void logInfo(String message, Throwable e, int callsBack);

    /**
     * Send warning log message to the logger. Automatically append container and entity name to the output log message. Appends information about catch
     * exception.
     *
     * @param message String - message
     * @param e Throwable - exception to be logged
     * @param callsBack int
     */
    public void logWarning(String message, Throwable e, int callsBack);

    /**
     * Send severe log message to the logger. Automatically append container and entity name to the output log message. Appends information about catch
     * exception.
     *
     * @param message String - message
     * @param e Throwable - exception to be logged
     * @param callsBack int
     */
    public void logSevere(String message, Throwable e, int callsBack);

    /**
     * Create log, the message for logging is generated using specified logProvider
     * only if log passed all filtration rules
     * @param level Level
     * @param logProvider LogProvider
     */
    public void log(Level level, LogProvider logProvider);

    /**
     * Create log, the message for logging is generated using specified logProvider
     * only if log passed all filtration rules
     * @param level Level
     * @param logProvider LogProvider
     * @param callsBack int
     */
    public void log(Level level, LogProvider logProvider, int callsBack);

    /**
     * Check if specified level is loggable in the current context
     *
     * @param level Level
     * @return boolean
     */
    public boolean isLoggable(Level level);

    /**
     * Check if specified level is loggable in the current context
     *
     * @param level Level
     * @param callsBack int
     * @return boolean
     */
    public boolean isLoggable(Level level, int callsBack);
}
