package aglobe.container.gui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.SwingUtilities;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;

import aglobe.container.transport.Address;

/**
 * Agent container tree model used for showing inner container
 * components.
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * 
 * @author David Sislak
 * @version $Revision: 1.17 $ $Date: 2010/08/04 11:48:05 $
 */
final class AgentContainerTreeModel implements TreeModel, ListListener {

	private String ROOT = "Root";
	
	/** List of the fixed children leaves of the root */
	// +1 for container address
	private final List<Object> ROOTCHILDREN = new ArrayList<Object>(ListType.values().length + 1);

	/** Listeners registered by GUI */
	private final List<TreeModelListener> listeners = new LinkedList<TreeModelListener>();

	/** Lists of all the components that might be displayed in the tree */
	private final Map<ListType, List<String>> realValues = new HashMap<ListType, List<String>>();

	/** Lists of the components that are actually displayed in the GUI */
	private final Map<ListType, List<String>> guiValues = new HashMap<ListType, List<String>>();

	/** Flags whether some list of realValues changed, set to true if so.
	 * Is used together with realValues and synchronized by locking the maps in realValues. */
	private final Map<ListType, Boolean> realValuesChanged = new HashMap<ListType, Boolean>();
	
	/** Regular expression pattern that affects what is displayed */
	private Pattern regexpPattern = null;
	
	/** False if the GUI is still not initialized and we cannot update it. After succesful
	 * initialization, this flag is set to true and updates will start.
	 */
	private volatile boolean guiInitialized = false;
	
	/** Notifies the model that GUI is fully initialized. Also immediately updates the tree. */
	void SetGuiInitialized() { this.guiInitialized = true; UpdateGUI(); }

	/**
	 * 
	 * @param owner
	 */
	AgentContainerTreeModel(AgentContainerGUI owner) {

		// initialize hash maps
		for (ListType l : ListType.values()) {
			realValues.put(l, new ArrayList<String>());
			guiValues.put(l, new ArrayList<String>());
			realValuesChanged.put(l, Boolean.valueOf(false));
		}
		
		// Root
		if (owner.owner.getContainerName() != null)
			ROOT = owner.owner.getContainerName();

		// Fixed children
		ROOTCHILDREN.add(Address.getLocalContainerAddress(owner.owner).toString());
		for (ListType l : ListType.values())
			ROOTCHILDREN.add(l);
		
		// Register listeners to the changes in agents, services libraries
		if (owner.owner.getAgentManager() != null)
			owner.owner.getAgentManager().addListListener(this);
		if (owner.owner.getServiceManager() != null)
			owner.owner.getServiceManager().addListListener(this);
		if (owner.owner.getLibraryManager() != null)
			owner.owner.getLibraryManager().addListListener(this);
	}

	@Override
	public Object getRoot() {
		return ROOT;
	}

	@Override
	public Object getChild(Object parent, int index) {
		
		if (parent == ROOT)
			return ROOTCHILDREN.get(index);
		
		// not parent, should be some fixed child from the hash maps
		List<String> list = guiValues.get(parent); // ClassCastException if wrong parent => OK
		assert (list != null); // we added all the possible values, should be there
		
		synchronized (list) {
			return list.get(index);
		}
	}

	@Override
	public int getChildCount(Object parent) {

		if (parent == ROOT)
			return ROOTCHILDREN.size();
		
		// fixed root children
		if (parent == ROOTCHILDREN.get(0)) // parent == first node with container address
			return 0;
		// some other fixed child?
		List<String> list = guiValues.get(parent); // ClassCastException if wrong parent => OK
		
		if (list == null) // not fixed child
			return 0;
		
		synchronized (list) {
			return list.size();
		}
	}

	@Override
	public boolean isLeaf(Object node) {

		// all nodes but the fixed are leaves
		if (node == ROOT)
			return false;
		for (ListType l : ListType.values())
			if (node == l)
				return false;
		
		return true;
	}

	/**
	 * This method is not implemented since changes to the Container contents
	 * are not made by the user, but come from inside of the Container. The
	 * method throws the <code>java.lang.UnsupportedOperationException</code>
	 * exception.
	 * 
	 * @param path
	 *            void
	 * @param newValue
	 *            void
	 */
	@Override
	public void valueForPathChanged(TreePath path, Object newValue) {
		throw new java.lang.UnsupportedOperationException(
				"Method ContainerTreeModel.valueForPathChanged should have never been called.");
	}

	@Override
	public int getIndexOfChild(Object parent, Object child) {
		
		if (parent == ROOT)
			return ROOTCHILDREN.indexOf(child);

		// not parent, should be some fixed child from the hash maps
		List<String> list = guiValues.get(parent); // ClassCastException if wrong parent => OK
		assert (list != null); // we added all the possible values, should be there
		
		synchronized (list) {
			return list.indexOf(child);
		}
	}

	@Override
	public void addTreeModelListener(TreeModelListener l) {
		synchronized (listeners) {
			if (!listeners.contains(l)) {
				listeners.add(l);
			}
		}
	}

	@Override
	public void removeTreeModelListener(TreeModelListener l) {
		synchronized (listeners) {
			listeners.remove(l);
		}
	}

	@Override
	public void ValueChanged(ListType where, Object what) {
		/**
		 * @todo Implement this aglobe.container.gui.ListListener method Use it
		 *       for refreshing currently displayed object.
		 */
	}

	@Override
	public void ListChanged(final ListType which, Set<String> values) {
		
		// not parent, should be some fixed child from the hash maps
		List<String> list = realValues.get(which);
		assert (list != null); // we added all the possible values, should be there
		
		synchronized (list) {
			list.clear();
			list.addAll(values);
			realValuesChanged.put(which, true);
		}
		
		// And update the GUI
		UpdateGUI();
	}
	
	private void UpdateGUI()
	{
		if (!guiInitialized)
			return;
		
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {

				ArrayList<ListType> whatListsChanged = new ArrayList<ListType>(ListType.values().length);

				// copy the real values to the structures used by GUI
				for (ListType l : ListType.values()) {
					List<String> realList = realValues.get(l);
					synchronized (realList) {
						if (realValuesChanged.get(l)) {
							realValuesChanged.put(l, false);
							whatListsChanged.add(l);
							
							// no need to synchronize guiList, it's accessed by this thread only
							List<String> guiList = guiValues.get(l);
							guiList.clear();
							
							if (regexpPattern == null) {
								guiList.addAll(realList);
							}
							else {
								for (String item : realList) {
									Matcher m = regexpPattern.matcher(item);
									if (m.find())
										guiList.add(item);
								}
							}
						}
					}
						
				}

				// inform of those lists that changed only
				for (ListType l : whatListsChanged) {
					final TreeModelEvent e = new TreeModelEvent(this, new Object[] {
							ROOT,  l});

					synchronized (listeners) {
						for (TreeModelListener listener : listeners) {
							listener.treeStructureChanged(e);
						}
					}
					
				}
			}
		});
	}
	
	/**
	 * 
	 * @param regexpPattern Might be null, in this case it matches all
	 */
	void ApplyFilter(Pattern regexpPattern) {
		this.regexpPattern = regexpPattern;

		// mark all lists as changed
		for (ListType l : ListType.values()) {
			List<String> realList = realValues.get(l);
			synchronized (realList) {
					realValuesChanged.put(l, true);
			}
		}
		
		UpdateGUI();
	}
	
	/**
	 * @return Returns counts of items in the lists. The result is a map indexed by ListType, it contains
	 * lists of two integers. First integer is a number of items (total), the second number is
	 * count of items displayed currently in the GUI. 
	 */
	Map<ListType, List<Integer> > GetCounts() {
	
		Map<ListType, List<Integer> > result =
			new HashMap<ListType, List<Integer>>(ListType.values().length);
		
		for (ListType l : ListType.values()) {
			ArrayList<Integer> item = new ArrayList<Integer>(2); 
			List<String> realList = realValues.get(l);
			item.add(realList.size());
			List<String> guiList = guiValues.get(l);
			item.add(guiList.size());
			result.put(l, item);
		}
		
		return result;
	}
}
