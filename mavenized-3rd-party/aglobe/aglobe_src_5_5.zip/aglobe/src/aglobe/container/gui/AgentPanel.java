package aglobe.container.gui;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;
import java.text.*;

import java.util.*;

import aglobe.ontology.*;

import java.awt.event.*;

/**
 * Agent details panel.
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.16 $ $Date: 2010/08/04 11:48:05 $
 */
class AgentPanel extends InfoPanel {
    private static final long serialVersionUID = -2013080984960043422L;

    private static final String[] HISTORYLABELS = new String[] { "Container", "Since", "Until" };

    private static final String[] PARAMLABELS = new String[] { "Name", "Value" };

    private final AgentContainerGUI owner;

    private DefaultTableModel historytm = new UneditableTableModel(HISTORYLABELS, 0);

    private DefaultTableModel paramtm = new UneditableTableModel(PARAMLABELS, 0);

    private DefaultListModel liblm = new DefaultListModel();

    private GridBagLayout gridBagLayout1 = new GridBagLayout();

    private JScrollPane contentScrollPane = new JScrollPane();

    private JPanel buttonPanel = new JPanel();

    private JPanel contentPanel = new JPanel();

    private GridBagLayout gridBagLayout2 = new GridBagLayout();

    private JButton killButton = new JButton();

    private JButton hideButton = new JButton();

    private JButton showButton = new JButton();

    private JButton refreshButton = new JButton();

    private GridBagLayout gridBagLayout3 = new GridBagLayout();

    private JLabel nameLabel = new JLabel();

    private JLabel mainclassLabel = new JLabel();

    private JTextField nameValue = new JTextField();

    private JTextField mainclassValue = new JTextField();

    private JLabel librariesLabel = new JLabel();

    private JLabel parametersLabel = new JLabel();

    private JLabel historyLabel = new JLabel();

    private JScrollPane libraryScrollPane = new JScrollPane();

    private JList libraryList = new JList(liblm);

    private JScrollPane parametersScrollPane = new JScrollPane();

    private JScrollPane historyScrollPane = new JScrollPane();

    private JTable parametersTable = new JTable(paramtm);

    private JTable historyTable = new JTable(historytm);

    private JLabel jLabel1 = new JLabel();

    AgentPanel(AgentContainerGUI owner) {
        this.owner = owner;
        try {
            jbInit();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Set values
     *
     * @param name
     *            String
     */
    @Override
    void setValues(String name) {
        AgentInfo ai = owner.owner.getAgentManager().getAgentInfo(name);

        historytm = new DefaultTableModel(HISTORYLABELS, 0);
        historyTable.setModel(historytm);
        paramtm = new DefaultTableModel(PARAMLABELS, 0);
        parametersTable.setModel(paramtm);
        liblm.clear();

        if (ai != null) {
            nameValue.setText(ai.getName());
            mainclassValue.setText(ai.getMainClass());

            int pos = 0;
            for (Iterator<String> i = ai.getLibraries().getLibrary().iterator(); i.hasNext();) {
                String l = i.next();
                liblm.add(pos++, l);
            }

            for (Iterator<AglobeParam> i = ai.getAglobeParam().iterator(); i.hasNext();) {
                AglobeParam p = i.next();
                paramtm.addRow(new Object[] { p.getName(), p.getValue() });
            }

            DateFormat df = DateFormat.getInstance();
            for (Iterator<AgentInfo.TravelHistory> i = ai.getTravelHistory().iterator(); i.hasNext();) {
                AgentInfo.TravelHistory he = i.next();

                // convert to String
                String start;
                String stop;
                if (he.getStart() != 0)
                    start = df.format(new Date(he.getStart()));
                else
                    start = "";

                if (he.getStop() != 0)
                    stop = df.format(new Date(he.getStop()));
                else
                    stop = "";

                historytm.addRow(new Object[] { he.getContainer(), start, stop });
            }
        } else {
            nameValue.setText("");
            mainclassValue.setText("");
        }
    }

    private void jbInit() throws Exception {
        this.setLayout(gridBagLayout1);
        buttonPanel.setLayout(gridBagLayout2);
        killButton.setText("Kill");
        killButton.addActionListener(new java.awt.event.ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                killButton_actionPerformed(e);
            }
        });
        hideButton.setText("Hide");
        hideButton.addActionListener(new java.awt.event.ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                hideButton_actionPerformed(e);
            }
        });
        showButton.setText("Show");
        showButton.addActionListener(new java.awt.event.ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                showButton_actionPerformed(e);
            }
        });
        refreshButton.setText("Refresh");
        refreshButton.addActionListener(new java.awt.event.ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                refreshButton_actionPerformed(e);
            }
        });
        contentPanel.setLayout(gridBagLayout3);
        nameLabel.setText("Name:");
        mainclassLabel.setText("Main class:");
        nameValue.setEditable(false);
        nameValue.setColumns(30);
        mainclassValue.setEditable(false);
        mainclassValue.setColumns(30);
        librariesLabel.setText("Libraries:");
        parametersLabel.setText("Parameters:");
        historyLabel.setText("Travel history:");
        libraryList.setVisibleRowCount(4);
        historyScrollPane.getViewport().add(historyTable, null);
        parametersScrollPane.getViewport().add(parametersTable, null);
        libraryScrollPane.getViewport().add(libraryList, null);
        contentScrollPane.getViewport().add(contentPanel, null);
        this.add(contentScrollPane, new GridBagConstraints(0, 0, 1, 1, 0.5, 0.5, GridBagConstraints.NORTH, GridBagConstraints.BOTH, new Insets(5, 5, 0, 5), 0,
                0));
        this.add(buttonPanel, new GridBagConstraints(0, 1, 1, 1, 0.5, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 5), 0,
                0));
        buttonPanel.add(killButton, new GridBagConstraints(3, 0, 1, 1, 0.1, 0.0, GridBagConstraints.SOUTHEAST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0),
                0, 0));
        buttonPanel.add(hideButton, new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0, GridBagConstraints.SOUTHWEST, GridBagConstraints.NONE, new Insets(0, 2, 0, 0),
                0, 0));
        buttonPanel.add(showButton, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0, GridBagConstraints.SOUTHEAST, GridBagConstraints.NONE, new Insets(0, 0, 0, 2),
                0, 0));
        buttonPanel.add(refreshButton, new GridBagConstraints(0, 0, 1, 1, 0.1, 0.0, GridBagConstraints.SOUTHWEST, GridBagConstraints.NONE, new Insets(0, 0, 0,
                0), 0, 0));
        contentPanel.add(nameLabel,
                new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 5, 2, 4), 0, 0));
        contentPanel.add(mainclassLabel, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(2, 5, 2, 4),
                0, 0));
        contentPanel.add(nameValue,
                new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 2, 2, 5), 0, 0));
        contentPanel.add(mainclassValue, new GridBagConstraints(1, 2, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(2, 2, 2, 5),
                0, 0));
        contentPanel.add(librariesLabel, new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(2, 5, 2, 4),
                0, 0));
        contentPanel.add(parametersLabel, new GridBagConstraints(0, 4, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE,
                new Insets(2, 5, 2, 4), 0, 0));
        contentPanel.add(historyLabel, new GridBagConstraints(0, 5, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(2, 5, 2, 4),
                0, 0));
        contentPanel.add(libraryScrollPane, new GridBagConstraints(1, 3, 1, 1, 0.1, 0.0, GridBagConstraints.NORTHWEST, GridBagConstraints.HORIZONTAL,
                new Insets(2, 2, 2, 5), 0, 0));
        contentPanel.add(parametersScrollPane, new GridBagConstraints(1, 4, 1, 1, 0.1, 0.0, GridBagConstraints.NORTHWEST, GridBagConstraints.HORIZONTAL,
                new Insets(2, 2, 2, 5), 0, 0));
        contentPanel.add(historyScrollPane, new GridBagConstraints(1, 5, 1, 1, 0.1, 0.0, GridBagConstraints.NORTHWEST, GridBagConstraints.HORIZONTAL,
                new Insets(2, 2, 2, 5), 0, 0));
        contentPanel.add(jLabel1,
                new GridBagConstraints(0, 6, 2, 1, 0.0, 0.1, GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));

        Dimension d = nameValue.getPreferredSize();
        d.height = parametersTable.getRowHeight() * 3;
        parametersTable.setPreferredScrollableViewportSize(d);
        d.height = historyTable.getRowHeight() * 4;
        historyTable.setPreferredScrollableViewportSize(d);
    }

    /**
     * @param e
     */
    void refreshButton_actionPerformed(ActionEvent e) {
        setValues(nameValue.getText());
    }

    /**
     * @param e
     */
    void showButton_actionPerformed(ActionEvent e) {
        owner.owner.getAgentManager().showAgent(nameValue.getText());
    }

    /**
     * @param e
     */
    void hideButton_actionPerformed(ActionEvent e) {
        owner.owner.getAgentManager().hideAgent(nameValue.getText());
    }

    /**
     * @param e
     */
    void killButton_actionPerformed(ActionEvent e) {
        String an = nameValue.getText();
        int res = JOptionPane.showConfirmDialog(this, "Really kill the agent " + an, "Kill Agent", JOptionPane.YES_NO_OPTION);
        if (res != JOptionPane.YES_OPTION)
            return;
        owner.owner.getAgentManager().killAgent(an);
    }
}
