package aglobe.container.gui;

import java.awt.*;
import javax.swing.*;
import java.util.*;

import aglobe.ontology.*;
import aglobe.container.library.*;
import java.awt.event.*;

/**
 * Library panel of agent container GUI.
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.19 $ $Date: 2010/08/04 11:48:05 $
 */
class LibraryPanel extends InfoPanel {
    private static final long serialVersionUID = 4728318528674243336L;

    private final AgentContainerGUI owner;

    private DefaultListModel lm = new DefaultListModel();

    private GridBagLayout gridBagLayout1 = new GridBagLayout();

    private JScrollPane contentScrollPane = new JScrollPane();

    private JPanel contentPanel = new JPanel();

    private GridBagLayout contentgridBagLayout = new GridBagLayout();

    private JLabel nameLabel = new JLabel();

    private JLabel versionLabel = new JLabel();

    private JLabel commentLabel = new JLabel();

    private JTextField nameValue = new JTextField();

    private JTextField versionValue = new JTextField();

    private JTextField commentValue = new JTextField();

    private JLabel usersLabel = new JLabel();

    private JScrollPane usersScrollPane = new JScrollPane();

    private JList usersList = new JList(lm);

    private JPanel buttonPanel = new JPanel();

    private JButton deleteButton = new JButton();

    private GridBagLayout gridBagLayout2 = new GridBagLayout();

    private JButton refreshButton = new JButton();

    private JLabel emptyLabel = new JLabel();

    LibraryPanel(AgentContainerGUI owner) {
        this.owner = owner;
        try {
            jbInit();
            // usersList.getP
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    void setValues(String libname) {
        LibraryManager libMan = owner.owner.getLibraryManager();
        if (libname != null && libMan.exists(libname)) {
            LibInfo li = libMan.getLibInfo(libname);
            nameValue.setText(li.getName());
            versionValue.setText(li.getVersion());
            commentValue.setText(li.getComment());

            lm.clear();
            int pos = 0;
            for (Iterator<LibInfo.LibUser> i = li.getLibUser().iterator(); i.hasNext();) {
                LibInfo.LibUser usr = i.next();
                lm.add(pos++, new User(usr.getType(), usr.getName()));
            }
        } else {
            nameValue.setText("");
            versionValue.setText("");
            commentValue.setText("");
            lm.clear();
        }
    }

    private void jbInit() throws Exception {
        nameLabel.setText("Name: ");
        this.setLayout(gridBagLayout1);
        versionLabel.setText("Version:");
        commentLabel.setText("Comment:");
        nameValue.setEditable(false);
        nameValue.setColumns(30);
        versionValue.setEditable(false);
        versionValue.setColumns(30);
        commentValue.setEditable(false);
        commentValue.setColumns(30);
        usersLabel.setText("Users:");
        usersList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        usersList.setVisibleRowCount(5);
        deleteButton.setText("Delete");
        deleteButton.addActionListener(new java.awt.event.ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                deleteButton_actionPerformed(e);
            }
        });
        buttonPanel.setLayout(gridBagLayout2);
        refreshButton.setText("Refresh");
        refreshButton.addActionListener(new java.awt.event.ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                refreshButton_actionPerformed(e);
            }
        });
        contentPanel.setLayout(contentgridBagLayout);
        contentPanel.add(nameLabel,
                new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 4, 2, 4), 0, 0));
        contentPanel.add(versionLabel, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(2, 4, 2, 4),
                0, 0));
        contentPanel.add(commentLabel, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(2, 4, 2, 4),
                0, 0));
        contentPanel.add(nameValue, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 2, 2,
                5), 0, 0));
        contentPanel.add(versionValue, new GridBagConstraints(1, 1, 1, 1, 0.1, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(2, 2,
                2, 5), 0, 0));
        contentPanel.add(commentValue, new GridBagConstraints(1, 2, 1, 1, 0.1, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(2, 2,
                2, 5), 0, 0));
        contentPanel.add(usersLabel, new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(2, 4, 2, 4), 0,
                0));
        contentPanel.add(usersScrollPane, new GridBagConstraints(1, 3, 1, 1, 0.1, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(2, 2, 2,
                5), 0, 0));
        contentPanel.add(emptyLabel, new GridBagConstraints(0, 4, 2, 1, 0.0, 0.5, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0),
                0, 0));
        this.add(contentScrollPane, new GridBagConstraints(0, 0, 1, 1, 0.1, 0.5, GridBagConstraints.NORTH, GridBagConstraints.BOTH, new Insets(5, 5, 5, 5), 0,
                0));
        this.add(buttonPanel, new GridBagConstraints(0, 1, 1, 1, 0.1, 0.0, GridBagConstraints.SOUTH, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 5), 0,
                0));
        buttonPanel.add(deleteButton, new GridBagConstraints(1, 0, 1, 1, 0.1, 0.0, GridBagConstraints.SOUTHEAST, GridBagConstraints.NONE,
                new Insets(0, 0, 0, 0), 0, 0));
        buttonPanel.add(refreshButton, new GridBagConstraints(0, 0, 1, 1, 0.1, 0.0, GridBagConstraints.SOUTHWEST, GridBagConstraints.NONE, new Insets(0, 0, 0,
                0), 0, 0));
        usersScrollPane.getViewport().add(usersList, null);
        contentScrollPane.getViewport().add(contentPanel, null);
    }

    /**
     * @param e
     */
    void deleteButton_actionPerformed(ActionEvent e) {
        if (lm.size() != 0) {
            JOptionPane.showMessageDialog(this, "The library is in use. Cannot be removed.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            owner.owner.getLibraryManager().deleteLibrary(nameValue.getText());
        } catch (LibraryException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            // do nothing
        }
    }

    /**
     * @param e
     */
    void refreshButton_actionPerformed(ActionEvent e) {
        setValues(nameValue.getText());
    }

    private static class User {
        final String type;

        final String name;

        private User(String type, String name) {
            this.type = type;
            this.name = name;
        }

        @Override
        public String toString() {
            if (type.equals("agent"))
                return "A " + name;
            else
                return "S " + name;
        }
    }
}
