package aglobe.container.gui;


/**
 * List source interface of agent container GUI.
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.8 $ $Date: 2009/05/15 08:46:58 $
 */
public interface ListSource
{
    /**
     * Add list listener
     * @param ll ListListener
     */
    public void addListListener(ListListener ll);
}
