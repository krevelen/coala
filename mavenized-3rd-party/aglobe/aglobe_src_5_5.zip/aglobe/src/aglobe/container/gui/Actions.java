package aglobe.container.gui;

import javax.swing.*;
import java.awt.event.*;

/**
 * Agent container GUI actions.
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.15 $ $Date: 2010/08/04 11:48:05 $
 */
public class Actions {
    private static final Icon ExitICON = null;

    private static final Icon LoadLibraryICON = new ImageIcon(Actions.class.getResource("newLibrary.gif"));

    private static final Icon LoadServiceICON = new ImageIcon(Actions.class.getResource("newService.gif"));

    private static final Icon LoadAgentICON = new ImageIcon(Actions.class.getResource("newAgent.gif"));

    /**
     * Class cannot be created
     */
    private Actions() {
    }

    /**
     *
     * <p>
     * Title: Aglobe
     * </p>
     *
     * <p>
     * Description: Exit action of agent container GUI
     * </p>
     *
     * <p>
     * Copyright: Copyright (c) 2006
     * </p>
     *
     * <p>
     * Company: Agent Technology Center, Gerstner Laboratory
     * </p>
     *
     * @author David Sislak
     * @version $Revision: 1.15 $ $Date: 2010/08/04 11:48:05 $
     */
    static class ExitAction extends AbstractAction {
        private static final long serialVersionUID = -192868569621286366L;

        AgentContainerGUI parent;

        ExitAction() {
            this(null);
        }

        ExitAction(AgentContainerGUI parent) {
            this.parent = parent;
            this.setEnabled(true);
            this.putValue(Action.SMALL_ICON, ExitICON);
            this.putValue(Action.NAME, "Shutdown");
            this.putValue(Action.SHORT_DESCRIPTION, "Shutdown the agent container");
            this.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_X, KeyEvent.ALT_MASK));
        }

        @Override
        public void actionPerformed(ActionEvent a) {
            if (parent != null)
                parent.Quit();
        }
    }

    /**
     *
     * <p>
     * Title: Aglobe
     * </p>
     *
     * <p>
     * Description: Load service action of agent container GUI
     * </p>
     *
     * <p>
     * Copyright: Copyright (c) 2006
     * </p>
     *
     * <p>
     * Company: Agent Technology Center, Gerstner Laboratory
     * </p>
     *
     * @author David Sislak
     * @version $Revision: 1.15 $ $Date: 2010/08/04 11:48:05 $
     */
    static class LoadServiceAction extends AbstractAction {
        private static final long serialVersionUID = -4312462889941389784L;

        AgentContainerGUI parent;

        LoadServiceAction() {
            this(null);
        }

        LoadServiceAction(AgentContainerGUI parent) {
            this.parent = parent;
            this.setEnabled(true);
            this.putValue(Action.SMALL_ICON, LoadServiceICON);
            this.putValue(Action.NAME, "Load Service");
            this.putValue(Action.SHORT_DESCRIPTION, "Start a new service");
            this.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_S, KeyEvent.ALT_MASK));
        }

        @Override
		public void actionPerformed(ActionEvent a) {
            if (parent != null)
                parent.LoadService();
        }
    }

    /**
     *
     * <p>
     * Title: Aglobe
     * </p>
     *
     * <p>
     * Description: Load agent action of agent container GUI
     * </p>
     *
     * <p>
     * Copyright: Copyright (c) 2006
     * </p>
     *
     * <p>
     * Company: Agent Technology Center, Gerstner Laboratory
     * </p>
     *
     * @author David Sislak
     * @version $Revision: 1.15 $ $Date: 2010/08/04 11:48:05 $
     */
    static class LoadAgentAction extends AbstractAction {
        private static final long serialVersionUID = 347333626440518338L;

        AgentContainerGUI parent;

        LoadAgentAction() {
            this(null);
        }

        LoadAgentAction(AgentContainerGUI parent) {
            this.parent = parent;
            this.setEnabled(true);
            this.putValue(Action.SMALL_ICON, LoadAgentICON);
            this.putValue(Action.NAME, "Load Agent");
            this.putValue(Action.SHORT_DESCRIPTION, "Start a new agent");
            this.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_A, KeyEvent.ALT_MASK));
        }

        @Override
		public void actionPerformed(ActionEvent a) {
            if (parent != null)
                parent.LoadAgent();
        }
    }

    /**
     *
     * <p>
     * Title: Aglobe
     * </p>
     *
     * <p>
     * Description: Load library action of agent container GUI
     * </p>
     *
     * <p>
     * Copyright: Copyright (c) 2006
     * </p>
     *
     * <p>
     * Company: Agent Technology Center, Gerstner Laboratory
     * </p>
     *
     * @author David Sislak
     * @version $Revision: 1.15 $ $Date: 2010/08/04 11:48:05 $
     */
    static class LoadLibraryAction extends AbstractAction {
        private static final long serialVersionUID = 217020938378393690L;

        AgentContainerGUI parent;

        LoadLibraryAction() {
            this(null);
        }

        LoadLibraryAction(AgentContainerGUI parent) {
            this.parent = parent;
            this.setEnabled(true);
            this.putValue(Action.SMALL_ICON, LoadLibraryICON);
            this.putValue(Action.NAME, "Load Library");
            this.putValue(Action.SHORT_DESCRIPTION, "Start a new service");
            this.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_L, KeyEvent.ALT_MASK));
        }

        @Override
		public void actionPerformed(ActionEvent a) {
            if (parent != null)
                parent.LoadLibrary();
        }
    }

    /**
     *
     * <p>
     * Title: Aglobe
     * </p>
     *
     * <p>
     * Description: Start ES matrix server action of agent container GUI
     * </p>
     *
     * <p>
     * Copyright: Copyright (c) 2006
     * </p>
     *
     * <p>
     * Company: Agent Technology Center, Gerstner Laboratory
     * </p>
     *
     * @author David Sislak
     * @version $Revision: 1.15 $ $Date: 2010/08/04 11:48:05 $
     */
    static class StartESMatrixServerAction extends AbstractAction {
        private static final long serialVersionUID = -627240463828588660L;

        AgentContainerGUI parent;

        StartESMatrixServerAction() {
            this(null);
        }

        StartESMatrixServerAction(AgentContainerGUI parent) {
            this.parent = parent;
            this.setEnabled(true);
            this.putValue(Action.NAME, "Start ES Matrix Agent");
            this.putValue(Action.SHORT_DESCRIPTION, "Start ES Matrix Agent");
        }

        @Override
		public void actionPerformed(ActionEvent a) {
            if (parent != null)
                parent.startESMatrixServer();
        }
    }

    /**
     *
     * <p>
     * Title: Aglobe
     * </p>
     *
     * <p>
     * Description: Start sniffer action of agent container GUI
     * </p>
     *
     * <p>
     * Copyright: Copyright (c) 2006
     * </p>
     *
     * <p>
     * Company: Agent Technology Center, Gerstner Laboratory
     * </p>
     *
     * @author David Sislak
     * @version $Revision: 1.15 $ $Date: 2010/08/04 11:48:05 $
     */
    static class StartSnifferAction extends AbstractAction {
        private static final long serialVersionUID = -8279887154887945281L;

        AgentContainerGUI parent;

        StartSnifferAction() {
            this(null);
        }

        StartSnifferAction(AgentContainerGUI parent) {
            this.parent = parent;
            this.setEnabled(true);
            this.putValue(Action.NAME, "Start Sniffer");
            this.putValue(Action.SHORT_DESCRIPTION, "Start Sniffer");
        }

        @Override
		public void actionPerformed(ActionEvent a) {
            if (parent != null)
                parent.startSniffer();
        }
    }

    /**
     *
     * <p>
     * Title: Aglobe
     * </p>
     *
     * <p>
     * Description: Start com analyzer action of agent container GUI
     * </p>
     *
     * <p>
     * Copyright: Copyright (c) 2006
     * </p>
     *
     * <p>
     * Company: Agent Technology Center, Gerstner Laboratory
     * </p>
     *
     * @author David Sislak
     * @version $Revision: 1.15 $ $Date: 2010/08/04 11:48:05 $
     */
    static class StartComAnalyzerAction extends AbstractAction {
        private static final long serialVersionUID = -5612684070116723170L;

        AgentContainerGUI parent;

        StartComAnalyzerAction() {
            this(null);
        }

        StartComAnalyzerAction(AgentContainerGUI parent) {
            this.parent = parent;
            this.setEnabled(true);
            this.putValue(Action.NAME, "Start ComAnalyzer");
            this.putValue(Action.SHORT_DESCRIPTION, "Start ComAnalyzer");
        }

        @Override
		public void actionPerformed(ActionEvent a) {
            if (parent != null)
                parent.startComAnalyzer();
        }
    }

    /**
     *
     * <p>
     * Title: Aglobe
     * </p>
     *
     * <p>
     * Description: Start logger action of agent container GUI
     * </p>
     *
     * <p>
     * Copyright: Copyright (c) 2006
     * </p>
     *
     * <p>
     * Company: Agent Technology Center, Gerstner Laboratory
     * </p>
     *
     * @author David Sislak
     * @version $Revision: 1.15 $ $Date: 2010/08/04 11:48:05 $
     */
    static class StartLoggerAction extends AbstractAction {
        private static final long serialVersionUID = 8970196813058655987L;
        AgentContainerGUI parent;

        StartLoggerAction() {
            this(null);
        }

        StartLoggerAction(AgentContainerGUI parent) {
            this.parent = parent;
            this.setEnabled(true);
            this.putValue(Action.NAME, "Start Logger");
            this.putValue(Action.SHORT_DESCRIPTION, "Start Logger");
        }

        @Override
		public void actionPerformed(ActionEvent a) {
            if (parent != null)
                parent.startLogger();
        }
    }

}
