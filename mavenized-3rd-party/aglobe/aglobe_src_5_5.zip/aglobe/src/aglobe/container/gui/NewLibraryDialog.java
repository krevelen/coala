package aglobe.container.gui;

import java.io.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

import aglobe.container.*;
import aglobe.container.library.*;

import aglobe.util.fileinputtextfield.*;

/**
 * New library dialog of agent container GUI.
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.15 $ $Date: 2010/08/04 11:48:05 $
 */
class NewLibraryDialog extends JDialog {
    private static final long serialVersionUID = 5127517836821847533L;

    private static final String LIB_DIRECTORY = "gui/lib_directory";

    private AgentContainerGUI owner;

    private JPanel panel1 = new JPanel();

    private BorderLayout borderLayout1 = new BorderLayout();

    private JPanel fieldPanel = new JPanel();

    private JPanel buttonPanel = new JPanel();

    private GridBagLayout gridBagLayout1 = new GridBagLayout();

    private GridBagLayout gridBagLayout2 = new GridBagLayout();

    private JButton cancelButton = new JButton();

    private JButton okButton = new JButton();

    private TitledBorder titledBorder1;

    private JLabel fileLabel = new JLabel();

    private JLabel commentLabel = new JLabel();

    private FileInputTextField fileTextField = new FileInputTextField();

    private JTextField commentTextField = new JTextField();

    NewLibraryDialog(Frame frame, String title, boolean modal, AgentContainerGUI owner) {
        super(frame, title, modal);
        this.owner = owner;
        try {
            jbInit();
            pack();
            Store s = owner.owner.getGlobalStore();
            if (s.exist(LIB_DIRECTORY))
                fileTextField.setCurrentDirectory(s.getString(LIB_DIRECTORY, "ERROR"));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    NewLibraryDialog(Frame frame) {
        this(frame, "Register Library", true, (AgentContainerGUI) frame);
    }

    NewLibraryDialog(AgentContainerGUI owner) {
        this(null, "Register Library", true, owner);
    }

    private void jbInit() throws Exception {
        titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white, new Color(165, 163, 151)), "Library properties");
        panel1.setLayout(borderLayout1);
        fieldPanel.setLayout(gridBagLayout1);
        buttonPanel.setLayout(gridBagLayout2);
        cancelButton.setText("Cancel");
        cancelButton.addActionListener(new java.awt.event.ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                cancelButton_actionPerformed(e);
            }
        });
        okButton.setText("OK");
        okButton.addActionListener(new java.awt.event.ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                okButton_actionPerformed(e);
            }
        });
        okButton.setPreferredSize(cancelButton.getPreferredSize());
        fieldPanel.setBorder(titledBorder1);
        fileLabel.setText("File:");
        commentLabel.setText("Comment:");
        commentTextField.setColumns(20);
        getContentPane().add(panel1);
        panel1.add(fieldPanel, BorderLayout.CENTER);
        fieldPanel.add(fileLabel, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(2, 3, 2, 3),
                0, 0));
        fieldPanel.add(commentLabel, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL,
                new Insets(2, 3, 2, 3), 0, 0));
        panel1.add(buttonPanel, BorderLayout.SOUTH);
        buttonPanel.add(cancelButton, new GridBagConstraints(1, 0, 1, 1, 0.5, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(4, 4, 4, 4), 0,
                0));
        buttonPanel.add(okButton, new GridBagConstraints(0, 0, 1, 1, 0.5, 0.0, GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(4, 4, 4, 4), 0, 0));
        fieldPanel.add(fileTextField, new GridBagConstraints(1, 0, 1, 1, 0.5, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(2, 2,
                2, 3), 0, 0));
        fieldPanel.add(commentTextField, new GridBagConstraints(1, 2, 1, 1, 0.5, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(2,
                2, 2, 3), 0, 0));
    }

    /**
     * @param e
     */
    void cancelButton_actionPerformed(ActionEvent e) {
        this.dispose();
    }

    /**
     * @param e
     */
    void okButton_actionPerformed(ActionEvent e) {
        LibraryManager lm = owner.owner.getLibraryManager();

        File f = new File(fileTextField.getText());

        // Save settings
        owner.owner.getGlobalStore().putString(LIB_DIRECTORY, f.getParentFile().getAbsolutePath());

        if (lm.storeLibrary(f, commentTextField.getText()) == null) {
            JOptionPane.showMessageDialog(this, "An error occured while loading the library!", "Error", JOptionPane.ERROR_MESSAGE);
        } else
            this.dispose();
    }
}
