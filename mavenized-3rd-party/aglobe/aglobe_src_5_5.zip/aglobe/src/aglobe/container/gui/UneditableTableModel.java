package aglobe.container.gui;

import javax.swing.table.*;
import java.util.Vector;

/**
 * Uneditable table model.
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.9 $ $Date: 2009/05/15 08:46:58 $
 */
class UneditableTableModel extends DefaultTableModel {

    private static final long serialVersionUID = -6978325377264026618L;

    UneditableTableModel() {
        super();
    }

    UneditableTableModel(int rowCount, int columnCount) {
        super(rowCount, columnCount);
    }

    UneditableTableModel(Object[][] data, Object[] columnNames) {
        super(data, columnNames);
    }

    UneditableTableModel(Object[] columnNames, int rowCount) {
        super(columnNames, rowCount);
    }

    UneditableTableModel(Vector<?> columnNames, int rowCount) {
        super(columnNames, rowCount);
    }

    UneditableTableModel(Vector<?> data, Vector<?> columnNames) {
        super(data, columnNames);
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return false;
    }
}
