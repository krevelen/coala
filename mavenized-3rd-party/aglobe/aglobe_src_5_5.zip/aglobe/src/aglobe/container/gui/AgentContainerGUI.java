package aglobe.container.gui;

import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.event.*;

import aglobe.util.*;
import aglobe.container.*;
import aglobe.ontology.Command;
import aglobe.ontology.AgentInfo;
import aglobe.ontology.Libraries;
import aglobe.util.gui.RememberPositionJFrame;

/**
 * Agent container GUI.
 * <p>
 * Copyright: Copyright (c) 2003
 * </p>
 * <p>
 * Company: Gerstner Laboratory
 * </p>
 * 
 * @author David Sislak
 * @version $Revision: 1.40 $ $Date: 2010/08/04 11:48:05 $
 */
public class AgentContainerGUI extends RememberPositionJFrame {

	private static final long serialVersionUID = 6406912721207481723L;

	private static final int minimumInfoPanelWidthOnShow = 200;

	private static final String STORE_KEY_FILTER = "gui/AgentContFilter";
	private static final String STORE_KEY_INFO_WIDTH = "gui/AgentContInfoPanelWidth";
	private static final String STORE_KEY_INFO_HIDDEN = "gui/AgentContInfoPanelHidden";

	/** The container which items we are displaying in this GUI */
	transient final AgentContainer owner;

	/** The data that should be displayed in the tree on the left */
	transient private AgentContainerTreeModel containerTreeModel1;

	/** A movable divider between tree and info on the right side */
	private JSplitPane jSplitPane1 = new JSplitPane();

	/** Field for writing filter regular expressions */
	private JTextField filterText = new JTextField();

	/** Temporary field for some status information - debug purposes */
	private StatusBar statusBar = new StatusBar();

	private JPanel infoPanel = new JPanel();
	private JTree jTree1 = new AgentContainerTree();

	/** The panels for information about agents, services and libraries */
	private Map<ListListener.ListType, InfoPanel> panels = new HashMap<ListListener.ListType, InfoPanel>();

	// Services which presence/absence affects the GUI behavior.
	private final boolean hasTopics;
	private final boolean hasLink;

	/**
	 * The width of the info panel (right part of the window) - necessary to
	 * keep the same size while the user is hiding/showing it. Local copy of the
	 * STORE_KEY_INFO_WIDTH store variable.
	 */
	private int infoPanelWidth;

	/**
	 * True iff the right part (information window) is hidden. Local copy of the
	 * STORE_KEY_INFO_HIDDEN store variable.
	 */
	private boolean infoPanelHidden;

	/**
	 * Constructor
	 * 
	 * @param owner
	 *            AgentContainer
	 */
	public AgentContainerGUI(final AgentContainer owner) {

		super(new StoreOwner() {
			@Override
			public Store getStore() {
				return owner.getGlobalStore();
			}
		});
		this.owner = owner;
		containerTreeModel1 = new AgentContainerTreeModel(this);

		// Try to get the services, their presence/absence affect the GUI
		// behavior
		hasTopics = owner.hasTopics();
		hasLink = owner.hasLink();

		try {
			jbInit(); // init all the components

			// local cache of store variables
			infoPanelWidth = store.getInt(STORE_KEY_INFO_WIDTH, infoPanel
					.getPreferredSize().width);
			infoPanelHidden = store.getBoolean(STORE_KEY_INFO_HIDDEN, false);

			containerTreeModel1.addTreeModelListener(statusBar);

			// hide right part
			hideInfo(true);

			// do it as the user wrote the filter string right now
			String filter = store.getString(STORE_KEY_FILTER, "");
			filterText.setText(filter);
			filterTextFocusGained();
			filterTextFocusLost();
			applyFilter(filter);

			// and finally notify the model that it can send updates..
			containerTreeModel1.SetGuiInitialized();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Save other window settings
	 */
	@Override
	protected void saveWindowSettings() {
		store.putInt(GUI_DIVIDER, jSplitPane1.getDividerLocation());
	}

	/**
	 * Load other window settings
	 */
	@Override
	protected void loadWindowSettings() {
		int divPos = store.getInt(GUI_DIVIDER, Integer.MIN_VALUE);
		if (divPos != Integer.MIN_VALUE) {
			jSplitPane1.setDividerLocation(divPos);			
		}
	}

	private void jbInit() throws Exception {

		// create panels
		for (ListListener.ListType l : ListListener.ListType.values()) {
			if (l == ListListener.ListType.AGENTS)
				panels.put(l, new AgentPanel(this));
			else if (l == ListListener.ListType.SERVICES)
				panels.put(l, new ServicePanel(this));
			else if (l == ListListener.ListType.LIBRARIES)
				panels.put(l, new LibraryPanel(this));
		}

		this.getContentPane().setLayout(new BorderLayout());
		infoPanel.setMinimumSize(new Dimension(0, 0));
		infoPanel.setPreferredSize(new Dimension(600, 400));

		//
		// create menu
		//
		JMenuBar jMenuBar1 = new JMenuBar();
		this.setJMenuBar(jMenuBar1);

		// File menu
		JMenu fileMenu = new JMenu();
		fileMenu.setMnemonic('F');
		fileMenu.setText("File");
		// Load Agent
		JMenuItem loadAgentMenuItem = new JMenuItem();
		loadAgentMenuItem.setAction(new Actions.LoadAgentAction(this));
		fileMenu.add(loadAgentMenuItem);
		// Load Service
		JMenuItem loadServiceMenuItem = new JMenuItem();
		loadServiceMenuItem.setAction(new Actions.LoadServiceAction(this));
		fileMenu.add(loadServiceMenuItem);
		// Load Library
		JMenuItem loadLibraryMenuItem = new JMenuItem();
		loadLibraryMenuItem.setAction(new Actions.LoadLibraryAction(this));
		fileMenu.add(loadLibraryMenuItem);

		fileMenu.addSeparator();
		// Exit
		JMenuItem exitMenuItem = new JMenuItem();
		exitMenuItem.setAction(new Actions.ExitAction(this));
		fileMenu.add(exitMenuItem);

		// Environment Simulator menu
		JMenu esMenu = new JMenu();
		esMenu.setText("Environment Simulator");
		esMenu.setMnemonic('E');
		JMenuItem startESMatrixServerMenuItem = new JMenuItem();
		startESMatrixServerMenuItem
				.setAction(new Actions.StartESMatrixServerAction(this));
		esMenu.add(startESMatrixServerMenuItem);

		// Tools Menu
		JMenu tools = new JMenu();
		tools.setText("Tools");
		tools.setMnemonic('T');

		JMenuItem startSnifferMenuItem = new JMenuItem();
		startSnifferMenuItem.setAction(new Actions.StartSnifferAction(this));
		tools.add(startSnifferMenuItem);

		JMenuItem startComAnalyzerMenuItem = new JMenuItem();
		startComAnalyzerMenuItem.setAction(new Actions.StartComAnalyzerAction(
				this));
		tools.add(startComAnalyzerMenuItem);

		JMenuItem startLoggerMenuItem = new JMenuItem();
		startLoggerMenuItem.setAction(new Actions.StartLoggerAction(this));
		if (!hasLink) {
			tools.add(startLoggerMenuItem);
		}

		// Complete the menu items
		jMenuBar1.add(fileMenu);
		if (hasTopics) {
			jMenuBar1.add(esMenu);
			jMenuBar1.add(tools);
		}
		if (hasLink) {
			jMenuBar1.add(tools);
		}

		//
		// Tree view on the left
		//

		jTree1.setModel(containerTreeModel1);
		jTree1.getSelectionModel().setSelectionMode(
				TreeSelectionModel.SINGLE_TREE_SELECTION);
		jTree1.addTreeSelectionListener(new TreeSelectionListener() {
			@Override
			public void valueChanged(TreeSelectionEvent e) {
				treeSelectionChanged(e);
			}
		});

		//
		// Information labels
		//
		// JLabel emptyLabel = new JLabel();
		// emptyLabel.setHorizontalAlignment(SwingConstants.CENTER);
		// emptyLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		// emptyLabel.setText("No object selected");
		// emptyPanel.setLayout(new GridBagLayout());
		//
		// JLabel aglobeLabel = new JLabel();
		// aglobeLabel.setFont(new java.awt.Font("SansSerif", Font.BOLD, 20));
		// aglobeLabel.setHorizontalAlignment(SwingConstants.CENTER);
		// aglobeLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		// aglobeLabel.setText("A-globe");
		//
		// JLabel aglobeVer = new JLabel();
		// aglobeVer.setFont(new java.awt.Font("Tahoma", Font.BOLD, 11));
		// aglobeVer.setHorizontalAlignment(SwingConstants.CENTER);
		// aglobeVer.setHorizontalTextPosition(SwingConstants.CENTER);
		// aglobeVer.setText("ver. " + Platform.MAJOR_VERSION + "." +
		// Platform.MINOR_VERSION);

		infoPanel.setLayout(new CardLayout());
		for (ListListener.ListType l : ListListener.ListType.values()) {
			infoPanel.add(panels.get(l), l.toString());
		}

		// ToolBar and StatusBar
		this.getContentPane().add(new JToolBar(), BorderLayout.NORTH);
		this.getContentPane().add(statusBar, BorderLayout.SOUTH);

		JPanel mainPanel = new JPanel(new BorderLayout());
		this.getContentPane().add(mainPanel, BorderLayout.CENTER);
		mainPanel.add(jSplitPane1, BorderLayout.CENTER);
		jSplitPane1.setDividerSize(3);
		jSplitPane1.setResizeWeight(0); // resize only right part while resizing
		// the window
		jSplitPane1.setDividerLocation(150); // default value, the actual is
		// loaded from the store

		// left part of the window
		JPanel leftContent = new JPanel(new BorderLayout());
		leftContent.add(filterText, BorderLayout.NORTH);
		JScrollPane jScrollPane1 = new JScrollPane();
		jScrollPane1.getViewport().setScrollMode(JViewport.SIMPLE_SCROLL_MODE);
		jScrollPane1.getViewport().add(jTree1, BorderLayout.CENTER);
		leftContent.add(jScrollPane1, BorderLayout.CENTER);
		jSplitPane1.add(leftContent, JSplitPane.LEFT);
		// right part of the window
		jSplitPane1.add(infoPanel, JSplitPane.RIGHT);

		// Logos
		// JLabel logoLabel = new JLabel();
		// logoLabel.setIcon(new
		// ImageIcon(AgentContainerGUI.class.getResource("logo.png")));
		// JLabel logoLabel2 = new JLabel();
		// logoLabel2.setIcon(new
		// ImageIcon(AgentContainerGUI.class.getResource("logo2.png")));

		// default values for the window
		setTitle(owner.getContainerName());
		// setSize(400, 300);

		filterText.addKeyListener(new KeyListener() {
			@Override
			public void keyPressed(KeyEvent e) {
			}

			@Override
			public void keyReleased(KeyEvent e) {
				String text = filterText.getText();
				applyFilter(text);
			}

			@Override
			public void keyTyped(KeyEvent e) {
			}
		});

		filterText.addFocusListener(new FocusListener() {
			@Override
			public void focusGained(FocusEvent e) {
				filterTextFocusGained();
			}

			@Override
			public void focusLost(FocusEvent e) {
				filterTextFocusLost();
			}
		});

		this.addComponentListener(new ComponentAdapter() {
			/**
			 * Invoked when the component's size changes.
			 * 
			 * @param e
			 *            ComponentEvent
			 */
			@Override
			public void componentResized(ComponentEvent e) {
				// store the width even if the window is resized to keep the
				// same size
				// even if the user close the window right now
				int width = infoPanel.getWidth();
				if (width > 0) {
					store.putInt(STORE_KEY_INFO_WIDTH, width);
					infoPanelWidth = width;
				}
			}

		});

	}

	/**
	 * Quit the GUI
	 */
	void Quit() {
		int res = JOptionPane.showConfirmDialog(this,
				"Are you sure to shut down the Agent Container?",
				"Shutdown agent container", JOptionPane.YES_NO_OPTION);
		if (res != JOptionPane.YES_OPTION)
			return;

		AgentContainer.CommandService.Shell s = (AgentContainer.CommandService.Shell) owner
				.getServiceManager().getService(null,
						AgentContainer.COMMANDSERVICE);
		Command c = new Command();
		c.setName(AgentContainer.CommandService.QUIT);
		s.execute(c);
	}

	/**
	 * Show Load library dialog
	 */
	void LoadLibrary() {
		Dialog nld = new NewLibraryDialog(this);
		GUIUtils.centerOnScreen(nld);
		nld.setVisible(true);
	}

	/**
	 * Show Load agent dialog
	 */
	void LoadAgent() {
		Dialog nad = new NewAgentDialog(this);
		GUIUtils.centerOnScreen(nad);
		nad.setVisible(true);
	}

	/**
	 * Show Load service dialog.
	 */
	void LoadService() {
		Dialog nsd = new NewServiceDialog(this);
		GUIUtils.centerOnScreen(nsd);
		nsd.setVisible(true);
	}

	private void treeSelectionChanged(TreeSelectionEvent e) {
		try {
			TreePath newLeadPath = e.getNewLeadSelectionPath();
			if (newLeadPath != null) {
				TreePath parentPath = newLeadPath.getParentPath();
				if (parentPath != null) { // otherwise ROOT is selected
					// Should be Agent/Service/Library
					Object parent = parentPath.getLastPathComponent();
					Object current = newLeadPath.getLastPathComponent();

					for (ListListener.ListType l : ListListener.ListType
							.values()) {
						if (parent == l) {
							panels.get(l).setValues(current.toString());
							showInfo(l.toString());
							return;
						}
					}
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		// no specific agent/library/service selected, hide the information on
		// the right
		if (e.getNewLeadSelectionPath() != null)
			hideInfo(false);
	}

	/**
	 * Displays an appropriate page on the right side.
	 * 
	 * @param page
	 */
	private void showInfo(String page) {
		// show appropriate panel
		((CardLayout) infoPanel.getLayout()).show(infoPanel, page);

		// and resize if needed (hidden right part)
		if (infoPanelHidden) {

			int width = Math.max(infoPanelWidth, minimumInfoPanelWidthOnShow)
					+ this.getWidth();
			int dividerPos = jSplitPane1.getComponents()[1].getWidth(); 
			
			// add right content back
			jSplitPane1.add(infoPanel, JSplitPane.RIGHT);
			// and resize appropriately
			this.setSize(width, this.getHeight());
			jSplitPane1.setDividerLocation(dividerPos);

			store.putBoolean(STORE_KEY_INFO_HIDDEN, false);
			infoPanelHidden = false;
		} else { // not hidden, but still check whether it is not minimized
			if (this.getWidth() < jSplitPane1.getDividerLocation()
					+ minimumInfoPanelWidthOnShow)
				this.setSize(jSplitPane1.getDividerLocation()
						+ minimumInfoPanelWidthOnShow, this.getHeight());
		}
	}

	private void hideInfo(boolean init) {

		if (!init && infoPanelHidden)
			return; // already hidden

		if (infoPanel.getWidth() > 0) {
			infoPanelWidth = infoPanel.getWidth();
			store.putInt(STORE_KEY_INFO_WIDTH, infoPanel.getWidth());
		}

		int width = this.getWidth() - infoPanel.getWidth();

		if (init && !store.getBoolean(STORE_KEY_INFO_HIDDEN, false)) {
			// will be applied by RememberPositionJFrame
			int oldWidth = store.getInt(GUI_W, Integer.MIN_VALUE);
			if (oldWidth != Integer.MIN_VALUE) { 
				store.putInt(GUI_W, oldWidth - store.getInt(STORE_KEY_INFO_WIDTH, 0));
			}
		}

		// remove right to hide it completely
		jSplitPane1.remove(infoPanel);
		store.putBoolean(STORE_KEY_INFO_HIDDEN, true);
		infoPanelHidden = true;

		this.setSize(width, this.getHeight());
	}

	/**
	 * Start ES matrix server
	 */
	void startESMatrixServer() {

		if (!hasTopics) {
			return;
		}

		AgentInfo ai = new AgentInfo();
		ai.setName("MatrixESAgent");
		ai.setReadableName("MatrixESAgent");
		ai.setType("EnvironmentSimulator");
		ai.setMainClass("aglobe.agent.matrixes.MatrixESAgent");
		ai.setLibraries(new Libraries());
		try {
			owner.getAgentManager().createAgent(ai, false);
		} catch (ClassNotFoundException ex1) {
			JOptionPane.showMessageDialog(this,
					"Class not found: \"aglobe.agent.matrixes.MatrixESAgent\"",
					"Error", JOptionPane.ERROR_MESSAGE);
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(this,
					"An exception occured while loading the agent: \""
							+ ex.toString() + "\"", "Error",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	/**
	 * Start sniffer agent
	 */
	void startSniffer() {

		if ((!hasTopics) && (!hasLink))
			return;

		AgentInfo ai = new AgentInfo();
		ai.setName("Sniffer");
		ai.setReadableName("Sniffer");
		ai.setType("Sniffer");
		ai.setMainClass("aglobe.agent.sniffer.SnifferAgent");
		ai.setLibraries(new Libraries());
		try {
			owner.getAgentManager().createAgent(ai, false);
		} catch (ClassNotFoundException ex1) {
			JOptionPane.showMessageDialog(this,
					"Class not found: \"aglobe.agent.sniffer.SnifferAgent\"",
					"Error", JOptionPane.ERROR_MESSAGE);
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(this,
					"An exception occured while loading the agent: \""
							+ ex.toString() + "\"", "Error",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	/**
	 * Start ComAnalyzer agent
	 */
	void startComAnalyzer() {

		if ((!hasTopics) && (!hasLink))
			return;

		AgentInfo ai = new AgentInfo();
		ai.setName("ComAnalyzer");
		ai.setReadableName("ComAnalyzer");
		ai.setType("ComAnalyzer");
		ai.setMainClass("aglobe.agent.comanalyzer.ComAnalyzerAgent");
		ai.setLibraries(new Libraries());
		try {
			owner.getAgentManager().createAgent(ai, false);
		} catch (ClassNotFoundException ex1) {
			JOptionPane
					.showMessageDialog(
							this,
							"Class not found: \"aglobe.agent.comanalyzer.ComAnalyzerAgent\"",
							"Error", JOptionPane.ERROR_MESSAGE);
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(this,
					"An exception occured while loading the agent: \""
							+ ex.toString() + "\"", "Error",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	/**
	 * Start logger agent
	 */
	void startLogger() {

		if (!hasTopics) {
			return;
		}

		AgentInfo ai = new AgentInfo();
		ai.setName("Logger");
		ai.setReadableName("Logger");
		ai.setType("Logger");
		ai.setMainClass("aglobe.agent.logger.LoggerAgent");
		ai.setLibraries(new Libraries());
		try {
			owner.getAgentManager().createAgent(ai, false);
		} catch (ClassNotFoundException ex1) {
			JOptionPane.showMessageDialog(this,
					"Class not found: \"aglobe.agent.logger.LoggerAgent\"",
					"Error", JOptionPane.ERROR_MESSAGE);
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(this,
					"An exception occured while loading the agent: \""
							+ ex.toString() + "\"", "Error",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	private void applyFilter(String filter) {
		store.putString(STORE_KEY_FILTER, filter);

		// empty string - match all
		if (filter.equals("")) {
			containerTreeModel1.ApplyFilter(null);
			filterText.setBackground(null);
			return;
		}

		// try to compile the regex
		try {
			Pattern p = Pattern.compile(filter, Pattern.CASE_INSENSITIVE);
			containerTreeModel1.ApplyFilter(p);
			filterText.setBackground(Color.GREEN);

			// and expand all while we are using the filter
			for (int i = 0; i < jTree1.getRowCount(); i++) {
				jTree1.expandRow(i);
			}
		} catch (PatternSyntaxException ex) {
			filterText.setBackground(Color.RED);
		}
	}

	private void filterTextFocusGained() {
		if (filterText.getHorizontalAlignment() == JTextField.CENTER) { // empty
			// field
			filterText.setText("");
			filterText.setFont(new Font(filterText.getFont().getName(),
					Font.PLAIN, filterText.getFont().getSize()));
			filterText.setBackground(null);
			filterText.setHorizontalAlignment(JTextField.LEFT);
		}
	}

	private void filterTextFocusLost() {
		if (filterText.getText().equals("")) {
			filterText.setText("Filter");

			filterText.setFont(new Font(filterText.getFont().getName(),
					Font.ITALIC, filterText.getFont().getSize()));
			filterText.setBackground(Color.LIGHT_GRAY);
			filterText.setHorizontalAlignment(JTextField.CENTER);
		}
	}

	class StatusBar extends JTextField implements TreeModelListener {

		private static final long serialVersionUID = 6483991834802142290L;

		@Override
		public void treeNodesChanged(TreeModelEvent e) {
			UpdateStatus();
		}

		@Override
		public void treeNodesInserted(TreeModelEvent e) {
			UpdateStatus();
		}

		@Override
		public void treeNodesRemoved(TreeModelEvent e) {
			UpdateStatus();
		}

		@Override
		public void treeStructureChanged(TreeModelEvent e) {
			UpdateStatus();
		}

		public StatusBar() {
			setEditable(false);
		}

		private void UpdateStatus() {
			Map<ListListener.ListType, java.util.List<Integer>> counts = AgentContainerGUI.this.containerTreeModel1
					.GetCounts();

			StringBuilder result = new StringBuilder(256);
			for (ListListener.ListType l : ListListener.ListType.values()) {
				java.util.List<Integer> values = counts.get(l);
				if (values != null)
					result.append(String.format("  %s:%d/%d", l.toString(),
							values.get(1), values.get(0)));
			}

			this.setText(result.toString());
		}
	}
}

class AgentContainerTree extends JTree {

	private static final long serialVersionUID = 6945891397580890644L;
	private ImageIcon logoGerstner = null;
	private ImageIcon logoATG = null;

	public AgentContainerTree() {
		this.logoGerstner = new ImageIcon(AgentContainerGUI.class
				.getResource("logo.png"));
		this.logoATG = new ImageIcon(AgentContainerGUI.class
				.getResource("logo2.png"));
	}

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);

		// assume that we are in a JScrollPane which is the second parent, first
		// is JViewport
		Point scrollPosition = ((JScrollPane) this.getParent().getParent())
				.getViewport().getViewPosition();

		// draw icons if the tree is not too high
		boolean drawGerstner = this.getRowForLocation(scrollPosition.x
				+ logoGerstner.getIconWidth() / 2, scrollPosition.y
				+ this.getVisibleRect().height - logoGerstner.getIconHeight()) < 0
				&& this.getVisibleRect().height > logoGerstner.getIconHeight()
				&& this.getVisibleRect().width > logoGerstner.getIconWidth();
		if (drawGerstner) {
			g.drawImage(logoGerstner.getImage(), scrollPosition.x + 2,
					scrollPosition.y + this.getVisibleRect().height
							- logoGerstner.getIconHeight() - 2, null);
		}

		boolean drawATG = this.getRowForLocation(scrollPosition.x
				+ Math.max(
						this.getVisibleRect().width - logoATG.getIconWidth(),
						logoGerstner.getIconWidth()), scrollPosition.y
				+ this.getVisibleRect().height - logoATG.getIconHeight()) < 0
				&& this.getVisibleRect().height > logoATG.getIconHeight()
				&& this.getVisibleRect().width > logoATG.getIconWidth()
						+ logoGerstner.getIconWidth();
		if (drawATG) {
			g.drawImage(logoATG.getImage(), scrollPosition.x
					+ Math.max(this.getVisibleRect().width
							- logoATG.getIconWidth() - 2, logoGerstner
							.getIconWidth() + 6), scrollPosition.y
					+ this.getVisibleRect().height - logoATG.getIconHeight()
					- 2, null);
		}
	}
}
