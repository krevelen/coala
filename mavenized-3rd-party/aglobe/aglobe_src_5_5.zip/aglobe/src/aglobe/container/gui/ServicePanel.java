package aglobe.container.gui;

import java.awt.*;
import javax.swing.*;
import java.util.*;

import aglobe.ontology.*;
import java.awt.event.*;

/**
 * Service panel of agent container GUI.
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.15 $ $Date: 2010/08/04 11:48:05 $
 */
class ServicePanel extends InfoPanel {
    private static final long serialVersionUID = -7611474399242122046L;

    private final AgentContainerGUI owner;

    private DefaultListModel liblm = new DefaultListModel();

    private GridBagLayout gridBagLayout1 = new GridBagLayout();

    private JPanel contentPanel = new JPanel();

    private JPanel buttonPanel = new JPanel();

    private JScrollPane contentScrollPane = new JScrollPane();

    private GridBagLayout gridBagLayout2 = new GridBagLayout();

    private GridBagLayout gridBagLayout3 = new GridBagLayout();

    private JButton stopButton = new JButton();

    private JButton hideButton = new JButton();

    private JButton showButton = new JButton();

    private JButton refreshButton = new JButton();

    private JLabel nameLabel = new JLabel();

    private JLabel mainclassLabel = new JLabel();

    private JLabel descriptionLabel = new JLabel();

    private JLabel LibrariesLabel = new JLabel();

    private JTextField nameValue = new JTextField();

    private JTextField mainclassValue = new JTextField();

    private JScrollPane descriptionScrollPane = new JScrollPane();

    private JTextArea descriptionTextArea = new JTextArea();

    private JScrollPane librariesScrollPane = new JScrollPane();

    private JList librariesList = new JList(liblm);

    private JLabel jLabel1 = new JLabel();

    ServicePanel(AgentContainerGUI owner) {
        this.owner = owner;
        try {
            jbInit();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    void setValues(String name) {
        ServiceInfo si = owner.owner.getServiceManager().getServiceInfo(name);

        liblm.clear();

        if (si != null) {
            nameValue.setText(si.getName());
            mainclassValue.setText(si.getMainClass());
            descriptionTextArea.setText(si.getDescription());

            if (si.getLibraries() != null) {
                int pos = 0;
                for (Iterator<String> i = si.getLibraries().getLibrary().iterator(); i.hasNext();) {
                    String l = i.next();
                    liblm.add(pos++, l);
                }
            }
        } else {
            nameValue.setText("");
            mainclassValue.setText("");
            descriptionTextArea.setText("");
        }
    }

    void jbInit() throws Exception {
        this.setLayout(gridBagLayout1);
        contentPanel.setLayout(gridBagLayout2);
        buttonPanel.setLayout(gridBagLayout3);
        stopButton.setText("Stop");
        stopButton.addActionListener(new java.awt.event.ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                stopButton_actionPerformed(e);
            }
        });
        hideButton.setText("Hide");
        hideButton.addActionListener(new java.awt.event.ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                hideButton_actionPerformed(e);
            }
        });
        showButton.setText("Show");
        showButton.addActionListener(new java.awt.event.ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                showButton_actionPerformed(e);
            }
        });
        refreshButton.setText("Refresh");
        refreshButton.addActionListener(new java.awt.event.ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                refreshButton_actionPerformed(e);
            }
        });
        nameLabel.setText("Name:");
        mainclassLabel.setText("Main class:");
        descriptionLabel.setText("Description:");
        LibrariesLabel.setText("Libraries:");
        nameValue.setEditable(false);
        nameValue.setColumns(30);
        mainclassValue.setEditable(false);
        mainclassValue.setColumns(30);
        descriptionTextArea.setEditable(false);
        descriptionTextArea.setColumns(30);
        descriptionTextArea.setRows(3);
        librariesList.setVisibleRowCount(4);
        contentScrollPane.getViewport().add(contentPanel, null);
        librariesScrollPane.getViewport().add(librariesList, null);
        descriptionScrollPane.getViewport().add(descriptionTextArea, null);
        this.add(contentScrollPane, new GridBagConstraints(0, 0, 1, 1, 0.1, 0.1, GridBagConstraints.NORTH, GridBagConstraints.BOTH, new Insets(5, 5, 0, 5), 0,
                0));
        this.add(buttonPanel, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 5), 0,
                0));
        buttonPanel.add(stopButton, new GridBagConstraints(3, 0, 1, 1, 0.1, 0.0, GridBagConstraints.SOUTHEAST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0),
                0, 0));
        buttonPanel.add(hideButton, new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0, GridBagConstraints.SOUTHWEST, GridBagConstraints.NONE, new Insets(0, 2, 0, 0),
                0, 0));
        buttonPanel.add(showButton, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0, GridBagConstraints.SOUTHEAST, GridBagConstraints.NONE, new Insets(0, 0, 0, 2),
                0, 0));
        buttonPanel.add(refreshButton, new GridBagConstraints(0, 0, 1, 1, 0.1, 0.0, GridBagConstraints.SOUTHWEST, GridBagConstraints.NONE, new Insets(0, 0, 0,
                0), 0, 0));
        contentPanel.add(nameLabel,
                new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 4, 2, 4), 0, 0));
        contentPanel.add(mainclassLabel, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(2, 4, 2, 4),
                0, 0));
        contentPanel.add(descriptionLabel, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE,
                new Insets(2, 4, 2, 4), 0, 0));
        contentPanel.add(LibrariesLabel, new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(2, 4, 2, 4),
                0, 0));
        contentPanel.add(nameValue, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL,
                new Insets(5, 0, 2, 4), 0, 0));
        contentPanel.add(mainclassValue, new GridBagConstraints(1, 1, 1, 1, 0.1, 0.0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(2, 0,
                2, 4), 0, 0));
        contentPanel.add(descriptionScrollPane, new GridBagConstraints(1, 2, 1, 1, 0.1, 0.0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL,
                new Insets(2, 0, 2, 4), 0, 0));
        contentPanel.add(librariesScrollPane, new GridBagConstraints(1, 3, 1, 1, 0.1, 0.0, GridBagConstraints.NORTHWEST, GridBagConstraints.HORIZONTAL,
                new Insets(2, 0, 2, 4), 0, 0));
        contentPanel.add(jLabel1,
                new GridBagConstraints(0, 4, 2, 1, 0.0, 0.1, GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));

    }

    /**
     * @param e
     */
    void refreshButton_actionPerformed(ActionEvent e) {
        setValues(nameValue.getText());
    }

    /**
     * @param e
     */
    void showButton_actionPerformed(ActionEvent e) {
        owner.owner.getServiceManager().showService(nameValue.getText());
    }

    /**
     * @param e
     */
    void hideButton_actionPerformed(ActionEvent e) {
        owner.owner.getServiceManager().hideService(nameValue.getText());
    }

    /**
     * @param e
     */
    void stopButton_actionPerformed(ActionEvent e) {
        String an = nameValue.getText();
        int res = JOptionPane.showConfirmDialog(this, "Really stop the service " + an, "Stop Service", JOptionPane.YES_NO_OPTION);
        if (res != JOptionPane.YES_OPTION)
            return;
        owner.owner.getServiceManager().deregisterService(an);
    }
}
