package aglobe.container.gui;

import java.awt.*;
import javax.swing.*;
import aglobe.platform.Platform;

/**
 * Background panel. Contains logos and aglobe info.
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: Agent Technology Center, Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.12 $ $Date: 2009/05/15 08:46:58 $
 */
class Background extends JPanel {

    private static final long serialVersionUID = 7382761975355523836L;

    private Icon bmpGrid = new ImageIcon(AgentContainerGUI.class.getResource("grid.png"));
    private Icon bmpBarMain = new ImageIcon(AgentContainerGUI.class.getResource("bar_main.png"));
    private Icon bmpBarExt = new ImageIcon(AgentContainerGUI.class.getResource("bar_ext.png"));

    @Override
    public void paintComponent(Graphics g) {
        drawGrid(g);
        drawBar(g);
    }

    private void drawGrid(Graphics g) {
        int panelWidth = this.getWidth();
        int panelHeight = this.getHeight();
        int gridWidth = bmpGrid.getIconWidth();
        int gridHeight = bmpGrid.getIconHeight();

        int countX = (int) Math.ceil(panelWidth / (double) gridWidth);
        int countY = (int) Math.ceil(panelHeight / (double) gridHeight);

        int y = 0;
        for (int j = 0; j < countY; j++) {
            int x = 0;
            for (int i = 0; i < countX; i++) {
                bmpGrid.paintIcon(this, g, x, y);
                x += gridWidth;
            }
            y += gridHeight;
        }
    }

    private void drawBar(Graphics g) {
        int panelWidth = this.getWidth();
        int panelHeight = this.getHeight();
        int barMainWidth = bmpBarMain.getIconWidth();
        int barMainHeight = bmpBarExt.getIconHeight();
        int barExtWidth = bmpBarExt.getIconWidth();

        int y = panelHeight - barMainHeight/*- 30*/;
        // y = (y / 16) * 16;
        if (y < 0) {
            y = 0;
        }

        bmpBarMain.paintIcon(this, g, 0, y);

        if (panelWidth > barMainWidth) {
            int barExtCount = (int) Math.ceil((panelWidth - barMainWidth) / (double) barExtWidth);
            int x = barMainWidth;
            for (int i = 0; i < barExtCount; i++) {
                bmpBarExt.paintIcon(this, g, x, y);
                x += barExtWidth;
            }
        }

        drawAglobeVersion(g, panelWidth - 30, y + 15);
    }

    private void drawAglobeVersion(Graphics g, int x, int y) {
        String version = "v" + Platform.MAJOR_VERSION + "." + Platform.MINOR_VERSION;
        g.setColor(Color.GRAY);
        g.setFont(new Font("Tahoma", Font.PLAIN, 11));
        g.drawString(version, x, y);
    }
}
