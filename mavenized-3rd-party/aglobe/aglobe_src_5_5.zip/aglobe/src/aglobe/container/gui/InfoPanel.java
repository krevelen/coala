package aglobe.container.gui;

import javax.swing.JPanel;

/**
 * Info panel.
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.8 $ $Date: 2009/05/15 08:46:58 $
 */
abstract class InfoPanel extends JPanel
{
    private static final long serialVersionUID = 7408371934797078198L;

    /**
     * Set values
     * @param name String
     */
    void setValues(String name) {
        throw new UnsupportedOperationException("The method setValues should be overriden!!!");
    }
}
