package aglobe.container.gui;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.*;

import aglobe.ontology.*;
import aglobe.container.library.LibraryManager;
import java.util.Iterator;

/**
 * New service dialog of agent container GUI.
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.16 $ $Date: 2010/12/01 12:36:10 $
 */
class NewServiceDialog extends JDialog {
    private static final long serialVersionUID = 6421090150899297927L;

    private AgentContainerGUI owner;

    private JPanel panel1 = new JPanel();

    private BorderLayout borderLayout1 = new BorderLayout();

    private JPanel fieldPanel = new JPanel();

    private JPanel buttonPanel = new JPanel();

    private GridBagLayout gridBagLayout1 = new GridBagLayout();

    private GridBagLayout gridBagLayout2 = new GridBagLayout();

    private JButton cancelButton = new JButton();

    private JButton okButton = new JButton();

    private TitledBorder titledBorder1;

    private JLabel nameLabel = new JLabel();

    private JLabel mainclassLabel = new JLabel();

    private JLabel librariesLabel = new JLabel();

    private JTextField nameValue = new JTextField();

    private boolean textField;

    private JTextField mainclassValue = new JTextField();

    private JComboBox mainclassCombo = new JComboBox();

    // private JTextField librariesValue = new JTextField();

    private JScrollPane libScroll = new JScrollPane();

    private JList libList = new JList();

    private TitledBorder libBorder;

    NewServiceDialog(Frame frame, String title, boolean modal, AgentContainerGUI owner) {
        super(frame, title, modal);
        this.owner = owner;
        try {
            jbInit();

            LibraryManager.LibraryRecord[] libs = owner.owner.getLibraryManager().getLibraryList();
            libList.setListData(libs);
            libList.setVisibleRowCount(Math.min(libs.length, 4));

            java.util.List<String> cls = owner.owner.getClassFinder().getServiceList();
            if (cls.size() != 0) {
                for (Iterator<String> iter = cls.iterator(); iter.hasNext();) {
                    String item = iter.next();
                    mainclassCombo.addItem(item);
                }
                mainclassLabel.setLabelFor(mainclassCombo);
                fieldPanel.add(mainclassCombo, new GridBagConstraints(1, 1, 1, 1, 0.6, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
                        new Insets(2, 4, 2, 4), 0, 0));
                textField = false;
            } else {
                mainclassLabel.setLabelFor(mainclassValue);
                fieldPanel.add(mainclassValue, new GridBagConstraints(1, 1, 1, 1, 0.6, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
                        new Insets(2, 4, 2, 4), 0, 0));
                textField = true;
            }

            pack();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    NewServiceDialog(Frame owner) {
        this(owner, "New Service", true, (AgentContainerGUI) owner);
    }

    NewServiceDialog(AgentContainerGUI owner) {
        this(null, "New Service", true, owner);
    }

    private void jbInit() throws Exception {
        titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white, new Color(165, 163, 151)), "New service properties");
        libBorder = new TitledBorder(BorderFactory.createEtchedBorder(Color.white, new Color(165, 163, 151)), "Select libraries");
        panel1.setLayout(borderLayout1);
        fieldPanel.setLayout(gridBagLayout1);
        buttonPanel.setLayout(gridBagLayout2);
        cancelButton.setText("Cancel");
        cancelButton.addActionListener(new java.awt.event.ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                cancelButton_actionPerformed(e);
            }
        });
        okButton.setText("OK");
        okButton.addActionListener(new java.awt.event.ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                okButton_actionPerformed(e);
            }
        });
        okButton.setPreferredSize(cancelButton.getPreferredSize());
        fieldPanel.setBorder(titledBorder1);
        nameLabel.setLabelFor(nameValue);
        nameLabel.setText("Name:");
        mainclassLabel.setText("Main Class:");
        librariesLabel.setLabelFor(libScroll);
        librariesLabel.setText("Libraries:");
        // librariesValue.setToolTipText(
        // "Names of required libraries separated by semicolon character (\";\")."
        // );
        // librariesValue.setColumns(20);
        libScroll.setBorder(libBorder);
        libScroll.getViewport().setView(libList);
        libList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        nameValue.setColumns(20);
        getContentPane().add(panel1);
        panel1.add(fieldPanel, BorderLayout.CENTER);
        fieldPanel.add(nameLabel, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(2, 4, 2, 4), 0, 0));
        fieldPanel.add(mainclassLabel, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(2, 4, 2, 4),
                0, 0));
        fieldPanel.add(librariesLabel, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(2, 4, 2, 4),
                0, 0));
        fieldPanel.add(nameValue, new GridBagConstraints(1, 0, 1, 1, 0.6, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
                new Insets(2, 2, 2, 4), 0, 0));
        fieldPanel.add(libScroll, new GridBagConstraints(1, 2, 1, 1, 0, 0.1, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(2, 2, 2, 4), 0, 0));
        panel1.add(buttonPanel, BorderLayout.SOUTH);
        buttonPanel.add(cancelButton, new GridBagConstraints(1, 0, 1, 1, 0.5, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(4, 4, 4, 4), 0,
                0));
        buttonPanel.add(okButton, new GridBagConstraints(0, 0, 1, 1, 0.5, 0.0, GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(4, 4, 4, 4), 0, 0));
    }

    /**
     * @param e
     */
    void cancelButton_actionPerformed(ActionEvent e) {
        this.dispose();
    }

    /**
     * @param e
     */
    void okButton_actionPerformed(ActionEvent e) {
        // fetch selected libraries
        Object libs[] = libList.getSelectedValues();

        // strip class name part from the library part
        String mainClass = (textField) ? mainclassValue.getText() : (String) mainclassCombo.getSelectedItem();
        int separatorPosition = mainClass.indexOf('@');
        if (separatorPosition != -1) {
            String libId = mainClass.substring(separatorPosition + 1);
            mainClass = mainClass.substring(0, separatorPosition);
            // check if library is selected
            boolean found = false;
            for (int i = 0; i < libs.length; i++) {
                LibraryManager.LibraryRecord lib = (LibraryManager.LibraryRecord) libs[i];
                if (lib.readableName.equalsIgnoreCase(libId)) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                JOptionPane.showMessageDialog(this, "The library with main class of a service is not selected. Requested library: \"" + libId + "\"", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        ServiceInfo si = new ServiceInfo();
        si.setName(nameValue.getText());
        si.setMainClass(mainClass);

        Libraries l = new Libraries();

        for (int i = 0; i < libs.length; i++) {
            String lib = ((LibraryManager.LibraryRecord) libs[i]).libInfo.getName();
            l.getLibrary().add(lib);
        }

        si.setLibraries(l);

        try {
            owner.owner.getServiceManager().registerService(si, true);
            this.dispose();
        } catch (ClassNotFoundException ex1) {
            JOptionPane.showMessageDialog(this, "Class not found: \"" + ((textField) ? mainclassValue.getText() : (String) mainclassCombo.getSelectedItem())
                    + "\"", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane
                    .showMessageDialog(this, "An exception occured while loading the service: \"" + ex.toString() + "\"", "Error", JOptionPane.ERROR_MESSAGE);
        }

    }
}
