package aglobe.container.gui;

import java.util.*;

/**
 * List listener of agent container GUI.
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * 
 * @author David Sislak
 * @version $Revision: 1.11 $ $Date: 2009/05/15 08:46:58 $
 */
public interface ListListener {
	public enum ListType {
		AGENTS, SERVICES, LIBRARIES
	}

	public void ValueChanged(ListType where, Object what);

	public void ListChanged(ListType which, Set<String> values);
}
