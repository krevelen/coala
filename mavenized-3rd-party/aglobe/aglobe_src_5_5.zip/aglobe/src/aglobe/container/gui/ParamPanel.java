package aglobe.container.gui;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.border.*;
import java.awt.event.*;

import aglobe.ontology.*;

/**
 * Param panel of agent container GUI.
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.14 $ $Date: 2010/08/04 11:48:05 $
 */
class ParamPanel extends JPanel {
    private static final long serialVersionUID = -9159051316521148929L;

    // private static final String[][] EMPTY = new String[][] {new String[0],
    // new String[0]};
    private static final String[] NAMES = new String[] { "Name", "Value" };

    private DefaultTableModel tm = new DefaultTableModel(NAMES, 0);

    private GridBagLayout gridBagLayout1 = new GridBagLayout();

    private JScrollPane paramScrollPane = new JScrollPane();

    private JButton removeButton = new JButton();

    private JButton addButton = new JButton();

    private JTable paramTable = new JTable(tm);

    private Border border1;

    ParamPanel() {
        try {
            jbInit();
            Dimension d = removeButton.getPreferredSize();
            d.width = d.width * 4;
            d.height = paramTable.getRowHeight() * 4;
            paramTable.setPreferredScrollableViewportSize(d);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    AglobeParam[] getParams() {
        int len = 0;
        for (int i = 0; i < tm.getRowCount(); i++) {
            String s = (String) tm.getValueAt(i, 0);
            if (s != null && !"".equals(s))
                len++;
        }

        int pos = 0;
        AglobeParam[] res = new AglobeParam[len];
        for (int i = 0; i < tm.getRowCount(); i++) {
            String name = (String) tm.getValueAt(i, 0);
            if (name != null && !"".equals(name)) {
                AglobeParam np = new AglobeParam();
                np.setName(name);
                np.setValue((String) tm.getValueAt(i, 1));
                res[pos++] = np;
            }
        }

        return res;
    }

    private void jbInit() throws Exception {
        border1 = BorderFactory.createLineBorder(UIManager.getColor("Panel.background"), 1);
        this.setLayout(gridBagLayout1);
        removeButton.setText("Remove");
        removeButton.addActionListener(new java.awt.event.ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                removeButton_actionPerformed(e);
            }
        });
        addButton.setText("Add");
        addButton.addActionListener(new java.awt.event.ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                addButton_actionPerformed(e);
            }
        });
        paramScrollPane.setBorder(border1);
        this.add(paramScrollPane,
                new GridBagConstraints(0, 0, 1, 2, 1.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        this.add(removeButton, new GridBagConstraints(1, 1, 1, 1, 0.0, 0.5, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        this.add(addButton, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.5, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        paramScrollPane.getViewport().add(paramTable, null);
    }

    /**
     * @param e
     */
    void addButton_actionPerformed(ActionEvent e) {
        tm.addRow(new String[] { "", "" });
    }

    /**
     * @param e
     */
    void removeButton_actionPerformed(ActionEvent e) {
        int i = paramTable.getSelectedRow();
        if (i >= 0)
            tm.removeRow(i);
    }
}
