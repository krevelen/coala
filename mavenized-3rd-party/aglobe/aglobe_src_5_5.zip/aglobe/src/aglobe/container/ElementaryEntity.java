package aglobe.container;


import java.lang.reflect.Field;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;

import javax.swing.SwingUtilities;

import aglobe.container.service.ServiceShell;
import aglobe.container.transport.Address;
import aglobe.container.transport.InvisibleContainerException;
import aglobe.container.transport.MessageTransport;
import aglobe.ontology.Message;
import aglobe.ontology.MessageConstants;
import aglobe.platform.thread.AglobeThreadPool;
import aglobe.platform.transport.MessageReceiver;
import aglobe.util.ExceptionPrinter;
import aglobe.util.concurrent.ArrayFIFO;
import aglobe.util.logging.LogProvider;

/**
 * <p>Title: A-Globe</p>
 *
 * <p>Description: Elementary Entity interface denotes that implementor object will
 * provide logger function, event handling, is holder of address, has own store, can receive message, can send
 * message, has own timer. There are two implementor in A-globe now - Agent and Service</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.12 $ $Date: 2010/08/04 11:48:05 $
 */
public abstract class ElementaryEntity extends MessageReceiver implements EventReceiver, LoggerOwner, ContainerOwner,
      MessageHandler, MessageSender, TimerShellOwner, StoreOwner {
    /**
     * @internal
     * Entity's state type: entity is getting ready.
     */
    public static final int INIT = 0;

    /**
     * @internal
     * Entity's state type: entity is running.
     */
    public static final int RUNNING = 1;

    /**
     * @internal
     * Entity's state type: execution finished, but should start again.
     */
    public static final int DONE = 2;

    /**
     * @internal
     * Entity's state type: totally finished.
     */
    public static final int DEAD = 3; // Totally finished, remove

    /**
     * @internal
     * Entity throw an exception during its running
     */
    public static final int EXCEPTION = 4;

    /**
     * @internal
     * Entity's state type: execution finished, should migrate.
     */
    public static final int MIGRATING = 5;

    /**
     * @internal
     * Entity's state type: cloning
     */
    public static final int CLONING = 6;

    /**
     * @internal
     * Status masks
     */
    private static final int FULL_32BIT = 0xffffffff;

    /**
     * @internal
     */
    private static final int PLAN_SIZE_MASK = 0xfffff;

    /**
     * @internal
     */
    private static final int DIE_MASK = 0x100000;

    /**
     * @internal
     */
    private static final int STOP_MASK = 0x200000;

    /**
     * @internal
     */
    protected static final int MIGRATION_MASK = 0x400000;

    /**
     * @internal
     */
    private static final int USE_IDLE_MASK = 0x800000;

    /**
     * @internal
     */
    private static final int IS_ACTIVE_MASK = 0x1000000;

    /**
     * @internal
     */
    private static final int HAS_THREAD_ASSIGNED_MASK = 0x2000000;

    /**
     * @internal
     */
    private static final int USE_PERSISTENT_THREAD_MASK = 0x4000000;

    /**
     * @internal
     */
    private static final int WAITS_MASK = 0x8000000;

    /**
     * @internal
     * Entity status.
     */
    private transient AtomicInteger status = new AtomicInteger(HAS_THREAD_ASSIGNED_MASK | IS_ACTIVE_MASK | USE_IDLE_MASK);

    /**
     * A plan of the entity. It is list of messages or tasks to process.
     * Max 2^20 items
     */
    private transient ArrayFIFO<Object> plan = new ArrayFIFO<Object>(1<<20 -1);

    /**
     * Current entity's thread. If entity is in non-persistent thread mode, in the
     * time when entity is waiting for the new event it has no thread assigned to it.
     * In such case this variable contains null.
     */
    private transient AtomicReference<Thread> myThread = new AtomicReference<Thread>(null);

    /**
     * My thread name
     */
    private transient String myThreadName = null;

    /**
     * @internal
     * Entity's container.
     */
    protected transient AgentContainer container = null;

    /**
     * Entity's MessageTransport.
     */
    private transient MessageTransport mt = null;

    /**
     *  @internal
     *  Entity's name.
     */
    protected String name;

    /**
     *  @internal
     *  Entity's state variable, initial setting: entity is initializing first.
     */
    protected int state = INIT;

    /**
     * @internal
     * List of the owned service shells
     */
    protected transient ConcurrentHashMap<ServiceShell,ServiceShell> ownedServiceShells;

    /**
     * @internal
     * My actual entity runner
     */
    transient EntityRunner myEntityRunner = null;

    private transient ReentrantLock waitLock = new ReentrantLock();
    private transient Condition waitCondition = waitLock.newCondition();

    private transient ReentrantLock waiterLock = new ReentrantLock();
    private transient Condition waiterCond = waiterLock.newCondition();
    private transient Runnable waiterRunner = null;

    /**
     * @internal
     */
    protected final void initializeTransient() {
        plan = new ArrayFIFO<Object>(1<<20 -1);

        status = new AtomicInteger(HAS_THREAD_ASSIGNED_MASK | IS_ACTIVE_MASK);
        waitLock = new ReentrantLock();
        waitCondition = waitLock.newCondition();

        myThreadName = null;
        myThread = new AtomicReference<Thread>(null);
    }

    /**
     * @internal
     */
    @Override
    public void addServiceShell(final ServiceShell shell) {
        ownedServiceShells.put(shell, shell);
    }

    /**
     * @internal
     */
    @Override
    public void removeServiceShell(final ServiceShell shell) {
        ownedServiceShells.remove(shell);
    }

    /**
     * @internal
     *
     * Returns true if entity is active
     * @return
     */
    protected final boolean isActive() {
        return (status.get() & IS_ACTIVE_MASK) != 0;
    }

    /**
     * @internal
     * This method assigns a container to the entity.
     *
     * @param newContainer is assigned container.
     * @throws Exception
     */
    public void setContainer(final AgentContainer newContainer) throws
            Exception {
        if (container == null) {
            this.container = newContainer;
            this.mt = container.getMessageTransport();
        }
    }

    /**
     * @internal
     * Entity's initialization method used by A-globe. It is called automatically by Container.
     *
     * @throws Exception
     */
    public void sysInit(final String name) {
        state = INIT;
        ownedServiceShells = new ConcurrentHashMap<ServiceShell,ServiceShell>();
        this.name = name;
    }

    /**
     * @internal
     * This is the internal methods which is called just after initialization.
     */
    public final void sysPostInit() {
        state = RUNNING;
    }

    /**
     * @internal
     * This method performs services cleanup.
     */
    protected void sysFinish() {
        for (ServiceShell elem : ownedServiceShells.keySet()) {
            elem.dispose();
        }
        if ((status.get() & IS_ACTIVE_MASK) == 0) {
            Object o;
            while ((o = plan.pop()) != null) {
                if (o instanceof Message) {
                    ((Message) o).release();
                }
            }
            for (;;) {
                final int curStatus = status.get();
                if (status.compareAndSet(curStatus, curStatus & (FULL_32BIT ^ PLAN_SIZE_MASK))) {
                    return;
                }
            }
        }
    }

    /**
     * Override this method to perform quick clean up (such as close opened files, hide GUI etc.).
     */
    protected void finish() {
    }

    /**
     * @internal
     * The entity's main method. It is called by <code>AgentManager</code> or <code>ServiceManager</code>.
     * Exiting from <code>run</code> method means either termination of the entity,
     * its migration or suspension.
     * @return boolean - true if entity finished otherwise it is only suspended until next new message. If it is
     * finished it sets internal state to the exit status
     */
    final public boolean run() {
        try {
            myThread.set(Thread.currentThread());
            if (myThreadName == null) {
                myThreadName = Thread.currentThread().getName();
            }
            int curStatus;
            for (;;) {
                curStatus = status.get();
                if ((curStatus & (DIE_MASK | STOP_MASK)) != 0) {
                    // stop or die entity
                    break;
                }
                final int inPlan = curStatus & PLAN_SIZE_MASK;
                if (inPlan > 0) {
                    // yes there are some events waiting
                    final int newPlan = (inPlan - 1) & PLAN_SIZE_MASK;
                    if (status.compareAndSet(curStatus, (curStatus & (FULL_32BIT ^ PLAN_SIZE_MASK) | newPlan))) {
                        // ok, I got it
                        final Object o = plan.pop();
                        if (o != null) {
                            if (o instanceof Runnable) {
                                ((Runnable) o).run();
                            } else if (o instanceof Message) {
                                Message m = (Message) o;
                                handleIncomingMessage(m);
                            }
                            // continue with next event
                        } else {
                            throw new IllegalStateException("No element in the entity queue");
                        }
                    }
                    // try again, some changes
                    continue;
                } else {
                    // no event ready
                    if ((curStatus & MIGRATION_MASK) != 0) {
                        // migrate
                        break;
                    }
                    if ((curStatus & USE_IDLE_MASK) != 0) {
                        // call idle method
                        idle();
                    }
                    if ((curStatus & (USE_PERSISTENT_THREAD_MASK | USE_IDLE_MASK)) != 0) {
                        // try wait, cannot release thread
                        waitLock.lock();
                        try {
                            if (status.compareAndSet(curStatus, curStatus | WAITS_MASK)) {
                                // wait set
                                try {
                                    if ((curStatus & USE_IDLE_MASK) != 0) {
                                        waitCondition.await(1, TimeUnit.SECONDS);
                                    } else {
                                        waitCondition.await();
                                    }
                                } catch (InterruptedException ex1) {
                                }
                            }
                        } finally {
                            waitLock.unlock();
                        }
                    } else {
                        // can release thread now
                        final Thread oldMyThread = myThread.get();
                        if (status.compareAndSet(curStatus, curStatus & (FULL_32BIT ^ HAS_THREAD_ASSIGNED_MASK))) {
                            // released
                            myThread.compareAndSet(oldMyThread,null);
                            return false;
                        }
                    }
                }

            }

            if ((curStatus & DIE_MASK) != 0) {
                // set not active
                for (;;) {
                    if (status.compareAndSet(curStatus, curStatus & (FULL_32BIT ^ IS_ACTIVE_MASK))) {
                        break;
                    }
                    curStatus = status.get();
                }
                state = DEAD;
            } else if ((curStatus & STOP_MASK) != 0) {
                // set not active
                for (;;) {
                    if (status.compareAndSet(curStatus, curStatus & (FULL_32BIT ^ IS_ACTIVE_MASK))) {
                        break;
                    }
                    curStatus = status.get();
                }
                state = DONE;
            } else if ((curStatus & MIGRATION_MASK) != 0) {
                state = MIGRATING;
            } else {
                // set not active
                for (;;) {
                    if (status.compareAndSet(curStatus, curStatus & (FULL_32BIT ^ IS_ACTIVE_MASK))) {
                        break;
                    }
                    curStatus = status.get();
                }
                throw new IllegalStateException(
                        "Illegal entity state - stopped without reason.");
            }

            // unblock waiting threads
            waiterLock.lock();
            try {
                waiterCond.signalAll();
            } finally {
                waiterLock.unlock();
            }

            // returns without releasing thread
            return true;
        } catch (Throwable ex) {
            for (;;) {
                final int curStatus = status.get();
                if (status.compareAndSet(curStatus, curStatus & (FULL_32BIT ^ IS_ACTIVE_MASK))) {
                    break;
                }
            }
            logSevere("Run exception: " + ExceptionPrinter.toStringWithStackTrace(ex));
            state = EXCEPTION;
            return true;
        }
    }

    /**
     * Inserts event or message into entity plan
     * @param what
     * @return
     */
    private final boolean insertIntoQueue(final Object what) {
        int curStatus = status.get();
        if ((curStatus & IS_ACTIVE_MASK) == 0) {
            // entity is not active
            return false;
        }
        // insert event in the queue
        try {
            plan.push(what);
        } catch (Exception ex) {
            throw new IllegalStateException("Cannot insert event in the entity queue",ex);
        }

        for (;;) {
            final int newPlanLen = ((curStatus & PLAN_SIZE_MASK) + 1) & PLAN_SIZE_MASK;
            if (newPlanLen == 0) {
                throw new IllegalStateException(
                        "Maximum scheduled events limit exceeded");
            }
            if ((curStatus & HAS_THREAD_ASSIGNED_MASK) == 0) {
                // assign thread at the same time
                if (status.compareAndSet(curStatus, (curStatus & (FULL_32BIT ^ PLAN_SIZE_MASK)) | newPlanLen | HAS_THREAD_ASSIGNED_MASK)) {
                    // done
                    AglobeThreadPool.startInNewThread(myEntityRunner.entityThreadGroup,myEntityRunner,myThreadName);
                    return true;
                }
            } else {
                // add and test if is waiting
                if ((curStatus & WAITS_MASK) == 0) {
                    // not waiting only push event there
                    if (status.compareAndSet(curStatus, (curStatus & (FULL_32BIT ^ PLAN_SIZE_MASK)) | newPlanLen)) {
                        // done
                        return true;
                    }
                } else {
                    // waiting - push event, clear wait flag and notify
                    waitLock.lock();
                    try {
                        if (status.compareAndSet(curStatus, (curStatus & (FULL_32BIT ^ (PLAN_SIZE_MASK | WAITS_MASK))) | newPlanLen)) {
                            // done, wake up persistent thread
                            waitCondition.signal();
                            return true;
                        }
                    } finally {
                        waitLock.unlock();
                    }
                }
            }
            curStatus = status.get();
            if ((curStatus & IS_ACTIVE_MASK) == 0) {
                // entity is not active
                return true;
            }
        }
    }

    /**
     * @internal
     * Called by the Container to pass the entity an incoming message
     * @param m is a message (event respectively) that is added to plan.
     */
    @Override
    final public void incomingMessage(final Message m) {
        if (!insertIntoQueue(m)) {
            m.release();
        }
    }

    /**
     * Method used for adding an event to the end of entity dispatching queue.
     * @param e The event to execute in entity event dispatching thread
     */
    @Override
	public void addEvent(final Runnable e) {
        insertIntoQueue(e);
    }

    /**
     * Adds an event to the entity's event queue to be executed ONCE, after the
     * specified delay passes. This event will be executed in the entity's thread.
     *
     * @param event Runnable
     * @param delay long - real time delay in milliseconds
     * @return TimerTask - handler to the planned timer task, it can be used for cancellation of the task;
     * null can be returned if the entity is not active
     */
    @Override
	public final TimerTask scheduleEvent(final Runnable event, final long delay) {
        if ((status.get() & IS_ACTIVE_MASK) == 0) {
            return null;
        }
        final TimerTask tt = new TimerTask() {
            @Override
            public void run() {
                addEvent(event);
            }
        };
        try {
            getContainer().TIMER.schedule(tt, delay);
        } catch (Exception e) {
            // timer is already canceled
        }
        return tt;
    }

    /**
     * Adds an event to the entity's event queue to be executed REPEATEDLY,
     * beginning after the specified delay. This event will be executed in the
     * entity's thread.
     *
     * @param event Runnable
     * @param delay long - real time delay in milliseconds
     * @param period long - in milliseconds
     * @return TimerTask - handler to the planned timer task, which can be used for cancellation of the;
     * null can be returned if the entity is not active
     * task
     */
    @Override
	public TimerTask scheduleEvent(final Runnable event, final long delay, final long period) {
        if ((status.get() & IS_ACTIVE_MASK) == 0) {
            return null;
        }
        final TimerTask tt = new TimerTask() {
            @Override
            public void run() {
                addEvent(event);
            }
        };
        try {
            getContainer().TIMER.schedule(tt, delay, period);
        } catch (Exception e) {
            // already canceled
        }
        return tt;
    }

    /**
     * @internal
     *
     * @param mode
     */
    protected final void setTermination(final int mode) {
        if (state == INIT) {
            if (Thread.currentThread() != myThread.get()) {
                waitForProcessingAllEvents();
            }
        }
        for (;;) {
            final int curStatus = status.get();
            if ((curStatus & IS_ACTIVE_MASK) == 0) {
                // not active
                return;
            }
            if ((curStatus & HAS_THREAD_ASSIGNED_MASK) == 0) {
                // not thread assigned
                if (status.compareAndSet(curStatus, curStatus | mode | HAS_THREAD_ASSIGNED_MASK)) {
                    // assign thread
                    AglobeThreadPool.startInNewThread(myEntityRunner.entityThreadGroup,myEntityRunner,myThreadName);
                    return;
                }
            } else {
                if ((curStatus & WAITS_MASK) == 0) {
                    // no waiting, only set the stop bit
                    if (status.compareAndSet(curStatus, curStatus | mode)) {
                        // done
                        return;
                    }
                } else {
                    waitLock.lock();
                    try {
                        // clear wait flag and set stop flag
                        if (status.compareAndSet(curStatus, (curStatus & (FULL_32BIT ^ WAITS_MASK)) | mode)) {
                            // done
                            // wake receiver
                            waitCondition.signal();
                            return;
                        }
                    } finally {
                        waitLock.unlock();
                    }
                }
            }
        }

    }

    /**
     * Entity can use this method to terminate its execution. Entity will be automatically started when agent container
     * starts next time. <code>finish</code> method of the entity will be invoked before the termination.
     */
    public final void stop() {
        setTermination(STOP_MASK);
    }

    /**
     * Entity can use this method to terminate its execution. Entity will be also removed from auto run script. So
     * it will not be automatically started when agent container starts next time.
     * <code>finish</code> method of the entity will be invoked before the termination.
     */
    public final void kill() {
        setTermination(DIE_MASK);
    }

    /**
     * Set entity thread persistence. This method must be called from the entity thread
     *
     * @param persistent boolean - iff true, entity will not release thread in its idle state.
     * It is useful, when the entity will run with other priority than normal
     */
    final protected void setThreadPersistence(final boolean persistent) {
        // set persistence
        for (;;) {
            final int curStatus = status.get();
            if (persistent) {
                if (status.compareAndSet(curStatus, curStatus | USE_PERSISTENT_THREAD_MASK)) {
                    break;
                }
            } else {
                if (status.compareAndSet(curStatus, curStatus & (FULL_32BIT ^ USE_PERSISTENT_THREAD_MASK))) {
                    break;
                }
            }
        }
        AglobeThreadPool.adjustThreadMode(!persistent);
    }

    /**
     * Gets current entity's thread. If entity is in non-persistent thread mode
     * (default behavior), this method can return null in the case when entity
     * is in the waiting state for new event. This method is useful in the case
     * when the caller wants to change the priority of the running thread.
     *
     * @return Thread - current entity's thread, can returns null if there is no thread assigned now
     */
    final protected Thread getCurrentEntityThread() {
        return myThread.get();
    }

    /**
     * @internal
     * Returns the size of event queue (
     *
     * @return int
     */
    public int getEventSize() {
        return plan.size();
    }

    /**
     * Returns the current container of the entity.
     * @return Container
     */
    @Override
	final public AgentContainer getContainer() {
        return container;
    }

    /**
     * The method returns entity's name.
     * @return String
     */
    @Override
    final public String getName() {
        return name;
    }

    /**
     * Returns address of the entity.
     * @return Address
     */
    @Override
	public abstract Address getAddress();

    /**
     * @internal
     * The method returns entity's state.
     * @return int
     */
    final public int getState() {
        return state;
    }

    /**
     * @internal
     * Returns true iff entity is running.
     * @return boolean
     */
    final public boolean isRunning() {
        return state == RUNNING;
    }

    /**
     * Causes the calling thread to wait until all the events currently in the queue
     * are processed. All the events coming after this call will be processed
     * after this method returns.
     *
     * DO NOT CALL IT IN THE MAIN THREAD! It will cause a deadlock.
     */
    protected final void waitForProcessingAllEvents() {
        if ((status.get() & IS_ACTIVE_MASK) == 0) {
            // not active
            return;
        }
        if ((status.get() & (DIE_MASK | STOP_MASK | MIGRATION_MASK)) != 0) {
            // entity is just being stopped, died or migrated
            return;
        }
        waiterLock.lock();
        try {
            // initialize
            if (waiterRunner == null) {
                waiterRunner = new Runnable() {
                    @Override
                    public final void run() {
                        waiterLock.lock();
                        try {
                            waiterCond.signalAll();
                        } finally {
                            waiterLock.unlock();
                        }
                    }

                };
            }

            // wait until the event in the queue appears
            addEvent(waiterRunner);
            try {
                waiterCond.await();
            } catch (InterruptedException e) {
            }
        } finally {
            waiterLock.unlock();
        }
    }

    /**
     * The method is called by the entity when there is no task to execute. It should
     * be overridden by the entity in case it wants to perform some idle tasks.
     * If user wants to use the idle functionality he cannot call super.idle() from
     * the implemented idle() method otherwise the functionality will be disabled.
     */
    protected void idle() {
        // set to not to use idle functionality of entity
        for (;;) {
            final int curStatus = status.get();
            if ((curStatus & USE_IDLE_MASK) == 0) {
                return;
            }
            if (status.compareAndSet(curStatus, curStatus ^ USE_IDLE_MASK)) {
                // done
                return;
            }
        }
    }

    /**
     * @internal
     * This method is called by the container to show the entity's GUI. The default
     * method implementation tries to find a field <code>gui</code> in <code>this
     * </code> and to call its <code>setVisible()</code> method inherited from
     * <code>java.awt.Component</code>.
     */
    final public void showGUI() {
        try {
            if ((status.get() & IS_ACTIVE_MASK) == 0) {
                return;
            }
            final java.awt.Component reflectGUI;
            final Field gui = this.getClass().getField("gui");
            final Object o = gui.get(this);
            if ((o != null) && (o instanceof java.awt.Component)) {
                reflectGUI = (java.awt.Component) o;
                SwingUtilities.invokeLater(new Runnable() {
                    @Override
					public void run() {
                        if (reflectGUI != null) {
                            reflectGUI.setVisible(true);
                        }
                    }
                });
            }
        } catch (Exception ex) {
        }
    }

    /**
     * @internal
     * This method is called by the container to hide the entity's GUI. The default
     * method implementation tries to find a field <code>gui</code> in <code>this
     * </code> and to call its <code>setVisible()</code> method inherited from
     * <code>java.awt.Component</code>.
     */
    final public void hideGUI() {
        try {
            final java.awt.Component reflectGUI;
            final Field gui = this.getClass().getField("gui");
            final Object o = gui.get(this);
            if ((o != null) && (o instanceof java.awt.Component)) {
                reflectGUI = (java.awt.Component) o;
                SwingUtilities.invokeLater(new Runnable() {
                    @Override
					public void run() {
                        if (reflectGUI != null) {
                            reflectGUI.setVisible(false);
                        }
                    }
                });
            }
        } catch (Exception ex) {
        }
    }

    /**
     * @internal
     * This method is called by the container to destroy the entity's GUI before removing entity from the system.
     * The default method implementation tries to find a field <code>gui</code> in <code>this
     * </code> and to call its <code>dispose()</code> method inherited from
     * <code>java.awt.Window</code>.
     */
    final public void destroyGUI() {
      try {
        final java.awt.Window reflectGUI;
        final Field gui = this.getClass().getField("gui");
        final Object o = gui.get(this);
        if ((o != null) && (o instanceof java.awt.Window)) {
            reflectGUI = (java.awt.Window) o;
            SwingUtilities.invokeLater(new Runnable() {
                    @Override
					public void run() {
                        reflectGUI.dispose();
                    }
                });
        }
      } catch (Exception ex) {

      }
    }

    /**
     * The entity uses this method for communication with other agents and services.
     * Transmitter and receiver have to be on mutually visible containers. The
     * size of the successfully transmitted message can be retrieved by the subsequent
     * call of the getLastMessageSize method.
     *
     * @param m is a message to send
     * @throws InvisibleContainerException
     */
    @Override
	public final void sendMessage(final Message m) throws InvisibleContainerException {
        mt.sendMessage(m);
    }

    /**
     * The entity uses this method for communication with other agents and services within the
     * same platform. The message is passed as a reference. It is not duplicated. The
     * size of the successfully transmitted message can be retrieved by the subsequent
     * call of the getLastMessageSize method. If it is not possible to pass message as reference,
     * the object is transmitted as normal message, but on the destination JVM the instance of
     * the message can be shared by more receivers again.

     *
     * @param m is a message to send
     * @throws InvisibleContainerException
     */
    @Override
	public final void sendMessageAsReference(final Message m)  throws InvisibleContainerException {
        m.setAsReference();
        mt.sendMessage(m);
    }

    /**
     * This method is used by the entity for sending message with 'not understood'
     * content. The method does not allow to send 'not understood' message as
     * a reply to 'not understood' message.
     *
     * @param m is a message to send.
     * @param reason is a reason why entity didn't understand - can be null.
     */
    final protected void sendNotUnderstood(final Message m, final String reason) {
        // Never reply NOT_UNDERSTOOD to NOT_INDERSTOOD
        if (!m.getPerformative().equalsIgnoreCase(MessageConstants.NOT_UNDERSTOOD)) {
            Message re = m.getReply();
            re.setContent(m.getContent());
            re.setPerformative(MessageConstants.NOT_UNDERSTOOD);
            if (reason != null) {
                re.setReason(reason);
            }
            try {
                sendMessage(re);
            } catch (InvisibleContainerException ex) {
                // do nothing
            }
            re.release();
        }
    }

    /**
     * Send finest log message to the logger. Automatically append container and entity
     * name to the output log message
     *
     * @param message String - message
     */
    @Override
	final public void logFinest(final String message) {
        logFinest(message,1);
    }

    /**
     * Send fine log message to the logger. Automatically append container and entity
     * name to the output log message
     *
     * @param message String - message
     */
    @Override
	final public void logFine(final String message) {
        logFine(message,1);
    }

    /**
     * Send info log message to the logger. Automatically append container and entity
     * name to the output log message
     *
     * @param message String - message
     */
    @Override
	final public void logInfo(final String message) {
        logInfo(message,1);
    }

    /**
     * Send warning log message to the logger. Automatically append container and entity
     * name to the output log message
     *
     * @param message String - message
     */
    @Override
	final public void logWarning(final String message) {
        logWarning(message,1);
    }

    /**
     * Send severe log message to the logger. Automatically append container and entity
     * name to the output log message
     *
     * @param message String - message
     */
    @Override
	final public void logSevere(final String message) {
        logSevere(message,1);
    }

    @Override
	final public void logFinest(final String message, final Throwable e) {
        logFinest(message,e,1);
    }

    @Override
	final public void logFine(final String message, final Throwable e) {
        logFine(message,e,1);
    }

    @Override
	final public void logInfo(final String message, final Throwable e) {
        logInfo(message,e,1);
    }

    @Override
	final public void logWarning(final String message, final Throwable e) {
        logWarning(message,e,1);
    }

    @Override
	final public void logSevere(final String message, final Throwable e) {
        logSevere(message,e,1);
    }

    /**
     * Send finest log message to the logger. Automatically append container and entity name to the output log message
     *
     * @param message String - message
     * @param callsBack int
     */
    @Override
	final public void logFinest(final String message, final int callsBack) {
        aglobe.util.Logger.log(Level.FINEST,message,this,callsBack+1);
    }

    /**
     * Send fine log message to the logger. Automatically append container and entity name to the output log message
     *
     * @param message String - message
     * @param callsBack int
     */
    @Override
	final public void logFine(final String message, final int callsBack) {
        aglobe.util.Logger.log(Level.FINE,message,this,callsBack+1);
    }

    /**
     * Send info log message to the logger. Automatically append container and entity name to the output log message
     *
     * @param message String - message
     * @param callsBack int
     */
    @Override
	final public void logInfo(final String message, final int callsBack) {
        aglobe.util.Logger.log(Level.INFO,message,this,callsBack+1);
    }

    /**
     * Send warning log message to the logger. Automatically append container and entity name to the output log message
     *
     * @param message String - message
     * @param callsBack int
     */
    @Override
	final public void logWarning(final String message, final int callsBack) {
        aglobe.util.Logger.log(Level.WARNING,message,this,callsBack+1);
    }

    /**
     * Send severe log message to the logger. Automatically append container and entity name to the output log message
     *
     * @param message String - message
     * @param callsBack int
     */
    @Override
	final public void logSevere(final String message, final int callsBack) {
        aglobe.util.Logger.log(Level.SEVERE,message,this,callsBack+1);
    }

    @Override
	final public void logFinest(final String message, final Throwable e, final int callsBack) {
        logFinest(message + ExceptionPrinter.toStringWithCause(e),callsBack+1);
    }

    @Override
	final public void logFine(final String message, final Throwable e, final int callsBack) {
        logFine(message + ExceptionPrinter.toStringWithCause(e),callsBack+1);
    }

    @Override
	final public void logInfo(final String message, final Throwable e, final int callsBack) {
        logInfo(message + ExceptionPrinter.toStringWithCause(e),callsBack+1);
    }

    @Override
	final public void logWarning(final String message, final Throwable e, final int callsBack) {
        logWarning(message + ExceptionPrinter.toStringWithCause(e),callsBack+1);
    }

    @Override
	final public void logSevere(final String message, final Throwable e, final int callsBack) {
        logSevere(message + ExceptionPrinter.toStringWithCause(e),callsBack+1);
    }

    /**
     * Create log, the message for logging is generated using specified logProvider
     * only if log passed all filtration rules
     * @param level Level
     * @param logProvider LogProvider
     */
    @Override
	final public void log(final Level level, final LogProvider logProvider) {
        log(level, logProvider, 1);
    }

    /**
     * Create log, the message for logging is generated using specified logProvider
     * only if log passed all filtration rules
     * @param level Level
     * @param logProvider LogProvider
     * @param callsBack int
     */
    @Override
	final  public void log(final Level level, final LogProvider logProvider, final int callsBack) {
        aglobe.util.Logger.log(level, logProvider, this, callsBack);
    }

    /**
     * Check if specified level is loggable in the current context
     *
     * @param level Level
     * @return boolean
     */
    @Override
	public boolean isLoggable(final Level level) {
        return isLoggable(level,1);
    }

    /**
     * Check if specified level is loggable in the current context
     *
     * @param level Level
     * @param callsBack int
     * @return boolean
     */
    @Override
	public boolean isLoggable(final Level level, final int callsBack) {
        return aglobe.util.Logger.isLoggable(level, this, callsBack);
    }
}
