package aglobe.container;

/**
 * @internal
 * <p>Title: A-Globe</p>
 * <p>Description: Thrown by Store module. </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.10 $ $Date: 2009/05/15 08:46:58 $
 */
public final class StoreException extends Exception
{
    private static final long serialVersionUID = -4216290820666618305L;

    /**
     * Constructor of the exception
     */
    public StoreException() {
        super();
    }
}
