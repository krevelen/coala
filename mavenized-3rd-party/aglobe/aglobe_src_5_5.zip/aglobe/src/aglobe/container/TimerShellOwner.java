/**
 *
 */
package aglobe.container;

import aglobe.container.service.ShellOwner;

/**
 * <p>Title: A-Globe</p>
 *
 * <p>Description: Implementing entity can act as TimerOwner and ShellOwner as well</p>
 *
 * <p>Copyright: Copyright (c) 2009</p>
 *
 * <p>Company: Agent Technology Center</p>
 *
 * @author David Sislak
 * @version $Revision: 1.2 $ $Date: 2009/06/15 13:38:01 $
 *
 */
public interface TimerShellOwner extends TimerOwner, ShellOwner {

}
