package aglobe.container;

/**
 * @internal
 * <p>Title: A-Globe</p>
 *
 * <p>Description: Container owner interfaces denotes that implementor entity has
 * agent container link.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.6 $ $Date: 2009/06/15 13:38:01 $
 */
public interface ContainerOwner {

    /**
     * Provides the name of agent/service
     * @return
     */
    String getName();

    /**
     * Returns AgentContainer of the entity
     * @return AgentContainer
     */
    AgentContainer getContainer();
}
