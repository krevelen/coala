package aglobe.container.sharedobjects;

import java.util.HashMap;

/**
 * @internal
 * <p>Title: A-Globe</p>
 *
 * <p>Description: Container shared objects manager. Objects are stored under String key.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.5 $ $Date: 2009/05/15 08:46:59 $
 */
public class SharedObjectsManager {
    /**
     * Shared objects holder
     */
    private HashMap<String, Object> sharedObjects = new HashMap<String, Object>();

    /**
     * Constructor.
     */
    public SharedObjectsManager() {
    }

    /**
     * Store new object or replace old object in the shared objects manager
     * @param key String
     * @param object Object
     */
    synchronized public void putObject(String key, Object object) {
        sharedObjects.put(key, object);
    }

    /**
     * Fetch object from shared objects manager
     * @param key String
     * @return Object - null iff object for specified key doesn't exists
     */
    synchronized public Object getObject(String key) {
        return sharedObjects.get(key);
    }

    /**
     * Remove object from shared objects manager
     * @param key String
     */
    synchronized public void removeObject(String key) {
        sharedObjects.remove(key);
    }
}
