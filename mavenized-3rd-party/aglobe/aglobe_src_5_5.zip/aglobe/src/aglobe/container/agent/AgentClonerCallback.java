package aglobe.container.agent;

import aglobe.container.transport.Address;

/**
 * Callback used for notify agent about cloning request.
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.1 $ $Date: 2009/05/15 08:46:58 $
 */
public interface AgentClonerCallback {
    /**
     * Cloning was successfull
     * @param cloneAddress Address - address of the clone
     */
    void done(Address cloneAddress);

    /**
     * Cloning failed
     * @param cloneName String - requested name of the clone
     * @param destinationContainer Address - requested destination of the clone
     */
    void failed(String cloneName, Address destinationContainer);
}
