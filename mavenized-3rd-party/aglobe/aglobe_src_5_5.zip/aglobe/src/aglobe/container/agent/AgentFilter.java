package aglobe.container.agent;

import aglobe.ontology.*;

/**
 * @internal
 * Description: Internal class used by AgentManager.
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.15 $ $Date: 2009/05/15 08:46:58 $
 *
 */
public class AgentFilter
{
  String _name= null;
  String _readablename= null;
  String _type= null;
  String _mainclass= null;

  /**
   * Get name filter
   * @param name String
   * @return AgentFilter
   */
  public static AgentFilter getNameFilter(String name)
  {
    return new AgentFilter(name, null, null, null);
  }

  /**
   * Get class filter
   * @param classname String
   * @return AgentFilter
   */
  public static AgentFilter getClassFilter(String classname)
  {
    return new AgentFilter(null, null, null, classname);
  }

  /**
   * Constructor
   * @param name String
   * @param readname String
   * @param type String
   * @param main String
   */
  private AgentFilter(String name, String readname, String type, String main)
  {
    _name= name;
    _readablename= readname;
    _type= type;
    _mainclass= main;
  }

  /**
   * Equals?
   * @param other Object
   * @return boolean
   */
  @Override
public boolean equals(Object other)
  {
    return filter(other);
  }

  /**
   * Filter ?
   * @param other Object
   * @return boolean
   */
  public boolean filter(Object other)
  {
    if (other instanceof AgentFilter)
    {
      AgentFilter o= (AgentFilter)other;
      return _name.equals(o._name) && _readablename.equals(o._readablename)
                    && _type.equals(o._type) && _mainclass.equals(o._mainclass);
    }
    else if (other instanceof AgentInfo)
    {
      AgentInfo o= (AgentInfo)other;
      boolean match= true;
      if(_name!=null)
        match&= _name.equalsIgnoreCase(o.getName());
      if(_readablename!=null)
        match&= _readablename.equalsIgnoreCase(o.getReadableName());
      if(_type!=null)
        match&= _type.equalsIgnoreCase(o.getType());
      if(_mainclass!=null)
        match&= _mainclass.equalsIgnoreCase(o.getMainClass());
      return match;
    }
    else
      return false;
  }
}
