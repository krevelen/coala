package aglobe.container.agent;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;

import aglobe.container.AgentContainer;
import aglobe.container.ElementaryEntity;
import aglobe.container.Store;
import aglobe.container.service.ServiceShell;
import aglobe.container.sysservice.AgentMoverCallback;
import aglobe.container.transport.Address;
import aglobe.ontology.AgentInfo;


/**
 * Agent's main class.

 * This is a basic class for creating agents. Agents are derived from this
 * class and name of class should be entered into Load Agent Dialog. There is
 * also possible to enter jar archive that the agent needs.
 * <p> Each agent has a unique name and also a (readable) name for
 * human eye. An Agent can migrate between containers using serialization and TCP/IP.
 *  Travel history is archived. When platform shuts down, it stores all running
 *  agents and services to directory specified by parameter -store.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.105 $ $Date: 2010/08/04 11:48:06 $
 *
 */
public abstract class Agent extends ElementaryEntity implements
        Serializable {
    /**
     * This number has to be changed, when Agent's variables are changed
     */
    private static final long serialVersionUID = -7803140422777661595L;

    /**
     * @internal
     * State type of agent's initialization: an agent is created
     */
    public static final int isCREATED = 1;

    /**
     * @internal
     * State type of agent's initialization: an agent is restarted
     */
    public static final int isRESTARTED = 2;

    /**
     * @internal
     * State type of agent's initialization: an agent is moved from another container.
     */
    public static final int isMOVED = 3;

    /**
     * @internal
     * State type of agent's initialization: agent's movement was unsuccessful.
     */
    public static final int isMOVEFAILED = 4;

    /**
     * @internal
     * State type of agent's initialization: an agent is cloned from its mother agent.
     */
    public static final int isCLONED = 5;

    /**
     * Current agent address
     */
    private transient Address agentAddress = null;

    /**
     * Agent's destination address of migration/cloning.
     */
    private transient Address migrationDest = null;

    /**
     * Keeps the services which are migrating
     */
    private ArrayList<ServiceShell> migrationServices = new ArrayList<ServiceShell>();

    /* @internal
     * (non-Javadoc)
     * @see aglobe.container.ElementaryEntity#setContainer(aglobe.container.AgentContainer)
     */
    @Override
    public final void setContainer(final AgentContainer newContainer) throws Exception {
        super.setContainer(newContainer);

        for (ServiceShell elem : migrationServices) {
            elem.setContainer(container);
        }
    }

    /**
     * Initialization of the agent.
     *
     * @param a AgentInfo
     * @param initState int
     */
    public abstract void init(final AgentInfo a, final int initState);

    /* @internal
     * (non-Javadoc)
     * @see aglobe.container.ElementaryEntity#sysInit(java.lang.String)
     */
    @Override
    public final void sysInit(final String name) {
        super.sysInit(name);

        addEvent(new Runnable() {
            @Override
			public void run() {
                resetupServices();
            }
        });
    }

    /**
     * Re-setup services
     */
    private void resetupServices() {
        if (isActive()) {
            for (ServiceShell elem : migrationServices) {
                elem.postInit();
                ownedServiceShells.put(elem, elem);
            }
        }
        migrationServices.clear();
    }

    /* @internal
     * (non-Javadoc)
     * @see aglobe.container.ElementaryEntity#sysFinish()
     */
    @Override
    protected void sysFinish() {
        migrationServices.addAll(ownedServiceShells.values());

        super.sysFinish();
    }

    /**
     * This method starts the migration process.
     * @param dest is agent's destination container address.
     */
    protected final void migrate(final Address dest) {
        if (!isActive()) {
            return;
        }
        if (!dest.isContainerAddress()) {
            throw new IllegalArgumentException(
                    "Migrating to non-container address: " +
                    dest.toString());
        }
        if (dest.isSameContainer(getAddress())) {
            throw new IllegalArgumentException("Migrating to same container");
        }

        migrationDest = dest;

        setTermination(MIGRATION_MASK);
    }

    /**
     * This method starts the cloning process of an agent.
     *
     * @param newCloneName String - new name of an cloned agent. Name must be
     *   unique
     * @param destination Address - destination container address of its clone
     * @param cloneCallback AgentClonerCalleback - callback interface for notifying about result
     * @throws Exception - throws if there is come problem with cloning
     */
    protected void clone(final String newCloneName,
                               final Address destination,
                               final AgentClonerCallback cloneCallback) throws Exception {
        if (!isActive()) {
            return;
        }
        if (!destination.isContainerAddress()) {
            throw new IllegalArgumentException(
                    "Cloning to non-container address: " +
                    destination.toString());
        }
        if (destination.isSameContainer(getAddress())) {
            throw new IllegalArgumentException("Cloning to same container");
        }

        migrationDest = destination;
        final AgentMoverCallback callback = new AgentMoverCallback() {
            @Override
			public void agentMoveFinished(Result result, Agent agent) {
                if (result == AgentMoverCallback.DONE) {
                    cloneCallback.done(destination.deriveAgentAddress(newCloneName));
                } else {
                    cloneCallback.failed(newCloneName, destination);
                }
            }
        };

        state = CLONING;
        getContainer().getAgentManager().cloneAgent(this, newCloneName,
                                                    callback);
        state = RUNNING;

    }

    /**
     * @internal
     * Called after cloning/migrating by the <code>AgentManager</code>
     */
    final void moveFinished() {
        migrationDest = null;
    }

    /**
     * This method returns agent's address.
     * @return Address
     */
    @Override
    final public Address getAddress() {
        if (agentAddress != null) {
            return agentAddress;
        }
        if (name == null) {
            throw new RuntimeException("Agent is not initialized yet, there is no address.");
        }
        agentAddress = Address.getLocalAgentAddress(this, name);
        return agentAddress;
    }

    /**
     * Get agent store
     *
     * @return Store - agent store
     */
    @Override
	final public Store getStore() {
        return container.getAgentStore(name);
    }

    /**
     * @internal
     * This method returns a destination address of the migrating agent.
     *
     * @return Address
     */
    final public Address getMigrationDest() {
        return migrationDest;
    }

    /**
     * @internal
     * The method is used for serialization of the agent.
     * @param out ObjectOutputStream - output stream where object is written
     * @throws IOException - thrown if some problem with serialization of the agent
     */
    private void writeObject(final java.io.ObjectOutputStream out) throws IOException {
        out.defaultWriteObject();
    }

    /**
     * @internal
     * The method is used for de-serialization of the agent.
     * @param in ObjectInputStream - input stream from where object is read
     * @throws IOException - thrown if some problem with de-serialization of the agent
     * @throws ClassNotFoundException - thrown if some class of the agent is not found
     */
    private void readObject(final java.io.ObjectInputStream in) throws IOException,
            ClassNotFoundException {
        in.defaultReadObject();

        initializeTransient();
    }
}
