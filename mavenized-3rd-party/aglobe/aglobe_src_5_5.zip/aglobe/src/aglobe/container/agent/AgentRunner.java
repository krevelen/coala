package aglobe.container.agent;

import aglobe.container.EntityRunner;
import aglobe.util.ExceptionPrinter;


/**
 * @internal
 * Takes care about running agent in separate thread. It also catch all uncatched exception
 * by agent.
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.20 $ $Date: 2009/06/15 13:38:02 $
 */
public final class AgentRunner extends EntityRunner
{
    /**
     * @internal
     * @param e
     * @param tg
     */
    public AgentRunner(final Agent e, final ThreadGroup tg) {
        super(e, tg);
    }

    /* (non-Javadoc)
     * @see aglobe.container.EntityRunner#entityFinished()
     */
    @Override
    protected final void entityFinished() {
        try {
            entity.getContainer().getAgentManager().agentFinished((Agent)entity);
        } catch (Exception ex) {
            entity.logSevere("Exception from agentFinished: " + ExceptionPrinter.toStringWithStackTrace(ex));
        }
    }
}
