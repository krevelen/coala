package aglobe.container.agent;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Constructor;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Logger;

import javax.swing.SwingUtilities;

import aglobe.container.AgentContainer;
import aglobe.container.DuplicateNameException;
import aglobe.container.Store;
import aglobe.container.gui.ListListener;
import aglobe.container.gui.ListSource;
import aglobe.container.library.EntityClassLoader;
import aglobe.container.library.LibraryManager;
import aglobe.container.library.LibraryObjectInputStream;
import aglobe.container.library.LibraryRequesterCallback;
import aglobe.container.sysservice.AgentMoverCallback;
import aglobe.container.sysservice.AgentMoverService;
import aglobe.container.transport.Address;
import aglobe.ontology.AgentInfo;
import aglobe.ontology.AgentList;
import aglobe.ontology.AglobeParam;
import aglobe.ontology.Libraries;
import aglobe.platform.Platform;
import aglobe.platform.thread.AglobeThreadPool;
import aglobe.platform.transport.MessageReceiver;
import aglobe.platform.transport.MessageReceiverSplitter;
import aglobe.platform.transport.RecepientNotFound;
import aglobe.util.AglobeXMLtools;
import aglobe.util.ExceptionPrinter;

/**
 * This class manage agents in the container.
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.93 $ $Date: 2010/10/18 12:25:43 $
 *
 * <h3>Agent scenarios</h3>
 * <blockquote>
 * <b>Agent creation</b><br><blockquote>
 *    Someone fills in the agents AgentInfo and calls the createAgents.
 *    The method ensures, that all the agents needed libraries are present and
 *    registers the agent to use them with the <code>LibraryManager</code>
 *    [The Library Manager should take case of gathering the libraries] and
 *    starts the agent. Starting agent means creating its object (eventually
 *    loading the serialized, then calling agents <code>init</code> method and
 *    finally creating the <code>AgentRunner</code> which manages the agents
 *    execution.</blockquote>
 *
 * <b>Agent start</b><blockquote>
 *    Starting agent means creating its object (eventually
 *    loading the serialized), then calling agents <code>init</code> method and
 *    finally creating the <code>AgentRunner</code> which manages she agents
 *    execution.</blockquote>
 *
 * <b>Agent stop</b><blockquote>
 *    Calls the agent stop method. Adds the listener for agent actual finish
 *    (the <code>agentFinished</code> method). When the agent is finished, the
 *    binding with <code>agentmap</code> is deleted and the optional final code
 *    is called (supplied as method parameter of type runnable).
 *    </blockquote>
 *
 * <b>Agent delete</b><blockquote>
 *    Stops the agent, if running. Then removes its storage, deletes the agent
 *    from <code>autorun.xml</code> and deregister the agent from the <code>
 *    LibraryManager</code>.
 *    </blockquote>
 * </blockquote>
 */
public final class AgentManager implements ListSource, AgentMoverCallback, MessageReceiverSplitter {
    private static final String AUTORUN = "agents/autorun.xml";

    private static final String AGENTCNT = "agents/cnt";

    private static final ClassLoader systemClassLoader = Platform.class.getClassLoader(); 

    /**
     * @internal
     * Thread group name.
     */
    public static final String AGENTTHREAD = "Agents";

    /**
     * @internal
     * Main agent thread name
     */
    public static final String MAIN_AGENT_THREAD_NAME = "main agent thread";

    /**
     * Link to the Agent container
     */
    private final AgentContainer container;

    /**
     * Logger
     */
    private final Logger logger = Logger.getLogger("container.AgentManager");

    /**
     * Map of current running agents
     */
    private final ConcurrentHashMap<String,Agent> agentMap = new ConcurrentHashMap<String,Agent>();

    /**
     * Map of agents' thread group
     */
    private final ConcurrentHashMap<String,ThreadGroup> agentThreadGroupMap = new ConcurrentHashMap<String,ThreadGroup>();

    /**
     * Map of agents' information
     */
    private final ConcurrentHashMap<String,AgentInfo> agentInfoMap = new ConcurrentHashMap<String,AgentInfo>();

    /**
     * Map of agents which migrates to another container
     */
    private final ConcurrentHashMap<String,AgentInfo> agentInMigration = new ConcurrentHashMap<String, AgentInfo>();

    /**
     * true iff agent manager is in the shutdown cycle
     */
    private boolean managerShutDown = false;

    /**
     * Agent thread group
     */
    private ThreadGroup agentThreads = null;

    /**
     * @internal
     * Listener for watching changes in the list of agents.
     */
    ListListener listListener = null;

    /**
     * @internal
     * Service for agent migration.
     */
    AgentMoverService moverservice = null;

    /**
     * @internal
     * Waits for library?
     */
    boolean libraryWait = false;

    /**
     * @internal
     * Library loading failed?
     */
    boolean libraryFailed = false;

    private final ReentrantLock libraryLock = new ReentrantLock();
    private final Condition libraryCondition = libraryLock.newCondition();


    private final ReentrantLock finalizerLock = new ReentrantLock();
    private final Condition finalizerCondition = finalizerLock.newCondition();

    private AgentList agentsStartList = null;

    public AgentList getAgentsStartList() {
        return agentsStartList;
    }


    /**
     * @internal
     * This method is called by the AgentContainer after all services are loaded.
     *
     * @param agentList AgentList - starts requested agents or start agents
     *   from store iff null
     * @param noMigration boolean
     * @param librarySourceContainer Address - library source container for the service list, can be null
     */
    public void afterContainerInit(final AgentList agentList,
                                   final boolean noMigration, final Address librarySourceContainer, final boolean useUniqueNames) {
        initAgents(agentList,librarySourceContainer,useUniqueNames);
        try {
            if (!noMigration) {
                moverservice = new AgentMoverService();
                container.getServiceManager().startService(AgentMoverService.SERVICENAME, moverservice);
            }
        } catch (DuplicateNameException ex) {
            logger.severe("Cannot start AgentMoverService: " + ex);
        }
    }

    /**
     * @internal
     * The method stops the agent manager.
     * @param timeout means maximal time in mills for removing agents.
     */
    public void stopAgentManager(final int timeout) {
        managerShutDown = true;
        for (Agent elem : agentMap.values()) {
            elem.stop();
        }

        int curRunning = agentMap.size();
        int lastRunning = -1;

        finalizerLock.lock();
        try {
            while ((curRunning > 0) && (curRunning != lastRunning)) {
                lastRunning = curRunning;
                try {
                    finalizerCondition.await(timeout, TimeUnit.MILLISECONDS);
                } catch (InterruptedException ex1) {
                }
                curRunning = agentMap.size();
            }
            if (curRunning > 0) {
                logger.warning("Finished before finish of all agents");
            }
        } finally {
            finalizerLock.unlock();
        }
    }

    /**
     * @internal
     * Constructor
     * @param owner AgentContainer - agent container instance which create AgentManager
     */
    public AgentManager(final AgentContainer owner) {
        container = owner;
        agentThreads = new ThreadGroup(container.getContainerThreadGroup(),
                                       AGENTTHREAD);
    }

    /**
     * Initialize agents
     * @param startAgents AgentList
     * @param librarySourceContainer Address
     */
    synchronized private void initAgents(final AgentList startAgents, final Address librarySourceContainer, final boolean useUniqueNames) {
        Store s = container.getGlobalStore();

        try {
            boolean checkLibrary = false;
            boolean saveChanges = false;
            if (startAgents == null) {
                if (s.exist(AUTORUN)) {
                    agentsStartList = (AgentList) s.getXML(AUTORUN, AgentList.class);
                } else {
                    agentsStartList = new AgentList();
                }
            } else {
                checkLibrary = true;
                agentsStartList = startAgents;
            }

            final LibraryManager lm = container.getLibraryManager();
            libraryFailed = false;

            for (AgentInfo elem : agentsStartList.getAgentInfo()) {
                if (useUniqueNames) {
                    elem.setName(elem.getReadableName().replace(' ', '_') + "-" +
                               createUniqueAgentName());
                }

                if (agentMap.containsKey(elem.getName())) {
                    throw new DuplicateNameException(elem.getName());
                }

                if (checkLibrary) {
                    // check if libraries already are present
                    if (elem.getLibraries().getLibrary().size() > 0) {
                        if (librarySourceContainer == null) {
                            logger.severe("Libary source container is not specified.");
                            throw new Exception("Library source container is not specified.");
                        }
                        for (String elem2 : elem.getLibraries().getLibrary()) {
                            libraryLock.lock();
                            try {
                                libraryWait = true;

                                lm.obtainLibrary(container, librarySourceContainer,
                                                 elem2, new LibraryRequesterCallback() {
                                    @Override
									public void libraryRequestFinished(Result
                                            result) {
                                        libraryLock.lock();
                                        try {
                                            if (result ==
                                                LibraryRequesterCallback.FAILED) {
                                                libraryFailed = true;
                                            }
                                            libraryWait = false;
                                            libraryCondition.signal();
                                        } finally {
                                            libraryLock.unlock();
                                        }
                                    }
                                });

                                while (libraryWait) {
                                    try {
                                        libraryCondition.await();
                                    } catch (InterruptedException ex1) {
                                    }
                                    if (libraryFailed) {
                                        logger.severe("Library: " + elem2 + " for "+ elem + " cannot be loaded from: " + librarySourceContainer);
                                        throw new Exception("Library: " + elem2 + " for "+ elem + " cannot be loaded from: " + librarySourceContainer);
                                    }
                                }
                            } finally {
                                libraryLock.unlock();
                            }
                        }
                    }
                }
                // all libraries are loaded
                try {
                    startAgent(elem, Agent.isRESTARTED);
                } catch (Exception ex1) {
                    saveChanges = true;
                    logger.severe("Cannot restart the agent: " +
                                  elem.getName() + " (" + ex1 +
                                  ")\nThe agent has been removed from autostart configuration.");
                }
            }

            if (saveChanges) {
                // store new auto start configuration
                final AgentList al = new AgentList();
                al.getAgentInfo().addAll(agentInfoMap.values());
                s.putXML(AUTORUN, al);
            }
            // fire agent list changes
            fireAgentListChanged();
        } catch (Exception ex) {
            ex.printStackTrace();
            logger.severe("Cannot start the default agents on container " +
                          container.getContainerName() + "! " + ex);
        }
    }

    /**
     * Start new agent
     * @param ai AgentInfo
     * @param requestedInitState int
     * @throws ClassNotFoundException
     * @throws DuplicateNameException
     * @throws Exception
     */
    private void startAgent(final AgentInfo ai, final int requestedInitState) throws
            ClassNotFoundException, DuplicateNameException, Exception {
        final int initState;

        final LibraryManager lm = container.getLibraryManager();
        if (agentMap.containsKey(ai.getName())) {
            throw new DuplicateNameException(ai.getName());
        }
        try {
            final Agent agent;

            // test if there are all necessary libraries to run the agent
            final List<String> libs = ai.getLibraries().getLibrary();
            EntityClassLoader classLoader = null;
            if (libs.size() != 0) {
                classLoader = EntityClassLoader.getInstance(lm, libs.toArray(new String[libs.size()]));
            }

            if (ai.getSerialized() == null) {
                // Create the new agent
                final Class<?> cl = (classLoader != null) ? classLoader.loadClass(ai.getMainClass()) : systemClassLoader.loadClass(ai.getMainClass());
                final Constructor<?> con = cl.getConstructor(new Class[] {});
                agent = (Agent) con.newInstance(new Object[] {});
                initState = requestedInitState;
            } else {
                // load the agent from the stream
                final ObjectInputStream in = new LibraryObjectInputStream(new ByteArrayInputStream(ai.getSerialized()), classLoader, null);
                agent = (Agent) in.readObject();
                ai.setSerialized(null);
                if (agent.getState() == Agent.CLONING) {
                    initState = Agent.isCLONED;
                } else {
                    initState = Agent.isMOVED;
                }
                // call move finished
                agent.moveFinished();
            }
            // set agent's class loader
            agent.setClassLoader(classLoader, ai.getName(), true);

            // set agent container
            agent.setContainer(container);
            // schedule call the initialization method
            agent.addEvent(new Runnable() {
                @Override
				public void run() {
                    agent.sysInit(ai.getName());
                    agent.init(ai, initState);
                    agent.sysPostInit();
                }
            });
            // put agent into agent maps
            agentMap.put(ai.getName(), agent);
            agentInfoMap.put(ai.getName(),ai);
            // create new agent thread group
            final ThreadGroup atg = new ThreadGroup(agentThreads, ai.getName());
            agentThreadGroupMap.put(ai.getName(), atg);

            // remove the agent from the migration pool as the agent already migrated back to its
            //   previous location
            agentInMigration.remove(ai.getName());

            // start agent thread
            AglobeThreadPool.startInNewThread(atg, new AgentRunner(agent, atg),
                                              container.getContainerName() + ": " + ai.getName() +
                                              ": " + AgentManager.MAIN_AGENT_THREAD_NAME);
        } catch (Exception ex) {
            logger.severe("Error loading agent:\n" + ExceptionPrinter.toStringWithStackTrace(ex));
            deleteAgent(ai.getName(), true);
            throw ex;
        }
    }

    /**
     * @internal
     * Called by the <code>Agent</code> when it want to be cloned somewhere
     *
     * @param agent Agent - an agent to clone
     * @param newName String - new clone agent name
     * @param callback AgentMoverCallback - callback interface where result of
     *   the cloning should be returned
     */
    void cloneAgent(final Agent agent, final String newName,
                    final AgentMoverCallback callback) {
        if (agent.getMigrationDest().isSameContainer(Address.
                getLocalContainerAddress(container))) {
            callback.agentMoveFinished(AgentMoverCallback.FAILED, agent);
        }
        try {
            final AgentInfo ai = getAgentInfo(agent.getName());
            ai.setName(newName);
            ai.setReadableName(newName);

            // Encode serialized agent
            final ByteArrayOutputStream bout = new ByteArrayOutputStream();
            final ObjectOutputStream oout = new ObjectOutputStream(bout);
            oout.writeObject(agent);
            oout.close();
            ai.setSerialized(bout.toByteArray());
            
            bout.reset();

            // Encode its store
            final Store s = container.getAgentStore(agent.getName());
            if (s.zip(bout)) {
            	ai.setData(bout.toByteArray());
            }
            
            if (ai.getTravelHistory().size() > 0) {
                AgentInfo.TravelHistory t = ai.getTravelHistory().get(ai.
                        getTravelHistory().size() - 1);
                t.setStop(System.currentTimeMillis());
            }

            moverservice.moveAgent(agent, ai, callback, agent);
        } catch (IOException ex) {
            callback.agentMoveFinished(AgentMoverCallback.FAILED, agent);
        }
    }

    /**
     * @internal
     * Called by the <code>AgentRunner</code> when the Agent's <code>run</code>
     * method returns.
     *
     * @param agent The finished agent.
     */
    void agentFinished(final Agent agent) {
        switch (agent.getState()) {
        case Agent.RUNNING:
            logger.warning(container.getContainerName() +
                           ": A running agent has finished!");
            break;
        case Agent.EXCEPTION:
            logger.severe(container.getContainerName() + ": Agent " +
                          agent.getName() +
                          " has been removed because it throws an exception !");
            deleteAgent(agent.getName(), false);
            break;
        case Agent.DONE:
            deleteAgent(agent.getName(), false);
            break;
        case Agent.DEAD:
            deleteAgent(agent.getName(), true);
            break;

        case Agent.MIGRATING:
            // migrate the agent
            try {
                final AgentInfo originalAi = agentInfoMap.get(agent.getName());
                if (originalAi == null) {
                    throw new Exception("Trying to migrate agent without agent info");
                }
                // remove agent registrations
                deleteAgent(originalAi.getName(),true);
                // remember as agent in migration
                agentInMigration.put(originalAi.getName(), originalAi);

                // deregister from the thread group
                agentThreadGroupMap.remove(agent.getName());
                if (agent.getMigrationDest().isSameContainer(Address.
                        getLocalContainerAddress(container))) {
                    throw new Exception(
                            "Cannot migrate to the current container");
                }

                // Clone the AgentInfo, so that the original is not modified
                final AgentInfo ai = (AgentInfo) AglobeXMLtools.cloneSerializable(originalAi);

                // Encode serialized agent
                final ByteArrayOutputStream bout = new ByteArrayOutputStream();
                final ObjectOutputStream oout = new ObjectOutputStream(bout);
                oout.writeObject(agent);
                oout.close();
                ai.setSerialized(bout.toByteArray());
                
                bout.reset();

                // Encode its store
                final Store s = container.getAgentStore(agent.getName());
                if (s.zip(bout)) {
                	ai.setData(bout.toByteArray());
                }
                
                // set the travel history end
                int i = ai.getTravelHistory().size();
                if (i > 0) {
                    AgentInfo.TravelHistory t = ai.getTravelHistory().get(
                            i - 1);
                    t.setStop(System.currentTimeMillis());
                }
                // start agent migration
                moverservice.moveAgent(agent, ai, this, null);
            } catch (Exception ex) {
                logger.severe(container.getContainerName() +
                              ": Exception migrating Agent" + ExceptionPrinter.toStringWithStackTrace(ex));
                // Start the agent again, because there was some exception
                restartAfterFailure(agent);
            }
            break;
        default:
            throw new RuntimeException("Bad agent state");
        }
        fireAgentListChanged();
    }

    /**
     * Restart agent after migration failure
     *
     * @param agent
     */
    private void restartAfterFailure(final Agent agent) {
        final AgentInfo ai = agentInMigration.get(agent.getName());
        if (ai == null) {
            throw new RuntimeException("FATAL: AgentInfo not found!");
        }
        try {
            agent.setContainer(container);
            agent.addEvent(new Runnable() {
                @Override
				public void run() {
                    agent.sysInit(ai.getName());
                    agent.init(ai, Agent.isMOVEFAILED);
                    agent.sysPostInit();
                }
            });
            agentMap.put(ai.getName(), agent);
            agentInfoMap.put(ai.getName(), ai);

            // store agent info list to the store
            saveAutorun();

            // create new agent thread group
            final ThreadGroup atg = new ThreadGroup(agentThreads, ai.getName());
            agentThreadGroupMap.put(ai.getName(), atg);

            // start agent thread
            AglobeThreadPool.startInNewThread(atg,
                  new AgentRunner(agent, atg),
                  container.getContainerName() + ": " + ai.getName() +
                  ": " + AgentManager.MAIN_AGENT_THREAD_NAME);

            // send update of the agent list
            fireAgentListChanged();
        } catch (Exception ex1) {
            logger.severe(container.getContainerName() +
                          ": Cannot start agent " + ai.getName() + "\n" +
                          ExceptionPrinter.toStringWithStackTrace(ex1));
        }
    }

    /**
     * Creates the agent, that has not run before.
     *
     * @param readableName String - readable name of the agent
     * @param mainClass String - main class of the agent
     * @param params List - parameters passed to the agent
     * @throws DuplicateNameException - thrown when agent with same name already
     *   exists
     * @throws Exception - other exception, e.g. when agent is started
     */
    public void createAgent(final String readableName, final String mainClass, final List<AglobeParam> params) throws
            DuplicateNameException, Exception {
        final AgentInfo ai = new AgentInfo();
        // set readable name
        ai.setReadableName(readableName);
        // set main class
        ai.setMainClass(mainClass);
        // copy starting parameters
        for (Iterator<AglobeParam> iter = params.iterator(); iter.hasNext(); ) {
            final AglobeParam item = iter.next();
            ai.getAglobeParam().add(item);
        }
        // no special library
        ai.setLibraries(new Libraries());
        // start new agent
        createAgent(ai);
    }

    /**
     * Creates the agent, that has not run before. Agent will not be saved into the
     * <code>autorun.xml</code> file.
     *
     * @param agentInfo AgentInfo - the <code>AgentInfo</code> to start with.
     * @throws DuplicateNameException - thrown when agent with same name already
     *   exists
     * @throws Exception - other exception, e.g. when agent is started
     */
    public void createAgent(final AgentInfo ai) throws DuplicateNameException,
            Exception {
        // Assign the name
        if (ai.getName() == null) {
            ai.setName(ai.getReadableName());
        }
        // test if agent with same name already exists
        if (agentMap.containsKey(ai.getName())) {
            throw new DuplicateNameException(ai.getName());
        }

        // Make an entry in agents Travel History
        final AgentInfo.TravelHistory t = new AgentInfo.TravelHistory();
        t.setContainer(Address.getLocalContainerAddress(container).toString());
        t.setStart(System.currentTimeMillis());
        t.setStop(0L);
        ai.getTravelHistory().add(t);

        startAgent(ai, Agent.isCREATED);

        fireAgentListChanged(); // send update of the agent list
    }

    /**
     * Creates the agent, that has not run before. Saves the agent's store (if
     * one exists), assigns the agent a unique name and inserts the agent into
     * the <code>autorun.xml</code> file.
     *
     * @param agentInfo AgentInfo - the <code>AgentInfo</code> to start with.
     * @param cloneAgentInfo boolean - if true, ai is internally cloned first
     * @throws DuplicateNameException - thrown when agent with same name
     *   already exists
     * @throws Exception - other exception, e.g. when agent is started
     */
    public void createAgent(final AgentInfo agentInfo, final boolean cloneAgentInfo) throws DuplicateNameException,
            Exception {
        AgentInfo ai;
        // Create a copy of AgentInfo
        if (cloneAgentInfo) {
            ai = (AgentInfo) AglobeXMLtools.cloneSerializable(agentInfo);
        } else {
            ai = agentInfo;
        }
        // Assign the name
        if (ai.getName() == null) {
            ai.setName(ai.getReadableName().replace(' ', '_') + "-" +
                       createUniqueAgentName());
        }
        // test if agent with same name already exists
        if (agentMap.containsKey(ai.getName())) {
            throw new DuplicateNameException(ai.getName());
        }

        // Check for any data & store them
        if (ai.getData() != null) {
            Store s = container.getAgentStore(ai.getName());
            s.unZip(new ByteArrayInputStream(ai.getData()));
            ai.setData(null); // clear the data, for faster further ai handling
        }

        // Make an entry in agents Travel History
        final AgentInfo.TravelHistory t = new AgentInfo.TravelHistory();
        t.setContainer(Address.getLocalContainerAddress(container).toString());
        t.setStart(System.currentTimeMillis());
        t.setStop(0L);
        ai.getTravelHistory().add(t);

        startAgent(ai, Agent.isCREATED);

        saveAutorun(); // store agent info list to the store
        fireAgentListChanged(); // send update of the agent list
    }

    /**
     * Returns instance of the agent.
     * @param agentName String - name of the agent.
     * @return Agent - instance of the requested agent
     */
    public Agent getAgentInstance(final String agentName) {
        return agentMap.get(agentName);
    }

    /**
     * @internal
     * Returns thread group of the agent.
     * @param agentName String - name of the agent.
     * @return ThreadGroup - the requested thread group
     */
    public ThreadGroup getAgentThreadGroup(final String agentName) {
        return agentThreadGroupMap.get(agentName);
    }

    /**
     * Returns list of running agents.
     * @return List - list contains AgentInfo objects
     */
    public List<AgentInfo> getRunningAgents() {
        final TreeSet<AgentInfo> sorted = new TreeSet<AgentInfo>(new Comparator<AgentInfo>() {
            @Override
			public int compare(final AgentInfo o1, final AgentInfo o2) {
                return o1.getName().compareTo(o2.getName());
            }
        });

        sorted.addAll(agentInfoMap.values());
        return new ArrayList<AgentInfo>(sorted);
    }

    /**
     * Stops the agent and then permanently removes it from the structures.
     * @param agentname String - agent name
     */
    public void killAgent(final String agentname) {
        final Agent a = agentMap.get(agentname);
        if (a != null) {
            a.kill();
        }
    }

    /**
     * @internal
     * Invoke agents <code>showGUI</code> method in the AWT Event handling thread.
     * @param agentname String - agent name
     */
    public void showAgent(final String agentname) {
        final Agent a = agentMap.get(agentname);
        if (a != null) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
				public void run() {
                    a.showGUI();
                }
            });
        }
    }

    /**
     * @internal
     * Invoke agents <code>GUI</code> method in the AWT Event handling thread.
     * @param agentname String - agent name
     */
    public void hideAgent(final String agentname) {
        final Agent a = agentMap.get(agentname);
        if (a != null) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
				public void run() {
                    a.hideGUI();
                }
            });
        }
    }

    /**
     * Removes completely the agent from container.
     *
     * @param agentname The agent to remove.
     * @param die boolean - true iff agent should not start again after container restart
     */
    synchronized private void deleteAgent(final String agentname, final boolean die) {
        // Remove from the map
        agentThreadGroupMap.remove(agentname);
        final Agent a = agentMap.remove(agentname);
        if (a != null) {
            // deregister class owner
            a.setClassLoader(null, null, true);
        }
        if (managerShutDown) {
            finalizerLock.lock();
            try {
                finalizerCondition.signal();
            } finally {
                finalizerLock.unlock();
            }
        }

        if (die) {
            // Remove from the auto-run
            agentInfoMap.remove(agentname);
            saveAutorun();
        }

        fireAgentListChanged();

    }

    /**
     * Returns <code>AgentInfo</code> of the agent.
     * @param aname String name of the agent.
     * @return AgentInfo requested agent info
     */
    public AgentInfo getAgentInfo(final String aname) {
        final AgentInfo iai = agentInfoMap.get(aname);
        if (iai == null) {
            return null;
        }
        return (AgentInfo) AglobeXMLtools.cloneSerializable(iai);
    }

    /**
     * @internal
     * Get message receiver
     *
     * @param receiver Address - agent address
     * @return MessageReceiver
     * @throws RecepientNotFound
     */
    @Override
	public MessageReceiver getMessageReceiver(final Address receiver) throws RecepientNotFound {
        if (!receiver.isAgent()) {
            throw new RecepientNotFound();
        }
        final Agent agent = agentMap.get(receiver.getName());
        if (agent == null) {
            throw new RecepientNotFound();
        }
        return agent;
    }

    /**
     * Test if there is already agent with this name running.
     * @param name String - name of the agent
     * @return boolean - returns <code>true</code> iff there is an agent with specified name.
     */
    public boolean existsAgent(final String name) {
        return agentMap.containsKey(name);
    }

    /**
     * Create new unique agent name
     * @return String
     */
    private String createUniqueAgentName() {
        Store s = container.getGlobalStore();
        int i = s.getInt(AGENTCNT, 0);
        NumberFormat format = new DecimalFormat("000");
        s.putInt(AGENTCNT, (i + 1) % 1000);
        return container.getContainerName() + format.format(i) + "." +
                System.currentTimeMillis();
    }

    /**
     * @internal
     * The method adds ListListener to the <code>AgentManager</code>.
     * @param ll <code>ListListener</code>
     */
    @Override
	public void addListListener(final ListListener ll) {
        if (listListener != null)
            throw new UnsupportedOperationException("Just a single ListListener supported with AgentManager.");

        listListener = ll;
        fireAgentListChanged();
    }

    /**
     * Fire agent list changes
     */
    private void fireAgentListChanged() {
        if (listListener != null) {
            final Set<String> agentmap = agentMap.keySet();
            listListener.ListChanged(ListListener.ListType.AGENTS, agentmap);
        }
    }

    /**
     * @internal
     * This method handles agent after migration.
     * @param result result of migration
     * @param agent migrated agent
     */
    @Override
	public void agentMoveFinished(final Result result, final Agent agent) {
        if (result == AgentMoverCallback.DONE) { // Moved successfully - delete agent
            agentInMigration.remove(agent.getName());
        } else {
            // Move failed - start the agent again
            restartAfterFailure(agent);
        }
    }

    private void saveAutorun() {
        final Store s = container.getGlobalStore();
        final AgentList al = new AgentList();
        for (AgentInfo ai : agentInfoMap.values()) {
            // save the agent only if it should be restarted next time
            if (ai.isAutoRun())
                al.getAgentInfo().add(ai);
        }
        s.putXML(AUTORUN, al);
    }
}
