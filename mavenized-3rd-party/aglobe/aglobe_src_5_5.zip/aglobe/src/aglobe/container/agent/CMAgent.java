package aglobe.container.agent;

import aglobe.container.task.*;
import aglobe.ontology.*;

/**
 * This is a child class of the agent. It implements conversation manager that
 * creates IDs of messages. A task gets only messages that reply on its
 * messages.
 *
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.22 $ $Date: 2010/08/04 11:48:06 $
 */
public abstract class CMAgent extends Agent implements ConversationUnit {

    private static final long serialVersionUID = 2046926401545194702L;

    /**
     * It is the conversation manager of the agent.
     */
    private transient ConversationManager cm;

    /**
     * @internal
     * This final method guarantees that incoming messages are sent into the
     * conversation manager.
     * @param m is incoming message.
     */
    @Override
	final public void handleIncomingMessage(final Message m) {
        if (cm == null) {
            cm = new ConversationManager(this);
        }
        cm.handleIncomingMessage(m);
    }

    /**
     * @internal
     * Sets a task for handling all unsorted messages to any registered task.
     * @param t is an idle task.
     */
    final protected void setIdleTask(final Task t) {
        if (cm == null) {
            cm = new ConversationManager(this);
        }
        cm.setIdleTask(t);
    }

    /**
     * @internal
     * This method returns the conversation manager of the agent.
     * @return ConversationManager
     */
    @Override
	final public ConversationManager getConversationUnit() {
        if (cm == null) {
            cm = new ConversationManager(this);
        }
        return cm;
    }

    /**
     * @internal
     * This method performs services cleanup.
     */
    @Override
    protected final void sysFinish() {
        // remove all tasks
        if (cm != null) {
            cm.sysFinish();
            cm = null;
        }
        super.sysFinish();
    }

}
