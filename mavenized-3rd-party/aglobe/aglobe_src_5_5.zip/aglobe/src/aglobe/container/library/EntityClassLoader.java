package aglobe.container.library;

import java.net.*;
import java.util.HashMap;
import java.util.Set;
import java.util.HashSet;
import java.util.ArrayList;
import java.io.File;
import java.util.Arrays;

import aglobe.ontology.LibInfo;
import aglobe.platform.transport.MessageReceiver;

/**
 * Agent/Service class loader.
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.14 $ $Date: 2009/06/15 13:38:01 $
 */
public class EntityClassLoader
    extends URLClassLoader {

    /**
     * Existing class loaders
     */
    private final static HashMap<EntityClassLoader.EntityClassLoaderDescriptor,EntityClassLoader> classLoaders = new HashMap<EntityClassLoader.EntityClassLoaderDescriptor, EntityClassLoader> ();

    /**
     * Class loader descriptor
     */
    public final EntityClassLoaderDescriptor classLoaderDescriptor;

    /**
     * Set of class loader users
     */
    private final Set<MessageReceiver> classUsers = new HashSet<MessageReceiver> ();

    /**
     * Owner library manager
     */
    private final LibraryManager libraryManger;

    /**
     * Gets instance of entity class loader
     * @param owner LibraryManager - Library Manager owner
     * @param libs String[] - array of the libraries which should this class loader use
     * @return EntityClassLoader - defined class loader
     * @throws LibraryException - throws if there is some exception during starting new class loader, e.g. library not found exception
     */
    public static EntityClassLoader getInstance(final LibraryManager owner, final String[] libs) throws LibraryException {
        EntityClassLoader loader;
        // first find if loader already exists
        final EntityClassLoaderDescriptor classLoaderDescriptor = new EntityClassLoaderDescriptor(libs);
        synchronized (classLoaders) {
            loader = classLoaders.get(classLoaderDescriptor);
            if (loader != null) {
                // if it exists return existing one
                return loader;
            }
        }
        // try to create new class loader
        File f;
        // test if all requested libraries exists
        final ArrayList<URL> tmplibs = new ArrayList<URL> (libs.length);
        for (int i = 0; i < libs.length; i++) {
            f = new File(owner._store.getAbsolutePath(libs[i]));
            if (f.exists()) {
                try {
                    tmplibs.add(f.toURI().toURL());
                }
                catch (MalformedURLException ex) {
                }
            }
            else {
                throw new LibraryException("Library not found: " + libs[i]);
            }
        }
        final URL[] urls = tmplibs.toArray(new URL[tmplibs.size()]);
        // create new class loader
        loader = new EntityClassLoader(owner, urls, classLoaderDescriptor);
        // returns the loader
        return loader;
    }

    /**
     * Constructor
     * @param owner LibraryManager - owner Library Manager
     * @param urls URL[] - requested libraries in array of URLs
     * @param classLoaderDescriptor EntityClassLoaderDescriptor - class loader descriptor
     */
    private EntityClassLoader(final LibraryManager owner, final URL[] urls, final EntityClassLoaderDescriptor classLoaderDescriptor) {
        super(urls);
        this.libraryManger = owner;
        this.classLoaderDescriptor = classLoaderDescriptor;
    }

    /**
     * Add class loader user
     * @param owner ClassLoaderOwner
     */
    synchronized public void addClassLoaderOwner(final MessageReceiver owner, final LibInfo.LibUser libraryUser) {
        if (classUsers.size() == 0) {
            synchronized (classLoaders) {
                // register it in the Library Manager
                classLoaders.put(classLoaderDescriptor, this);
            }
        }
        classUsers.add(owner);
        libraryManger.register(libraryUser, classLoaderDescriptor.libs);
    }

    /**
     * Remove class loader user
     * @param owner ClassLoaderOwner
     * @return boolean - true iff there isn't any other user of this class loader.
     * It means, that this class loader can be destroyed
     */
    synchronized public void removeClassLoaderOwner(final MessageReceiver owner, final LibInfo.LibUser libraryUser) {
        libraryManger.deregister(libraryUser, classLoaderDescriptor.libs);
        classUsers.remove(owner);
        if (classUsers.isEmpty()) {
            // the last user removed, thus remove also class loader itself
            synchronized (classLoaders) {
                classLoaders.remove(classLoaderDescriptor);
            }
        }
    }

    /**
     *
     * <p>Title: A-Globe</p>
     * <p>Description: Inner class of A-globe. Class loader descriptor. It is used for describing class laoder.</p>
     * <p>Copyright: Copyright (c) 2004</p>
     * <p>Company: Gerstner Laboratory</p>
     *
     * @author David Sislak
     * @version $Revision: 1.14 $ $Date: 2009/06/15 13:38:01 $
     */
    private static class EntityClassLoaderDescriptor {
        /**
         * Libraries which class loader uses
         */
        private final String[] libs;

        /**
         *
         * @param libs String[] - libraries which class loader uses
         */
        private EntityClassLoaderDescriptor(final String[] libs) {
            this.libs = libs;
        }

        /**
         * Indicates whether some other object is "equal to" this one.
         *
         * @param obj the reference object with which to compare.
         * @return <code>true</code> if this object is the same as the obj
         *   argument; <code>false</code> otherwise.
         */
        @Override
        public boolean equals(final Object obj) {
            if (! (obj instanceof EntityClassLoaderDescriptor)) {
                return false;
            }
            EntityClassLoaderDescriptor cmp = (EntityClassLoaderDescriptor) obj;
            if (this == obj) {
                return true;
            }
            if (libs.length != cmp.libs.length) {
                return false;
            }
            Set<String> test = new HashSet<String> (Arrays.asList(cmp.libs));
            for (int i = 0; i < libs.length; i++) {
                if (!test.contains(libs[i])) {
                    return false;
                }
            }
            return true;
        }

        @Override
        public int hashCode() {
            int result = 0;
            for (int i = 0; i < libs.length; i++) {
                result += libs[i].hashCode();
            }
            return result;
        }
    }
}
