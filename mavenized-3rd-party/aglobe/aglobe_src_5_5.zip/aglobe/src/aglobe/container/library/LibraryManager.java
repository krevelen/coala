package aglobe.container.library;

import java.io.*;
import java.nio.channels.*;
import java.text.*;
import java.util.Map;
import java.util.logging.*;
import java.util.regex.*;

import aglobe.container.*;
import aglobe.container.gui.*;
import aglobe.container.sysservice.*;
import aglobe.container.transport.*;
import aglobe.ontology.*;
import java.security.*;
import java.util.LinkedList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;
import aglobe.util.FileUtils;
import java.util.TreeSet;
import aglobe.util.AglobeXMLtools;
import java.util.Date;


/**
 * This class takes care about loaded libraries inside one Agent Container. It plays important
 * role during agent migration procedure.
 *
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.27 $ $Date: 2010/08/04 11:48:05 $
 *
 */

public final class LibraryManager implements ListSource
{
  /**
   * Library Manager logger
   */
  private static Logger logger = Logger.getLogger("platform.LibraryManager");

  /**
   * Jar extension
   */
  private static final String JAREXT = ".jar";

  /**
   * Agent Container which owns this Library Manager
   */
  private final AgentContainer ownerContainer;

  /**
   * Store for the Library Manager
   */
  Store _store = null;

  /**
   * Registred libraries. Key are String name of the libraries with JAR extension and value are LibInfo objects
   */
  private Map<String,LibInfo> _libmap = null;

  /**
   * Registred listeners for listining changes in the _libmap
   */
  private LinkedList<ListListener> listListeners = new LinkedList<ListListener>();

  /**
   * Library Requester service
   */
  private HashMap<AgentContainer,LibraryRequesterService> requesters = new HashMap<AgentContainer,LibraryRequesterService>();


  /**
   * This method is called by Agent Container after container init
   * @param container AgentContainer - agent container
   */
  public void aferContainerInit(AgentContainer container) {
      LibraryRequesterService requester = new LibraryRequesterService();
      synchronized (requesters) {
        requesters.put(container, requester);
      }
      // try start library requester service
      try {
        container.getServiceManager().startService(LibraryRequesterService.
            SERVICENAME, requester);
      }
      catch (Exception ex) {
        logger.severe("Cannot start LibraryRequesterService: " + ex);
      }
  }

  /**
   * Constructor of Library Manager
   * @param container AgentContainer - owner agent container
   */
  public LibraryManager(AgentContainer container) {
    this.ownerContainer = container;
    _store = container.getLibraryStore();
    _libmap = new TreeMap<String,LibInfo>();

    String libs[] = _store.listEntries("");

    for (int i = 0; i < libs.length; i++)
      if (FileUtils.hasExtension(libs[i], FileUtils.JAR)) {
        // Add the libinfo into the _libraries
        getLibInfo(FileUtils.removeExtension(libs[i]));
      }
  }

  /**
   * Get library name under which the library referenced by libraryFile will be
   * stored in the A-globe.
   * @param libraryFile File
   * @return String
   */
  public String getLibraryName(File libraryFile) {
    try {
        String newLibName = FileUtils.removeExtension(libraryFile.getName()).
                            toLowerCase() + "." +
                            HashCounter.getHash(libraryFile) + "." +
                            FileUtils.JAR;
        return newLibName;
    } catch (NoSuchAlgorithmException ex) {
        return null;
    } catch (IOException ex) {
        return null;
    }

  }

  /**
   * Get LibInfo for specified library
   * @param libraryFile File
   * @param version String
   * @param comment String
   * @return LibInfo
   */
  private LibInfo getLibInfo(File libraryFile, String version, String comment) {
      String newLibName = getLibraryName(libraryFile);
      if (newLibName == null) {
          return null;
      }
      LibInfo li = getLibInfo(newLibName);
      li.setVersion(version);
      li.setComment(comment);
      return li;
  }

  /**
   * Register library user
   * @param ui LibUser - library user
   * @param libnames String[] - libraries to register
   */
  synchronized public void register(final LibInfo.LibUser ui, final String[] libnames) {
    for (int i = 0; i < libnames.length; i++) {
      register(ui, libnames[i]);
    }
    // send update to the listeners
    sendListChanged(ListListener.ListType.LIBRARIES, _libmap.keySet());
  }

  /**
   * Register library user
   * @param ui LibUser - library user
   * @param _libname String - library to register
   */
  private void register(final LibInfo.LibUser ui, final String _libname) {
    String libname = _libname.toLowerCase();
    try {
      LibInfo li = getLibInfo(libname);

      if (!li.getLibUser().contains(new LibUserComparator(ui))) {
        li.getLibUser().add(ui);
        storeLibInfo(li);
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  /**
   * Deregister library user
   * @param ui LibUser
   * @param libnames String[]
   */
  synchronized public void deregister(final LibInfo.LibUser ui, final String[] libnames) {
    for (int i = 0; i < libnames.length; i++) {
      deregister(ui, libnames[i]);
    }
    // send update to the listeners
    sendListChanged(ListListener.ListType.LIBRARIES, _libmap.keySet());
  }

  /**
   * Deregister library user
   * @param ui LibUser
   * @param _libname String
   */
  private void deregister(final LibInfo.LibUser ui, final String _libname) {
    String libname = _libname.toLowerCase();
    try {
      LibInfo li = getLibInfo(libname);

      if (li.getLibUser().remove(new LibUserComparator(ui)))
        storeLibInfo(li);
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  /**
   * Tests if some library exists
   * @param libname String - library name
   * @return boolean - true iff library with libname is registred in the Library Manager
   */
  public boolean exists(String libname) {
    return _store.exist(lib2jar(libname.toLowerCase()));
  }

  /**
   * Get library list of the registred libraries in the Library Manager
   * @return LibraryRecord[]
   */
  synchronized public LibraryRecord[] getLibraryList() {
    String libs[] = _store.listEntries("");
    TreeSet<LibraryRecord> records = new TreeSet<LibraryRecord> ();

    for (int i = 0; i < libs.length; i++) {
      if (FileUtils.hasExtension(libs[i], FileUtils.JAR))
        records.add(new LibraryRecord(getLibInfo(libs[i])));
    }

    return records.toArray(new LibraryRecord[records.size()]);
  }

  /**
   * Get Library Manager store root directory
   * @return String
   */
  public String getLibraryStoreRoot() {
    return _store.getAbsolutePath("");
  }

  /**
   * Sends list update to the listeners
   * @param which ListType - update type
   * @param values Set - updated list
   */
  private void sendListChanged(ListListener.ListType which, Set<String> values) {
    synchronized (listListeners) {
      for (Iterator<ListListener> iter = listListeners.iterator(); iter.hasNext(); ) {
        ListListener item = iter.next();
        item.ListChanged(which, values);
      }
    }
  }

  /**
   * Sends updated value to the listeners
   * @param where ListType - update type
   * @param what Object - updated value
   */
  private void sendValueChanged(ListListener.ListType where, Object what) {
    synchronized (listListeners) {
      for (Iterator<ListListener> iter = listListeners.iterator(); iter.hasNext(); ) {
        ListListener item = iter.next();
        item.ValueChanged(where, what);
      }
    }
  }

  /**
   * Use a .jar file on current filesystem to create the library.
   *
   * @param l File - the library file
   * @param comment String - comments to the library
   * @return LibInfo - lib info of stored library (contains real name of new
   *   library), null iff there were some problem with storing new library
   */
  synchronized public LibInfo storeLibrary(File l, String comment) {
    try {
      // test name of the library
      if (!FileUtils.hasExtension(l.getName(), FileUtils.JAR)) {
        throw new IllegalArgumentException("Illegal library file name: " +
                                           l.getName());
      }
      // get name without extension
      String lname = FileUtils.removeExtension(l.getName()).toLowerCase();

      // find last version number
      int maxVersion = 0;
      String xmlname = lib2xml(lname);
      Pattern p = Pattern.compile("^(\\d+)$");
      try {
        if (_store.exist(xmlname)) {
          InputStream in = _store.getFile(xmlname);
          LibInfo li = (LibInfo)AglobeXMLtools.unmarshallJAXBObject(LibInfo.class,in);
          in.close();
          Matcher m = p.matcher(li.getVersion());
          if (m.find()) {
            try {
              maxVersion = Math.max(maxVersion, Integer.parseInt(m.group(1)));
            }
            catch (NumberFormatException ex1) {
            }
          }
        }
      }
      catch (Exception ex) {
      }

      // create new LibInfo for new library
      LibInfo li = getLibInfo(l,
                              "ver" + (maxVersion + 1) + "@" +
                              ownerContainer.getContainerName(), comment);

      FileOutputStream out = _store.putFile(li.getName());
      FileChannel chout = out.getChannel();
      FileInputStream in = new FileInputStream(l);
      FileChannel chin = in.getChannel();

      // Copy the file
      chin.transferTo(0, chin.size(), chout);
      chin.close();
      chout.close();

      //invalidate class finder cache
      ownerContainer.getClassFinder().invalidate();

      // store lib info
      storeLibInfo(li);
      sendListChanged(ListListener.ListType.LIBRARIES, _libmap.keySet());

      // remember last library version
      LibInfo lllast = new LibInfo();
      lllast.setName(lname);
      lllast.setVersion(Integer.toString(maxVersion + 1));
      lllast.setComment(li.getComment());
      try {
        OutputStream out2 = _store.putFile(lib2xml(lllast.getName()));
        AglobeXMLtools.marshallJAXBObject(lllast, out2);
        out2.close();
      }
      catch (Exception ex) {
        logger.warning("Warning storing LibInfo: " + ex);
      }

      // returns LibInfo of the new stored library
      return li;
    }
    catch (Exception ex) {
      ex.printStackTrace();
      return null;
    }
  }

  /**
   * Store new library from the TheLibrary ontology. It is used for transfering libraries between agent containers
   * @param l TheLibrary
   */
  synchronized public void storeLibrary(TheLibrary l) {
    try {
      LibInfo li = getLibInfo(l.getName());
      if (li.getVersion().equalsIgnoreCase("unknown") ||
          (li.getVersion().compareToIgnoreCase(l.getVersion()) < 0)) {
        li.setComment(l.getComment());
        li.setVersion(l.getVersion());

        sendListChanged(ListListener.ListType.LIBRARIES, _libmap.keySet());
        storeLibInfo(li);

        FileOutputStream out = _store.putFile(lib2jar(l.getName()));
        out.write(l.getData());
        out.close();

        ownerContainer.getClassFinder().invalidate();
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
      logger.severe("Error writing library file.");
    }
  }

  /**
   * Remove library
   * @param _libname String - library name
   * @throws LibraryException - throws if there were some problem with removing library, e.g. library in use
   */
  synchronized public void deleteLibrary(String _libname) throws
      LibraryException {
    LibInfo li = getLibInfo(_libname);
    // test if it is in use
    if (!li.getLibUser().isEmpty()) {
      throw new LibraryException("The library is used.");
    }

    // try to remove it from the store
    String libname = _libname.toLowerCase();
    if (!_store.removeFile(libname)) {
      throw new LibraryException(
          "The library cannot be removed, because it is still loaded.");
    }
    // if it is sucessful, remove libinfo etc.
    _store.deleteKey(lib2xml(libname));
    _libmap.remove(lib2jar(libname));
    sendListChanged(ListListener.ListType.LIBRARIES, _libmap.keySet());
    // invalidate ClassFinder
    ownerContainer.getClassFinder().invalidate();
  }

  /**
   * Obtain a library from remote Agent Container. This method is called automatically when some agent migrates and there
   * isn't necessary library present
   * @param container AgentContainer - agent container
   * @param srcContainer Address - address of source Agent container with specified library
   * @param _libname String - library name
   * @param callback LibraryRequesterCallback - registred callback listener for the transfer
   */
  synchronized public void obtainLibrary(AgentContainer container,
                                         Address srcContainer, String _libname,
                                         LibraryRequesterCallback callback) {
    String libname = _libname.toLowerCase();
    // check if library already exists here first
    if (!exists(libname)) {
      LibraryRequesterService requester = null;
      synchronized (requesters) {
        requester = requesters.get(container);
      }
      if (requester != null)
        // try obtain library from remote Agent Container
        requester.obtainLibrary(srcContainer, libname, callback);
      else
        callback.libraryRequestFinished(LibraryRequesterCallback.FAILED);
    }
    else {
      // notify callback listener
      callback.libraryRequestFinished(LibraryRequesterCallback.DONE);
    }
  }

  /**
   * Convert library name to the name of the describing XML file
   * @param lib String - library
   * @return String - XML name
   */
  protected static String lib2xml(String lib) {
    if (lib.endsWith(JAREXT))
      return lib.replaceAll(JAREXT, AglobeXMLtools.XMLEXT);
    else
      return lib + AglobeXMLtools.XMLEXT;
  }

  /**
   * Convert library name to the jar file
   * @param lib String - library name
   * @return String - jar file name
   */
  protected static String lib2jar(String lib) {
    if (!lib.endsWith(JAREXT))
      return lib + JAREXT;
    else
      return lib;
  }

  /**
   * Get LibInfo for a library
   * @param _libname String - library name
   * @return LibInfo - LibInfo for the library
   */
  synchronized public LibInfo getLibInfo(String _libname) {
    String libname = _libname.toLowerCase();
    LibInfo li = _libmap.get(lib2jar(libname));

    if (li != null)
      return li;
    else {
      String xmlname = lib2xml(libname);

      try {
        if (_store.exist(xmlname)) {
          InputStream in = _store.getFile(xmlname);
          li = (LibInfo) AglobeXMLtools.unmarshallJAXBObject(LibInfo.class,in);
          in.close();
        }
        else
          throw new Exception("File not found.");
      }
      catch (Exception ex) {

        li = new LibInfo();
        li.setName(lib2jar(libname));
        li.setComment("LibInfo automatically generated on "
                      +
                      DateFormat.getInstance().format(new Date(System.currentTimeMillis())));
        li.setVersion("unknown");

        _store.putXML(xmlname, li);
      }
    }

    _libmap.put(lib2jar(libname), li);
    return li;
  }

  /**
   * Save LibInfo to the store
   * @param li LibInfo
   */
  private void storeLibInfo(LibInfo li) {
    try {
      OutputStream out = _store.putFile(lib2xml(li.getName()));
      AglobeXMLtools.marshallJAXBObject(li, out);
      out.close();
      sendValueChanged(ListListener.ListType.LIBRARIES, li.getName());
    }
    catch (Exception ex) {
      logger.warning("Warning storing LibInfo: " + ex);
    }
  }

  /**
   *
   * <p>Title: A-Globe</p>
   * <p>Description: Class describing library.</p>
   * <p>Copyright: Copyright (c) 2004</p>
   * <p>Company: Gerstner Laboratory</p>
   *
   * @author David Sislak
   * @version $Revision: 1.27 $ $Date: 2010/08/04 11:48:05 $
   */
  public class LibraryRecord
      implements Comparable<LibraryRecord> {
    /**
     * LibInfo of the library
     */
    public final LibInfo libInfo;

    /**
     * Absolute local path to the library
     */
    public final String absolutePathToTheLibrary;

    /**
     * Library readable name. Consists of the readable part of the lib name and library version
     */
    public final String readableName;

    /**
     *
     * @param li LibInfo - LibInfo for the library
     */
    private LibraryRecord(LibInfo li) {
      this.libInfo = li;
      this.absolutePathToTheLibrary = _store.getAbsolutePath(li.getName());
      this.readableName = new StringBuilder(FileUtils.removeExtension(FileUtils.
          removeExtension(li.getName()))).append(".").append(li.getVersion()).
          toString();
    }

    /**
     * Returns readable name of the library
     * @return String
     */
    @Override
    public String toString() {
      return readableName;
    }

    /**
     * Compares this object with the specified object for order.
     *
     * @param o the Object to be compared.
     * @return a negative integer, zero, or a positive integer as this object
     *   is less than, equal to, or greater than the specified object.
     */
    @Override
	public int compareTo(LibraryRecord o) {
      return readableName.compareTo(o.toString());
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof LibraryRecord) {
            return this.compareTo((LibraryRecord)obj) == 0;
        }
        return false;
    }
  }

  /**
   *
   * <p>Title: A-Globe</p>
   * <p>Description: A-globe internal class used for comparing library users</p>
   * <p>Copyright: Copyright (c) 2004</p>
   * <p>Company: Gerstner Laboratory</p>
   *
   * @author David Sislak
   * @version $Revision: 1.27 $ $Date: 2010/08/04 11:48:05 $
   */
  private static class LibUserComparator {
    /**
     * name of the user
     */
    String name;

    /**
     * User type
     */
    String type;

    /**
     *
     * @param lu LibUser - creates Lib user comparator from LibUser
     */
    LibUserComparator(LibInfo.LibUser lu) {
      name = lu.getName();
      type = lu.getType();
    }

    /**
     * Tests if other object is same as this
     * @param other Object
     * @return boolean - true iff other object is same as this
     */
    @Override
    public boolean equals(Object other) {
      //TODO Pavel: strange behavior! checkes different type than this,
      // no getHashCode() present
      if (other instanceof LibInfo.LibUser) {
        LibInfo.LibUser lu = (LibInfo.LibUser) other;
        return name.equals(lu.getName()) && (type.equals(lu.getType()));
      }
      else
        return super.equals(other);
    }
  }

  /**
   *
   * <p>Title: A-Globe</p>
   * <p>Description: Library Directory service. Used for searching in the registred libraries</p>
   * <p>Copyright: Copyright (c) 2004</p>
   * <p>Company: Gerstner Laboratory</p>
   *
   * @author David Sislak
   * @version $Revision: 1.27 $ $Date: 2010/08/04 11:48:05 $
   */
  public static class LibraryDir extends DirService {
    /**
     *
     */
    public LibraryDir() {
    }

    /**
     * perform search in the Library Manager
     * @param query Query - query object define query of the search and search result is stored there too
     */
    @Override
    protected void search(Query query) {
      if (PARAM.equalsIgnoreCase(query.getParam())) {
        String libs[] = getContainer().getLibraryManager()._store.listEntries(
            "");

        Pattern p = Pattern.compile(query.getValue());

        for (int i = 0; i < libs.length; i++) {
          if (libs[i].endsWith(JAREXT) && p.matcher(libs[i]).matches()) {
            Query.QueryResult r = new Query.QueryResult();
            r.setName(libs[i]);
            query.getQueryResult().add(r);
          }
        }
      }
      else
        throw new IllegalArgumentException("Service search 'parameter' is not " +
                                           PARAM + ", but " + query.getParam());
    }
  }

  /**
   * Add list listener for registred libraries and users changes
   * @param ll ListListener - listener to register
   */
  @Override
public void addListListener(ListListener ll) {
    if (ll != null) {
      ll.ListChanged(ListListener.ListType.LIBRARIES, _libmap.keySet());
      synchronized (listListeners) {
        listListeners.add(ll);
      }
    }
  }
}
