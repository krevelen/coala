package aglobe.container.library;

import java.io.FileInputStream;
import java.io.IOException;

import aglobe.container.service.CMService;
import aglobe.container.service.ServiceShell;
import aglobe.container.service.ShellOwner;
import aglobe.container.task.Task;
import aglobe.container.task.TimeoutTask;
import aglobe.container.transport.Address;
import aglobe.container.transport.InvisibleContainerException;
import aglobe.ontology.LibInfo;
import aglobe.ontology.Message;
import aglobe.ontology.MessageConstants;
import aglobe.ontology.TheLibrary;


/**
 * Acts as library requester during agent migration procedure from the destination AgentContainer.
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.26 $ $Date: 2010/08/04 11:48:05 $
 */

public final class LibraryRequesterService
extends CMService {
    /**
     * Timeout for the request
     */
    private static final int TIMEOUT = 10000;

    /**
     * Library Requester service name
     */
    public final static String SERVICENAME = "library/loader";

    /**
     *
     */
    public LibraryRequesterService() {
        setIdleTask(new SenderTask(this, true));
    }

    /**
     * Obtain specified library from remote agent container
     * @param srcContainer Address - remote agent container from where library should be obtained
     * @param libname String - library name
     * @param callback LibraryRequesterCallback - callback listener
     */
    protected void obtainLibrary(final Address srcContainer, final String libname,
            final LibraryRequesterCallback callback) {
        new RequesterTask(this, srcContainer, libname, callback, true);
    }

    /**
     * Returns library requester service shell
     *
     * @return ServiceShell - always null, there isn't any shell for this service
     * @param shellOwner ElementaryEntity
     */
    @Override
    public ServiceShell getServiceShell(final ShellOwner shellOwner) {
        return null;
    }

    /**
     *
     * <p>Title: A-Globe</p>
     * <p>Description: Requester task. Receives libraries from the remote sender task</p>
     * <p>Copyright: Copyright (c) 2004</p>
     * <p>Company: Gerstner Laboratory</p>
     *
     * @author David Sislak
     * @version $Revision: 1.26 $ $Date: 2010/08/04 11:48:05 $
     */
    private class RequesterTask
    extends TimeoutTask {
        /**
         * Task owner
         */
        @SuppressWarnings("unused")
		LibraryRequesterService owner;

        /**
         * Source container of the library
         */
        @SuppressWarnings("unused")
		Address srcContainer;

        /**
         * Library name
         */
        @SuppressWarnings("unused")
		String libname;

        /**
         * Callback listener
         */
        LibraryRequesterCallback callback;

        /**
         * if true, task is terminated
         */
        boolean terminated = false;

        /**
         * Constructor
         * @param owner LibraryRequesterService - owner service
         * @param srcContainer Address - source container for the library
         * @param libname String - library name
         * @param callback LibraryRequesterCallback - callback listener
         */
        RequesterTask(LibraryRequesterService owner,
                Address srcContainer,
                String libname,
                LibraryRequesterCallback callback,
                boolean messageAsReference) {
            super(owner, TIMEOUT, messageAsReference);
            this.owner = owner;
            this.srcContainer = srcContainer;
            this.libname = libname;
            this.callback = callback;

            // send request for the library to the library requester service on the source agent container
            Message m = Message.newInstance(MessageConstants.REQUEST, owner.getAddress(),
                    srcContainer.deriveServiceAddress(SERVICENAME));

            TheLibrary l = new TheLibrary();
            l.setName(libname);
            m.setContent(l);
            try {
                sendMessageAsReference(m);
            }
            catch (InvisibleContainerException ex) {
                terminate(LibraryRequesterCallback.FAILED);
            }
            m.release();
        }

        /**
         * timeout expired
         */
        @Override
        protected void timeout() {
            terminate(LibraryRequesterCallback.FAILED);
        }

        /**
         * Terminate the requester task
         * @param result Result - termination result
         */
        synchronized private void terminate(LibraryRequesterCallback.Result result) {
            if (!terminated) {
                terminated = true;
                callback.libraryRequestFinished(result);
                cancelTask();
            }
        }

        /**
         * Handles incoming messages
         * @param m Message - incoming message
         */
        @Override
		public void handleIncomingMessage(Message m) {
            LibraryRequesterCallback.Result result = LibraryRequesterCallback.FAILED;

            if (m.getPerformative().equalsIgnoreCase(MessageConstants.DONE)) {
                if (m.getContent() instanceof TheLibrary) {
                    TheLibrary l = (TheLibrary) m.getContent();
                    getContainer().getLibraryManager().storeLibrary(l);
                    result = LibraryRequesterCallback.DONE;
                }
                else {
                    String msg = "Wrong ontology (" + m.getOntology() + ")";
                    logWarning(msg);
                }
            }
            else if (!m.getPerformative().equalsIgnoreCase(MessageConstants.FAILURE)) {
                String msg = "Wrong performative (" + m.getPerformative() + ")";
                logWarning(msg);
            }
            m.release();
            // terminate task
            terminate(result);
        }
    }

    /**
     * <p>Title: A-Globe</p>
     * <p>Description: Sender task. Sends libraries to the remote requester task</p>
     * <p>Copyright: Copyright (c) 2004</p>
     * <p>Company: Gerstner Laboratory</p>
     *
     * @author David Sislak
     * @version $Revision: 1.26 $ $Date: 2010/08/04 11:48:05 $
     */
    private class SenderTask
    extends Task {

        /**
         * Constructor
         * @param owner CMService - owner service
         */
        @SuppressWarnings("unused")
		public SenderTask(CMService owner) {
            this(owner, false);
        }

        public SenderTask(CMService owner, boolean messageAsReference){
            super(owner, messageAsReference);
        }

        /**
         * handles incoming messages
         * @param m Message
         */
        @Override
		public void handleIncomingMessage(Message m) {
            if (!m.getPerformative().equalsIgnoreCase(MessageConstants.REQUEST)) {
                String msg = "Wrong performative (" + m.getPerformative() + ")";
                logWarning(msg);
            }

            if (m.getContent() instanceof TheLibrary) {
                TheLibrary l = (TheLibrary) m.getContent();


                if (l.getData() != null)
                    logWarning("SenderTask received message with non-empty data.");
                else {
                    LibraryManager lm = getContainer().getLibraryManager();
                    Message re = m.getReply();
                    if (lm.exists(l.getName())) {
                        try {
                            String jarname = LibraryManager.lib2jar(l.getName());

                            FileInputStream in = lm._store.getFile(jarname);
                            byte[] content = new byte[in.available()];
                            in.read(content);
                            in.close();

                            LibInfo li = lm.getLibInfo(l.getName());

                            TheLibrary nl = new TheLibrary();
                            nl.setName(l.getName());
                            nl.setVersion(li.getVersion());
                            nl.setComment(li.getComment());
                            nl.setData(content);

                            re.setPerformative(MessageConstants.DONE);
                            re.setContent(nl);
                        }
                        catch (IOException ex) {
                            re.setPerformative(MessageConstants.FAILURE);
                            re.setReason(ex.toString());
                        }
                    }
                    else
                        re.setPerformative(MessageConstants.FAILURE);

                    try {
                        sendMessageAsReference(re);
                    }
                    catch (InvisibleContainerException ex1) {
                        logWarning("Cannot send failure to the requester: "+ex1);
                    }
                    re.release();
                }
            }
            else {
                String msg = "Wrong ontology (" + m.getOntology() + ")";
                logWarning(msg);
            }
            m.release();
        }
    }
}
