package aglobe.container.library;


/**
 * Library Requester Callback listener. This listener must be implemented if some agent/service
 * want request library from the remote agent container by calling obtainLibrary method of the Library Manager.
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.6 $ $Date: 2009/05/15 08:46:58 $
 */

public interface LibraryRequesterCallback
{
  /**
   * Result DONE
   */
  public static final Result DONE = new Result();

  /**
   * Result FAILED
   */
  public static final Result FAILED = new Result();

  /**
   * Method for notifying about library obtain result
   * @param result Result
   */
  public void libraryRequestFinished(Result result);

  /**
   *
   * <p>Title: A-Globe</p>
   * <p>Description: Result object. Passed as parameter to the libraryRequestFinished method</p>
   * <p>Copyright: Copyright (c) 2004</p>
   * <p>Company: Gerstner Laboratory</p>
   *
   * @author David Sislak
   * @version $Revision: 1.6 $ $Date: 2009/05/15 08:46:58 $
   */
  public static class Result {
    private Result() {}
  }
}
