package aglobe.container.library;

import java.io.*;
import java.security.*;

/**
 * Class which provide methods for counting SHA-1 hash of the file. The
 * hash of the library is used for distingush among several versions of the
 * java library with the same name.
 * 
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.7 $ $Date: 2009/05/15 08:46:58 $
 */
public class HashCounter {
  /**
   * Class cannot be created
   */
  private HashCounter() {
  }

  /**
   * Get the SHA-1 hash of the given file
   *
   * @param filename String - name and path to the given file
   * @return String
   * @throws IOException - thrown when file not found, or some problem with reading
   * @throws NoSuchAlgorithmException - thrown when SHA-1 algorithm cannot be
   *   used
   */
  public static String getHash(String filename) throws IOException,
      NoSuchAlgorithmException {
    return getHash(new File(filename));
  }

  /**
   * Get the SHA-1 hash of the given file
   *
   * @param file File
   * @return String
   * @throws IOException - thrown when file not found, or some problem with reading
   * @throws NoSuchAlgorithmException - thrown when SHA-1 algorithm cannot be
   *   used
   */
  public static String getHash(File file) throws IOException,
      NoSuchAlgorithmException {
    FileInputStream fis = new FileInputStream(file);
    MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
    sha1.reset();
    byte[] buffer = new byte[1024];
    int read;
    while ( (read = fis.read(buffer)) != -1) {
      sha1.update(buffer, 0, read);
    }
    byte[] hash = sha1.digest();
    StringBuilder sb = new StringBuilder(hash.length * 2);
    int usbyte = 0;
    for (int i = 0; i < hash.length; i++) {
      usbyte = hash[i] & 0xFF;
      if (usbyte < 0x10) {
        sb.append('0');
      }
      sb.append(Integer.toHexString(usbyte));
    }
    fis.close();
    return sb.toString();
  }

}
