package aglobe.container.library;

import java.io.*;

import aglobe.platform.transport.AddressReader;
import aglobe.platform.transport.MessageReceiver;


/**
 * A-globe internal class used for loading classes from correct class loader during deserialization.
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.16 $ $Date: 2009/09/24 14:25:23 $
 */

public final class LibraryObjectInputStream
    extends ObjectInputStream {

    /**
     * Class loader used for finding correct classes
     */
    private ClassLoader classLoader;

    /**
     * @internal
     * Used for Message deserialization purposes
     */
    public final AddressReader addressReader;

    /**
     * Constructor
     * @param in InputStream - original input stream
     * @param classLoader ClassLoader - class loader for resolving classes from input stream
     * @throws IOException - throws if there was some problem during creating new input stream
     */
    public LibraryObjectInputStream(final InputStream in, final ClassLoader classLoader, final AddressReader addressReader) throws
    IOException {
        super(in);
        this.classLoader = classLoader;
        this.addressReader = addressReader;
    }

    /**
     * Constructor
     * @param in InputStream - original input stream
     * @param classLoaderOwner ClassLoader - class loader owner for resolving classes from input stream
     * @throws IOException - throws if there was some problem during creating new input stream
     */
    public LibraryObjectInputStream(final InputStream in, final MessageReceiver classLoaderOwner, final AddressReader addressReader) throws
            IOException {
        this(in, classLoaderOwner.getClassLoader(), addressReader);
    }

    /**
     * Set new class loader
     *
     * @param classLoaderOwner ClassLoader
     */
    public void setClassLoader(final MessageReceiver classLoaderOwner) {
        this.classLoader = classLoaderOwner.getClassLoader();
    }

    /**
     * Fetch class current class loader
     * @return ClassLoader
     */
    public ClassLoader getClassLoader() {
        return this.classLoader;
    }

    /**
     * This method ensures, that deserialized classes are searched in the
     * dynamically loaded libraries.
     *
     * @param v ObjectStreamClass
     * @throws IOException
     * @throws ClassNotFoundException
     * @return Class
     */
    @Override
    protected Class<?> resolveClass(final ObjectStreamClass v) throws IOException,
    ClassNotFoundException {
        try {
            return Class.forName(v.getName(), false, classLoader);
        }
        catch (ClassNotFoundException ex) {
            try {
                return super.resolveClass(v);
            }
            catch (ClassNotFoundException ex2) {
                throw new IOException("No class definition found: " + v.getName());
            }
        }
    }
}
