package aglobe.container.library;

/**
 * The Library Exception.
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.7 $ $Date: 2009/05/15 08:46:58 $
 */
public class LibraryException extends Exception {
    private static final long serialVersionUID = 5793222175982035087L;

    /**
     * Exception contstructor
     * @param message String - exception message
     */
    public LibraryException(String message) {
        super(message);
    }
}
