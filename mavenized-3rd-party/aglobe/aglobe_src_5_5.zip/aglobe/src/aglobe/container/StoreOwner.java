package aglobe.container;

/**
 * <p>Title: A-Globe</p>
 *
 * <p>Description: Store owner denotes that the implementor class owns store.</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.3 $ $Date: 2008/11/23 09:14:11 $
 */
public interface StoreOwner {
    /**
     * Get entity store
     * @return Store
     */
    public Store getStore();
}
