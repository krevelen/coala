package aglobe.agent.matrixes;

import java.util.*;
import java.util.List;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;

import aglobe.container.transport.*;

/**
 * <p>
 * Title: A-Globe
 * </p>
 * <p>
 * Description: It is a graphical component for disply container visibility.
 * </p>
 * <p>
 * Copyright: Copyright (c) 2003
 * </p>
 * <p>
 * Company: Gerstner Laboratory
 * </p>
 *
 * @author David Sislak
 * @version $Revision: 1.19 $ $Date: 2010/08/04 11:48:05 $
 */
class MatrixTableModel extends AbstractTableModel {
    private static final long serialVersionUID = 1473045122000123261L;

    /**
     * List of rows.
     */
    List<LinkedList<Object>> rows = new ArrayList<LinkedList<Object>>();

    /**
     * List of containers.
     */
    List<Address> containers = new ArrayList<Address>();

    /**
     * Default visibility is true.
     */
    private static Boolean DefaultVisibility = Boolean.TRUE;

    MatrixESAgent owner = null;

    RowHeaderListModel rowHeaderModel = new RowHeaderListModel();

    MatrixTableModel(MatrixESAgent owner) {
        this.owner = owner;
    }

    /**
     * Returns count of the rows.
     *
     * @return count
     */
    @Override
	synchronized public int getRowCount() {
        return rows.size();
    }

    /**
     * Returns count of the columns.
     *
     * @return count
     */
    @Override
	synchronized public int getColumnCount() {
        return containers.size();
    }

    /**
     * The method returns name of a column. The column is givem by index.
     *
     * @param columnIndex
     *            index of the column
     * @return name of the container
     */
    @Override
    synchronized public String getColumnName(int columnIndex) {
        if (columnIndex >= containers.size())
            return "unknown";

        return (containers.get(columnIndex)).getContainerName();
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        return Boolean.class;
    }

    /**
     * Returns whether cell is editable.Row names and diagonal are not editable.
     *
     * @param rowIndex
     *            int
     * @param columnIndex
     *            int
     * @return boolean
     */
    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        // Row names and diagonal are not editable
        return (rowIndex != columnIndex);
    }

    /**
     * The method returns a value from the table.
     *
     * @param rowIndex
     *            int
     * @param columnIndex
     *            int
     * @return Object
     */
    @Override
	synchronized public Object getValueAt(int rowIndex, int columnIndex) {
        if (rowIndex == columnIndex) // Diagonal elements are always true
            return Boolean.TRUE;

        if (rowIndex >= rows.size())
            return null;

        LinkedList<Object> row = rows.get(rowIndex);
        if (columnIndex >= row.size())
            return null;

        return row.get(columnIndex);
    }

    /**
     * The method sets a value at given place.
     *
     * @param aValue
     *            Object
     * @param rowIndex
     *            int
     * @param columnIndex
     *            int
     */
    @Override
    synchronized public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        owner.visibilityID++;
        (rows.get(rowIndex)).set(columnIndex, aValue);
        // Change the symetric cell also
        (rows.get(columnIndex)).set(rowIndex, aValue);
        fireTableCellUpdated(columnIndex, rowIndex);
        sendChange(rowIndex);
        sendChange(columnIndex);
    }

    /**
     * This mehtod adds container (row respectively)
     *
     * @param p
     *            <code>VisibleContainer</code>
     */
    synchronized public void addContainer(final Address p) {
        containers.add(p);
        LinkedList<Object> row = new LinkedList<Object>();
        for (int i = 0; i < containers.size(); i++)
            row.add(DefaultVisibility);

        Iterator<LinkedList<Object>> i = rows.iterator();
        while (i.hasNext())
            i.next().addLast(DefaultVisibility);

        rows.add(row);
        fireTableStructureChanged();
        rowHeaderModel.fireChange();
        sendChangeAll();
    }

    /**
     * The method removes container from the table.
     *
     * @param p
     *            <code>VisibleContainer</code>
     */
    synchronized void removeContainer(final Address p) {
        int pos = containers.indexOf(p);

        if (pos != -1) {
            containers.remove(pos);

            rows.remove(pos);
            Iterator<LinkedList<Object>> i = rows.iterator();
            while (i.hasNext())
                i.next().remove(pos);

            fireTableStructureChanged();
            rowHeaderModel.fireChange();
            sendChangeAll();
        } else
            throw new RuntimeException("Removing non-existing container from the Matrix.");
    }

    /**
     * Method sends to a container a visibility list about all the containers.
     *
     * @param container
     *            - number of the container from <code>containers</code>
     *
     */
    private void sendChange(int container) {
        if (owner != null) {
            try {
                LinkedList<Address> pList = new LinkedList<Address>();
                Iterator<Object> pi = rows.get(container).iterator();
                Iterator<Address> i = containers.iterator();

                while (i.hasNext()) {
                    if (((Boolean) pi.next()).booleanValue())
                        pList.add(i.next()); // add the container info tho the
                                             // visible list
                    else
                        i.next(); // Skip the container
                }

                owner.sendChange(containers.get(container), pList);
            } catch (Exception ex) {
                ex.printStackTrace();
                System.err.println("MatrixTableModel error (sendChangeMethod)");
            }
        }
    }

    /**
     * This method sends visibility list to all contaniners.
     */
    private void sendChangeAll() {
        owner.visibilityID++;
        for (int i = 0; i < containers.size(); i++)
            sendChange(i);
    }

    synchronized public Component getRowHeader(JTable table) {
        JList rowHeader = new JList(rowHeaderModel);
        rowHeader.setFixedCellWidth(70);

        rowHeader.setFixedCellHeight(table.getRowHeight());
        rowHeader.setCellRenderer(new RowHeaderRenderer(table));

        rowHeader.setOpaque(false);
        return rowHeader;
    }

    private class RowHeaderListModel extends AbstractListModel {
        private static final long serialVersionUID = -8990915929164708522L;

        @Override
		public int getSize() {
            synchronized (MatrixTableModel.this) {
                return containers.size();
            }
        }

        @Override
		public Object getElementAt(int index) {
            synchronized (MatrixTableModel.this) {
                return containers.get(index).getContainerName();
            }
        }

        public void fireChange() {
            synchronized (MatrixTableModel.this) {
                fireContentsChanged(this, 0, containers.size());
            }
        }
    }

    public static class RowHeaderRenderer extends JLabel implements ListCellRenderer {

        private static final long serialVersionUID = 4658489090905107488L;

        RowHeaderRenderer(JTable table) {
            JTableHeader header = table.getTableHeader();
            setOpaque(true);
            setBorder(UIManager.getBorder("TableHeader.cellBorder"));
            setHorizontalAlignment(CENTER);
            setForeground(header.getForeground());
            setBackground(header.getBackground());
            setFont(header.getFont());
        }

        @Override
		public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
            setText((value == null) ? "" : value.toString());
            return this;
        }
    }
}
