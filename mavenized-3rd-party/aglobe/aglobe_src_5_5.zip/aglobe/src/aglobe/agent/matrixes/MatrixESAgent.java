package aglobe.agent.matrixes;

import java.util.*;

import aglobe.container.*;
import aglobe.container.agent.*;
import aglobe.ontology.*;
import aglobe.service.topics.ContainerHandler;
import aglobe.service.topics.ContainerMonitor;
import aglobe.service.topics.TopicsService;
import aglobe.service.visibility.VisibilityService;
import aglobe.util.ExceptionPrinter;
import aglobe.container.transport.Address;
import javax.swing.SwingUtilities;

/**
 * <p>
 * Title: A-Globe
 * </p>
 * <p>
 * Description: Matrix Environment Simulator Agent. The agent provides manual
 * changing of visibility between containers. It can runs only on the master container.
 * </p>
 * <p>
 * Copyright: Copyright (c) 2003
 * </p>
 * <p>
 * Company: Gerstner Laboratory
 * </p>
 *
 * @author David Sislak
 * @version $Revision: 1.37 $ $Date: 2010/08/04 11:48:05 $
 *
 */

public class MatrixESAgent extends Agent {
    private static final long serialVersionUID = -1149790077232224226L;

    /**
     * GUI of the MatrixESAgent
     */
    public MatrixESAgentGUI gui = null;

    /**
     * Visibility update ID
     */
    long visibilityID = 1;

    private TopicsService.Shell topicsShell;
    private ContainerMonitor containerMonitor;

    /**
     * List of logged containers.
     */
    Map<String, Address> logged_containers = new LinkedHashMap<String, Address>();

    /**
     * Initialization of the agent.
     *
     * @param a
     *            AgentInfo
     * @param initState
     *            int
     */
    @SuppressWarnings("serial")
    @Override
    public void init(AgentInfo a, int initState) {
        try {
            SwingUtilities.invokeAndWait(new Runnable() {
                @Override
				public void run() {
                    try {
                        gui = new MatrixESAgentGUI(MatrixESAgent.this);
                        gui.setTitle(getAddress().toString());
                        gui.pack();
                        gui.setVisible(true);
                    } catch (Exception ex) {
                        logWarning("Cannot create GUI due to: " + ex);
                    }
                }
            });
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        topicsShell = (TopicsService.Shell) getContainer().getServiceManager().getService(this, TopicsService.SERVICENAME);
        if (topicsShell == null) {
            logSevere("TopicsService not running");
            stop();
            return;
        }
        try {
            containerMonitor = new ContainerMonitor(this, new ContainerHandler() {

                @Override
                public void containerFinished(final String containerName) {
                    logoutContainer(containerName);
                }

                @Override
                public void containerStarted(final Address containerAddress) {
                    loginContainer(containerAddress);
                }

            });
        } catch (Exception e) {
            logSevere(ExceptionPrinter.toStringWithStackTrace(e));
        }
    }

    /**
     * This method stops the agent.
     */
    @Override
    protected void finish() {
        if (gui != null) {
            gui.setVisible(false);
            gui = null;
        }
        if (containerMonitor != null) {
            containerMonitor.dispose();
            containerMonitor = null;
        }
        if (topicsShell != null) {
            topicsShell.dispose();
            topicsShell = null;
        }
    }

    /**
     * This method handles incoming message.
     *
     * @param m
     *            Message
     */
    @Override
	public void handleIncomingMessage(Message m) {
        logWarning("Unexpected message: " + m.toString());
    }

    /**
     * This method sends visibility changes to a container.
     *
     * @param receiver
     *            VisibleContainer
     * @param seen
     *            List
     */
    protected final void sendChange(final Address receiver, final List<Address> seen) {
        if (topicsShell != null) {
            final VisibilityUpdate nfo = VisibilityUpdate.getInstance();
            nfo.setVisibilityID(visibilityID);
            nfo.getVisibleContainerAddress().addAll(seen);
            topicsShell.sendTopic(VisibilityService.TOPIC_VISIBILITY_UPDATES_PREFIX + receiver.getContainerName(), nfo);
            nfo.release();
        }
    }

    /**
     * This method shows GUIs of all containers.
     */
    protected void showAll() {
        sendAllCommand(getVisibilityCommand(true));
    }

    /**
     * This method hides GUIs of all containers.
     */
    protected void hideAll() {
        sendAllCommand(getVisibilityCommand(false));
    }

    /**
     * This method shows GUI of the MatrixESAgent.
     */
    protected void showThis() {
        addEvent(new Runnable() {
            @Override
			public void run() {
                AgentContainer.CommandService.Shell s = (AgentContainer.CommandService.Shell) getContainer().getServiceManager().getService(MatrixESAgent.this,
                        AgentContainer.COMMANDSERVICE);
                s.execute(getVisibilityCommand(true));
            }
        });
    }

    /**
     * This method kill all containers.
     */
    protected void killAll() {
        // Prepare the command
        Command c = new Command();

        // GUI Command
        c.setName(AgentContainer.CommandService.QUIT);

        sendAllCommand(c);
    }

    /**
     * The method returns command about visibility that will be send to all
     * registered containers. All containers will on screen or not.
     *
     * @return command
     * @param visible
     *            boolean
     */
    private Command getVisibilityCommand(boolean visible) {
        // Prepare the command
        Command c = new Command();

        // GUI Command
        c.setName(AgentContainer.CommandService.GUI);

        // With GUI Visible true parameter
        AglobeParam p = new AglobeParam();
        p.setName(AgentContainer.CommandService.VISIBLE);
        p.setValue(Boolean.toString(visible));

        // add parameter
        c.getAglobeParam().add(p);

        return c;
    }

    /**
     * The method send a command as a broadcast.
     *
     * @param c
     *            command
     */
    private void sendAllCommand(final Command c) {
        if (topicsShell != null) {
            topicsShell.sendTopic(AgentContainer.CommandService.TOPIC_COMMAND_IMPLEMENTOR_ALL, c);
        }
    }

    /**
     * This method registers a new container.
     *
     * @param vp
     *            a <code>VisibleContainer</code>
     */
    private void loginContainer(Address vp) {
        logged_containers.put(vp.getContainerName(), vp);
        if (gui != null) {
            gui.addContainer(vp);
        }
    }

    /**
     * This method logs out a container by its name.
     *
     * @param containeName
     *            Name of the container to be logged out.
     */
    private void logoutContainer(String containeName) {
        Address vp = logged_containers.get(containeName);
        logged_containers.remove(containeName);
        if (gui != null) {
            gui.removeContainer(vp);
        }
    }

}
