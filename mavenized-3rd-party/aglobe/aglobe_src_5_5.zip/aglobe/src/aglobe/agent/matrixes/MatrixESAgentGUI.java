package aglobe.agent.matrixes;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import aglobe.container.*;
import aglobe.ontology.*;
import aglobe.container.transport.Address;
import aglobe.util.gui.RememberPositionJFrame;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: Matrix ES Agent GUI</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.20 $ $Date: 2010/08/04 11:48:05 $
 */
class MatrixESAgentGUI extends RememberPositionJFrame {
    private static final long serialVersionUID = -7946632204646451522L;
    private String MATRIX = "matrix";
    private String EMPTY = "empty";

    private MatrixESAgent owner = null;

    private MatrixTableModel matrixTableModel = null;
    private CardLayout cardLayout1 = new CardLayout();
    private JPanel matrixPanel = new JPanel();
    private JPanel emptyPanel = new JPanel();
    private JTable matrixTable = new JTable();
    private JScrollPane jScrollPane1 = new JScrollPane(matrixTable);
    private JLabel jLabel1 = new JLabel();
    private BorderLayout borderLayout1 = new BorderLayout();
    private BorderLayout borderLayout2 = new BorderLayout();
    private JMenuBar menuBar = new JMenuBar();
    private JMenu containersMenu = new JMenu("Agent Containers");
    private JMenuItem showAllMenuItem = new JMenuItem("Show All GUIs");
    private JMenuItem hideAllMenuItem = new JMenuItem("Hide All GUIs");
    private JMenuItem killAllMenuItem = new JMenuItem("Kill All");
    private JMenuItem showThisMenuItem = new JMenuItem("Show This GUI");
    private JMenuItem exitContainerMenuItem = new JMenuItem(
            "Shutdown This Agent Container");
    private JMenuItem killTotalMenuItem = new JMenuItem(
            "Kill All + Shutdown This");

    MatrixESAgentGUI(MatrixESAgent owner) {
        super(owner);
        try {
            this.owner = owner;
            matrixTableModel = new MatrixTableModel(owner);
            jbInit();
            jScrollPane1.setRowHeaderView(matrixTableModel.getRowHeader(
                    matrixTable));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        this.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
                this_windowClosed(e);
            }

            @Override
            public void windowClosing(WindowEvent e) {
                this_windowClosing(e);
            }
        });
        menuBar.add(containersMenu);
        containersMenu.add(showAllMenuItem);
        containersMenu.add(hideAllMenuItem);
        containersMenu.addSeparator();
        containersMenu.add(showThisMenuItem);
        containersMenu.addSeparator();
        containersMenu.add(exitContainerMenuItem);
        containersMenu.add(killAllMenuItem);
        containersMenu.add(killTotalMenuItem);

        showAllMenuItem.addActionListener(new ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                if (owner != null)
                    owner.showAll();
            }
        });

        hideAllMenuItem.addActionListener(new ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                if (owner != null)
                    owner.hideAll();
            }
        });

        showThisMenuItem.addActionListener(new ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                if (owner != null)
                    owner.showThis();
            }
        });

        exitContainerMenuItem.addActionListener(new ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                exitContainerMenuItem_actionPerformed(e);
            }
        });

        killAllMenuItem.addActionListener(new ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                if (owner != null)
                    owner.killAll();
            }
        });

        killTotalMenuItem.addActionListener(new ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                killTotalMenuItem_actionPerformed(e);
            }
        });

        this.getContentPane().setLayout(cardLayout1);
        jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel1.setHorizontalTextPosition(SwingConstants.CENTER);
        jLabel1.setText("No containers registered.");
        emptyPanel.setLayout(borderLayout1);
        matrixTable.setModel(matrixTableModel);
        jScrollPane1.setMinimumSize(new Dimension(100, 100));
        matrixPanel.setLayout(borderLayout2);
        this.getContentPane().add(matrixPanel, MATRIX);
        matrixPanel.add(jScrollPane1, BorderLayout.CENTER);
        this.getContentPane().add(emptyPanel, EMPTY);
        emptyPanel.add(jLabel1, BorderLayout.CENTER);
        cardLayout1.show(this.getContentPane(), EMPTY);

        this.setJMenuBar(menuBar);
    }

    /**
     * Add container
     * @param p Address
     */
    void addContainer(Address p) {
        matrixTableModel.addContainer(p);
        synchronized (matrixTableModel) {
            if (matrixTableModel.containers.size() > 0) {
                SwingUtilities.invokeLater(new Runnable() {
                    @Override
					public void run() {
                        cardLayout1.show(getContentPane(), MATRIX);
                    }
                });
            }
        }
    }

    /**
     * remove container
     * @param p Address
     */
    void removeContainer(Address p) {
        matrixTableModel.removeContainer(p);
        synchronized (matrixTableModel) {
            if (matrixTableModel.containers.size() == 0)
                cardLayout1.show(this.getContentPane(), EMPTY);
        }
    }

    /**
     * Ask if exit should be performed and perform it if requested
     * @param e ActionEvent
     */
    void exitContainerMenuItem_actionPerformed(ActionEvent e) {
        int res = JOptionPane.showConfirmDialog(this,
                "Are you sure to shut down the Agent Container?",
                                                "Shutdown agent container",
                                                JOptionPane.YES_NO_OPTION);
        if (res != JOptionPane.YES_OPTION)
            return;

        AgentContainer.CommandService.Shell s = (AgentContainer.CommandService.
                                                 Shell) owner.getContainer().
                                                getServiceManager().getService(
                owner, AgentContainer.COMMANDSERVICE);
        Command c = new Command();
        c.setName("quit");
        s.execute(c);
    }

    /**
     * Ask if kill should be performed and perform it if requested
     * @param e ActionEvent
     */
    void killTotalMenuItem_actionPerformed(ActionEvent e) {
        int res = JOptionPane.showConfirmDialog(this,
                "Kill all containers including Server container?",
                                                "Shutdown agent container?",
                                                JOptionPane.YES_NO_OPTION);
        if (res != JOptionPane.YES_OPTION)
            return;

        if (owner != null) {
            owner.killAll();
        }
    }

    /**
     * Kill all and exit
     * @param e WindowEvent
     */
    void this_windowClosed(WindowEvent e) {
        owner.killAll();
    }

    /**
     * Kill all and exit
     * @param e WindowEvent
     */
    void this_windowClosing(WindowEvent e) {
        owner.killAll();
    }
}
