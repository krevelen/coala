package aglobe.agent.sniffer;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.*;
import java.awt.Color;

/**
 * <p>
 * Title: A-Globe
 * </p>
 * <p>
 * Description: ACL message GUI. It is used for displaying details about
 * selected message.
 * </p>
 * <p>
 * Copyright: Copyright (c) 2003
 * </p>
 * <p>
 * Company: Gerstner Laboratory
 * </p>
 *
 * @author David Sislak
 * @version $Revision: 1.15 $ $Date: 2010/08/04 11:48:05 $
 */
class ACLMessageGUI extends JFrame {
    private static final long serialVersionUID = 4362452925586331044L;

    private final DetailMainPanel owner;

    private DataContainer.MessageCover[] mcs;

    private int curPos;

    GridBagLayout gridBagLayout1 = new GridBagLayout();

    JPanel jPanel1 = new JPanel();

    JButton closeButton = new JButton();

    Border border1;

    TitledBorder titledBorder1;

    GridBagLayout gridBagLayout2 = new GridBagLayout();

    JLabel jLabel1 = new JLabel();

    JLabel jLabel2 = new JLabel();

    JTextField sender = new JTextField();

    JTextField receiver = new JTextField();

    JLabel jLabel3 = new JLabel();

    JTextField performative = new JTextField();

    JLabel jLabel4 = new JLabel();

    JScrollPane jScrollPane1 = new JScrollPane();

    JTextPane content = new JTextPane();

    JTextField protocol = new JTextField();

    JLabel jLabel5 = new JLabel();

    JLabel jLabel6 = new JLabel();

    JTextField ontology = new JTextField();

    JLabel jLabel7 = new JLabel();

    JTextField conversationID = new JTextField();

    JLabel jLabel8 = new JLabel();

    JTextField inReplyTo = new JTextField();

    JLabel jLabel9 = new JLabel();

    JTextField replyWith = new JTextField();

    JLabel jLabel10 = new JLabel();

    JTextField reason = new JTextField();

    JLabel jLabel11 = new JLabel();

    JTextField msgId = new JTextField();

    JPanel buttonPanel = new JPanel();

    GridBagLayout gridBagLayout3 = new GridBagLayout();

    JButton prevButton = new JButton();

    JButton nextButton = new JButton();

    /**
     * Constructor for window
     *
     * @param _owner
     *            DetailMainPanel
     */
    ACLMessageGUI(DetailMainPanel _owner) {
        owner = _owner;
        try {
            setTitle("ACL Message");
            jbInit();
            pack();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        border1 = new EtchedBorder(EtchedBorder.RAISED, Color.white, new Color(134, 134, 134));
        titledBorder1 = new TitledBorder(border1, "ACL Message details");
        this.getContentPane().setLayout(gridBagLayout1);
        closeButton.setSelected(true);
        closeButton.setText("Close");
        closeButton.addActionListener(new ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                closeButton_actionPerformed(e);
            }
        });
        jPanel1.setBorder(titledBorder1);
        jPanel1.setLayout(gridBagLayout2);
        jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel1.setIconTextGap(4);
        jLabel1.setText("Sender:");
        jLabel2.setVerifyInputWhenFocusTarget(true);
        jLabel2.setHorizontalAlignment(SwingConstants.RIGHT);
        jLabel2.setHorizontalTextPosition(SwingConstants.TRAILING);
        jLabel2.setText("Receiver:");
        sender.setPreferredSize(new Dimension(300, 21));
        sender.setEditable(false);
        sender.setText("");
        receiver.setEditable(false);
        receiver.setText("");
        jLabel3.setText("Performative:");
        performative.setEditable(false);
        performative.setText("");
        performative.setBackground(Color.WHITE);
        jLabel4.setText("Content:");
        jScrollPane1.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        content.setBackground(Color.LIGHT_GRAY);
        content.setOpaque(false);
        content.setPreferredSize(new Dimension(300, 84));
        content.setDisabledTextColor(Color.LIGHT_GRAY);
        content.setEditable(false);
        content.setText("");
        protocol.setEditable(false);
        protocol.setText("");
        jLabel5.setText("Protocol:");
        jLabel6.setText("Ontology:");
        ontology.setToolTipText("");
        ontology.setVerifyInputWhenFocusTarget(true);
        ontology.setEditable(false);
        ontology.setText("");
        jLabel7.setText("ConversationID:");
        conversationID.setEditable(false);
        conversationID.setText("");
        jLabel8.setText("InReplyTo:");
        inReplyTo.setEnabled(true);
        inReplyTo.setEditable(false);
        inReplyTo.setText("");
        jLabel9.setText("ReplyWith:");
        replyWith.setEditable(false);
        replyWith.setSelectionStart(11);
        replyWith.setText("");
        jLabel10.setText("Reason:");
        reason.setEditable(false);
        reason.setText("");
        this.setResizable(false);
        jLabel11.setText("Sniffer msgId:");
        msgId.setDoubleBuffered(false);
        msgId.setEditable(false);
        msgId.setText("jTextField1");
        buttonPanel.setLayout(gridBagLayout3);
        prevButton.setText("<< Conversation");
        prevButton.addActionListener(new ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                prevButton_actionPerformed(e);
            }
        });
        nextButton.setText("Conversation >>");
        nextButton.addActionListener(new ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                nextButton_actionPerformed(e);
            }
        });
        this.getContentPane().add(jPanel1,
                new GridBagConstraints(1, 0, 1, 1, 0.1, 0.1, GridBagConstraints.NORTH, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        buttonPanel.add(closeButton, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(5, 20, 5, 20),
                0, 0));
        buttonPanel.add(prevButton, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0,
                0));
        buttonPanel.add(nextButton, new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0,
                0));
        this.getContentPane().add(buttonPanel,
                new GridBagConstraints(1, 1, 1, 1, 0.1, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
        jPanel1.add(jLabel1, new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 5, 0, 0), 0, 0));
        jPanel1.add(jLabel2, new GridBagConstraints(1, 2, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 5, 0, 0), 0, 0));
        jPanel1.add(sender, new GridBagConstraints(2, 1, 1, 1, 0.1, 0.0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 5), 0, 0));
        jPanel1.add(receiver,
                new GridBagConstraints(2, 2, 1, 1, 0.1, 0.0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 5), 0, 0));
        jPanel1.add(jLabel3, new GridBagConstraints(1, 3, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 5, 0, 0), 0, 0));
        jPanel1.add(performative, new GridBagConstraints(2, 3, 1, 1, 0.1, 0.0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 5),
                0, 0));
        jPanel1.add(jLabel4, new GridBagConstraints(1, 4, 1, 1, 0.0, 0.0, GridBagConstraints.NORTHWEST, GridBagConstraints.NONE, new Insets(5, 5, 0, 0), 0, 0));
        jPanel1.add(jScrollPane1, new GridBagConstraints(2, 4, 1, 1, 0.1, 0.1, GridBagConstraints.WEST, GridBagConstraints.BOTH, new Insets(5, 5, 5, 5), 0, 0));
        jScrollPane1.getViewport().add(content, null);
        jPanel1.add(protocol, new GridBagConstraints(2, 5, 1, 1, 0.1, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 5), 0,
                0));
        jPanel1.add(jLabel5, new GridBagConstraints(1, 5, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 5, 0, 0), 0, 0));
        jPanel1.add(jLabel6, new GridBagConstraints(1, 6, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 5, 0, 0), 0, 0));
        jPanel1.add(ontology,
                new GridBagConstraints(2, 6, 1, 1, 0.1, 0.0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 5), 0, 0));
        jPanel1.add(jLabel7, new GridBagConstraints(1, 7, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 5, 0, 0), 0, 0));
        jPanel1.add(conversationID, new GridBagConstraints(2, 7, 1, 1, 0.1, 0.0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL,
                new Insets(5, 5, 5, 5), 0, 0));
        jPanel1.add(jLabel8, new GridBagConstraints(1, 8, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 5, 0, 0), 0, 0));
        jPanel1.add(inReplyTo, new GridBagConstraints(2, 8, 1, 1, 0.1, 0.0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 5), 0,
                0));
        jPanel1.add(jLabel9, new GridBagConstraints(1, 9, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 5, 0, 0), 0, 0));
        jPanel1.add(replyWith, new GridBagConstraints(2, 9, 1, 1, 0.1, 0.0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 5), 0,
                0));
        jPanel1.add(jLabel10, new GridBagConstraints(1, 10, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 5, 0, 0), 0, 0));
        jPanel1
                .add(reason,
                        new GridBagConstraints(2, 10, 1, 1, 0.1, 0.0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 5), 0, 0));
        jPanel1.add(jLabel11, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 5, 0, 0), 0, 0));
        jPanel1.add(msgId, new GridBagConstraints(2, 0, 1, 1, 0.1, 0.0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 5), 0, 0));
    }

    /**
     * Parse messages object to String values
     *
     * @param object
     *            Object
     * @return String
     */
    private String parseText(Object object) {
        return (object != null) ? object.toString() : "{null}";
    }

    /**
     * Set new ACL message to display
     *
     * @param mc
     *            MessageCover[]
     * @param pos
     *            int
     */
    void setACLMessage(final DataContainer.MessageCover[] mc, final int pos) {
        this.mcs = mc;
        this.curPos = pos;
        SwingUtilities.invokeLater(new Runnable() {
            @Override
			public void run() {
                msgId.setText(Long.toString(mc[pos].msgId));
                sender.setText(parseText(mc[pos].msg.getSender()));
                receiver.setText(parseText(mc[pos].msg.getReceiver()));
                performative.setText(parseText(mc[pos].msg.getPerformative()));
                performative.setForeground(mc[pos].messageColor);
                content.setText(parseText(mc[pos].msg.getContent()));
                protocol.setText(parseText(mc[pos].msg.getProtocol()));
                ontology.setText(parseText(mc[pos].msg.getOntology()));
                conversationID.setText(parseText(mc[pos].msg.getConversationID()));
                inReplyTo.setText(parseText(mc[pos].msg.getInReplyTo()));
                replyWith.setText(parseText(mc[pos].msg.getReplyWith()));
                reason.setText(parseText(mc[pos].msg.getReason()));
                if (pos > 0) {
                    prevButton.setEnabled(true);
                } else {
                    prevButton.setEnabled(false);
                }
                if (pos < (mc.length - 1)) {
                    nextButton.setEnabled(true);
                } else {
                    nextButton.setEnabled(false);
                }
            }
        });
    }

    /**
     * Set window visibility
     *
     * @param state
     *            boolean - true iff window should be shown
     */
    void showGUI(final boolean state) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
			public void run() {
                setVisible(state);
            }
        });
    }

    /**
     * @param e
     */
    void closeButton_actionPerformed(ActionEvent e) {
        showGUI(false);
    }

    @Override
    public void setVisible(boolean b) {
        super.setVisible(b);
        if (!b)
            owner.clearSelection();
    }

    private void updateSelectedMessage() {
        owner.setSelectedMsg(mcs[curPos].msgId);
    }

    /**
     * @param e
     */
    void prevButton_actionPerformed(ActionEvent e) {
        if (curPos > 0) {
            curPos--;
            this.setACLMessage(mcs, curPos);
            updateSelectedMessage();
        }
    }

    /**
     * @param e
     */
    void nextButton_actionPerformed(ActionEvent e) {
        if (curPos < (mcs.length - 1)) {
            curPos++;
            this.setACLMessage(mcs, curPos);
            updateSelectedMessage();
        }
    }

}
