package aglobe.agent.sniffer;

import java.awt.Color;
import java.awt.Font;
import java.awt.Stroke;
import java.awt.BasicStroke;
import aglobe.ontology.MessageConstants;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: Sniffer agent settings</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.8 $ $Date: 2008/11/23 09:14:11 $
 */
interface DrawingConstants {
  final static int HEADER_HEIGHT = 60;
  final static int LEFT_WIDTH = 30;
  final static int MESSAGE_NUMBER_X_POSITION = 29;
  final static int MESSAGE_NUMBER_Y_OFFSET = 4;
  final static int FIRST_ACTOR_X_POSITION = 27;
  final static int SPACE_BETWEEN_ACTORS = 54;
  final static int BOX_WIDTH = 48;   // must be even
  final static int BOX_HEIGHT = 30; // must be even
  final static int BOX_Y_POSITION = 20;
  final static int BOX_BOTTOM_TEXT_POSITION = 40;
  final static int BOX_CONTAINER_OFFSET = 2;
  final static int BOX_CONTAINER_Y1 = 5;
  final static int BOX_CONTAINER_HEIGHT = 50;
  final static int BOX_CONTAINER_BOTTOM_TEXT_POSITION = 15;
  final static int ACTOR_LINE_WIDTH = 1;
  final static int BOX_ROUNDING = 10;
  final static int SPACE_BETWEEN_MESSAGES = 10;

  final static int ARROW_LENGTH = 7;
  final static int ARROW_WIDTH = 4;

  final static Color BACKGROUND_COLOR = Color.WHITE;
  final static Color BOX_BORDER_COLOR = Color.BLACK;
  final static Color BOX_LOGGED_CONTAINER_COLOR = Color.LIGHT_GRAY;
  final static Color BOX_UNLOGGED_CONTAINER_COLOR = Color.WHITE;
  final static Color BOX_OTHER_ACTOR = Color.WHITE;
  final static Color BOX_AGENT_ACTOR = Color.RED;
  final static Color BOX_SERVICE_ACTOR = Color.GREEN;
  final static Color ACTOR_LINE_COLOR = Color.BLACK;

  final static Font BOX_FONT = new Font("Arial",Font.PLAIN, 10);

  final static Stroke BOX_ACTOR_STROKE = new BasicStroke(1);
  final static Stroke BOX_CONTAINER_STROKE = new BasicStroke(1,BasicStroke.CAP_BUTT,BasicStroke.JOIN_BEVEL,1.0f,new float[]{3,2},0);
  final static Stroke BOX_ACTOR_SELECTED_STROKE = new BasicStroke(2);
  final static Stroke BOX_CONTAINER_SELECTED_STROKE = new BasicStroke(2,BasicStroke.CAP_BUTT,BasicStroke.JOIN_BEVEL,1.0f,new float[]{3,2},0);
  final static Stroke REGULAR_MESSAGE_STROKE = new BasicStroke(2);
  final static Stroke INACCESSIBLE_MESSAGE_STROKE = new BasicStroke(2,BasicStroke.CAP_BUTT,BasicStroke.JOIN_BEVEL,1.0f,new float[]{5,5},0);
  final static Stroke SELECTED_REGULAR_MESSAGE_STROKE = new BasicStroke(4);
  final static Stroke SELECTED_INACCESSIBLE_MESSAGE_STROKE = new BasicStroke(4,BasicStroke.CAP_BUTT,BasicStroke.JOIN_BEVEL,1.0f,new float[]{5,5},0);

  final static Color OTHER_MESSAGE_TYPE_COLOR = Color.PINK;

  final static String[] MESSAGE_TYPES = new String[]{
      MessageConstants.INFORM,
      MessageConstants.REQUEST,
      MessageConstants.FAILURE,
      MessageConstants.DONE,
      MessageConstants.REFUSE,
      MessageConstants.NOT_UNDERSTOOD,
      MessageConstants.INFORM_RESULT,
      MessageConstants.INFORM_DONE,
      MessageConstants.PROPOSAL,
      MessageConstants.ACCEPT_PROPOSAL,
      MessageConstants.REJECT_PROPOSAL
  };
  final static Color[] MESSAGE_TYPE_COLORS = {
      Color.BLACK,
      Color.BLUE,
      Color.ORANGE,
      Color.GREEN,
      Color.RED,
      Color.GRAY,
      Color.MAGENTA,
      Color.CYAN,
      Color.YELLOW,
      Color.GREEN,
      Color.RED
  };
}
