package aglobe.agent.sniffer;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import javax.swing.border.*;
import javax.swing.tree.TreeSelectionModel;
import aglobe.util.gui.RememberPositionJFrame;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: Sniffer agent GUI</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.17 $ $Date: 2010/08/04 11:48:05 $
 */
class SnifferGUI
      extends RememberPositionJFrame {
    private static final long serialVersionUID = -3057981683347066007L;

    final SnifferAgent owner;

    private final DataContainer dataContainer;
    private AboutGUI aboutWindow;

    JMenuBar jMenuBar1 = new JMenuBar();
    JMenu jMenu1 = new JMenu();
    JMenuItem closeSniffer = new JMenuItem();
    GridBagLayout gridBagLayout1 = new GridBagLayout();
    JSplitPane jSplitPanel = new JSplitPane();
    JPanel previewPanel = new JPanel();
    GridBagLayout gridBagLayout2 = new GridBagLayout();
    JScrollPane detailedScrollPanel = new JScrollPane();
    final DetailMainPanel detailMainPanel;
    final DetailHeaderPanel detailHeaderPanel;
    final LeftHeaderPanel leftHeaderPanel;
    JPanel cornerPanel1 = new JPanel();
    JPanel cornerPanel2 = new JPanel();
    Border border1;
    JMenuItem showContainerGUI_MenuItem = new JMenuItem();
    JScrollPane previewScrollPanel = new JScrollPane();
    JTree previewTree;
    JMenu jMenu2 = new JMenu();
    JMenuItem jMenuItem1 = new JMenuItem();
    JPanel statusPanel = new JPanel();
    GridBagLayout gridBagLayout3 = new GridBagLayout();
    JLabel jLabel1 = new JLabel();
    JLabel historyUsed = new JLabel();
    JLabel maxHistory = new JLabel();
    JLabel jLabel3 = new JLabel();
    JLabel parsedMsg = new JLabel();
    JMenuItem option_MenuItem = new JMenuItem();

    SnifferGUI(SnifferAgent _owner, DataContainer _dataContainer) {
        super(_owner);
        owner = _owner;
        dataContainer = _dataContainer;
        detailMainPanel = new DetailMainPanel(dataContainer);
        detailHeaderPanel = new DetailHeaderPanel(dataContainer);
        leftHeaderPanel = new LeftHeaderPanel(dataContainer);
        try {
            jbInit();
            setSize(300,300);
            jSplitPanel.setDividerLocation(100);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        dataContainer.setHeaderPanel(detailHeaderPanel);
        dataContainer.setMainPanel(detailMainPanel);
        dataContainer.setLeftHeaderPanel(leftHeaderPanel);
        dataContainer.setContainerTree(previewTree);
        setVisible(true);
    }

    /**
     * Save other window settings
     */
    @Override
    protected void saveWindowSettings() {
        store.putInt(GUI_DIVIDER, jSplitPanel.getDividerLocation());
    }

    /**
     * Load other window settings
     */
    @Override
    protected void loadWindowSettings() {
        int divPos = jSplitPanel.getDividerLocation();
        jSplitPanel.setDividerLocation(store.getInt(GUI_DIVIDER, divPos));
    }

    private void jbInit() throws Exception {
        border1 = BorderFactory.createEmptyBorder();
        this.setJMenuBar(jMenuBar1);
        this.setState(Frame.NORMAL);
        this.setTitle("Sniffer");
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
                this_windowClosed(e);
            }

            @Override
            public void windowClosing(WindowEvent e) {
                this_windowClosing(e);
            }
        });
        this.getContentPane().setLayout(gridBagLayout1);

        jSplitPanel.setMinimumSize(new Dimension(250, 250));
        jSplitPanel.setDividerSize(3);
        jSplitPanel.setBorder(null);
        previewPanel.setLayout(gridBagLayout2);
        cornerPanel1.setBackground(DrawingConstants.BACKGROUND_COLOR);
        cornerPanel2.setBackground(DrawingConstants.BACKGROUND_COLOR);

        previewTree = new JTree();
        previewTree.setModel(dataContainer.getTreeModel());
        previewTree.setCellRenderer(dataContainer.getTreeCellRenderer());
        previewTree.getSelectionModel().setSelectionMode(TreeSelectionModel.
              SINGLE_TREE_SELECTION);
        previewTree.addMouseListener(dataContainer.getMouseListener(previewTree));

        jMenu1.setText("File");
        closeSniffer.setText("Close Sniffer");
        closeSniffer.addActionListener(new ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                closeSniffer_actionPerformed(e);
            }
        });
        showContainerGUI_MenuItem.setText("Show agent container GUI");
        showContainerGUI_MenuItem.addActionListener(new ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                showContainerGUI_MenuItem_actionPerformed(e);
            }
        });
        jMenu2.setText("About");
        jMenuItem1.setText("About Sniffer");
        jMenuItem1.addActionListener(new ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                aboutItem_actionPerformed(e);
            }
        });
        statusPanel.setLayout(gridBagLayout3);
        jLabel1.setText("Message history buffer:");
        historyUsed.setText("0");
        maxHistory.setText("/0");
        jLabel3.setText("Total sniffed messages:");
        parsedMsg.setVerifyInputWhenFocusTarget(true);
        parsedMsg.setText("0");
        option_MenuItem.setText("Options");
        option_MenuItem.addActionListener(new ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                option_MenuItem_actionPerformed(e);
            }
        });
        jMenuBar1.add(jMenu1);
        jMenuBar1.add(jMenu2);
        jMenu1.add(showContainerGUI_MenuItem);
        jMenu1.addSeparator();
        jMenu1.add(option_MenuItem);
        jMenu1.addSeparator();
        jMenu1.add(closeSniffer);

        this.getContentPane().add(jSplitPanel,
                                  new GridBagConstraints(0, 1, 1, 1, 0.1, 0.1
              , GridBagConstraints.CENTER, GridBagConstraints.BOTH,
              new Insets(0, 0, 0, 0), 0, 0));
        jSplitPanel.add(previewPanel, JSplitPane.LEFT);
        previewPanel.add(previewScrollPanel,
                         new GridBagConstraints(0, 0, 1, 1, 0.1, 0.1
                                                , GridBagConstraints.CENTER,
                                                GridBagConstraints.BOTH,
                                                new Insets(0, 0, 0, 0), 0, 0));
        jSplitPanel.add(detailedScrollPanel, JSplitPane.RIGHT);
        this.getContentPane().add(statusPanel,
                                  new GridBagConstraints(0, 2, 1, 1, 0.1, 0.0
              , GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
              new Insets(0, 0, 0, 0), 0, 0));
        detailedScrollPanel.getViewport().add(detailMainPanel, null);
        previewScrollPanel.getViewport().add(previewTree, null);
        jMenu2.add(jMenuItem1);
        statusPanel.add(jLabel1, new GridBagConstraints(4, 0, 1, 1, 0.0, 0.0
              , GridBagConstraints.CENTER, GridBagConstraints.NONE,
              new Insets(0, 0, 0, 5), 0, 0));
        statusPanel.add(historyUsed,
                        new GridBagConstraints(5, 0, 1, 1, 0.0, 0.0
                                               , GridBagConstraints.CENTER,
                                               GridBagConstraints.NONE,
                                               new Insets(0, 0, 0, 0), 0, 0));
        statusPanel.add(maxHistory, new GridBagConstraints(6, 0, 1, 1, 0.0, 0.0
              , GridBagConstraints.CENTER, GridBagConstraints.NONE,
              new Insets(0, 0, 0, 15), 0, 0));
        statusPanel.add(jLabel3, new GridBagConstraints(7, 0, 1, 1, 0.0, 0.0
              , GridBagConstraints.CENTER, GridBagConstraints.NONE,
              new Insets(0, 0, 0, 5), 0, 0));
        statusPanel.add(parsedMsg, new GridBagConstraints(8, 0, 1, 1, 0.1, 0.0
              , GridBagConstraints.WEST, GridBagConstraints.NONE,
              new Insets(0, 0, 0, 0), 0, 0));
        detailedScrollPanel.setColumnHeaderView(detailHeaderPanel);
        detailedScrollPanel.setRowHeaderView(leftHeaderPanel);
        detailedScrollPanel.setCorner(JScrollPane.UPPER_RIGHT_CORNER,
                                      cornerPanel1);
        detailedScrollPanel.setCorner(JScrollPane.UPPER_LEFT_CORNER,
                                      cornerPanel2);
    }

    /**
     * @param e
     */
    void closeSniffer_actionPerformed(ActionEvent e) {
        owner.close_gui();
    }

    /**
     * @param e
     */
    void showContainerGUI_MenuItem_actionPerformed(ActionEvent e) {
        owner.showContainerGUI();
    }

    /**
     * @param e
     */
    void aboutItem_actionPerformed(ActionEvent e) {
        if (aboutWindow == null)
            aboutWindow = new AboutGUI();
        aboutWindow.setVisible(true);
    }

    /**
     * @param e
     */
    void this_windowClosed(WindowEvent e) {
        owner.close_gui();
    }

    /**
     * @param e
     */
    void this_windowClosing(WindowEvent e) {
        owner.close_gui();
    }

    /**
     * @param e
     */
    void option_MenuItem_actionPerformed(ActionEvent e) {
        OptionGUI options = new OptionGUI(this);
//    options.show();
        options.setVisible(true);
    }

}

