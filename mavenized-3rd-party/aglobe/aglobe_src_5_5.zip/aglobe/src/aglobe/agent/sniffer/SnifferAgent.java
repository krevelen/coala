package aglobe.agent.sniffer;

import javax.swing.*;

import aglobe.container.*;
import aglobe.container.agent.*;
import aglobe.container.transport.*;
import aglobe.ontology.*;
import java.util.regex.Pattern;
import aglobe.util.*;
import aglobe.container.AgentContainer.CommandService;
import aglobe.service.link.LinkService;
import aglobe.service.link.LinkNeighbourListener;
import aglobe.service.link.LinkMessageCopyListener;
import aglobe.service.sniffer.SnifferService;
import aglobe.service.topics.ContainerHandler;
import aglobe.service.topics.ContainerMonitor;
import aglobe.service.topics.TopicsHandler;
import aglobe.service.topics.TopicsService;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: This agent provides discovering the flow of messages. </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.54 $ $Date: 2010/08/04 11:48:05 $
 */
public class SnifferAgent
      extends Agent {
    private static final long serialVersionUID = 1508037500964083852L;

    /**
     * Sniffer version
     */
    final static String SNIFFER_VERSION = "1.2";

    /**
     * Agent's GUI.
     */
    public SnifferGUI gui;

    private TopicsService.Shell topicsShell = null;
    private ContainerMonitor containerMonitor = null;

    /**
     * Link service shell
     */
    private LinkService.Shell link = null;

    /**
     * Agent's <code>DataContainer</code>. It contains list of agents and
     * containers etc.
     */
    private DataContainer dataContainer;

    /**
     * Max message history length
     */
    int msgHistoryLength;

    /**
     * Default max message history length
     */
    private final static int MSG_HISTORY_LENGTH_DEFAULT = 4000;

    /**
     * Msg history length store key name
     */
    private final static String MSG_HISTORY_LENGTH_NAME =
          "MSG_HISTORY_LENGTH_NAME";

    /**
     * Current address filter
     */
    String addressFilter;

    /**
     * Current address filter pattern
     */
    Pattern addressFilterPattern;

    /**
     * Default address filter
     */
    private final static String ADDRESS_FILTER_DEFAULT = "(agent|others)";

    /**
     * Address filter store key name
     */
    private final static String ADDRESS_FILTER_NAME = "ADDRESS_FILTER";

    /**
     * Agent's store
     */
    transient private Store store;

    /**
     * Command service shell
     */
    private CommandService.Shell cshell;

    /**
     * Initialization of the agent.
     *
     * @param a AgentInfo
     * @param initState int
     */
    @SuppressWarnings("serial")
    @Override
    public void init(AgentInfo a, int initState) {

        // Load settings
        store = getContainer().getAgentStore(getName());
        msgHistoryLength = store.getInt(MSG_HISTORY_LENGTH_NAME,
                                        MSG_HISTORY_LENGTH_DEFAULT);
        addressFilter = store.getString(ADDRESS_FILTER_NAME,
                                        ADDRESS_FILTER_DEFAULT);
        addressFilterPattern = Pattern.compile(addressFilter,
                                               Pattern.CASE_INSENSITIVE);

        // create gui
        dataContainer = new DataContainer(this);
        try {
            SwingUtilities.invokeAndWait(new Runnable() {
                @Override
				public void run() {
                    gui = new SnifferGUI(SnifferAgent.this, dataContainer);
                }
            });
            SwingUtilities.invokeLater(new Runnable() {
                @Override
				public void run() {
                    gui.maxHistory.setText("/" + msgHistoryLength);
                }
            });
        }
        catch (Exception ex) {
            logSevere("Cannot create GUI due to: " + ex +
                      "\nSniffer will be stopped.");
            stop();
            return;
        }

        topicsShell = (TopicsService.Shell) getContainer().getServiceManager().getService(this, TopicsService.SERVICENAME);
        if (topicsShell == null) {
            link = (LinkService.Shell) getContainer().getServiceManager().
                  getService(this, LinkService.SERVICENAME);
            if (link == null) {
                logSevere("Neither TopicsService nor LinkService not running");
                stop();
                return;
            }
            else {
                link.subscribeNeighbour(new LinkNeighbourListener() {
                    @Override
					public void handleRegister(Address containerAddress) {
                        loginContainer(containerAddress);
                    }

                    @Override
					public void handleDeregister(Address containerAddress) {
                        logoutContainer(containerAddress.getContainerName());
                    }

                    @Override
					public void addEvent(Runnable e) {
                        SnifferAgent.this.addEvent(e);
                    }
                });
                link.subsribeMessageCopy(new LinkMessageCopyListener() {
                    @Override
					public final void handleMessageCopy(final Message originalMessage) {
                        try {
                            incomingMessageCopy(originalMessage);
                        }
                        catch (Exception ex) {
                        }
                    }

                    @Override
					public final void addEvent(final Runnable e) {
                        SnifferAgent.this.addEvent(e);
                    }
                });
            }
        } else {
            try {
                containerMonitor = new ContainerMonitor(this, new ContainerHandler() {

                    @Override
                    public void containerFinished(String containerName) {
                        logoutContainer(containerName);
                    }

                    @Override
                    public void containerStarted(Address containerAddress) {
                        loginContainer(containerAddress);
                    }

                });
            } catch (Exception e1) {
                logSevere(ExceptionPrinter.toStringWithStackTrace(e1));
            }
            topicsShell.subscribeHandlerAsync(SnifferService.TOPIC_OUTGOING_MESSAGE_COPY, new TopicsHandler() {

                @Override
                public void handleIncomingTopic(final String topic, final Object content, final String reason) {
                    try {
                        incomingMessageCopy((Message)content);
                    }
                    catch (Exception ex) {
                        logWarning("Problem with getting message copy: " + ExceptionPrinter.toStringWithStackTrace(ex) +
                                   "\nOrginal content: " + content);
                    }
                }

                @Override
                public void addEvent(final Runnable e) {
                    SnifferAgent.this.addEvent(e);
                }

            });
        }

        cshell = (CommandService.Shell) getContainer().getServiceManager().
              getService(null, AgentContainer.COMMANDSERVICE);

    }

    /**
     * Method stops the agent.
     */
    @Override
    protected void finish() {
        if (containerMonitor != null) {
            containerMonitor.dispose();
            containerMonitor = null;
        }
        if (topicsShell != null) {
            topicsShell.dispose();
            topicsShell = null;
        }
        if (gui != null) {
            gui.setVisible(false);
        }
    }

    /**
     * Agent's message handler. There are no messages expected.
     * @param m a message
     */
    @Override
	public void handleIncomingMessage(Message m) {
        logSevere("Unexpected message: " + m.toString());
        m.release();
    }

    /**
     * This method registers a container to be watched.
     *
     * @param containerAddress Address
     */
    private void loginContainer(final Address containerAddress) {
        dataContainer.loginContainer(containerAddress);
    }

    /**
     * This method deregister a watched container.
     *
     * @param containerName String
     */
    private void logoutContainer(final String containerName) {
        dataContainer.logoutContainer(containerName);
    }

    private final void incomingMessageCopy(final Message m) {
        if (m.isMulticast()) {
            // multicast message is just inserted couple of times with particular receivers
            for (Address receiver : m.getReceivers()) {
                Message unicastMessage = (Message) m.clone();
                unicastMessage.setReceiver(receiver);
                dataContainer.incomingMessageCopy(unicastMessage);
            }
            // release the original
            m.release();
            return;
        } else {
            dataContainer.incomingMessageCopy(m);
        }
//    SwingUtilities.invokeLater(new Runnable() {
//      public void run() {
//        JScrollBar vert = gui.detailedScrollPanel.getVerticalScrollBar();
//        vert.setValue(vert.getMaximum() - vert.getVisibleAmount());
//      }
//    });
    }

    /**
     * The method kills the agent.
     */
    void close_gui() {
        kill();
    }

    /**
     * The method shows GUI of the container where the agent runs.
     */
    void showContainerGUI() {
        if (cshell != null) {
            Command c = new Command();
            c.setName(AgentContainer.CommandService.GUI);
            c.getAglobeParam().add(AglobeXMLtools.makeAglobeParam(
                  AgentContainer.CommandService.VISIBLE, Boolean.toString(true)));
            cshell.execute(c);
        }
    }


    /**
     * updateMsgHistoryLength
     *
     * @param newMsgHistoryLength int
     */
    void updateMsgHistoryLength(int newMsgHistoryLength) {
        // save changes
        msgHistoryLength = newMsgHistoryLength;
        store.putInt(MSG_HISTORY_LENGTH_NAME, msgHistoryLength);

        if (gui != null) {
            //update gui
            SwingUtilities.invokeLater(new Runnable() {
                @Override
				public void run() {
                    gui.maxHistory.setText("/" + msgHistoryLength);
                }
            });
        }

        //update history queue
        dataContainer.updateMsgHistoryLength();
    }

    /**
     * updateAddressFilter
     *
     * @param newAddressFilter String
     */
    void updateAddressFilter(String newAddressFilter) {
        // save changes
        addressFilter = newAddressFilter;
        store.putString(ADDRESS_FILTER_NAME, addressFilter);
        addressFilterPattern = Pattern.compile(addressFilter,
                                               Pattern.CASE_INSENSITIVE);
    }
}
