package aglobe.agent.sniffer;

import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.BasicStroke;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.*;

/**
 * <p>
 * Title: A-Globe
 * </p>
 * <p>
 * Description: Detail main panel of sniffer agent
 * </p>
 * <p>
 * Copyright: Copyright (c) 2003
 * </p>
 * <p>
 * Company: Gerstner Laboratory
 * </p>
 *
 * @author David Sislak
 * @version $Revision: 1.16 $ $Date: 2010/08/04 11:48:05 $
 */
class DetailMainPanel extends JPanel {
    private static final long serialVersionUID = -6303546570391728296L;

    private final DataContainer dataContainer;

    ACLMessageGUI aclMessageGUI = null;

    private long selectedMsg = -1;

    DetailMainPanel(DataContainer _dataContainer) {
        super();
        dataContainer = _dataContainer;
        setBackground(DrawingConstants.BACKGROUND_COLOR);
        addMouseListener(new myMouseListener(this));
        repaintThis();
    }

    void repaintThis() {
        synchronized (dataContainer) {
            setPreferredSize(new Dimension(DrawingConstants.SPACE_BETWEEN_ACTORS * (dataContainer.filteredObjects.size()),
                    DrawingConstants.SPACE_BETWEEN_MESSAGES * (dataContainer.filteredMsg.size() + 1)));
        }
        revalidate();
        repaint();
    }

    void repaintLastMessage() {
        synchronized (dataContainer) {
            setPreferredSize(new Dimension(DrawingConstants.SPACE_BETWEEN_ACTORS * (dataContainer.filteredObjects.size()),
                    DrawingConstants.SPACE_BETWEEN_MESSAGES * (dataContainer.filteredMsg.size() + 1)));
        }
        revalidate();
        repaint();
    }

    private void drawMessage(Graphics2D g, int x1, int y1, int x2, int y2) {
        g.drawLine(x1, y1, x2, y2);
        // draw arrow at the end of the line
        g.setStroke(DrawingConstants.REGULAR_MESSAGE_STROKE);
        int direction = ((x2 < x1) ? 1 : -1) * DrawingConstants.ARROW_LENGTH;
        g.drawLine(x2, y2, x2 + direction, y2 + DrawingConstants.ARROW_WIDTH);
        g.drawLine(x2, y2, x2 + direction, y2 - DrawingConstants.ARROW_WIDTH);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        Rectangle currentClip = g2.getClipBounds();
        g2.setStroke(new BasicStroke(DrawingConstants.ACTOR_LINE_WIDTH));
        g2.setColor(DrawingConstants.ACTOR_LINE_COLOR);
        int msgNumFrom = (int) Math.round((double) currentClip.y / (double) DrawingConstants.SPACE_BETWEEN_MESSAGES) - 1;
        int msgNumTo = (int) Math.floor((double) currentClip.height / (double) DrawingConstants.SPACE_BETWEEN_MESSAGES) + 1 + msgNumFrom;
        if (msgNumFrom < 0)
            msgNumFrom = 0;
        int x, y;

        synchronized (dataContainer) {
            int actorCnt = dataContainer.filteredObjects.size();
            int msgCnt = dataContainer.filteredMsg.size();
            y = (msgCnt + 1) * DrawingConstants.SPACE_BETWEEN_MESSAGES;
            for (int k = 0; k < actorCnt; k++) {
                x = DrawingConstants.FIRST_ACTOR_X_POSITION + k * DrawingConstants.SPACE_BETWEEN_ACTORS;
                g2.drawLine(x, 0, x, y);
            }

            if (msgNumTo >= msgCnt)
                msgNumTo = msgCnt - 1;
            for (int k = msgNumFrom; k <= msgNumTo; k++) {
                DataContainer.FilteredMessageCover mc = dataContainer.filteredMsg.get(k);
                g2.setColor(mc.msgCover.messageColor);
                if (mc.msgCover.undeliverable)
                    g2.setStroke((mc.msgCover.msgId != selectedMsg) ? DrawingConstants.INACCESSIBLE_MESSAGE_STROKE
                            : DrawingConstants.SELECTED_INACCESSIBLE_MESSAGE_STROKE);
                else
                    g2.setStroke((mc.msgCover.msgId != selectedMsg) ? DrawingConstants.REGULAR_MESSAGE_STROKE
                            : DrawingConstants.SELECTED_REGULAR_MESSAGE_STROKE);

                y = (k + 1) * DrawingConstants.SPACE_BETWEEN_MESSAGES;
                drawMessage(g2, DrawingConstants.FIRST_ACTOR_X_POSITION + mc.fromPosition * DrawingConstants.SPACE_BETWEEN_ACTORS, y,
                        DrawingConstants.FIRST_ACTOR_X_POSITION + mc.toPosition * DrawingConstants.SPACE_BETWEEN_ACTORS, y);
            }
        }
    }

    private void parseMouseClick(int x, int y) {
        synchronized (dataContainer) {
            int msgCnt = dataContainer.filteredMsg.size();
            int _selectedMsg = (int) Math.round((double) y / (double) DrawingConstants.SPACE_BETWEEN_MESSAGES) - 1;
            if (_selectedMsg < 0 || _selectedMsg >= msgCnt) {
                selectedMsg = -1;
                repaint();
                showACLMessage(null);
                return;
            }
            DataContainer.FilteredMessageCover mc = dataContainer.filteredMsg.get(_selectedMsg);
            int left, right;
            if (mc.fromPosition < mc.toPosition) {
                left = mc.fromPosition * DrawingConstants.SPACE_BETWEEN_ACTORS + DrawingConstants.FIRST_ACTOR_X_POSITION;
                right = mc.toPosition * DrawingConstants.SPACE_BETWEEN_ACTORS + DrawingConstants.FIRST_ACTOR_X_POSITION;
            } else {
                right = mc.fromPosition * DrawingConstants.SPACE_BETWEEN_ACTORS + DrawingConstants.FIRST_ACTOR_X_POSITION;
                left = mc.toPosition * DrawingConstants.SPACE_BETWEEN_ACTORS + DrawingConstants.FIRST_ACTOR_X_POSITION;
            }
            if (x < left || x > right) {
                selectedMsg = -1;
                repaint();
                showACLMessage(null);
                return;
            }
            selectedMsg = mc.msgCover.msgId;
            repaint();
            showACLMessage(mc.msgCover);
        }
    }

    void setSelectedMsg(final long selectedMsgId) {
        this.selectedMsg = selectedMsgId;
        repaint();
    }

    void showACLMessage(final DataContainer.MessageCover mc) {
        if (mc == null && aclMessageGUI != null) {
            aclMessageGUI.showGUI(false);
            return;
        }
        if (mc == null)
            return;
        if (aclMessageGUI == null)
            aclMessageGUI = new ACLMessageGUI(this);
        /** @todo vyhledat celou konverzaci, a posilat array **/
        ArrayList<DataContainer.MessageCover> mcs = new ArrayList<DataContainer.MessageCover>();
        mcs.add(mc);
        int cur = 0;
        String convId = mc.msg.getConversationID();
        if (convId != null) {
            ArrayList<DataContainer.MessageCover> next = new ArrayList<DataContainer.MessageCover>();
            for (Iterator<DataContainer.FilteredMessageCover> iter = dataContainer.filteredMsg.iterator(); iter.hasNext();) {
                DataContainer.FilteredMessageCover item = iter.next();
                if (item.msgCover != mc && convId.equals(item.msgCover.msg.getConversationID())) {
                    next.add(item.msgCover);
                }
            }
            // sort conversation
            // find all before the message
            String inReplyTo = mc.msg.getInReplyTo();
            boolean stop = false;
            boolean found;
            int i;
            while (!stop && (inReplyTo != null)) {
                found = false;
                for (i = 0; i < next.size(); i++) {
                    if (inReplyTo.equals((next.get(i)).msg.getReplyWith())) {
                        found = true;
                        break;
                    }
                }
                if (found) {
                    DataContainer.MessageCover p = next.remove(i);
                    mcs.add(0, p);
                    cur++;
                    inReplyTo = p.msg.getInReplyTo();
                } else {
                    stop = true;
                }
            }
            // all conversation after selected message

            String replyWith = mc.msg.getReplyWith();
            if (replyWith != null) {
                stop = false;
                while (!stop) {
                    found = false;
                    for (i = 0; i < next.size(); i++) {
                        if (replyWith.equals((next.get(i)).msg.getInReplyTo())) {
                            found = true;
                            break;
                        }
                    }
                    if (found) {
                        DataContainer.MessageCover p = next.remove(i);
                        mcs.add(p);
                        replyWith = p.msg.getReplyWith();
                    } else {
                        stop = true;
                    }
                }
            }

        }
        aclMessageGUI.setACLMessage(mcs.toArray(new DataContainer.MessageCover[mcs.size()]), cur);
        aclMessageGUI.showGUI(true);
    }

    void clearSelection() {
        selectedMsg = -1;
        repaint();
    }

    void hideACLMessageWindow() {
        if (aclMessageGUI != null)
            aclMessageGUI.showGUI(false);
    }

    static class myMouseListener implements MouseListener {
        private final DetailMainPanel owner;

        myMouseListener(DetailMainPanel _owner) {
            owner = _owner;
        }

        @Override
		public void mouseClicked(MouseEvent e) {
            if (e.getButton() == MouseEvent.BUTTON1 && e.getClickCount() >= 2) {
                owner.parseMouseClick(e.getX(), e.getY());
            }
        }

        @Override
		public void mousePressed(MouseEvent e) {
        }

        @Override
		public void mouseReleased(MouseEvent e) {
        }

        @Override
		public void mouseEntered(MouseEvent e) {
        }

        @Override
		public void mouseExited(MouseEvent e) {
        }
    }
}
