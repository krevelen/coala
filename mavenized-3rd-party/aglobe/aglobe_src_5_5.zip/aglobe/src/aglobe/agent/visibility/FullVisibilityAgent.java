package aglobe.agent.visibility;

import java.util.LinkedHashMap;

import aglobe.container.agent.Agent;
import aglobe.container.transport.Address;
import aglobe.ontology.AgentInfo;
import aglobe.ontology.Message;
import aglobe.ontology.VisibilityUpdate;
import aglobe.ontology.VisibilityUpdate.VisibilityUpdateType;
import aglobe.service.topics.ContainerHandler;
import aglobe.service.topics.ContainerMonitor;
import aglobe.service.topics.TopicsService;
import aglobe.service.visibility.VisibilityService;
import aglobe.util.ExceptionPrinter;

/**
 * <p>
 * Title: A-Globe
 * </p>
 * <p>
 * Description: Full Visibility Agent. The agent ensures full visibility between
 * the containers. It can runs only on the master container.
 * </p>
 * <p>
 * Copyright: Copyright (c) 2003
 * </p>
 * <p>
 * Company: Gerstner Laboratory
 * </p>
 *
 * @author Stepan Urban, Jan Tozicka, rewritten by David Sislak
 * @version $Revision: 1.14 $ $Date: 2010/08/04 11:48:05 $
 *
 */
// Based on the matrix visibility agent
public class FullVisibilityAgent extends Agent {

    private static final long serialVersionUID = -3391327249008550564L;

    /**
     * Visibility update ID
     */
    long visibilityID = 1;

    private TopicsService.Shell topicsShell = null;
    private ContainerMonitor containerMonitor = null;

    private final LinkedHashMap<String, Address> logged_containers = new LinkedHashMap<String, Address>();

    /**
     * Public empty constructor.
     */
    public FullVisibilityAgent() {
    }

    /**
     * Initialization of the agent.
     *
     * @param a
     *            AgentInfo
     * @param initState
     *            int
     */
    @SuppressWarnings("serial")
    @Override
    public void init(AgentInfo a, int initState) {
        topicsShell = (TopicsService.Shell) getContainer().getServiceManager().getService(this, TopicsService.SERVICENAME);
        if (topicsShell == null) {
            logWarning("TopicsService not running");
            stop();
            return;
        }
        try {
            containerMonitor = new ContainerMonitor(this, new ContainerHandler() {

                @Override
                public void containerFinished(final String containerName) {
                    logoutContainer(containerName);
                }

                @Override
                public void containerStarted(final Address containerAddress) {
                    loginContainer(containerAddress);
                }

            });
        } catch (Exception e) {
            logSevere(ExceptionPrinter.toStringWithStackTrace(e));
        }
    }

    /**
     * This method stops the agent.
     */
    @Override
    protected void finish() {
        if (containerMonitor != null) {
            containerMonitor.dispose();
            containerMonitor = null;
        }
        if (topicsShell != null) {
            topicsShell.dispose();
            topicsShell = null;
        }
    }

    /**
     * This method handles incoming message.
     *
     * @param m
     *            Message
     */
    @Override
	public void handleIncomingMessage(Message m) {
        logWarning("Unexpected message: " + m.toString());
        m.release();
    }

    /**
     * This method registers a new container.
     *
     * @param vp
     *            a <code>VisibleContainer</code>
     */

    private final void loginContainer(final Address vp) {
        // send full list to new container
        final VisibilityUpdate nfo = VisibilityUpdate.getInstance();
        nfo.setVisibilityID(visibilityID);
        nfo.getVisibleContainerAddress().addAll(logged_containers.values());
        topicsShell.sendTopic(VisibilityService.TOPIC_VISIBILITY_UPDATES_PREFIX+ vp.getContainerName(), nfo);
        nfo.release();

        // distribute differential to all others
        distributeDifferentialUpdate(vp.deriveContainerAddress(), VisibilityUpdateType.DIFFERENTIAL_ADD);

        logged_containers.put(vp.getContainerName(), vp.deriveContainerAddress());

        // increment visibility ID
        visibilityID++;
    }

    /**
     * This method logs out a container by its name.
     *
     * @param containeName
     *            Name of the container to be logged out.
     */
    private final void logoutContainer(final String containeName) {
        final Address vp = logged_containers.remove(containeName);

        // distribute differential to all others
        distributeDifferentialUpdate(vp, VisibilityUpdateType.DIFFERENTIAL_REMOVE);

        // increment visibility ID
        visibilityID++;
    }

    private final void distributeDifferentialUpdate(final Address changed, final VisibilityUpdate.VisibilityUpdateType changeType) {
        final VisibilityUpdate nfo = VisibilityUpdate.getInstance();
        nfo.setVisibilityID(visibilityID);
        nfo.getVisibleContainerAddress().add(changed);
        nfo.setVisibilityUpdateType(changeType);
        topicsShell.sendTopic(VisibilityService.TOPIC_VISIBILITY_UPDATES_ALL, nfo);
        nfo.release();
    }

}
