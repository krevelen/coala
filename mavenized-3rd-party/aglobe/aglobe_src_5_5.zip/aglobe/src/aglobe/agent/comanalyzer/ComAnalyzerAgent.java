package aglobe.agent.comanalyzer;

import aglobe.container.agent.*;
import aglobe.container.transport.*;
import aglobe.ontology.*;
import javax.swing.SwingUtilities;
import aglobe.service.link.LinkService;
import aglobe.service.link.LinkNeighbourListener;
import aglobe.service.link.LinkMessageCopyListener;
import aglobe.service.sniffer.SnifferService;
import aglobe.service.topics.ContainerHandler;
import aglobe.service.topics.ContainerMonitor;
import aglobe.service.topics.TopicsHandler;
import aglobe.service.topics.TopicsService;
import aglobe.util.ExceptionPrinter;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: This agent visualizes communication between agents and/or services.
 * Does not support migration.</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author Dusan Pavlicek
 * @version $Revision: 1.31 $ $Date: 2010/08/04 11:48:05 $
 */
public class ComAnalyzerAgent extends Agent {

    private static final long serialVersionUID = 7608648940149528289L;

    /**
     *  ComAnalyzer agent gui
     */
    public ComAnalyzerAgentGUI gui;

    /**
     * Data container
     */
    private DataContainer dataContainer;

    private TopicsService.Shell topicsShell = null;
    private ContainerMonitor containerMonitor = null;

    /**
     * Link service shell
     */
    private LinkService.Shell link = null;

    /**
     * Initialization of the agent.
     * @param a AgentInfo
     * @param initState int
     */
    @SuppressWarnings("serial")
    @Override
    public void init(AgentInfo a, int initState) {
        try {
            SwingUtilities.invokeAndWait(new Runnable() {
                @Override
				public void run() {
                    gui = new ComAnalyzerAgentGUI(ComAnalyzerAgent.this);
                }
            });
        } catch (Exception ex) {
            logSevere("Cannot create gui due to: " + ex +
                      "\nComAnalyzer will be stopped.");
            stop();
            return;
        }
        dataContainer = new DataContainer(this);
        gui.setDataContainer(dataContainer);

        topicsShell = (TopicsService.Shell) getContainer().getServiceManager().getService(this, TopicsService.SERVICENAME);
        if (topicsShell == null) {
            link = (LinkService.Shell) getContainer().getServiceManager().getService(this, LinkService.SERVICENAME);
            if (link == null) {
                logSevere("TopicsService not running");
                stop();
                return;
            } else {
                link.subscribeNeighbour(new LinkNeighbourListener() {
                    @Override
					public void handleRegister(Address containerAddress) {
                        loginContainer(containerAddress.getContainerName(), containerAddress);
                    }

                    @Override
					public void handleDeregister(Address containerAddress) {
                        logoutContainer(containerAddress.getContainerName());
                    }

                    @Override
					public void addEvent(Runnable e) {
                        ComAnalyzerAgent.this.addEvent(e);
                    }
                });
                link.subsribeMessageCopy(new LinkMessageCopyListener() {
                    @Override
					public final void handleMessageCopy(final Message originalMessage) {
                        try {
                            incomingMessageCopy(originalMessage);
                        } catch (Exception ex) {
                        }
                    }

                    @Override
					public final void addEvent(final Runnable e) {
                        ComAnalyzerAgent.this.addEvent(e);
                    }
                });
            }
        } else {
            try {
                containerMonitor = new ContainerMonitor(this, new ContainerHandler() {

                    @Override
                    public void containerFinished(final String containerName) {
                        logoutContainer(containerName);
                    }

                    @Override
                    public void containerStarted(final Address containerAddress) {
                        loginContainer(containerAddress.getContainerName(), containerAddress);                }

                });
            } catch (Exception e1) {
                logSevere(ExceptionPrinter.toStringWithStackTrace(e1));
            }

            topicsShell.subscribeHandlerAsync(SnifferService.TOPIC_OUTGOING_MESSAGE_COPY, new TopicsHandler() {

                @Override
                public void handleIncomingTopic(final String topic, final Object content, final String reason) {
                    try {
                        incomingMessageCopy((Message)content);
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        logWarning("Problem with getting message copy: " + ex +
                                   "\nOriginal content: " + (String) content);
                    }
                }

                @Override
                public void addEvent(final Runnable e) {
                    ComAnalyzerAgent.this.addEvent(e);
                }

            });
        }
    }



    /* (non-Javadoc)
     * @see aglobe.container.ElementaryEntity#finish()
     */
    @Override
    protected void finish() {
        if (containerMonitor != null) {
            containerMonitor.dispose();
            containerMonitor = null;
        }
        if (topicsShell != null) {
            topicsShell.dispose();
            topicsShell = null;
        }
        if (link != null) {
            link.dispose();
            link = null;
        }
        super.finish();
    }



    /**
     * Kill itself
     */
    void killSelf() {
        this.kill();
    }

    /**
     * Returns communication analyzer gui
     * @return ComAnalyzerAgentGUI
     */
    ComAnalyzerAgentGUI getGUI() {
        return gui;
    }

    /**
     * This method handles a container's login to the system.
     * @param containerName String
     * @param containerAddress Address
     */
    private void loginContainer(final String containerName, final Address containerAddress) {
        dataContainer.loginContainer(containerName, containerAddress);
    }

    /**
     * This method handles a container's logout from the system.
     * @param containerName String
     */
    private void logoutContainer(final String containerName) {
        dataContainer.logoutContainer(containerName);
    }

    /**
     * This method handles a message sent between agents/services.
     * @param m Message
     * @param undeliverable boolean
     */
    private void incomingMessageCopy(final Message m) {
        if (m.isUndeliverable()) {
            m.release();
            return;
        }
        if (m.isMulticast()) {
            logWarning("Multicast message are not supported yet");
            m.release();
        } else {
            dataContainer.incomingMessageCopy(m);
        }
    }

    /**
     * Agent's message handler. There are no messages expected.
     * @param m Message
     */
    @Override
	public void handleIncomingMessage(Message m) {
        logSevere("Unexpected message: " + m.toString());
        m.release();
    }

}
