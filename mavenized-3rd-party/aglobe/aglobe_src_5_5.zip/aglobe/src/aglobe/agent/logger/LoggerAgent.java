package aglobe.agent.logger;

import aglobe.container.agent.Agent;
import aglobe.ontology.Message;
import aglobe.ontology.AgentInfo;
import javax.swing.SwingUtilities;

import aglobe.service.topics.TopicsHandler;
import aglobe.service.topics.TopicsService;
import aglobe.util.Logger;
import aglobe.util.logging.LogRecord;

/**
 * <p>Title: multi-agent platform A-globe</p>
 *
 * <p>Description: Logger window presents all log messages from the whole distributed multi-agent system at one
 * place. There are all log messages logged by set of log... methods of agents or services.</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Agent Technology Center, Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.15 $ $Date: 2010/08/04 11:48:05 $
 */
public class LoggerAgent extends Agent {
    private static final long serialVersionUID = 4726528272414702542L;

    private TopicsService.Shell topicsShell = null;

    /**
     * GUI
     */
    public LoggerAgentGUI gui;

    /**
     * This method must be declared by the child class to handle an incoming
     * message.
     *
     * @param m The message.
     */
    @Override
	public void handleIncomingMessage(Message m) {
        logSevere("Unexpected incoming message: "+m);
        m.release();
    }

    /**
     * @internal
     * Agent's initialization method.
     *
     * @param ai Agent should get its name from there.
     * @param initState This parameter can be used if this method is
     *   Overridden. Can have values: isCREATED - an agent is created
     *   isRESTARTED - an agent is restarted from auto run configuration
     *   isMOVED - an agent is moved from another container isCLONED - an
     *   agent is cloned from its mother agent isMOVEFAILED - agent's
     *   movement was unsuccessful
     */
    @SuppressWarnings("serial")
    @Override
    public void init(AgentInfo ai, int initState) {
        try {
            SwingUtilities.invokeAndWait(new Runnable() {
                @Override
				public void run() {
                    try {
                        // create GUI
                        gui = new LoggerAgentGUI(LoggerAgent.this);
                    } catch (Exception ex) {
                        logWarning("Cannot create GUI due to: "+ex);
                    }
                }
            });
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        topicsShell = (TopicsService.Shell)getContainer().getServiceManager().getService(this, TopicsService.SERVICENAME);
        if (topicsShell == null) {
            logWarning("Can run only on a container with TopicsService.");
            stop();
        }
        topicsShell.subscribeHandlerAsync(Logger.TOPIC_LOGGER_MESSAGE, new TopicsHandler() {

            @Override
            public void handleIncomingTopic(final String topic, final Object content, final String reason) {
                if (gui != null) {
                    LogRecord lr = (LogRecord) content;
                    gui.addLogMessage(Logger.formatLogMessage(lr), lr.level.intValue());
                }
            }

            @Override
            public void addEvent(final Runnable e) {
                LoggerAgent.this.addEvent(e);
            }

        });
    }

     /**
     * This method should perform quick clean up (such as close opened files,
     * hide GUI etc.).
     *
     */
    @Override
    protected void finish() {
        if (topicsShell != null) {
            topicsShell.dispose();
            topicsShell = null;
        }
        if (gui != null) {
            gui.setVisible(false);
        }
    }

    /**
     * Called by gui if gui is closed
     */
    void closeGUI() {
        kill();
    }

}
