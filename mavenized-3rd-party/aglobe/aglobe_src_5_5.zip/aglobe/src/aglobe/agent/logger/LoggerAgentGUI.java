package aglobe.agent.logger;

import java.awt.GridBagLayout;
import java.awt.*;
import aglobe.container.Store;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import aglobe.util.gui.SearchableTextArea;
import aglobe.util.gui.RememberPositionJFrame;

/**
 * <p>Title: multi-agent platform A-globe</p>
 *
 * <p>Description: Logger agent graphics user interface window</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Agent Technology Center, Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.13 $ $Date: 2010/08/04 11:48:05 $
 */
class LoggerAgentGUI extends RememberPositionJFrame {
    private static final long serialVersionUID = 9018184704281847467L;

    /**
     * Owner agent
     */
    private final LoggerAgent owner;

    /**
     * Selectable levels
     */
    private final String[] levels = new String[]{"FINEST","FINER","FINE","CONFIG","INFO","WARNING","SEVERE"};

    /**
     * Selectable level translation
     */
    private final int[] levelTranslation = new int[]{300,400,500,700,800,900,1000};

    /**
     * Current selected level
     */
    private int currentSelectedLevel=0;

    private static final String LEVEL = "gui/level";

    GridBagLayout gridBagLayout1 = new GridBagLayout();
    SearchableTextArea jEditorPane1 = new SearchableTextArea(false,true);
    JLabel jLabel1 = new JLabel();
    JComboBox jComboBox1 = new JComboBox(levels);


    LoggerAgentGUI(LoggerAgent owner) {
        super(owner);
        this.owner = owner;
        try {
            jbInit();
            setSize(300,300);
            jComboBox1.setSelectedIndex(4);
            setVisible(true);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Save other window settings
     */
    @Override
    protected void saveWindowSettings() {
        store.putInt(LEVEL, jComboBox1.getSelectedIndex());
    }

    /**
     * Load other window settings
     */
    @Override
    protected void loadWindowSettings() {
        int level = jComboBox1.getSelectedIndex();
        level = store.getInt(LEVEL, level);
        jComboBox1.setSelectedIndex(level);
    }


    private void jbInit() throws Exception {
        this.getContentPane().setLayout(gridBagLayout1);
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                this_windowClosing(e);
            }

            @Override
            public void windowClosed(WindowEvent e) {
                this_windowClosing(e);
            }
        });
        jLabel1.setText("Show only specified level and higher:");
        jComboBox1.addActionListener(new ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                currentSelectedLevel = levelTranslation[jComboBox1.getSelectedIndex()];
                Store store = owner.getContainer().getAgentStore(owner.getName());
                store.putInt(LEVEL, jComboBox1.getSelectedIndex());
            }
        });
        this.getContentPane().add(jEditorPane1, new GridBagConstraints(0, 1, 3, 1, 1.0, 1.0
                , GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        this.getContentPane().add(jLabel1, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
                , GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 5, 5, 0), 0, 0));
        this.getContentPane().add(jComboBox1, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
                , GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 5, 5, 0), 0, 0));
        setTitle("A-globe Agent&Service Distributed Logger");
    }


    /**
     * @param e
     */
    private void this_windowClosing(WindowEvent e) {
        owner.closeGUI();
    }

    /**
     * Add log message to the logger window
     * @param message String
     * @param logLevel int
     */
    void addLogMessage(final String message, final int logLevel) {
        if (logLevel >= currentSelectedLevel) {
            jEditorPane1.append(message + "\n");
        }
    }
}
