package aglobe.agent.dataanalyzer;

import javax.swing.JFrame;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.*;
import aglobe.platform.thread.AglobeThreadPool;

/**
 *
 * <p>Title: A-Globe Data Analyzer</p>
 *
 * <p>Description: A GUI (Graphics User Interface) for the Data Analyzer.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author Miroslav Uller
 *
 * @version 1.0
 */
public class DataAnalyzerGUI extends JFrame {
    private static final long serialVersionUID = -8983134585014709562L;
    private double minX = -1;
    private double maxX = 2;
    private double currentX = 0;
    private double period = 1;
    private double relativeStep = 0.1;
    private double zoomFactor = 1.3;

    /**
     * True, if the graph view automatically adjusts to current time.
     */
    private boolean running = false;

    /**
     * True, if at least one graph is visible.
     */
    private boolean somethingIsVisible = false;

    private Refresh timer = null;
    private DataAnalyzerAgent owner;
    public GraphSelectorGUI graphSelector;

    BorderLayout borderLayout1 = new BorderLayout();
    GraphComponent canvas = new GraphComponent();
    JPanel jPanel2 = new JPanel();
    JMenuBar jMenuBar1 = new JMenuBar();
    JMenu menuFile = new JMenu();
    JMenuItem itemSaveAs = new JMenuItem();
    JMenuItem itemExit = new JMenuItem();
    JButton btnRun = new JButton();
    JLabel staticText = new JLabel();
    JButton btnStart = new JButton();
    JButton btnEnd = new JButton();
    JButton btnBack = new JButton();
    JButton btnForward = new JButton();
    JButton btnZoomIn = new JButton();
    JButton btnZoomOut = new JButton();
    JMenu menuView = new JMenu();
    JMenu menuHelp = new JMenu();
    JMenuItem itemAbout = new JMenuItem();
    JMenuItem itemZoomIn = new JMenuItem();
    JMenuItem itemZoomOut = new JMenuItem();
    JMenuItem itemDefaultZoom = new JMenuItem();
    JMenuItem itemGoToStart = new JMenuItem();
    JMenuItem itemGoBack = new JMenuItem();
    JMenuItem itemGoForward = new JMenuItem();
    JMenuItem itemGoToEnd = new JMenuItem();
    JCheckBoxMenuItem itemSelect = new JCheckBoxMenuItem();
    JCheckBoxMenuItem itemLog = new JCheckBoxMenuItem();
    JCheckBoxMenuItem itemDescr = new JCheckBoxMenuItem();
    JCheckBoxMenuItem itemLines = new JCheckBoxMenuItem();

    /**
     * Updates the state of GUI components.
     */
    public void updateUI() {
        if(canvas.hasData()) {
            somethingIsVisible = true;
        } else {
            somethingIsVisible = false;
        }
        btnRun.setEnabled(somethingIsVisible);
        btnStart.setEnabled(somethingIsVisible && !running);
        btnEnd.setEnabled(somethingIsVisible && !running);
        btnBack.setEnabled(somethingIsVisible && !running);
        btnForward.setEnabled(somethingIsVisible && !running);
        btnZoomIn.setEnabled(somethingIsVisible && !running);
        btnZoomOut.setEnabled(somethingIsVisible && !running);
        staticText.setText("  "+String.format("%1$.1f", currentX)+" ("+String.format("%1$.1f", period)+")  ");
    }

    /**
     * Set the zoom to its default setting.
     */
    public void setDefaultZoom() {
        currentX = 0;
        period = 1;
        canvas.setXRange(currentX, currentX+period);
        updateUI();
    }

    /**
     * Sets the view to the start of the gathered data.
     */
    public void goToStart() {
        currentX = minX;
        canvas.setXRange(currentX, currentX+period);
        updateUI();
    }

    /**
     * Sets the view to the end of the gathered data.
     */
    public void goToEnd() {
        currentX = maxX - period;
        if(currentX < minX) currentX = minX;
        canvas.setXRange(currentX, currentX+period);
        updateUI();
    }

    /**
     * Scrolls the view forward.
     */
    public void goForward() {
        currentX += relativeStep*period;
        if(currentX > maxX - period) currentX = maxX - period;
        if(currentX < minX) currentX = minX;
        canvas.setXRange(currentX, currentX+period);
        updateUI();
    }

    /**
     * Scrolls the view backward.
     */
    public void goBack() {
        currentX -= relativeStep*period;
        if(currentX < minX) currentX = minX;
        canvas.setXRange(currentX, currentX+period);
        updateUI();
    }

    /**
     * Scrolls the view to the specified time.
     * @param x the time.
     */
    public void goTo(double x) {
        currentX = x;
        if(maxX < currentX + period) maxX = currentX + period;
        canvas.setXRange(currentX, currentX+period);
        updateUI();
    }

    /**
     * Zooms into the view.
     */
    public void zoomIn() {
        period/=zoomFactor;
        canvas.setXRange(currentX, currentX+period);
        updateUI();
    }

    /**
     * Zooms out of the view.
     */
    public void zoomOut() {
        period*=zoomFactor;
        if(currentX > maxX - period) currentX = maxX - period;
        if(currentX < minX) currentX = minX;
        canvas.setXRange(currentX, currentX+period);
        updateUI();
    }

    /**
     * Initializes the GUI.
     */
    public void init() {
        minX = 0;
        maxX = 1;
        currentX = 0;
        period = 10000;
        relativeStep = 0.3;
        zoomFactor = 1.3;

        running = false;
        somethingIsVisible = false;
        Graph.gc = canvas;
        graphSelector = new GraphSelectorGUI(owner);
        graphSelector.showGUI();
        itemLines.setState(true);
        itemDescr.setState(true);
        itemSelect.setState(true);
        itemLog.setState(false);
        updateUI();
    }


    /**
     * Class constructor.
     * @param owner the Data Analyzer.
     */
    public DataAnalyzerGUI(DataAnalyzerAgent owner) {
        this.owner = owner;
        try {
            jbInit();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        this.getContentPane().setLayout(borderLayout1);
        btnRun.setText("Run");
        btnRun.addActionListener(new DataAnalyzerGUI_btnRun_actionAdapter(this));
        staticText.setText("");
        btnStart.setText("|<");
        btnStart.addActionListener(new DataAnalyzerGUI_btnStart_actionAdapter(this));
        btnEnd.setText(">|");
        btnEnd.addActionListener(new DataAnalyzerGUI_btnEnd_actionAdapter(this));
        btnBack.setText("<");
        btnBack.addActionListener(new DataAnalyzerGUI_btnBack_actionAdapter(this));
        btnForward.setText(">");
        btnForward.addActionListener(new
                DataAnalyzerGUI_btnForward_actionAdapter(this));
        btnZoomIn.setText("+");
        btnZoomIn.addActionListener(new DataAnalyzerGUI_btnZoomIn_actionAdapter(this));
        btnZoomOut.setText("-");
        btnZoomOut.addActionListener(new
                DataAnalyzerGUI_btnZoomOut_actionAdapter(this));
        menuView.setText("View");
        menuHelp.setText("Help");
        itemAbout.setText("About...");
        itemAbout.addActionListener(new DataAnalyzerGUI_itemAbout_actionAdapter(this));
        itemZoomIn.setText("Zoom In");
        itemZoomIn.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.
                event.KeyEvent.VK_ADD, 0, false));
        itemZoomIn.addActionListener(new
                DataAnalyzerGUI_itemZoomIn_actionAdapter(this));
        itemZoomOut.setText("Zoom Out");
        itemZoomOut.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.
                event.KeyEvent.VK_SUBTRACT, 0, false));
        itemZoomOut.addActionListener(new
                DataAnalyzerGUI_itemZoomOut_actionAdapter(this));
        itemDefaultZoom.setText("Default zoom");
        itemDefaultZoom.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.
                awt.event.KeyEvent.VK_NUMPAD0, 0, false));
        itemDefaultZoom.addActionListener(new
                DataAnalyzerGUI_itemDefaultZoom_actionAdapter(this));
        itemGoToStart.setText("Go to start");
        itemGoToStart.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.
                event.KeyEvent.VK_B, java.awt.event.KeyEvent.CTRL_MASK, false));
        itemGoToStart.addActionListener(new
                DataAnalyzerGUI_itemGoToStart_actionAdapter(this));
        itemGoBack.setText("Go back");
        itemGoBack.setAccelerator(javax.swing.KeyStroke.getKeyStroke(',' , 0, false));
        itemGoBack.addActionListener(new
                DataAnalyzerGUI_itemGoBack_actionAdapter(this));
        itemGoForward.setText("Go forward");
        itemGoForward.setAccelerator(javax.swing.KeyStroke.getKeyStroke('.', 0, false));
        itemGoForward.addActionListener(new
                DataAnalyzerGUI_itemGoForward_actionAdapter(this));
        itemGoToEnd.setText("Go to end");
        itemGoToEnd.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.
                event.KeyEvent.VK_E, java.awt.event.KeyEvent.CTRL_MASK, false));
        itemGoToEnd.addActionListener(new
                DataAnalyzerGUI_itemGoToEnd_actionAdapter(this));
        itemSelect.setText("Select graphs");
        itemSelect.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.
                event.KeyEvent.VK_G, java.awt.event.KeyEvent.CTRL_MASK, false));
        itemSelect.addActionListener(new
                DataAnalyzerGUI_itemSelect_actionAdapter(this));
        itemLog.setText("System log");
        itemLog.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.
                event.KeyEvent.VK_O, java.awt.event.KeyEvent.CTRL_MASK, false));
        itemLog.addActionListener(new
                DataAnalyzerGUI_itemLog_actionAdapter(this));
        itemDescr.setText("Show descriptions");
        itemDescr.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.
                event.KeyEvent.VK_D, java.awt.event.KeyEvent.CTRL_MASK, false));
        itemDescr.addActionListener(new
                DataAnalyzerGUI_itemDescr_actionAdapter(this));
        itemLines.setText("Thick lines");
        itemLines.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.
                event.KeyEvent.VK_L, java.awt.event.KeyEvent.CTRL_MASK, false));
        itemLines.addActionListener(new
                DataAnalyzerGUI_itemLines_actionAdapter(this));
        itemSaveAs.addActionListener(new
                DataAnalyzerGUI_itemSaveAs_actionAdapter(this));
        itemExit.addActionListener(new DataAnalyzerGUI_itemExit_actionAdapter(this));
        this.addWindowListener(new DataAnalyzerGUI_this_windowAdapter(this));
        this.getContentPane().add(jPanel2, java.awt.BorderLayout.SOUTH);
        jPanel2.add(btnRun);
        jPanel2.add(btnStart);
        jPanel2.add(btnBack);
        jPanel2.add(staticText);
        jPanel2.add(btnForward);
        jPanel2.add(btnEnd);
        jPanel2.add(btnZoomIn);
        jPanel2.add(btnZoomOut);
        this.setJMenuBar(jMenuBar1);
        this.getContentPane().add(canvas, java.awt.BorderLayout.CENTER);
        menuFile.setText("File");
        itemSaveAs.setText("Save As...");
        itemExit.setText("Exit");
        jMenuBar1.add(menuFile);
        jMenuBar1.add(menuView);
        jMenuBar1.add(menuHelp);
        menuFile.add(itemSaveAs);
        menuFile.addSeparator();
        menuFile.add(itemExit);
        menuHelp.add(itemAbout);
        menuView.add(itemZoomIn);
        menuView.add(itemZoomOut);
        menuView.add(itemDefaultZoom);
        menuView.addSeparator();
        menuView.add(itemGoToStart);
        menuView.add(itemGoBack);
        menuView.add(itemGoForward);
        menuView.add(itemGoToEnd);
        menuView.addSeparator();
        menuView.add(itemSelect);
        menuView.add(itemLog);
        menuView.addSeparator();
        menuView.add(itemDescr);
        menuView.add(itemLines);
    }

    /**
     * @param e
     */
    public void btnStart_actionPerformed(ActionEvent e) {
        goToStart();
    }

    /**
     * @param e
     */
    public void btnBack_actionPerformed(ActionEvent e) {
        goBack();
    }

    /**
     * @param e
     */
    public void btnForward_actionPerformed(ActionEvent e) {
        goForward();
    }

    /**
     * @param e
     */
    public void btnEnd_actionPerformed(ActionEvent e) {
        goToEnd();
    }

    /**
     * @param e
     */
    public void btnZoomIn_actionPerformed(ActionEvent e) {
        zoomIn();
    }

    /**
     * @param e
     */
    public void btnZoomOut_actionPerformed(ActionEvent e) {
        zoomOut();
    }

    /**
     * @param e
     */
    public void itemSaveAs_actionPerformed(ActionEvent e) {
        JFileChooser fc = new JFileChooser();
        int returnVal = fc.showSaveDialog(this);
        if(returnVal == JFileChooser.APPROVE_OPTION) {
            owner.getData().saveAll(fc.getSelectedFile().getPath());
        }
    }

    /**
     * @param e
     */
    public void itemExit_actionPerformed(ActionEvent e) {
        graphSelector.dispose();
        dispose();
    }

    /**
     * @param e
     */
    public void itemZoomIn_actionPerformed(ActionEvent e) {
        zoomIn();
    }

    /**
     * @param e
     */
    public void itemZoomOut_actionPerformed(ActionEvent e) {
        zoomOut();
    }

    /**
     * @param e
     */
    public void itemDefaultZoom_actionPerformed(ActionEvent e) {
        setDefaultZoom();
    }

    public void itemSelect_actionPerformed(ActionEvent e) {
        if(((JCheckBoxMenuItem)e.getSource()).getState()) {
            graphSelector.setVisible(true);
        } else {
            graphSelector.setVisible(false);
        }
    }

    public void itemDescr_actionPerformed(ActionEvent e) {
        if(((JCheckBoxMenuItem)e.getSource()).getState()) {
            canvas.showDescriptions(true);
        } else {
            canvas.showDescriptions(false);
        }
    }

    /**
     * @param e
     */
    public void itemLog_actionPerformed(ActionEvent e) {
    }

    public void itemLines_actionPerformed(ActionEvent e) {
        if(((JCheckBoxMenuItem)e.getSource()).getState()) {
            canvas.setThickLines(true);
        } else {
            canvas.setThickLines(false);
        }
    }

    /**
     * @param e
     */
    public void itemGoToStart_actionPerformed(ActionEvent e) {
        goToStart();
    }

    /**
     * @param e
     */
    public void itemGoBack_actionPerformed(ActionEvent e) {
        goBack();
    }

    /**
     * @param e
     */
    public void itemGoForward_actionPerformed(ActionEvent e) {
        goForward();
    }

    /**
     * @param e
     */
    public void itemGoToEnd_actionPerformed(ActionEvent e) {
        goToEnd();
    }

    /**
     * @param e
     */
    public void itemAbout_actionPerformed(ActionEvent e) {
        new AboutGUI();
    }

    /**
     * @param e
     */
    public void btnRun_actionPerformed(ActionEvent e) {
        running = !running;
        if(running) {
            graphSelector.enableChoice(false);
            long time = System.currentTimeMillis()-owner.getStartTime();
            timer = new Refresh(time-(int)period, 100);
            AglobeThreadPool.getThread(timer, "Refresh thread").start();
            btnRun.setText("Stop");
        } else {
            timer.halt();
            timer = null;
            btnRun.setText("Run");
            graphSelector.enableChoice(true);
        }
        updateUI();
    }

    /**
     * @param e
     */
    public void this_windowClosing(WindowEvent e) {
        if(graphSelector!=null) graphSelector.dispose();
        owner.done();
    }

    /**
     * This thread performs automatic scrolling of visible area.
     *
     * @author Miroslav Uller
     */
    private class Refresh implements Runnable {
        private long frame = 0;
        private long period = 1000;
        private volatile Refresh dummy;

        public Refresh(long start, long period) {
            this.dummy = this;
            this.period = period;
            this.frame = start;
        }

        @Override
		public void run() {
            while (dummy == this) {
                try {
                    Thread.sleep(period);
                } catch (InterruptedException ioe) {}
                frame += period;
                goTo(frame);
            }
        }

        public void halt() {
            dummy = null;
        }
    }
}

class DataAnalyzerGUI_this_windowAdapter
extends WindowAdapter {
    private DataAnalyzerGUI adaptee;
    DataAnalyzerGUI_this_windowAdapter(DataAnalyzerGUI adaptee) {
        this.adaptee = adaptee;
    }

    @Override
    public void windowClosing(WindowEvent e) {
        adaptee.this_windowClosing(e);
    }
}

class DataAnalyzerGUI_itemAbout_actionAdapter implements ActionListener {
    private DataAnalyzerGUI adaptee;
    DataAnalyzerGUI_itemAbout_actionAdapter(DataAnalyzerGUI adaptee) {
        this.adaptee = adaptee;
    }

    @Override
	public void actionPerformed(ActionEvent e) {
        adaptee.itemAbout_actionPerformed(e);
    }
}


class DataAnalyzerGUI_btnRun_actionAdapter implements ActionListener {
    private DataAnalyzerGUI adaptee;
    DataAnalyzerGUI_btnRun_actionAdapter(DataAnalyzerGUI adaptee) {
        this.adaptee = adaptee;
    }

    @Override
	public void actionPerformed(ActionEvent e) {
        adaptee.btnRun_actionPerformed(e);
    }
}


class DataAnalyzerGUI_itemGoToEnd_actionAdapter implements ActionListener {
    private DataAnalyzerGUI adaptee;
    DataAnalyzerGUI_itemGoToEnd_actionAdapter(DataAnalyzerGUI adaptee) {
        this.adaptee = adaptee;
    }

    @Override
	public void actionPerformed(ActionEvent e) {
        adaptee.itemGoToEnd_actionPerformed(e);
    }
}


class DataAnalyzerGUI_itemGoForward_actionAdapter implements ActionListener {
    private DataAnalyzerGUI adaptee;
    DataAnalyzerGUI_itemGoForward_actionAdapter(DataAnalyzerGUI adaptee) {
        this.adaptee = adaptee;
    }

    @Override
	public void actionPerformed(ActionEvent e) {

        adaptee.itemGoForward_actionPerformed(e);
    }
}


class DataAnalyzerGUI_itemGoBack_actionAdapter implements ActionListener {
    private DataAnalyzerGUI adaptee;
    DataAnalyzerGUI_itemGoBack_actionAdapter(DataAnalyzerGUI adaptee) {
        this.adaptee = adaptee;
    }

    @Override
	public void actionPerformed(ActionEvent e) {

        adaptee.itemGoBack_actionPerformed(e);
    }
}


class DataAnalyzerGUI_itemGoToStart_actionAdapter implements ActionListener {
    private DataAnalyzerGUI adaptee;
    DataAnalyzerGUI_itemGoToStart_actionAdapter(DataAnalyzerGUI adaptee) {
        this.adaptee = adaptee;
    }

    @Override
	public void actionPerformed(ActionEvent e) {
        adaptee.itemGoToStart_actionPerformed(e);
    }
}


class DataAnalyzerGUI_itemSelect_actionAdapter implements ActionListener {
    private DataAnalyzerGUI adaptee;
    DataAnalyzerGUI_itemSelect_actionAdapter(DataAnalyzerGUI adaptee) {
        this.adaptee = adaptee;
    }

    @Override
	public void actionPerformed(ActionEvent e) {
        adaptee.itemSelect_actionPerformed(e);
    }
}

class DataAnalyzerGUI_itemLog_actionAdapter implements ActionListener {
    private DataAnalyzerGUI adaptee;
    DataAnalyzerGUI_itemLog_actionAdapter(DataAnalyzerGUI adaptee) {
        this.adaptee = adaptee;
    }

    @Override
	public void actionPerformed(ActionEvent e) {
        adaptee.itemLog_actionPerformed(e);
    }
}

class DataAnalyzerGUI_itemDescr_actionAdapter implements ActionListener {
    private DataAnalyzerGUI adaptee;
    DataAnalyzerGUI_itemDescr_actionAdapter(DataAnalyzerGUI adaptee) {
        this.adaptee = adaptee;
    }

    @Override
	public void actionPerformed(ActionEvent e) {
        adaptee.itemDescr_actionPerformed(e);
    }
}

class DataAnalyzerGUI_itemLines_actionAdapter implements ActionListener {
    private DataAnalyzerGUI adaptee;
    DataAnalyzerGUI_itemLines_actionAdapter(DataAnalyzerGUI adaptee) {
        this.adaptee = adaptee;
    }

    @Override
	public void actionPerformed(ActionEvent e) {
        adaptee.itemLines_actionPerformed(e);
    }
}


class DataAnalyzerGUI_itemDefaultZoom_actionAdapter implements ActionListener {
    private DataAnalyzerGUI adaptee;
    DataAnalyzerGUI_itemDefaultZoom_actionAdapter(DataAnalyzerGUI adaptee) {
        this.adaptee = adaptee;
    }

    @Override
	public void actionPerformed(ActionEvent e) {
        adaptee.itemDefaultZoom_actionPerformed(e);
    }
}


class DataAnalyzerGUI_itemZoomOut_actionAdapter implements ActionListener {
    private DataAnalyzerGUI adaptee;
    DataAnalyzerGUI_itemZoomOut_actionAdapter(DataAnalyzerGUI adaptee) {
        this.adaptee = adaptee;
    }

    @Override
	public void actionPerformed(ActionEvent e) {

        adaptee.itemZoomOut_actionPerformed(e);
    }
}


class DataAnalyzerGUI_itemZoomIn_actionAdapter implements ActionListener {
    private DataAnalyzerGUI adaptee;
    DataAnalyzerGUI_itemZoomIn_actionAdapter(DataAnalyzerGUI adaptee) {
        this.adaptee = adaptee;
    }

    @Override
	public void actionPerformed(ActionEvent e) {
        adaptee.itemZoomIn_actionPerformed(e);
    }
}


class DataAnalyzerGUI_itemExit_actionAdapter implements ActionListener {
    private DataAnalyzerGUI adaptee;
    DataAnalyzerGUI_itemExit_actionAdapter(DataAnalyzerGUI adaptee) {
        this.adaptee = adaptee;
    }

    @Override
	public void actionPerformed(ActionEvent e) {
        adaptee.itemExit_actionPerformed(e);
    }
}


class DataAnalyzerGUI_itemSaveAs_actionAdapter implements ActionListener {
    private DataAnalyzerGUI adaptee;
    DataAnalyzerGUI_itemSaveAs_actionAdapter(DataAnalyzerGUI adaptee) {
        this.adaptee = adaptee;
    }

    @Override
	public void actionPerformed(ActionEvent e) {
        adaptee.itemSaveAs_actionPerformed(e);
    }
}


class DataAnalyzerGUI_btnZoomOut_actionAdapter implements ActionListener {
    private DataAnalyzerGUI adaptee;
    DataAnalyzerGUI_btnZoomOut_actionAdapter(DataAnalyzerGUI adaptee) {
        this.adaptee = adaptee;
    }

    @Override
	public void actionPerformed(ActionEvent e) {
        adaptee.btnZoomOut_actionPerformed(e);
    }
}


class DataAnalyzerGUI_btnZoomIn_actionAdapter implements ActionListener {
    private DataAnalyzerGUI adaptee;
    DataAnalyzerGUI_btnZoomIn_actionAdapter(DataAnalyzerGUI adaptee) {
        this.adaptee = adaptee;
    }

    @Override
	public void actionPerformed(ActionEvent e) {
        adaptee.btnZoomIn_actionPerformed(e);
    }
}


class DataAnalyzerGUI_btnEnd_actionAdapter implements ActionListener {
    private DataAnalyzerGUI adaptee;
    DataAnalyzerGUI_btnEnd_actionAdapter(DataAnalyzerGUI adaptee) {
        this.adaptee = adaptee;
    }

    @Override
	public void actionPerformed(ActionEvent e) {
        adaptee.btnEnd_actionPerformed(e);
    }
}


class DataAnalyzerGUI_btnForward_actionAdapter implements ActionListener {
    private DataAnalyzerGUI adaptee;
    DataAnalyzerGUI_btnForward_actionAdapter(DataAnalyzerGUI adaptee) {
        this.adaptee = adaptee;
    }

    @Override
	public void actionPerformed(ActionEvent e) {
        adaptee.btnForward_actionPerformed(e);
    }
}


class DataAnalyzerGUI_btnBack_actionAdapter implements ActionListener {
    private DataAnalyzerGUI adaptee;
    DataAnalyzerGUI_btnBack_actionAdapter(DataAnalyzerGUI adaptee) {
        this.adaptee = adaptee;
    }

    @Override
	public void actionPerformed(ActionEvent e) {
        adaptee.btnBack_actionPerformed(e);
    }
}


class DataAnalyzerGUI_btnStart_actionAdapter implements ActionListener {
    private DataAnalyzerGUI adaptee;
    DataAnalyzerGUI_btnStart_actionAdapter(DataAnalyzerGUI adaptee) {
        this.adaptee = adaptee;
    }

    @Override
	public void actionPerformed(ActionEvent e) {
        adaptee.btnStart_actionPerformed(e);
    }
}

