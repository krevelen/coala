package aglobe.agent.dataanalyzer;

import java.util.*;

import java.awt.*;

/**
 *
 * <p>Title: A-Globe Data Analyzer</p>
 *
 * <p>Description: The main data store. Contains information about known data
 * sources ('agents'), signal types ('params') and the data gathered so far.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author Miroslav Uller
 *
 * @version 1.0
 */
public class CollectedData {
    /**
     * The signal names.
     */
    private Hashtable<String, Integer> agentNames = new Hashtable<String, Integer>();

    /**
     * The parameter names.
     */
    private Hashtable<String, Integer> paramNames = new Hashtable<String, Integer>();

    /**
     * Number of signal sources (agents).
     */
    private int agents = 0;

    /**
     * Number of different signal types (params).
     */
    private int params = 0;

    /**
     * The data gathered so far. A two-dimensional list of graphs of discrete functions; each
     * function represents the changes of some signal from some source over the
     * time.
     */
    private ArrayList<ArrayList<Graph>> data = new ArrayList<ArrayList<Graph>>();

    /**
     * The graph containing information about the current number of unique
     * signal sources.
     */
    private Graph numberOfAgents = new Graph(new DiscreteFunction(),
            "number of agents", Color.WHITE);

    private long startTime;

    private long endTime;

    /**
     * The color table, used for coloring of the graphs.
     */
    public final static Color[] BASIC_COLORS = { Color.MAGENTA, Color.GREEN,
            Color.RED, Color.BLUE, Color.ORANGE, Color.GREEN, Color.RED,
            Color.CYAN, Color.YELLOW, };

    public int aktDefaultColor = 0;

    public static class GraphEnumerator {
        private CollectedData cd;

        int ai, pi;

        public GraphEnumerator(CollectedData cd) {
            this.cd = cd;
            ai = pi = -1;
            nextValidPosition();
        }

        private void nextValidPosition() {
            if (ai < 0) {
                if (cd.getCounts().isVisible())
                    return;
                ai = pi = 0;
            }
            while (ai < cd.numAgents()) {
                while (pi < cd.numParams()) {
                    if (cd.get(ai, pi).isVisible())
                        return;
                    pi++;
                }
                pi = 0;
                ai++;
            }
        }

        public final boolean hasMoreElements() {
            return ai < cd.numAgents();
        }

        public Graph nextElement() {
            Graph gr;
            if (ai < 0) {
                gr = cd.getCounts();
                ai = pi = 0;
            } else {
                gr = cd.get(ai, pi);
                pi++;
            }
            nextValidPosition();
            return gr;
        }
    }

    /**
     * Class constructor. Creates an empty data store.
     */
    public CollectedData() {
        clear();
    }

    /**
     * Returns an enumerator for enumerating the collection of graphs.
     *
     * @return an enumerator for enumerating the collection of graphs
     */
    public final GraphEnumerator enumerator() {
        return new GraphEnumerator(this);
    }

    /**
     * Returns the graph containing information about current number of signal
     * sources.
     *
     * @return the graph containing information about current number of signal
     *         sources
     */
    public final Graph agentCount() {
        return numberOfAgents;
    }

    /**
     * Returns the number of known signal sources (agents).
     *
     * @return the number of known signal sources
     */
    public final int numAgents() {
        return agents;
    }

    /**
     * Returns the number of known signal types (params).
     *
     * @return the number of known signal types
     */
    public final int numParams() {
        return params;
    }

    /**
     * Returns true, if there exist a signal source with given name.
     *
     * @param name
     *            the name of the signal source
     * @return true or false
     */
    public final boolean containsAgent(String name) {
        return agentNames.containsKey(name);
    }

    /**
     * Returns true, if there exist a signal type with given name.
     *
     * @param name
     *            the name of the signal type
     * @return true or false
     */
    public final boolean containsParam(String name) {
        return paramNames.containsKey(name);
    }

    /**
     * Returns an index of a signal source with given name. Returns -1 if such signal source does not exist.
     * @param name the name of signal source
     * @return the index
     */
    private final int agentIndex(String name) {
        if (agentNames.containsKey(name))
            return agentNames.get(name).intValue();
        else
            return -1;
    }

    /**
     * Returns an index of a signal type with given name. Returns -1 if such signal type does not exist.
     * @param name the name of signal type
     * @return the index
     */
    private final int paramIndex(String name) {
        if (paramNames.containsKey(name))
            return paramNames.get(name).intValue();
        else
            return -1;
    }

    /**
     * Returns the name of a signal source with specified index.
     * @param index the index
     * @return the name of signal source, or string "n/a" if the index is invalid.
     */
    public final String agentName(int index) {
        for (Map.Entry<String, Integer> me : agentNames.entrySet()) {
            if (me.getValue() == index)
                return me.getKey();
        }
        return "n/a";
    }

    /**
     * Returns the name of a signal type with specified index.
     * @param index the index
     * @return the name of signal type, or string "n/a" if the index is invalid.
     */
    public final String paramName(int index) {
        for (Map.Entry<String, Integer> me : paramNames.entrySet()) {
            if (me.getValue() == index)
                return me.getKey();
        }
        return "n/a";
    }

    /**
     * Clears the data store. Removes all information stored so far.
     */
    public void clear() {
        agentNames.clear();
        paramNames.clear();
        numberOfAgents.getFunction().clear();
        numberOfAgents.getFunction().addSample(0, 0);
        data.clear();
        agents = 0;
        params = 0;
        startTime = 0;
        endTime = -1;
        addAgent("average"); // index = 0
    }

    /**
     * Adds a new signal source.
     *
     * @param name
     *            the name of signal source
     */
    private void addAgent(String name) {
        ArrayList<Graph> alist = new ArrayList<Graph>();
        for (int i = 0; i < params; i++)
            alist.add(new Graph(new DiscreteFunction(), name + " ("
                    + paramName(i) + ")", getDefaultColor()));
        data.add(alist);
        agentNames.put(name, agents);
        agents++;
    }

    /**
     * Adds a new signal type.
     *
     * @param name
     *            the name of signal type
     */
    private void addParam(String name) {
        for (int i = 0; i < agents; i++) {
            data.get(i).add(
                    new Graph(new DiscreteFunction(), agentName(i) + " ("
                            + name + ")", getDefaultColor()));
        }
        paramNames.put(name, params);
        params++;
    }

    /**
     * getRandomColor
     *
     * @return Color
     */
    private Color getDefaultColor() {
        Color returnColor = BASIC_COLORS[aktDefaultColor];
        aktDefaultColor = (aktDefaultColor + 1) % BASIC_COLORS.length;
        return returnColor;
    }

    /**
     * Return a graph representing the course of the specified signal coming from the specified signal source.
     * @param agent the name of the signal source
     * @param param the name of the signal type
     * @return the graph
     */
    public final Graph get(String agent, String param) {
        int ai = agentIndex(agent);
        int pi = paramIndex(param);
        if (ai >= 0 && pi >= 0)
            return data.get(ai).get(pi);
        else
            return null;
    }

    /**
     * Return a graph representing the course of the specified signal coming from the specified signal source.
     * @param agent the index of the signal source
     * @param param the index of the signal type
     * @return the graph
     */
    public final Graph get(int agent, int param) {
        return data.get(agent).get(param);
    }

    /**
     * Returns the graph containing information about the number of unique
     * signal sources.
     * @return the graph
     */
    public final Graph getCounts() {
        return numberOfAgents;
    }

    /**
     * Returns the time associated to the earliest sample present in the data store.
     * @return the start time.
     */
    public final long getStartTime() {
        return startTime;
    }

    /**
     * Returns the time associated to the latest sample present in the data store.
     * @return the start time.
     */
    public final long getEndTime() {
        return endTime;
    }

    /**
     * Adds a data sample to the data store.
     * @param agent the signal source
     * @param param the signal type
     * @param time the time
     * @param value the value
     */
    public void addValue(String agent, String param, long time, double value) {
        Graph gr;
        int ai, pi, i;
        double factor, avg, cnt;
        if (startTime > endTime)
            startTime = endTime = time;
        else if (time > endTime)
            endTime = time;
        if (!containsAgent(agent)) {
            factor = agents;
            addAgent(agent);
            factor /= agents;
            numberOfAgents.getFunction().addSample(time, agents - 1);
            for (i = 0; i < params; i++) {
                gr = data.get(0).get(i);
                gr.getFunction().addSample(time,
                        factor * gr.getFunction().lastValue());
            }
        }
        if (!containsParam(param)) {
            addParam(param);
            data.get(0).get(params - 1).getFunction().addSample(time, value);
        }
        ai = agentIndex(agent);
        pi = paramIndex(param);
        gr = data.get(ai).get(pi);
        gr.getFunction().addSample(time, value);
        avg = 0;
        cnt = 0;
        for (i = 1; i < agents; i++) {
            if (!data.get(i).get(pi).getFunction().isEmpty()) {
                cnt++;
                avg += data.get(i).get(pi).getFunction().lastValue();
            }
        }
        if (cnt > 0)
            avg /= cnt;
        else
            avg = Double.POSITIVE_INFINITY;
        data.get(0).get(pi).getFunction().addSample(time, avg);
    }

    /**
     * Returns true, if there is at least one graph visible.
     * @return true, if there is at least one graph visible
     */
    public final boolean anyVisible() {
        if (numberOfAgents.isVisible())
            return true;
        for (int i = 0; i < agents; i++) {
            for (int j = 0; j < params; j++) {
                if (data.get(i).get(j).isVisible())
                    return true;
            }
        }
        return false;
    }

    /**
     * Currently not implemented.
     * @param filename
     */
    public final void saveAll(String filename) {

    }

}
