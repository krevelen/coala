package aglobe.agent.dataanalyzer;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.border.Border;
import javax.swing.table.TableCellRenderer;
import java.awt.Color;
import java.awt.Component;

/**
 *
 * <p>Title: A-Globe Data Analyzer</p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author Miroslav Uller
 *
 * @version 1.0
 */
public class DummyRenderer extends JLabel
implements TableCellRenderer {
    private static final long serialVersionUID = -7240806996370982203L;
    Border unselectedBorder = null;
    Border selectedBorder = null;
    boolean isBordered = true;

    public DummyRenderer(boolean isBordered) {
        setHorizontalAlignment(JLabel.CENTER);
        this.isBordered = isBordered;
        setOpaque(true);
    }

    @Override
	public Component getTableCellRendererComponent(
            JTable table, Object value,
            boolean isSelected, boolean hasFocus,
            int row, int column) {
        Graph data = (Graph)value;
        if(data.isVisible()) {
            setBackground(data.getColor());
            setText("");
        } else {
            setBackground(Color.WHITE);
            setText("OFF");
        }
        if (isBordered) {
            if (isSelected) {
                if (selectedBorder == null) {
                    selectedBorder = BorderFactory.createMatteBorder(2,5,2,5,
                            table.getSelectionBackground());
                }
                setBorder(selectedBorder);
            } else {
                if (unselectedBorder == null) {
                    unselectedBorder = BorderFactory.createMatteBorder(2,5,2,5,
                            table.getBackground());
                }
                setBorder(unselectedBorder);
            }
        }

        return this;
    }
}
