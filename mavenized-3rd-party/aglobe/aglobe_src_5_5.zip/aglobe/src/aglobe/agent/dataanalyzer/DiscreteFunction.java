package aglobe.agent.dataanalyzer;

import java.util.*;

/**
*
* <p>Title: A-Globe Data Analyzer</p>
*
* <p>Description: Discrete function of one variable. Used for signal representation. A discrete function is defined
* by a sequence of couples (x, y).</p>
*
* <p>Copyright: Copyright (c) 2005</p>
*
* <p>Company: Gerstner Laboratory</p>
*
* @author Miroslav Uller
*
* @version 1.0
*/
public class DiscreteFunction {

    /**
     * A sample.
     *
     * @author Miroslav Uller
     */
    public static class Sample {
        /**
         * The x value.
         */
        public double x;

        /**
         * The y = f(x) value.
         */
        public double y;

        public Sample(double x, double y) {
            this.x = x;
            this.y = y;
        }
    }

    /**
     * A list of samples.
     */
    private ArrayList<Sample> data = new ArrayList<Sample>();

    /**
     * An 'undefined' value.
     */
    public static final double NO_VALUE = Double.POSITIVE_INFINITY;

    /**
     * The value of the first sample.
     */
    private double firstVal = NO_VALUE;

    /**
     * The value of the last sample.
     */
    private double lastVal = NO_VALUE;

    /**
     * The minimum value of the function.
     */
    private double minVal = NO_VALUE;

    /**
     * The maximum value of the function.
     */
    private double maxVal = NO_VALUE;

    /**
     * Class constructor.
     * Creates a discrete function with no samples. This function is undefined for any x value.
     *
     */
    public DiscreteFunction() {}

    /**
     * Returns true, if the discrete function is empty (i.e. contains no samples).
     * @return true, if the discrete function is empty
     */
    public boolean isEmpty() {
      return data.isEmpty();
    }

    /**
     * Returns number of samples.
     * @return number of samples
     */
    public final int size() {
        return data.size();
    }

    /**
     * Removes all samples.
     */
    public void clear() {
        data.clear();
    }

    /**
     * Adds a new sample to the definition of the discrete function. The sample's x value must be greater
     * than that of the last sample, i.e. the sequence of samples must me monotonous in x (increasing).
     * @param x the x value
     * @param y the y = f(x) value
     */
    public void addSample(double x, double y) {
        if(data.isEmpty() || data.get(data.size()-1).x < x) {
            data.add(new Sample(x, y));
            if(firstVal == NO_VALUE) {
              firstVal = lastVal = minVal = maxVal = y;
            } else {
              lastVal = y;
              if(y < minVal) minVal = y;
              if(y > maxVal) maxVal = y;
            }
        }
    }

    /**
     * Returns sample with the specified index.
     * @param index the index of sample
     * @return a sample
     */
    public final Sample getSample(int index) {
        return data.get(index);
    }

    /**
     * Returns the first value of the function, i.e. the y value of the first sample, or undefined value if there are no samples.
     * @return the first value of the function
     */
    public final double firstValue() {
        return firstVal;
    }

    /**
     * Returns the last value of the function, i.e. the y value of the last sample, or undefined value if there are no samples.
     * @return the last value of the function
     */
    public final double lastValue() {
      return lastVal;
    }

    /**
     * Returns the minimum value of the function.
     * @return the minimum value of the function
     */
    public final double minValue() {
      return minVal;
    }

    /**
     * Returns the maximum value of the function.
     * @return the maximum value of the function
     */
    public final double maxValue() {
      return maxVal;
    }

    /**
     * Returns the value of discrete function in specified point.
     * @param x the x value
     * @return the y value
     */
    public final double getValue(double x) {
        if(data.isEmpty()) return NO_VALUE;
        int cur = getIndex(x);
        if(cur<1) {
           return NO_VALUE;
        } else {
           return data.get(cur).y;
        }
    }

    /**
     * Returns the index of the last sample with x-value less or equal to argument value.
     * @param x double
     * @return int
     */
    public int getIndex(double x) {
      int begin = 0;
      int end = data.size()-1;
      int tmp;

      if(end<0 || data.get(0).x > x) {
         return -1;
      }
      if(data.get(end).x <= x) {
         return end;
      }
      while(begin != end && begin != end-1) {
          tmp = (begin+end)/2;
          if(data.get(tmp).x <= x)
              begin = tmp;
          else
              end = tmp;
      }
      return begin;
    }

}
