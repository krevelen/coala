package aglobe.agent.dataanalyzer;

import java.util.Random;

import aglobe.container.agent.Agent;
import aglobe.ontology.AgentInfo;
import aglobe.ontology.AglobeParam;
import aglobe.ontology.AglobeParams;
import aglobe.ontology.Message;
import aglobe.platform.thread.AglobeThreadPool;
import aglobe.service.topics.TopicsService;

/**
 *
 * <p>Title: A-Globe</p>
 *
 * <p>Description: Random data generator primarily intended for testing
 * DataAnalyzerAgent.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author Miroslav Uller
 * @version $Revision: 1.20 $ $Date: 2010/08/04 11:48:04 $
 */
public class RandomDataAgent extends Agent {

    private static final long serialVersionUID = 6641622189114690139L;

    private RandomTimer clockThread = null;

    private String valueName = "value";

    private double value = 0;

    private TopicsService.Shell topicsShell = null;

    /**
     * Type of the migrating agent
     */
    public final static String TYPE = "Test Agent";

    /**
     * The pseudorandom number generator.
     */
    private Random randomGenerator = new Random();

    /**
     * Thread for generating random numbers over random intervals of time. The
     * random numbers fall into interval <0,1>.
     */
    private class RandomTimer implements Runnable {
        private long frame = 0;

        private volatile RandomTimer dummy;

        /**
         * The minimum time interval (in miliseconds) between two generated values.
         */
        private int minTime;

        /**
         * The maximum time interval (in miliseconds) between two generated values.
         */
        private int maxTime;

        /**
         * Initializes the generator.
         *
         * @param min
         *            the minimum time interval (in miliseconds) between two
         *            generated values
         * @param max
         *            the maximum time interval (in miliseconds) between two
         *            generated values
         */
        public RandomTimer(int min, int max) {
            this.dummy = this;
            this.minTime = min;
            this.maxTime = max;
        }

        @Override
		public void run() {
            int wait = 0;
            dummy = this;
            while (dummy == this) {
                try {
                    wait = minTime + randomGenerator.nextInt(maxTime - minTime);
                    Thread.sleep(wait);
                } catch (InterruptedException ioe) {
                }
                frame += wait;
                processClockEvent(frame);
            }
        }

        /**
         * Stops the timer.
         */
        public void halt() {
            dummy = null;
        }
    }

    /**
     * Class constructor. Intentionally left empty.
     */
    public RandomDataAgent() {
    }

    /**
     * Initialization of <code>RandomDataAgent</code> and the GIS shell.
     *
     * @param ai
     *            AgentInfo
     * @param initState
     *            int
     */
    @Override
    public void init(final AgentInfo ai, final int initState) {
        if (ai.getAglobeParam().size() == 1) {
            valueName = ai.getAglobeParam().get(0).getValue();
        }
        if (clockThread == null) {
            clockThread = new RandomTimer(500, 1500);
            AglobeThreadPool.getThread(clockThread, "Random timer thread")
                    .start();
        }
        topicsShell = (TopicsService.Shell) getContainer().getServiceManager().getService(this, TopicsService.SERVICENAME);
        if (topicsShell == null) {
            logWarning("RandomDataAgent runs only on a container where TopicsService is running!");
            clockThread.halt();
            kill();
        }
    }

    /**
     * Sends some random data to the data analyzer.
     * @param time the time
     */
    public void processClockEvent(long time) {
        AglobeParams ps = new AglobeParams();
        AglobeParam p1 = new AglobeParam();
        AglobeParam p2 = new AglobeParam();
        AglobeParam p3 = new AglobeParam();
        p1.setName("timestamp");
        p1.setValue(time + "");
        p2.setName(valueName);
        p2.setValue((value + (0.5 * (randomGenerator.nextGaussian()) - 1)) + "");
        p3.setName("name");
        p3.setValue(getName());
        ps.getAglobeParam().add(p1);
        ps.getAglobeParam().add(p2);
        ps.getAglobeParam().add(p3);
        topicsShell.sendTopic(DataAnalyzerAgent.TOPIC_TEST_DATA, ps);
    }

    /**
     * This method overrides the standard <code>Agent</code>'s method
     * responsible for handling all incoming messages. It should never be
     * executed since <code>MigratingAgent</code> doesn't expect any messages
     * to come.
     *
     * @param m
     *            Message - an incoming message
     */
    @Override
	public void handleIncomingMessage(Message m) {
        logWarning("Unexpected message: " + m.toString());
                m.release();
    }

    /**
     * This method kills the agent. It is called by the GUI.
     */
    public void exit() {
        clockThread.halt();
        kill();
    }

    /**
     * This method implements the <code>GISTopicListener</code>'s method
     * responsible for handling all incoming topics.
     *
     * @param topic
     *            String
     * @param content
     *            Object
     * @param reason
     *            String
     */
    public void handleTopic(String topic, Object content, String reason) {
        logWarning("Unexpected incoming topic: " + topic);
    }

    /**
     * This method should perform quick clean up (such as close opened files,
     * hide GUI etc.).
     */
    @Override
    protected void finish() {
        clockThread.halt();
    }

}
