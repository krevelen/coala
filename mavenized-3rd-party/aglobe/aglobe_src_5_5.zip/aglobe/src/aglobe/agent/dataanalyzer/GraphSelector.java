package aglobe.agent.dataanalyzer;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;

/**
 *
 * <p>
 * Title: A-Globe Data Analyzer
 * </p>
 *
 * <p>
 * Description: A GUI component for selecting graphs, which are to be displayed.
 * </p>
 *
 * <p>
 * Copyright: Copyright (c) 2005
 * </p>
 *
 * <p>
 * Company: Gerstner Laboratory
 * </p>
 *
 * @author Miroslav Uller
 *
 * @version 1.0
 */
public class GraphSelector extends JPanel {

    private static final long serialVersionUID = -9070977808086670371L;

    private MyTableModel mtm = null;

    public GraphSelector(DataAnalyzerAgent da) {
        super(new GridLayout(1, 0));
        mtm = new MyTableModel(da);
        JTable table = new JTable(mtm);
        table.setPreferredScrollableViewportSize(new Dimension(600, 10));

        // Create the scroll pane and add the table to it.
        JScrollPane scrollPane = new JScrollPane(table);

        // Set up renderer and editor for the Favorite Color column.
        table.setDefaultRenderer(Color.class, new ColorRenderer(true));
        table.setDefaultEditor(Color.class, new ColorEditor());

        // Add the scroll pane to this panel.
        add(scrollPane);
    }

    public synchronized void updateContent() {
        mtm.fireTableDataChanged();
    }

    static class MyTableModel extends AbstractTableModel {
        private static final long serialVersionUID = 3425163253544776875L;

        private DataAnalyzerAgent da;

        private CollectedData cd;

        private String[] columnNames = { "Name", // 0
                "Value count", // 1
                "Start time", // 2
                "Last time", // 3
                "Min value", // 4
                "Max value", // 5
                "Last value", // 6
                "Color", // 7 - editable
                "Visible" }; // 8 - editable

        public MyTableModel(DataAnalyzerAgent da) {
            this.da = da;
            this.cd = da.getData();
        }

        @Override
		public int getColumnCount() {
            return columnNames.length;
        }

        @Override
		public synchronized int getRowCount() {
            return cd.numAgents() * cd.numParams() + 1;
        }

        @Override
        public String getColumnName(int col) {
            return columnNames[col];
        }

        @Override
		public synchronized Object getValueAt(int row, int col) {
            Graph gr;
            int r = 0, c = 0;
            if (row == 0) {
                gr = cd.agentCount();
            } else {
                r = (row - 1) / cd.numParams();
                c = (row - 1) % cd.numParams();
                gr = cd.get(r, c);
            }
            switch (col) {
            case 0:
                if (row == 0)
                    return "number of agents";
                return cd.agentName(r) + " (" + cd.paramName(c) + ")";
            case 1:
                return gr.getFunction().size();
            case 2:
                if (!gr.getFunction().isEmpty())
                    return gr.getFunction().getSample(0).x + "";
                else
                    return "n/a";
            case 3:
                if (!gr.getFunction().isEmpty())
                    return gr.getFunction().getSample(gr.getFunction().size() - 1).x + "";
                else
                    return "n/a";
            case 4:
                if (!gr.getFunction().isEmpty())
                    return gr.getFunction().minValue() + "";
                else
                    return "n/a";
            case 5:
                if (!gr.getFunction().isEmpty())
                    return gr.getFunction().maxValue() + "";
                else
                    return "n/a";
            case 6:
                if (!gr.getFunction().isEmpty())
                    return gr.getFunction().lastValue() + "";
                else
                    return "n/a";
            case 7:
                return gr.getColor();
            default:
                return gr.isVisible();
            }
        }

        /*
         * JTable uses this method to determine the default renderer/ editor for
         * each cell. If we didn't implement this method, then the last column
         * would contain text ("true"/"false"), rather than a check box.
         */
        @Override
        public Class<?> getColumnClass(int c) {
            return getValueAt(0, c).getClass();
        }

        @Override
        public boolean isCellEditable(int row, int col) {
            // Note that the data/cell address is constant,
            // no matter where the cell appears onscreen.
            return col >= 7;
        }

        @Override
        public synchronized void setValueAt(Object value, int row, int col) {
            Graph gr;
            if (row == 0) {
                gr = cd.agentCount();
            } else {
                int r = (row - 1) / cd.numParams();
                int c = (row - 1) % cd.numParams();
                gr = cd.get(r, c);
            }
            if (col == 7) {
                gr.setColor((Color) value);
                da.updateUI();
            }
            if (col == 8) {
                gr.setVisible((Boolean) value);
                da.updateUI();
            }
            fireTableCellUpdated(row, col);
        }

    }

}
