package aglobe.agent.dataanalyzer;

import java.util.*;
import aglobe.container.agent.*;
import aglobe.ontology.*;
import aglobe.service.topics.TopicsHandler;
import aglobe.service.topics.TopicsService;

/**
 *
 * <p>Title: A-Globe Data Analyzer</p>
 *
 * <p>Description: This agent visualizes data collected from agents. Must be run on the server.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author Miroslav Uller
 *
 * @version $Revision: 1.27 $ $Date: 2010/08/04 11:48:04 $
 */
public class DataAnalyzerAgent  extends Agent {
    private static final long serialVersionUID = 3614115527775010625L;

    /**
     * The GUI for the Data Analyzer.
     */
    private DataAnalyzerGUI gui;

    /**
     * The data store.
     */
    private CollectedData data;

    private long startTime;

    public static final String TOPIC_TEST_DATA = "TEST_DATA";

    private TopicsService.Shell topicsShell = null;

    /**
     * Class constructor. Intentionally left empty.
     */
    public DataAnalyzerAgent() {
    }

    @SuppressWarnings("serial")
    @Override
    public void init(final AgentInfo ai, final int initState) {

        if(data == null) {
            startTime = System.currentTimeMillis();
            data = new CollectedData();
        }

        // if I haven't own gui, create new one
        try {
            if (gui == null) {
                gui = new DataAnalyzerGUI(this);
            }
        } catch (Exception ex) {
            logSevere("Cannot create gui due to: "+ex+"\nDataAnalyzer will be stopped");
            stop();
            return;
        }
        // set the title of the gui window with my current container location name
        gui.setTitle("Test Agent - " + getContainer().getContainerName() +
                ":" + ai.getReadableName());
        gui.init();
        gui.setSize(800, 600);
        gui.validate();
        gui.setVisible(true);

        // initialize Topics shell
        topicsShell = (TopicsService.Shell) getContainer().getServiceManager().getService(this, TopicsService.SERVICENAME);
        if (topicsShell == null) {
            logWarning("DataAnalyzerAgent runs only on a container where TopicsService is running!");
            kill();
        } else {
            // register for receiving visibility update topic
            topicsShell.subscribeHandlerAsync(TOPIC_TEST_DATA, new TopicsHandler() {

                @Override
                public void handleIncomingTopic(final String topic, final Object content, final String reason) {
                    if (topic.equals(TOPIC_TEST_DATA)) {
                        List<AglobeParam> parList = ((AglobeParams) content).getAglobeParam();
                        ArrayList<AglobeParam> tmp = new ArrayList<AglobeParam>();
                        long timestamp = Long.MIN_VALUE;
                        String agentName = null;
                        for (Object listElem : parList) {
                            AglobeParam par = (AglobeParam) listElem;
                            try {
                                if (par.getName().equals("timestamp")) {
                                    timestamp = Integer.decode(par.getValue());
                                } else if (par.getName().equals("name")) {
                                    agentName = par.getValue();
                                } else {
                                    tmp.add(par);
                                }
                            }
                            catch (NumberFormatException nfe) {}
                        }

                        timestamp = System.currentTimeMillis() - startTime;

                        if(timestamp!=Long.MIN_VALUE) {
                            String paramName = "";
                            double value;
                            boolean added = false;
                            for(AglobeParam par: tmp) {
                                try {
                                    paramName = par.getName();
                                    value = Double.parseDouble(par.getValue());
                                    data.addValue(agentName, paramName, timestamp, value);
                                    added = true;
                                }
                                catch(NumberFormatException nfe) {
                                    logWarning("Invalid value for parameter '"+paramName+"'");
                                }
                            }
                            if(added) gui.graphSelector.updateContent();
                        }
                        return;
                    }
                    logWarning("Unexpected incoming topic: " + topic);                }

                @Override
                public void addEvent(Runnable e) {
                    DataAnalyzerAgent.this.addEvent(e);
                }

            });
        }
    }


    @Override
	public void handleIncomingMessage(Message m) {
        logWarning("Unexpected message: " + m.toString());
                m.release();
    }

    /**
     * This method kills the agent. It is called by the GUI.
     */
    public void exit() {
        kill();
    }

    /**
     * This method should perform quick clean up (such as close opened files, hide
     * GUI etc.).
     */
    @Override
    protected void finish() {
        if (topicsShell != null) {
            topicsShell.dispose();
            topicsShell = null;
        }
    }

    /**
     * Returns the main data store.
     * @return the main data store.
     */
    public final CollectedData getData() {
        return data;
    }

    public final long getStartTime() {
        return startTime;
    }

    /**
     * Finishes collecting of the data and terminates the agent's execution.
     */
    public void done() {
        stop();
    }

    /**
     * Updates the user interface.
     */
    public void updateUI() {
        gui.updateUI();
    }

}
