package aglobe.agent.dataanalyzer;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.AbstractCellEditor;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JDialog;
import javax.swing.JTable;
import javax.swing.table.TableCellEditor;

/**
*
* <p>Title: A-Globe Data Analyzer</p>
*
* <p>Description: </p>
*
* <p>Copyright: Copyright (c) 2005</p>
*
* <p>Company: Gerstner Laboratory</p>
*
* @author Miroslav Uller
*
* @version 1.0
*/
public class DummyEditor extends AbstractCellEditor
                         implements TableCellEditor,
                                    ActionListener, MouseListener {
    private static final long serialVersionUID = 4606043457615482394L;
    JButton button;
    JColorChooser colorChooser;
    JDialog dialog;
    protected static final String EDIT = "edit";
    private Graph data;

    public DummyEditor() {
        button = new JButton();
        button.setActionCommand(EDIT);
        button.addMouseListener(this);
        button.addActionListener(this);
        button.setBorderPainted(false);

        colorChooser = new JColorChooser();
        dialog = JColorChooser.createDialog(button,
                                        "Pick a Color",
                                        true,  //modal
                                        colorChooser,
                                        this,  //OK button handler
                                        null); //no CANCEL button handler
    }

    /**
     * Handles events from the editor button and from
     * the dialog's OK button.
     */
    @Override
	public void actionPerformed(ActionEvent e) {
        if(EDIT.equals(e.getActionCommand())) {
        } else {
            data.setColor(colorChooser.getColor());
            data.setVisible(true);
        }
    }


    @Override
	public void mouseClicked(MouseEvent e) {
      if(e.isShiftDown()) {
        colorChooser.setColor(data.getColor());
        dialog.setVisible(true);
        fireEditingStopped();
      } else {
        data.setVisible(!data.isVisible());
        fireEditingStopped();
      }
    }

    @Override
	public void mouseEntered(MouseEvent e) {
    }

    @Override
	public void mouseExited(MouseEvent e) {
    }

    @Override
	public void mousePressed(MouseEvent e) {
    }

    @Override
	public void mouseReleased(MouseEvent e) {

    }

    @Override
	public Object getCellEditorValue() {
        return data;
    }

    @Override
	public Component getTableCellEditorComponent(JTable table,
                                                 Object value,
                                                 boolean isSelected,
                                                 int row,
                                                 int column) {
        data = (Graph)value;
        return button;
    }
}

