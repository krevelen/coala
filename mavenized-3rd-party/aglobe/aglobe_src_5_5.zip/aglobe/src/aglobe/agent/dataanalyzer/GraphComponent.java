package aglobe.agent.dataanalyzer;

import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.Rectangle;
import java.awt.BasicStroke;
import java.util.HashMap;

/**
 *
 * <p>Title: A-Globe Data Analyzer</p>
 *
 * <p>Description: The graph visualization component.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author Miroslav Uller
 *
 * @version 1.0
 */
public class GraphComponent extends JPanel {
    private static final long serialVersionUID = -2827212560500178709L;

    /**
     * The extents of visible area.
     */
    private GraphInfo window = new GraphInfo();

    /**
     * Displayed discrete functions.
     */
    private HashMap<DiscreteFunction, Graph> graphs = new HashMap<DiscreteFunction, Graph>();

    /**
     * True, if graph descriptions should also be seen.
     */
    private boolean viewDescriptions = true;

    /**
     * True, if the graphs are to be drawn with thick lines.
     */
    private boolean thickLines = true;

    public static final BasicStroke THICK_STROKE = new BasicStroke(3);

    /**
     * Class constructor.
     */
    public GraphComponent() {
    }

    /**
     * Adds new graph to the display.
     * @param df the discrete function
     * @param descr the description
     * @param color the color
     */
    public void addGraph(DiscreteFunction df, String descr, Color color) {
        Graph gr = new Graph(df, descr, color);
        if(graphs.containsKey(df)) {
            graphs.remove(df);
        }
        graphs.put(df, gr);
        repaint();
    }

    /**
     * Removes a graph.
     * @param df the discrete function
     */
    public void removeGraph(DiscreteFunction df) {
        if(graphs.containsKey(df)) {
            graphs.remove(df);
            repaint();
        }
    }

    /**
     * Sets the visibility of graph descriptions.
     * @param enabled if true, graph descriptions will be shown
     */
    public void showDescriptions(boolean enabled) {
        if(viewDescriptions != enabled) {
            viewDescriptions = enabled;
            repaint();
        }
    }

    /**
     * Returns true, if the graph descriptions are visible.
     * @return true, if the graph descriptions are visible
     */
    public boolean descriptionsVisible() {
      return viewDescriptions;
    }

    /**
     * Sets the line drawing mode. If true, all function plots will be drawn with thick lines.
     * @param enabled the line drawing mode
     */
    public void setThickLines(boolean enabled) {
        if(thickLines != enabled) {
            thickLines = enabled;
            repaint();
        }
    }

    /**
     * Returns true, if the graphs are displayed with thick lines.
     * @return true, if the graphs are displayed with thick lines
     */
    public boolean useThickLines() {
      return thickLines;
    }

    /**
     * Sets the x range of the visible area.
     * @param minX the minimum x value
     * @param maxX the maximum x value
     */
    public void setXRange(double minX, double maxX) {
      window.minX = minX;
      window.maxX = maxX;
      repaint();
    }

    /**
     * Sets the y range of the visible area.
     * @param minY the minimum y value
     * @param maxY the maximum y value
     */
    public void setYRange(double minY, double maxY) {
      window.minY = minY;
      window.maxY = maxY;
      repaint();
    }

    /**
     * Sets both ranges defining the visible area.
     * @param minX the minimum x value
     * @param maxX the maximum x value
     * @param minY the minimum y value
     * @param maxY the maximum y value
     */
    public void setRanges(double minX, double maxX, double minY, double maxY) {
      window.minX = minX;
      window.maxX = maxX;
      window.minY = minY;
      window.maxY = maxY;
      repaint();
    }

    /**
     * Returns the extents of the visible area.
     * @return the extents of the visible area
     */
    public final GraphInfo getRanges() {
      return window;
    }

    /**
     * Returns true, if there are any graphs to be displayed.
     * @return true, if there are any graphs to be displayed
     */
    public final boolean hasData() {
        return !graphs.isEmpty();
    }

    /**
     * Draws axes.
     * @param g the graphics context
     * @param rect the target rectangle
     */
    public void drawAxes(Graphics g, Rectangle rect) {
         g.drawRect(rect.x, rect.y, rect.width, rect.height);
         int xxx, yyy, i;
         double min = window.minY;
         double max = window.maxY;
         if(Math.abs(max-min)<1e-10) {
             min-=1;
             max+=1;
         }
         double d = max - min;
         double lg = Math.floor(Math.log10(d));
         double step = Math.pow(10, lg);
         if(d/step<3) step/=10;
         for(i=(int)Math.ceil(min/step); i<=(int)Math.floor(max/step); i++) {
             yyy = rect.y + rect.height - (int)(rect.height*(i*step - window.minY)/d);
             g.drawLine(rect.x-3, yyy, rect.x+3, yyy);
             g.drawString(String.format("%1$.2f", i*step), rect.x-32, yyy+5);
         }
         d = window.maxX - window.minX;
         lg = Math.floor(Math.log10(d));
         step = Math.pow(10, lg);
         if(d/step<2) step/=10;
         for(i=(int)Math.ceil(window.minX/step); i<=(int)Math.floor(window.maxX/step); i++) {
             xxx = (int)(rect.x + rect.width*(i*step - window.minX)/d);
             g.drawLine(xxx, rect.y+rect.height-3, xxx, rect.y+rect.height+3);
             g.drawString(String.format("%1$.2f", i*step/1000), xxx-15, rect.y+rect.height+15);
         }
     }

    /**
     * Draws graph descriptions.
     * @param g the graphics context
     * @param rect the target rectangle
     */
     public void drawStrings(Graphics g, Rectangle rect) {
         int y = rect.y;
         for(Graph gr: graphs.values()) {
             g.setColor(gr.getColor());
             g.drawString(gr.getDescription(), rect.x+8, y+18);
             y+=18;
         }
     }

     /**
      * Overrides the JPanel's <p>paint</p> method.
      */
     @Override
    public void paint(Graphics g) {
         Graphics2D g2 = (Graphics2D)g;
         int w = getWidth(), h = getHeight();
         g2.setBackground(Color.BLACK);
         g2.clearRect(0, 0, w,h);

         g.setColor(Color.WHITE);
         Rectangle rect = new Rectangle(35, 20, w-55, h-40);
         drawAxes(g, rect);
         if(thickLines) ((Graphics2D)g).setStroke(THICK_STROKE);
         double min = Double.POSITIVE_INFINITY;
         double max = Double.NEGATIVE_INFINITY;
         double mm, MM;
         for(Graph gr2: graphs.values()) {
             if(!gr2.getFunction().isEmpty()) {
               mm = gr2.getFunction().minValue();
               MM = gr2.getFunction().maxValue();
               if (mm < min) min = mm;
               if (MM > max) max = MM;
             }
         }
         window.minY = min;
         window.maxY = max;
         if(min == Double.POSITIVE_INFINITY || max == Double.NEGATIVE_INFINITY) return;
         for(Graph gr: graphs.values()) {
             if(!gr.getFunction().isEmpty()) gr.draw(g2, window, rect);
         }
         if(viewDescriptions) drawStrings(g, rect);
     }

}

