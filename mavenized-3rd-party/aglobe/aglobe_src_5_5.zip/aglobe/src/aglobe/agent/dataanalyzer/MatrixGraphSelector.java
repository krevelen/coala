package aglobe.agent.dataanalyzer;

/*
 * TableDialogEditDemo.java is a 1.4 application that requires these files:
 *   ColorRenderer.java
 *   ColorEditor.java
 */

import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;

/**
 *
 * <p>
 * Title: A-Globe Data Analyzer
 * </p>
 *
 * <p>
 * Description: A GUI component for selecting graphs, which are to be displayed.
 * </p>
 *
 * <p>
 * Copyright: Copyright (c) 2005
 * </p>
 *
 * <p>
 * Company: Gerstner Laboratory
 * </p>
 *
 * @author Miroslav Uller
 *
 * @version 1.0
 */
public class MatrixGraphSelector extends JPanel {

    private static final long serialVersionUID = -8432813818650474648L;

    private MyTableModel mtm = null;

    private int cols = -1;

    public MatrixGraphSelector(DataAnalyzerAgent da) {
        super(new GridLayout(1, 0));
        mtm = new MyTableModel(da);
        JTable table = new JTable(mtm);
        table.setPreferredScrollableViewportSize(new Dimension(600, 10));
        JScrollPane scrollPane = new JScrollPane(table);
        table.setDefaultRenderer(Graph.class, new DummyRenderer(true));
        table.setDefaultEditor(Graph.class, new DummyEditor());
        add(scrollPane);
    }

    public synchronized void updateContent() {
        mtm.fireTableDataChanged();
        if (cols != mtm.getColumnCount())
            mtm.fireTableStructureChanged();
        cols = mtm.getColumnCount();
    }

    static class MyTableModel extends AbstractTableModel {
        private static final long serialVersionUID = -4371376778276710756L;

        private DataAnalyzerAgent da;

        private CollectedData cd;

        public MyTableModel(DataAnalyzerAgent da) {
            this.da = da;
            this.cd = da.getData();
        }

        @Override
		public int getColumnCount() {
            return cd.numParams() + 1;
        }

        @Override
		public synchronized int getRowCount() {
            return cd.numAgents();
        }

        @Override
        public synchronized String getColumnName(int col) {
            if (col == 0)
                return "Agent name";
            return cd.paramName(col - 1);
        }

        @Override
		public synchronized Object getValueAt(int row, int col) {
            if (col == 0) {
                return cd.agentName(row);
            } else {
                return cd.get(row, col - 1);
            }
        }

        @Override
        public Class<?> getColumnClass(int c) {
            return getValueAt(0, c).getClass();
        }

        @Override
        public boolean isCellEditable(int row, int col) {
            return col > 0;
        }

        @Override
        public synchronized void setValueAt(Object value, int row, int col) {
            // ...............
            da.updateUI();
            fireTableCellUpdated(row, col);
        }

    }

}
