package aglobe.agent.dataanalyzer;

/**
 *
 * <p>Title: A-Globe Data Analyzer</p>
 *
 * <p>Description: The extents of the visible area. The 2D interval specifying the part of the visualization,
 * which will be displayed in the GraphComponent.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author Miroslav Uller
 *
 * @version 1.0
 */
public class GraphInfo {
    /**
     * The minimum x value.
     */
    public double minX;

    /**
     * The maximum x value.
     */
    public double maxX;

    /**
     * The minimum y value.
     */
    public double minY;

    /**
     * The maximum y value.
     */
    public double maxY;

    /**
     * Class constructor.
     * Constructs the extents with default values.
     */
    public GraphInfo() {
        minX = minY = -3.0;
        maxX = maxY = 1.0;
    }

    /**
     * Class constructor.
     * @param minX the minimum x value
     * @param minY the minimum y value
     * @param maxX the maximum x value
     * @param maxY the maximum y value
     */
    public GraphInfo(double minX, double minY, double maxX, double maxY) {
        this.minX = minX;
        this.minY = minY;
        this.maxX = maxX;
        this.maxY = maxY;
    }
}
