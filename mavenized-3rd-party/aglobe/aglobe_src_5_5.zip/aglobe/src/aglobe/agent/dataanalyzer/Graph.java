package aglobe.agent.dataanalyzer;

import java.awt.*;
import java.util.*;

/**
 *
 * <p>Title: A-Globe Data Analyzer</p>
 *
 * <p>Description: The visualization of a discrete function. The 2D plot of a discrete function.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author Miroslav Uller
 *
 * @version 1.0
 */
public class Graph {
    /**
     * Graph color.
     */
    private Color color;

    /**
     * Graph description.
     */
    private String description;

    /**
     * The visualized discrete function.
     */
    private DiscreteFunction df;

    /**
     * An auxiliary buffer.
     */
    private ArrayList<Point> pointBuffer = new ArrayList<Point>();

    /**
     * Graph visibility.
     */
    private boolean visible = false;

    public static GraphComponent gc = null;

    /**
     * Class constructor.
     * @param df the discrete function
     * @param description the description
     * @param color the color
     */
    public Graph(DiscreteFunction df, String description, Color color) {
        this.df = df;
        this.description = description;
        this.color = color;
    }

    /**
     * Returns plot color.
     * @return plot color
     */
    public final Color getColor() {
        return color;
    }

    /**
     * Sets plot color.
     * @param color a color
     */
    public void setColor(Color color) {
        this.color = color;
        if(visible) {
          gc.removeGraph(df);
          gc.addGraph(df, description, color);
        }
    }

    /**
     * Returns plot description.
     * @return plot description
     */
    public final String getDescription() {
        return description;
    }

    /**
     * Returns the discrete function.
     * @return  the discrete function
     */
    public final DiscreteFunction getFunction() {
        return df;
    }

    /**
     * Returns true, if the plot is visible.
     * @return true, if the plot is visible
     */
    public final boolean isVisible() {
      return visible;
    }

    /**
     * Sets plot visibility.
     * @param enabled true, if the plot should be visible.
     */
    public final void setVisible(boolean enabled) {
      visible = enabled;
      if(visible) {
        gc.addGraph(df, description, color);
      } else {
        gc.removeGraph(df);
      }
    }


    /**
     * Draws the 2D plot.
     * @param g the graphics context
     * @param gi the graph information
     * @param rect the rectangular area of the canvas, where the graph will be drawn
     */
    public void draw(Graphics2D g, GraphInfo gi, Rectangle rect) {
        double x, x2, y;
        double dx = 1/(gi.maxX-gi.minX);
        double dy = 1/(gi.maxY-gi.minY);
        int n, ndx, xx1, xx2, yy;
        n = df.size();
        if(n==0) return;
        pointBuffer.clear();
        g.setColor(color);
        ndx = df.getIndex(gi.minX);
        if(ndx<0) {
          ndx = 0;
          x = df.getSample(ndx).x;
          if(x >= gi.maxX) return;
        } else {
          x = gi.minX;
        }
        while((x < gi.maxX) && (ndx < n-1)) {
            y = df.getSample(ndx).y;
            ndx++;
            x2 = df.getSample(ndx).x;
            if(x2 > gi.maxX) x2 = gi.maxX;
            xx1 = rect.x+(int)(rect.width*(x-gi.minX)*dx);
            xx2 = rect.x+(int)(rect.width*(x2-gi.minX)*dx);
            yy  = rect.height + rect.y - (int)(rect.height*(y-gi.minY)*dy);
            pointBuffer.add(new Point(xx1, yy));
            pointBuffer.add(new Point(xx2, yy));
            x = x2;
        }
        if(x < gi.maxX) {
            y = df.getSample(ndx).y;
            xx1 = rect.x+(int)(rect.width*(x-gi.minX)*dx);
            xx2 = rect.x+rect.width;
            yy  = rect.height + rect.y - (int)(rect.height*(y-gi.minY)*dy);
            pointBuffer.add(new Point(xx1, yy));
            pointBuffer.add(new Point(xx2, yy));
        }
        n = pointBuffer.size();
        Point p1, p2;
        p1 = pointBuffer.get(0);
        for(int i=1; i<n; i++) {
            p2 = pointBuffer.get(i);
            g.drawLine(p1.x, p1.y, p2.x, p2.y);
            p1 = p2;
        }
    }

}
