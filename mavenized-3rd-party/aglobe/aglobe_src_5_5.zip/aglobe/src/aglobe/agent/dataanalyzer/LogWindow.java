package aglobe.agent.dataanalyzer;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Time;

/**
*
* <p>Title: A-Globe Data Analyzer</p>
*
* <p>Description: Log window.</p>
*
* <p>Copyright: Copyright (c) 2005</p>
*
* <p>Company: Gerstner Laboratory</p>
*
* @author Miroslav Uller
*
* @version 1.0
*/
public class LogWindow extends JFrame {
    private static final long serialVersionUID = 7529443957497948264L;
    JScrollPane scrollPane = new JScrollPane();
    JTextArea textArea = new JTextArea();
    BorderLayout borderLayout1 = new BorderLayout();
    JPanel panel = new JPanel();
    JButton btnClear = new JButton();

    /**
     * Class constructor.
     * Constructs a log window.
     */
      public LogWindow() {
        try {
          jbInit();
        }
        catch (Exception ex) {
          ex.printStackTrace();
        }
      }

      private void jbInit() throws Exception {
          textArea.setEditable(false);
          textArea.setText("");
          this.getContentPane().setLayout(borderLayout1);
          btnClear.setText("Clear");
          btnClear.addActionListener(new LogWindow_btnClear_actionAdapter(this));
          this.getContentPane().add(scrollPane, java.awt.BorderLayout.CENTER);
          scrollPane.getViewport().add(textArea);
          this.getContentPane().add(panel, java.awt.BorderLayout.SOUTH);
          panel.add(btnClear);
          scrollPane.setAutoscrolls(true);
      }


      /**
       * Clears the contents of log window.
       */
      public void clear() {
        textArea.setText("");
      }

      /**
       * Appends a string to the log.
       */
      public void append(String str) {
        textArea.append((new Time(System.currentTimeMillis())) + "  " + str);
        textArea.append("\n");
        JScrollBar jsb = scrollPane.getVerticalScrollBar();
        jsb.setValue(jsb.getMaximum());
        if(isVisible()) scrollPane.updateUI();
      }


      /**
       * Clear button calllback.
       * @param e
       */
      public void btnClear_actionPerformed(ActionEvent e) {
        clear();
      }
    }

    class LogWindow_btnClear_actionAdapter
        implements ActionListener {
      private LogWindow adaptee;
      LogWindow_btnClear_actionAdapter(LogWindow adaptee) {
        this.adaptee = adaptee;
      }

      @Override
	public void actionPerformed(ActionEvent e) {
        adaptee.btnClear_actionPerformed(e);
      }
}
