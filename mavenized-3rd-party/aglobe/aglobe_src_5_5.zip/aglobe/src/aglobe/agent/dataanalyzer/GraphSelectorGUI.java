package aglobe.agent.dataanalyzer;

import javax.swing.*;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;

/**
*
* <p>Title: A-Globe Data Analyzer</p>
*
* <p>Description: GUI window for the graph selector.</p>
*
* <p>Copyright: Copyright (c) 2005</p>
*
* <p>Company: Gerstner Laboratory</p>
*
* @author Miroslav Uller
*
* @version 1.0
*/
public class GraphSelectorGUI extends JFrame {
    private static final long serialVersionUID = 1140393361373768716L;
    private DataAnalyzerAgent da = null;
    private GraphSelector gs = null;
    private MatrixGraphSelector gs2 = null;
    private JTabbedPane tabbedPane = new JTabbedPane();

    /**
     * Class constructor.
     * @param da the Data Analyzer
     */
    public GraphSelectorGUI(DataAnalyzerAgent da) {
        this.da = da;
        try {
            jbInit();
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event-dispatching thread.
     */
    private void createAndShowGUI() {
        gs = new GraphSelector(da);
        gs2 = new MatrixGraphSelector(da);

        tabbedPane.addTab("Matrix view", null, gs2, "");
        tabbedPane.addTab("List view", null, gs, "");
        setTitle("Graph Selector");
        setSize(800, 400);
        validate();
        setVisible(true);
    }

    /**
     * Shows the graph selector GUI.
     */
    public void showGUI() {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            @Override
			public void run() {
                createAndShowGUI();
            }
        });
    }

    /**
     * Updates the content of the graph selector GUI.
     */
    public void updateContent() {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            @Override
			public void run() {
                if(gs!=null) gs.updateContent();
                if(gs2!=null) gs2.updateContent();
                tabbedPane.updateUI();
            }
        });
    }

    private void jbInit() throws Exception {
        this.addWindowListener(new GraphSelectorGUI_this_windowAdapter(this));
        this.getContentPane().add(tabbedPane);
    }

    /**
     * @param e
     */
    public void this_windowClosing(WindowEvent e) {
    }

    public void enableChoice(boolean enabled) {
        tabbedPane.setEnabled(enabled);
    }

}

class GraphSelectorGUI_this_windowAdapter extends WindowAdapter {
    private GraphSelectorGUI adaptee;
    GraphSelectorGUI_this_windowAdapter(GraphSelectorGUI adaptee) {
        this.adaptee = adaptee;
    }

    @Override
    public void windowClosing(WindowEvent e) {
        adaptee.this_windowClosing(e);
    }
}
