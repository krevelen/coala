package aglobe.util;

import java.io.FileInputStream;
import java.io.File;
import java.io.InputStream;
import java.io.IOException;
import java.io.FileNotFoundException;

/**
 * @internal
 * <p>Title: Aglobe</p>
 *
 * <p>Description: todo</p>
 *
 * <p>Copyright: Copyright (c) 2007</p>
 *
 * <p>Company: Agent Technology Center, Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.1 $ $Date: 2009/12/16 12:24:21 $
 */
public class IncludingInputStream extends InputStream {
    private final static int BUFFER_SIZE = 1024;
    private final static char[] INCLUDE_STRING = {'<','!', '-', '-', '#', 'i', 'n', 'c', 'l', 'u', 'd', 'e'};
    private final static char[] END_INCLUDE_STRING = {'-', '-', '>'};
    private final static char[] PATH_STRING = {'<', '!', '-', '-', '#', 'p', 'a', 't', 'h', '-', '-', '>'};
    @SuppressWarnings("unused")
    private final static File initialRelative = new File("./");

    private byte[] buffer = new byte[BUFFER_SIZE];
    private int wPos = 0;
    private int rPos = 0;

    public IncludingInputStream(File file) throws FileNotFoundException, IOException {
        this(file, file);
    }

    private IncludingInputStream(File file, File relativeFromSrc) throws FileNotFoundException, IOException {
//        System.out.println("File: "+file.toString()+" relative: "+relativeFromSrc.toString());
        byte[] pathBytes = null;
        InputStream is = new FileInputStream(file);
        int data;
        int inclusion = 0;
        int path = 0;
        boolean inInclude = false;
        StringBuilder sb = new StringBuilder();
        data = is.read();
        while (data >= 0) {
            if (inInclude) {
                if (matchPattern(END_INCLUDE_STRING, data, inclusion)) {
                    inclusion++;
                    if (inclusion == END_INCLUDE_STRING.length) {
                        inInclude = false;
                        inclusion = 0;
                        // sb contains file reference
                        String child = sb.toString().trim();
                        IncludingInputStream iis = new IncludingInputStream(new File(file.getParent(), child), new File(relativeFromSrc.getParent(), child));
                        int toInclude = iis.dataAvailable();
                        // check the capacity
                        if (buffer.length < (wPos + toInclude)) {
                            byte[] newBuffer = new byte[buffer.length + toInclude + BUFFER_SIZE];
                            System.arraycopy(buffer, 0, newBuffer, 0, wPos);
                            buffer = newBuffer;
                        }
                        wPos += iis.read(buffer, wPos, toInclude);
                        iis.close();
                        sb = new StringBuilder();
                    }
                    data = is.read();
                } else {
                    // flush inclusion
                    if (inclusion > 0) {
                        for (int i = 0; i < inclusion; i++) {
                            sb.append(END_INCLUDE_STRING[i]);
                        }
                        inclusion = 0;
                    } else {
                        sb.append((char)data);
                        data = is.read();
                    }
                }
            } else {
                if (matchPattern(INCLUDE_STRING, data, inclusion)) {
                    inclusion++;
                    if (inclusion == INCLUDE_STRING.length) {
                        inInclude = true;
                        inclusion = 0;
                        path = 0;
                    }
                    data = is.read();
                } else {
                    if (inclusion == 5) {
                        path = 5;
                        inclusion = 0;
                    }
                    if (path > 0) {
                        if (matchPattern(PATH_STRING, data, path)) {
                            path++;
                            if (path == PATH_STRING.length) {
                                path = 0;
                                // found path tag
                                if (pathBytes == null) {
                                    String parent = relativeFromSrc.getParent();
                                    pathBytes = ((parent == null) ? "./":(parent+"/")).getBytes();
                                }
                                if (buffer.length < (wPos + pathBytes.length)) {
                                    byte[] newBuffer = new byte[buffer.length + pathBytes.length + BUFFER_SIZE];
                                    System.arraycopy(buffer, 0, newBuffer, 0, wPos);
                                    buffer = newBuffer;
                                }
                                System.arraycopy(pathBytes, 0, buffer, wPos, pathBytes.length);
                                wPos += pathBytes.length;
                            }
                            data = is.read();
                        } else {
                            for (int i = 0; i<path; i++) {
                                storeData(PATH_STRING[i]);
                            }
                            path = 0;
                        }
                    } else {
                        if (inclusion > 0) {
                            // flush inclusion
                            for (int i = 0; i < inclusion; i++) {
                                storeData(INCLUDE_STRING[i]);
                            }
                            inclusion = 0;
                        } else {
                            storeData(data);
                            data = is.read();
                        }
                    }
                }
            }
        }
        is.close();
    }

    private boolean matchPattern(char[] pattern, int data, int inclusion) {
        if (inclusion < pattern.length) {
            return pattern[inclusion] == data;
        }
        return false;
    }

    private void storeData(int data) {
        if (wPos == buffer.length) {
            byte[] newBuffer = new byte[buffer.length * 2];
            System.arraycopy(buffer, 0, newBuffer, 0, buffer.length);
            buffer = newBuffer;
        }
        buffer[wPos++] = (byte)data;
    }

    private int dataAvailable() {
        return wPos - rPos;
    }

    @Override
    public int read() throws IOException {
        if (rPos >= wPos) {
            return -1;
        }
        return buffer[rPos++];
    }

    /**
     * Reads up to <code>len</code> bytes of data from the input stream into an array of bytes.
     *
     * @param b the buffer into which the data is read.
     * @param off the start offset in array <code>b</code> at which the data is written.
     * @param len the maximum number of bytes to read.
     * @return the total number of bytes read into the buffer, or <code>-1</code> if there is no more data because the end of the stream has been reached.
     * @throws IOException If the first byte cannot be read for any reason other than end of file, or if the input stream has been closed, or if some other
     *   I/O error occurs.
     */
    @Override
    public int read(byte[] b, int off, int len) throws IOException {
        if (rPos >= wPos) {
            return -1;
        }
        int toCopy = Math.min(Math.min(b.length-off, len), wPos - rPos);
        System.arraycopy(buffer, rPos, b, off, toCopy);
        rPos += toCopy;
        return toCopy;
    }
}
