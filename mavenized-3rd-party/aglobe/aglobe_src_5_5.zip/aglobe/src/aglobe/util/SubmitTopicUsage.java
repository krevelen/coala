package aglobe.util;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * Annotation for "Topic Dependencies" Eclipse plug-in support.
 * Used for methods that send topics using non-constant value as a name. In such
 * a case, the plug-in is not able to recognize topic name and needs this hint.
 * <p>
 * All the function calls that send topics and contain non-constant string as a name
 * are than ignored. Those using constant strings are still used, so it is not
 * necessary to mention those topics in the annotation.
 * 
 * @author pavel
 * @see SubscribeTopicUsage
 */
@Target({ElementType.CONSTRUCTOR, ElementType.METHOD})
public @interface SubmitTopicUsage {

	/**
	 * An array of topic names that will be added to the list of topics sent by
	 * this module. Should contain constant strings, or references to constant (final)
	 * strings declared in other classes.
	 */
	String[] value();
}
