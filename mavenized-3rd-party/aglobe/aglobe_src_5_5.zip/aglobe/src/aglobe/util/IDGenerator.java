package aglobe.util;

import java.util.Arrays;

/**
 * This class generates IDs composed of prefix and an number (in reverse format).
 * It doesn't create any unnecessary object within the getNextID method.
 * @author Honza
 *
 */
public class IDGenerator {
    // length of prefix
    private int idStartLen;
    // last generated ID
    private char[] actualID;
    // length of actualID
    private int idLen;

    private Object lock = new Object();

    /**
     * Creates a generator with given prefix.
     * @param prefix is prefix of generated ids.
     */
    public IDGenerator(String prefix) {
        actualID = Arrays.copyOf(prefix.toCharArray(), 100);

        idStartLen = prefix.length();
        idLen = idStartLen;
    }

    /**
     * Generates next ID.
     * @return next ID.
     */
    public String getNextID() {
        // Works in preallocated array actualID
        synchronized (lock) {
            int actualLetter = idStartLen;
            while (actualID[actualLetter] == '9') {
                actualID[actualLetter] = '0';
                actualLetter++;
            }
            if (actualLetter == idLen) {
                actualID[actualLetter] = '1';
                idLen++;
            } else {
                actualID[actualLetter]++;
            }
            return new String(actualID, 0, idLen);
        }
    }

}