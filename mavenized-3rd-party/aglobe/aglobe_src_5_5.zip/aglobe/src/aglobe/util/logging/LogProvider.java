package aglobe.util.logging;

/**
 * @internal
 * <p>Title: Aglobe</p>
 *
 * <p>Description: LogProvider is used by aglobe.util.Logger.log(Level level, LogProvider logProvider) method
 * for logging complex log message where the resources for generating log message are significant. The listener method
 * is called only if the log message is necessary</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Agent Technology Center, Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.5 $ $Date: 2009/05/15 08:46:58 $
 */
public interface LogProvider {
    /**
     * Method is called iff the loging passed all filtration tests and log message
     * is requested.
     * @return String
     */
    public String getLogMessage();
}
