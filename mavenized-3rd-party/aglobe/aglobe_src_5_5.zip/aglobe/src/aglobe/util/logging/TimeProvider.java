package aglobe.util.logging;

import aglobe.service.topics.TopicsService;

/**
 * @internal
 * <p>Title: A-Globe</p>
 *
 * <p>Description: Provides formatted timestamp information which is added to all log messages.</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.5 $ $Date: 2009/06/15 13:38:02 $
 */
public interface TimeProvider {
    /**
     * Makes subscription using the following not null shell
     */
    public void makeSubscription(TopicsService.Shell topicsShell);

    /**
     * Returns current timestamp
     * @return String
     */
    public String getTimeStamp();
}
