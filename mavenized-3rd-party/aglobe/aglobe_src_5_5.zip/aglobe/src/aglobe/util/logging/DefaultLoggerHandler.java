package aglobe.util.logging;

import java.util.logging.*;
import aglobe.util.Logger;

/**
 * @internal
 * <p>Title: AGlobe</p>
 *
 * <p>Description: Logger handler used for catching all log messages passed via java.util.logging.Logger</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Agent Technology Center, Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.8 $ $Date: 2009/05/15 08:46:58 $
 */
public class DefaultLoggerHandler extends Handler {
    /**
     * Close the <tt>Handler</tt> and free all associated resources.
     *
     * @throws SecurityException if a security manager exists and if the caller does not have <tt>LoggingPermission("control")</tt>.
     */
    @Override
    public void close() throws SecurityException {
    }

    /**
     * Flush any buffered output.
     *
     */
    @Override
    public void flush() {
    }

    /**
     * Publish a <tt>LogRecord</tt>.
     *
     * @param record description of the log event. A null record is silently ignored and is not published
     */
    @Override
    public void publish(java.util.logging.LogRecord record) {
        // forward it
        if ((record.getLoggerName() == null) || !record.getLoggerName().startsWith("sun.awt.X11")) {
            Logger.log(record);
        }
    }
}
