package aglobe.util.logging;

import java.io.Externalizable;
import java.io.ObjectOutput;
import java.io.IOException;
import java.io.ObjectInput;
import aglobe.util.ConversionTools;
import java.util.logging.Level;

/**
 * @internal
 * <p>Title: A-Globe</p>
 *
 * <p>Description: agent platform A-Globe</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.6 $ $Date: 2010/08/04 11:48:05 $
 */
public class LogRecord implements Externalizable {
    public Level level;
    public String timeStamp;
    public String container;
    public String elementaryEntityName;
    public String className;
    public String methodName;
    public String threadName;
    public String fileName;
    public int lineNumber;
    public String message;

    public LogRecord() {

    }

    @Override
	public void writeExternal(ObjectOutput out) throws IOException {
        out.writeObject(level);
        ConversionTools.writeString(out, timeStamp);
        ConversionTools.writeString(out, container);
        ConversionTools.writeString(out, elementaryEntityName);
        ConversionTools.writeString(out, className);
        ConversionTools.writeString(out, methodName);
        ConversionTools.writeString(out, threadName);
        ConversionTools.writeString(out, fileName);
        out.writeInt(lineNumber);
        ConversionTools.writeString(out, message);
    }

    @Override
	public void readExternal(ObjectInput in) throws ClassNotFoundException, IOException {
        level = (Level) in.readObject();
        timeStamp = ConversionTools.readString(in);
        container = ConversionTools.readString(in);
        elementaryEntityName = ConversionTools.readString(in);
        className = ConversionTools.readString(in);
        methodName = ConversionTools.readString(in);
        threadName = ConversionTools.readString(in);
        fileName = ConversionTools.readString(in);
        lineNumber = in.readInt();
        message = ConversionTools.readString(in);

    }

}
