package aglobe.util;

import java.awt.Color;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.ObjectInput;
import java.io.IOException;
import java.io.ObjectOutput;

/**
 * <p>Title: </p>
 * <p>Description: Conversion tools</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.8 $ $Date: 2010/08/30 08:22:48 $
 */
public final class ConversionTools {
    /**
     * Singleton class
     */
    private ConversionTools() {
    }

    /**
     * Print color to the string representation
     * @param c Color
     * @return String
     */
    public final static String printColor(final Color c) {
        return "0x" + Integer.toHexString(c.getRGB());
    }

    /**
     * Parse color back to the object instance
     * @param s String
     * @return Color
     */
    public final static Color parseColor(final String s) {
        Color c = Color.getColor(s);
        try {
            c = (Color) Color.class.getDeclaredField(s).get(null);
        }
        catch (Exception ex) {
        }
        try {
            if (c == null) {
                c = Color.decode(s);
            }
        }
        catch (NumberFormatException ex1) {
            c = Color.WHITE;
        }
        return c;
    }

    /**
     * Write String to the output stream in special A-Globe format. For reading it
     * back from the stream the readeString method need to be used.
     *
     * @param out ObjectOutput
     * @param string String - can be null
     * @throws IOException
     */
    public final static void writeString(final ObjectOutput out, final String string) throws
            IOException {
        if (string == null) {
            out.writeInt( -1);
        } else {
            final int len = string.length();
            out.writeInt(len);
            final char[] chars = new char[len];
            string.getChars(0, len, chars, 0);
            for (int i = 0; i < len; i++) {
                out.writeChar(chars[i]);
            }
        }
    }

    /**
     * Write String to the output stream in special A-Globe format. For reading it
     * back from the stream the readeString method need to be used.
     *
     * @param out DataOutput
     * @param string String - can be null
     * @throws IOException
     */
    public final static void writeString(final DataOutput out, final String string) throws
            IOException {
        if (string == null) {
            out.writeInt( -1);
        } else {
            final int len = string.length();
            out.writeInt(len);
            final char[] chars = new char[len];
            string.getChars(0, len, chars, 0);
            for (int i = 0; i < len; i++) {
                out.writeChar(chars[i]);
            }
        }
    }

    /**
     * Read String from the input stream stored in special A-Globe format written
     * by writeString method.
     *
     * @param in ObjectInput
     * @return String - can be null
     * @throws IOException
     */
    public final static String readString(final ObjectInput in) throws IOException {
        final int len = in.readInt();
        if (len < 0) {
            return null;
        } else {
            if (len == 0) {
                return "";
            }
            final char[] buf = new char[len];
            for (int i = 0; i < len; i++) {
                buf[i] = in.readChar();
            }
            return new String(buf);
        }
    }

    /**
     * Read String from the input stream stored in special A-Globe format written
     * by writeString method.
     *
     * @param in DataOutput
     * @return String - can be null
     * @throws IOException
     */
    public final static String readString(final DataInput in) throws IOException {
        final int len = in.readInt();
        if (len < 0) {
            return null;
        } else {
            if (len == 0) {
                return "";
            }
            final char[] buf = new char[len];
            for (int i = 0; i < len; i++) {
                buf[i] = in.readChar();
            }
            return new String(buf);
        }
    }

    /**
     * Write byte array to the object output
     * @param out ObjectOutput - here is byte array  written
     * @param array byte[] - byte array to write
     * @throws IOException - if there is some problem with writing
     */
    public final static void writeByteArray(final ObjectOutput out, final byte[] array) throws IOException {
        if (array == null) {
            out.writeInt(-1);
        } else {
            out.writeInt(array.length);
            out.write(array);
        }
    }

    /**
     * Read complete byte array from input stream otherwise throw exception
     *
     * @param in InputStream - source input stream
     * @throws IOException - problem during reading
     * @return byte[] - output byte array
     */
    public final static byte[] readByteArray(final ObjectInput in) throws IOException {
        int remaining = in.readInt();
        if (remaining == -1) {
            return null;
        }
        final byte[] retVal = new byte[remaining];
        int pos = 0;
        int cur;
        while (remaining > 0) {
            cur = in.read(retVal, pos, remaining);
            if (cur < 0) {
                throw new IOException("End of stream");
            }
            pos += cur;
            remaining -= cur;
        }
        return retVal;
    }

    public final static void writeStringArray(final ObjectOutput out, final String[] array) throws IOException {
        if (array == null) {
            out.writeInt(-1);
        } else {
            final int len = array.length;
            out.writeInt(len);
            for (int i=0; i<len; i++) {
                writeString(out, array[i]);
            }
        }
    }

    public final static String[] readStringArray(final ObjectInput in) throws IOException {
        final int len = in.readInt();
        if (len == -1) {
            return null;
        }
        final String[] retVal = new String[len];
        for (int i=0; i<len; i++) {
            retVal[i] = readString(in);
        }
        return retVal;
    }
}
