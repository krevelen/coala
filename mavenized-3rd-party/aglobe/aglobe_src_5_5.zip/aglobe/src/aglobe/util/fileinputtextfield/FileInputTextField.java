package aglobe.util.fileinputtextfield;

import java.awt.*;
import java.awt.event.*;
import java.beans.PropertyChangeSupport;
import java.io.File;
import java.util.Vector;
import javax.swing.*;
import javax.swing.filechooser.FileFilter;

/**
 * @internal
 * <p>Title: A-Globe</p>
 *
 * <p>Description: FileInputTextField is internal A-Globe class used for file
 * input field</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.10 $ $Date: 2010/08/04 11:48:06 $
 */
public class FileInputTextField extends JPanel
{
    private static final long serialVersionUID = 3773541973340820205L;
    private JTextField fileNameTextField;
    private JButton fileChooserButton;
    private JFileChooser fc;
    private FileFilter fileFilters[];
    private transient Vector<TextListener> textListeners;
    private GridBagLayout gridBagLayout1;
    private int columns;
    private transient PropertyChangeSupport propertyChangeListeners;

    /**
     * Constructor
     * @param filters FileFilter[]
     */
    public FileInputTextField(FileFilter filters[])
    {
        this();
        setFileFilters(filters);
    }

    /**
     * Constructor
     * @param dir String
     * @param filters FileFilter[]
     */
    public FileInputTextField(String dir, FileFilter filters[])
    {
        this();
        setFileFilters(filters);
        setCurrentDirectory(dir);
    }

    /**
     * Constructor
     * @param dir String
     */
    public FileInputTextField(String dir)
    {
        this();
        setCurrentDirectory(dir);
    }

    /**
     * Constructor
     */
    public FileInputTextField()
    {
        fileNameTextField = new JTextField();
        fileChooserButton = new JButton();
        fc = new JFileChooser();
        gridBagLayout1 = new GridBagLayout();
        propertyChangeListeners = new PropertyChangeSupport(this);
        try
        {
            jbInit();
            Dimension tp = fileNameTextField.getPreferredSize();
            Dimension tb = fileChooserButton.getPreferredSize();
            tb.height = tp.height;
            fileChooserButton.setPreferredSize(tb);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }

    /**
     * Initialization of the frame
     * @throws Exception
     */
    private void jbInit()
        throws Exception
    {
        setLayout(gridBagLayout1);
        fileChooserButton.setText("...");
        fileChooserButton.addActionListener(new ActionListener() {

            @Override
			public void actionPerformed(ActionEvent e)
            {
                fileChooserButton_actionPerformed(e);
            }

        });
        fileNameTextField.addInputMethodListener(new InputMethodListener() {

            @Override
			public void inputMethodTextChanged(InputMethodEvent e)
            {
                fileNameTextField_inputMethodTextChanged(e);
            }

            @Override
			public void caretPositionChanged(InputMethodEvent inputmethodevent)
            {
            }

        });
        add(fileNameTextField, new GridBagConstraints(0, 0, 1, 1, 1.0D, 0.0D, 10, 2, new Insets(0, 0, 0, 1), 0, 0));
        add(fileChooserButton, new GridBagConstraints(1, 0, 1, 1, 0.0D, 0.0D, 17, 0, new Insets(0, 0, 0, 0), 0, 0));
    }

    /**
     * Set file filters
     * @param fileFilters FileFilter[]
     */
    public void setFileFilters(FileFilter fileFilters[])
    {
        this.fileFilters = fileFilters;
        for(int i = 0; i < fileFilters.length; i++)
            fc.addChoosableFileFilter(fileFilters[i]);

    }

    /**
     * Get file filters
     * @return FileFilter[]
     */
    public FileFilter[] getFileFilters()
    {
        return fileFilters;
    }

    /**
     * Set current directory
     * @param currentDirectory String
     */
    public void setCurrentDirectory(String currentDirectory)
    {
        fc.setCurrentDirectory(new File(currentDirectory));
    }

    /**
     * Get current directory
     * @return String
     */
    public String getCurrentDirectory()
    {
        return fc.getCurrentDirectory().getAbsolutePath();
    }

    /**
     * Remove test listener
     * @param l TextListener
     */
    public synchronized void removeTextListener(TextListener l)
    {
        if(textListeners != null && textListeners.contains(l))
        {
            Vector<TextListener> v = new Vector<TextListener>(textListeners);
            v.removeElement(l);
            textListeners = v;
        }
    }

    /**
     * Add text listener
     * @param l TextListener
     */
    public synchronized void addTextListener(TextListener l)
    {
        Vector<TextListener> v = textListeners != null ? new Vector<TextListener>(textListeners) : new Vector<TextListener>(2);
        if(!v.contains(l))
        {
            v.addElement(l);
            textListeners = v;
        }
    }

    /**
     * Get test
     * @return String
     */
    public String getText()
    {
        return fileNameTextField.getText();
    }

    /**
     * Set text
     * @param newtext String
     */
    public void setText(String newtext)
    {
        fileNameTextField.setText(newtext);
    }

    /**
     * Fire text value change
     * @param e TextEvent
     */
    protected void fireTextValueChanged(TextEvent e)
    {
        if(textListeners != null)
        {
            Vector<TextListener> listeners = textListeners;
            int count = listeners.size();
            for(int i = 0; i < count; i++)
                listeners.elementAt(i).textValueChanged(e);

        }
    }

    /**
     * Called when name is changed
     * @param e InputMethodEvent
     */
    void fileNameTextField_inputMethodTextChanged(InputMethodEvent e)
    {
        if(e.getID() == 1100)
            fireTextValueChanged(new TextEvent(this, 900));
    }

    /**
     * Button pressed
     * @param e ActionEvent
     */
    void fileChooserButton_actionPerformed(ActionEvent e)
    {
        int retVal = fc.showOpenDialog(this);
        if(retVal == 0)
        {
            File file = fc.getSelectedFile();
            if(file != null)
                fileNameTextField.setText(file.getAbsolutePath());
        }
    }

    /**
     * Set columns
     * @param columns int
     */
    public void setColumns(int columns)
    {
        int oldColumns = this.columns;
        this.columns = columns;
        fileNameTextField.setColumns(columns);
        propertyChangeListeners.firePropertyChange("columns",
        		Integer.valueOf(oldColumns), Integer.valueOf(columns));
    }

    /**
     * Get columns
     * @return int
     */
    public int getColumns()
    {
        return fileNameTextField.getColumns();
    }
}
