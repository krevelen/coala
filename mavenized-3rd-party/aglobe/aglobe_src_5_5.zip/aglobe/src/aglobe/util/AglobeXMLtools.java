package aglobe.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.adapters.XmlAdapter;

import aglobe.ontology.AgentInfo;
import aglobe.ontology.AglobeParam;
import aglobe.ontology.Libraries;
import aglobe.platform.transport.CloneBuffer;

/**
 * <p>Title: A-Globe XML Tools</p>
 * <p>Description: This class contains static utility methods for XML marshaling and unmarshalling.</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.23 $ $Date: 2010/08/04 11:48:05 $
 *
 */
public final class AglobeXMLtools {
    /**
     * XML extension
     */
    public static final String XMLEXT = ".xml";

    /**
     * Cached jaxb contexts
     */
    private static final HashMap<ClassLoader, HashMap<String,JAXBContext>> jaxbContexts = new HashMap<ClassLoader, HashMap<String,JAXBContext>>();

    /**
     * Keeps contexts marshallers
     */
    private static final HashMap<JAXBContext, Marshaller> jaxbMarshallers = new HashMap<JAXBContext,Marshaller>();

    /**
     * Keeps contexts unmarshallers
     */
    private static final HashMap<JAXBContext, Unmarshaller> jaxbUnmarshallers = new HashMap<JAXBContext,Unmarshaller>();

    /**
     * JAXB sync object
     */
    private static final ReentrantLock jaxbSync = new ReentrantLock();

    /**
     * Singleton class
     */
    private AglobeXMLtools() {

    }

    /**
     * Get jaxb context for the specified jaxb object
     *
     * @param object Object - Jaxb marshallable root element
     * @return JAXBContext
     * @throws JAXBException
     */
    private final static JAXBContext getJAXBContext(final Object object) throws JAXBException {
        String contextPath;
        ClassLoader classLoader;
        JAXBContext retVal;
        if (object instanceof Class<?>) {
            Class<?> c = (Class<?>) object;
            contextPath = c.getPackage().getName();
            classLoader = c.getClassLoader();
        } else {
            contextPath = object.getClass().getPackage().getName();
            classLoader = object.getClass().getClassLoader();
        }
        // try to read JAXBContext from the previous one first
        HashMap<String,JAXBContext> precachedContexts = jaxbContexts.get(classLoader);
        if (precachedContexts == null) {
            precachedContexts = new HashMap<String,JAXBContext>();
            jaxbContexts.put(classLoader, precachedContexts);
        }
        retVal = precachedContexts.get(contextPath);
        if (retVal != null) {
            return retVal;
        }
        // create new context
        retVal = JAXBContext.newInstance(contextPath, classLoader);
        precachedContexts.put(contextPath, retVal);
        return retVal;
    }

    /**
     * Get jaxb marshaller for specified jaxb object
     *
     * @param object Object
     * @return Marshaller
     * @throws JAXBException
     */
    private final static Marshaller getJAXBMarshaller(final Object object) throws JAXBException {
        final JAXBContext jc = getJAXBContext(object);
        Marshaller retVal = jaxbMarshallers.get(jc);
        if (retVal != null) {
            return retVal;
        }
        retVal = jc.createMarshaller();
        retVal.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
        jaxbMarshallers.put(jc, retVal);
        return retVal;
    }

    /**
     * Get jaxb unmarshaller for specified jaxb object
     * @param object Object
     * @return Unmarshaller
     * @throws JAXBException
     */
    private final static Unmarshaller getJAXBUnmarshaller(final Object object) throws JAXBException {
        final JAXBContext jc = getJAXBContext(object);
        Unmarshaller retVal = jaxbUnmarshallers.get(jc);
        if (retVal != null) {
            return retVal;
        }
        retVal = jc.createUnmarshaller();
        jaxbUnmarshallers.put(jc, retVal);
        return retVal;
    }

    /**
     * Marshall JAXB object to the specified output stream
     *
     * @param object Object
     * @param outputStream OutputStream
     * @throws JAXBException
     */
    public final static void marshallJAXBObject(final Object object, final OutputStream outputStream) throws JAXBException {
        jaxbSync.lock();
        try {
            final Marshaller marshaller = getJAXBMarshaller(object);
            marshaller.marshal(object, outputStream);
        } finally {
            jaxbSync.unlock();
        }
    }

    /**
     * Unmarshall JAXB object form the specified input stream
     *
     * @param defClass Class - defining class which is expected to be read
     * @param inputStream InputStream
     * @return Object
     * @throws JAXBException
     */
    public final static Object unmarshallJAXBObject(final Class<?> defClass, final InputStream inputStream) throws JAXBException {
        return unmarshallJAXBObject(defClass, inputStream, null, false);
    }

    /**
     * Unmarshall JAXB object form the specified input stream. Use this method if the unmarshall is
     * called from other running unmarshaller, e.g. from ObjectAdapter
     *
     * @param defClass Class
     * @param inputStream InputStream
     * @param doNotShareUnmarshaller boolean
     * @return Object
     * @throws JAXBException
     */
    public static Object unmarshallJAXBObject(Class<?> defClass, InputStream inputStream, boolean doNotShareUnmarshaller) throws
            JAXBException {
        return unmarshallJAXBObject(defClass, inputStream, null, doNotShareUnmarshaller);
    }

    /**
     * Unmarshall JAXB object form the specified input stream
     *
     * @param defClass Class - defining class which is expected to be read
     * @param inputStream InputStream
     * @param adapters XmlAdapter[] - array of XML adapters which should be used during unmarshalling
     * @param doNotShareUnmarshaller boolean
     * @return Object
     * @throws JAXBException
     */
    public final static Object unmarshallJAXBObject(final Class<?> defClass, final InputStream inputStream, final XmlAdapter<?,?>[] adapters, boolean doNotShareUnmarshaller) throws JAXBException {
        jaxbSync.lock();
        try {
            Unmarshaller unmarshaller;
            if (!doNotShareUnmarshaller) {
                // try get unmarshaller from shared set
                unmarshaller = getJAXBUnmarshaller(defClass);
            } else {
                // create new unique unmarshaller
                final JAXBContext jc = getJAXBContext(defClass);
                unmarshaller = jc.createUnmarshaller();
            }
            if (adapters != null) {
                for (final XmlAdapter<?, ?> elem : adapters) {
                    unmarshaller.setAdapter(elem);
                }
            }
            return unmarshaller.unmarshal(inputStream);
        } finally {
            jaxbSync.unlock();
        }
    }

    /**
     * Unmarshall JAXB object form the specified input stream. Use this method if the unmarshall is
     * called from other running unmarshaller, e.g. from ObjectAdapter
     *
     * @param defClass Class
     * @param inputStream InputStream
     * @param adapters XmlAdapter[]
     * @return Object
     * @throws JAXBException
     */
    public final static Object unmarshallJAXBObject(final Class<?> defClass, final InputStream inputStream, final XmlAdapter<?,?>[] adapters) throws JAXBException {
        return unmarshallJAXBObject(defClass, inputStream, adapters, false);
    }

    /**
     * Unmarshall JAXB object from the specified input file. In this case, inclusion tags are parsed as well.
     *
     * @param defClass
     * @param inputFile
     * @return
     * @throws FileNotFoundException
     * @throws IOException
     * @throws JAXBException
     */
    public final static Object unmarshallJAXBObject(final Class<?> defClass, final File inputFile) throws FileNotFoundException, IOException, JAXBException {
        final InputStream fis = new IncludingInputStream(inputFile);
        final Object retVal = unmarshallJAXBObject(defClass, fis,
                new XmlAdapter[] {new PathAdapter(inputFile), new ObjectAdapter(inputFile)});
        fis.close();
        return retVal;
    }


    /**
     * Print object to the string representation
     * @param o Object
     * @return String
     */
    public final static String printObject(final Object o) {
        if (o instanceof byte[]) {
            final byte[] b = (byte[]) o;
            final StringBuilder sb = new StringBuilder("byte[]{");
            boolean sc = false;
            for (int i = 0; i < b.length; i++) {
                if (sc) {
                    sb.append(";");
                }
                sb.append(b[i]);
                sc = true;
            }
            sb.append("}");
            return sb.toString();
        } else {
            return o.toString();
        }
    }

    /**
     * Clone marshallable object. If object is serializable, use cloneSerializable method
     * @param e Object - object to clone
     * @return Object - new instance. Null iff object cannot be cloned.
     */
    public final static Object cloneMarshalable(final Object e) {
        try {
            final CloneBuffer buf = CloneBuffer.getCloneBuffer();
            jaxbSync.lock();
            try {
                final Marshaller marshaller = getJAXBMarshaller(e);
                marshaller.marshal(e, buf.outputStream);
                final Unmarshaller unmarshaller = getJAXBUnmarshaller(e);
                return unmarshaller.unmarshal(buf.inputStream);
            } finally {
                jaxbSync.unlock();
                buf.release();
            }
        } catch (JAXBException ex) {
            return null;
        } catch (IOException ex) {
            return null;
        }
    }

    /**
     * Clone serializable object using ByteArray
     * @param s Serializable - object to clone
     * @return Serializable - new instance. Null iff object cannot be cloned.
     */
    public final static Serializable cloneSerializable(final Serializable s) {
        try {
            final CloneBuffer buf = CloneBuffer.getCloneBuffer();
            try {
                buf.outputStream.writeObject(s);
                buf.outputStream.flush();
                return (Serializable) buf.inputStream.readObject();
            } finally {
                buf.release();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    /**
     * Make A-Globe parameter structure with filled name and value attribute
     * @param name String
     * @param value String
     * @return Parameter
     */
    public final static AglobeParam makeAglobeParam(final String name, final String value) {
        final AglobeParam p = new AglobeParam();
        p.setName(name);
        p.setValue(value);
        return p;
    }

    /**
     * Reads parameter value
     * @param ai AgentInfo
     * @param paramName String
     * @return String - null iff parameter with specified name doesn't exists
     */
    public final static String getAglobeParamValue(final AgentInfo ai, final String paramName) {
        String retVal = null;
        for (Iterator<AglobeParam> iter = ai.getAglobeParam().iterator(); iter.hasNext(); ) {
            final AglobeParam item = iter.next();
            if (item.getName().equals(paramName)) {
                retVal = item.getValue();
                break;
            }
        }
        return retVal;
    }

    public final static AgentInfo makeAgentInfo(final String name, final String mainClass, final AglobeParam oneAglobeParam) {
        AgentInfo ai = new AgentInfo();
        ai.setName(name);
        ai.setReadableName(name);
        ai.setMainClass(mainClass);
        ai.setLibraries(new Libraries());
        List<AglobeParam> ap = ai.getAglobeParam();
        ap.add(oneAglobeParam);
        return ai;
    	
    }
}
