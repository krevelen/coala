package aglobe.util;

import javax.xml.bind.annotation.adapters.XmlAdapter;
import java.io.File;

import java.io.FileInputStream;

/**
 * @internal
 * <p>Title: Aglobe</p>
 *
 * <p>Description: todo</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Agent Technology Center, Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.1 $ $Date: 2009/12/16 12:24:21 $
 */
public class ObjectAdapter extends XmlAdapter<String,Object> {
    private final File currentFilePath;
    private final String currentFilePathStr;


    /**
     *
     * @param currentFile File
     */
    public ObjectAdapter(File currentFile) {
        currentFilePath = currentFile.getParentFile();
        currentFilePathStr = currentFilePath.getPath();
    }

    @Override
    public Object unmarshal(String v) throws Exception {
        String[] parts = v.split("\\|",2);
        final File file;
        if (parts[0].startsWith(currentFilePathStr)) {
            file = new File(parts[0]);
        } else {
            file = new File(currentFilePath, parts[0]);
        }
        if (!file.exists()) {
            Logger.logWarning("Unable to load configuration file: " + file);
            return null;
        } else {
            Class<?> targetClass = Thread.currentThread().getContextClassLoader().loadClass(parts[1]);
            Object retVal = AglobeXMLtools.unmarshallJAXBObject(targetClass,
                new FileInputStream(file.getCanonicalPath()), true);
            if (retVal == null) {
                throw new Exception("Cannot read specified object "+parts[1]+" from "+parts[0]);
            }
            if (!retVal.getClass().equals(targetClass)) {
                throw new Exception("Readed class type is different from requested one. Readed: "+retVal.getClass().toString()+" requested: "+parts[1]);
            }
            return retVal;
        }
    }

    @Override
    public String marshal(Object v) throws Exception {
        throw new Exception("Marshalling is not supported by the Inclusion adapter");
    }
}
