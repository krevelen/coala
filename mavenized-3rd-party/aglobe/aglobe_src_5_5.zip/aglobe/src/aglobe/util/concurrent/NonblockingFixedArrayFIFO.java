package aglobe.util.concurrent;

import java.util.concurrent.atomic.AtomicReferenceArray;
import java.util.concurrent.atomic.AtomicLong;

/**
 * <p>Title: A-Globe</p>
 *
 * <p>Description: NonblockingFixedArrayFIFO provides non-blocking FIFO
 * that holds elements internally in fixed size array. The size of the array is defined
 * by the capacity used in the constructor. Implementation is an
 * efficient wait-free algorithm. The maximal capacity is restricted to 2^30 - 1 elements,
 * which will use 4 GB RAM (32-bit JVM) or 8 GB RAM (64-bit JVM). There
 * cannot be null elements !!!.</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Agent Technology Center, Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.7 $ $Date: 2009/02/12 07:47:48 $
 */
public class NonblockingFixedArrayFIFO<E> {

    /**
     * Mask used for reading integer position 32-bit
     */
    private static final long INT_MASK = 0xffffffffL;

    /**
     * Backend array which will hold all data
     */
    private final AtomicReferenceArray<E> array;

    /**
     * Current makr position. Upper 32-bit is head, and lower 32-bit is tail.
     */
    private final AtomicLong mark = new AtomicLong(0);

    /**
     * Capacity of the FIFO
     */
    private final int capacityPlus1;

    /**
     * Current size mask
     */
    private final long lengthMask;

    /**
     * Create FIFO with specified size. The capacity of the FIFO is set to the
     * nearest higher or equal 2^n-1, where n is integer, n >= 1 and n <=30.
     *
     * @param minCapacity long
     */
    public NonblockingFixedArrayFIFO(int minCapacity) {
        if ((minCapacity <= 0) || (minCapacity >= 1<<29)) {
            throw new IndexOutOfBoundsException("0 < capacity < 2^30-1");
        }
        int c = 2;
        long mask = 1;
        while (c < minCapacity) {
            c <<= 1;
            mask <<= 1;
            mask |= 1;
        }
        this.capacityPlus1 = c;
        this.lengthMask = mask;
        // initialize array
        this.array = new AtomicReferenceArray<E>(capacityPlus1);
    }

    /**
     * Get capacity of the buffer
     * @return int
     */
    public int capacity() {
        return capacityPlus1 - 1;
    }

    /**
     * Returns the number of elements currently stored in the FIFO. The method
     * is thread safe and lock-free. So, the value can be used only for the
     * informational purposes. It doesn't mean that there can be size() times called
     * successfully pop() operations.
     *
     * @return int
     */
    public int size() {
        long m = mark.get();
        int curTail = (int)(m & lengthMask);
        int curHead = (int)((m >> 32) & lengthMask);
        if (curTail == curHead) {
            // no element there
            return 0;
        } else {
            // count the current size
            return ((curTail | capacityPlus1) - curHead) & (int)lengthMask;
        }
    }

    /**
     * Pushes object to the FIFO queue.
     * @param object E - object cannot be null
     * @return boolean - returns true if object was sucessfully pushed to the queue,
     * otherwise it returns false (the case when the queue is full)
     */
    public boolean push(E object) {
        if (object == null) {
            throw new NullPointerException("FIFO cannot hold null object");
        }
        for (;;) {
            long m = mark.get();
            long curTailV = m & INT_MASK;
            long curTailPos = curTailV & lengthMask;
            long curHeadV = (m >> 32) & INT_MASK;
            long curHeadPos = curHeadV & lengthMask;
            long nextTailV = (curTailV + 1) & INT_MASK;
            long nextTailPos = nextTailV & lengthMask;
            if (curHeadPos == nextTailPos) {
                // buffer is full
                return false;
            }
            E tailObject = array.get((int)curTailPos);
            if ((tailObject != null) && (m == mark.get())) {
                // buffer is full
                return false;
            }
            if (mark.compareAndSet(m,((curHeadV << 32) | nextTailV))) {
                array.set((int)curTailPos, object);
                return true;
            }
        }
    }

    /**
     * Pops object from the FIFO queue.
     *
     * @return E - returns null if the queue is empty or next object is not ready, otherwise it returns
     * poped object
     */
    public E pop() {
        for (;;) {
            long m = mark.get();
            long curTailV = m & INT_MASK;
            long curTailPos = curTailV & lengthMask;
            long curHeadV = (m >> 32) & INT_MASK;
            long curHeadPos = curHeadV & lengthMask;
            if (curHeadPos == curTailPos) {
                // buffer is empty
                return null;
            }
            long nextHeadV = (curHeadV + 1) & INT_MASK;
            E headObject = array.get((int)curHeadPos);
            if (headObject == null) {
                // buffer is not ready
                return null;
            }
            if (mark.compareAndSet(m, ((nextHeadV << 32) | curTailV))) {
                array.set((int)curHeadPos, null);
                return headObject;
            }
        }
    }
}
