package aglobe.util.concurrent;

import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReferenceArray;
import java.util.concurrent.locks.ReentrantLock;


/**
 * <p>Title: A-Globe</p>
 *
 * <p>Description: ArrayFIFO provides almost non-blocking FIFO
 * that holds elements internally in array. Only concurrent push operations
 * that causes extension of internal buffer can be blocked.
 *
 * The size of the array starts on the 1024 and dynamically can grow up to 2^30-1 elements. Implementation is an
 * efficient almost wait-free algorithm (the exception is described above).
 * The maximal capacity is restricted to 2^30 - 1 elements,
 * which will use 4 GB RAM (32-bit JVM) or 8 GB RAM (64-bit JVM). There
 * cannot be null elements inserted. </p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Agent Technology Center, Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.9 $ $Date: 2009/02/22 20:48:02 $
 */
public class ArrayFIFO<E> {
    /**
     * Position mask used for reading position 30-bit
     */
    private static final long POS_MASK = 0x3fffffffL;

    /**
     * Bank mask used for reading bank information 4-bit
     */
    private static final long BANK_MASK = 0x0f;

    /**
     * Initial backend size
     */
    private static final int INIT_BACKEND_SIZE = 1024;

    /**
     * lock used during buffer extension operation
     */
    private ReentrantLock bufferExtensionLock = new ReentrantLock();

    /**
     * Next bank to use.
     */
    private int nextBank = 1;

    /**
     * Backend array of bank1
     */
    private volatile AtomicReferenceArray<E> bank0 = new AtomicReferenceArray<E>(INIT_BACKEND_SIZE);

    /**
     * Backend array of bank2
     */
    private volatile AtomicReferenceArray<E> bank1;

    /**
     * Current mark position. Content 30-bit head pos, 30-bit tail pos and 4-bit current bank id.
     */
    private AtomicLong mark = new AtomicLong(0);

    /**
     * Max buffer capacity is this value -1
     */
    private final int maxCapacity;

    /**
     * Constructor
     *
     * @param maxCapacity int - the max capacity is set to the higher nearest 2^n - 1,
     * where n is integer n >= 1 and n <= 30 .
     */
    public ArrayFIFO(int maxCapacity) {
        int c = 1;
        while (c < maxCapacity) {
            c <<= 1;
        }
        if (c > 1<<29) {
            throw new IndexOutOfBoundsException("Max capacity can be 2^30");
        }
        this.maxCapacity = c;
    }

    /**
     * Get current capacity of the buffer
     * @return int
     */
    public int capacity() {
        for (;;) {
            long m = mark.get();
            AtomicReferenceArray<E> curBuf = ((m & BANK_MASK) == 0) ? bank0 : bank1;
            if (curBuf != null) {
                return curBuf.length() - 1;
            }
        }
    }

    /**
     * Returns the number of elements currently stored in the FIFO. The method
     * is thread safe and lock-free. So, the value can be used only for the
     * informational purposes. It doesn't mean that there can be size() times called
     * successfully pop() operations.
     *
     * @return int
     */
    public int size() {
        for (;;) {
            long m = mark.get();
            AtomicReferenceArray<E> curBuf = ((m & BANK_MASK) == 0) ? bank0 : bank1;
            if (curBuf != null) {
                long lengthMask = curBuf.length() - 1;
                int curTail = (int) ((m >> 4) & lengthMask);
                int curHead = (int) ((m >> 34) & lengthMask);
                if (curTail == curHead) {
                    // no element there
                    return 0;
                } else {
                    // count the current size
                    return ((curTail | curBuf.length()) - curHead) & (int) lengthMask;
                }
            }
        }
    }

    /**
     * Pushes object to the FIFO queue.
     *
     * @param object E - object cannot be null
     * @throws Exception - if the pushed object is null or buffer capacity is exceeded
     */
    public void push(E object) throws Exception {
        if (object == null) {
            throw new NullPointerException("FIFO cannot hold null object");
        }

        for (;;) {
            long m = mark.get();
            long bankId = m & BANK_MASK;
            AtomicReferenceArray<E> curBuf = (bankId == 0) ? bank0 : bank1;
            if (curBuf != null) {
                long lengthMask = curBuf.length() - 1;
                long curTailV = (m >> 4) & POS_MASK;
                long curTailPos = curTailV & lengthMask;
                long curHeadV = (m >> 34) & POS_MASK;
                long curHeadPos = curHeadV & lengthMask;
                long nextTailV = (curTailV + 1) & POS_MASK;
                long nextTailPos = nextTailV & lengthMask;
                if ((curHeadPos == nextTailPos) || // not enough space
                    (curBuf.get((int)curTailPos) != null)) { // space is there, but next position is not released by the pop operation yet
                    // buffer is full, try allocate new one
                    long lastLength = curBuf.length();
                    long newLength = lastLength << 1;
                    if (newLength > maxCapacity) {
                        // capacity cannot be grown
                        throw new Exception("Buffer capacity exceeded");
                    }
                    if (bufferExtensionLock.tryLock()) {
                        // this code should be running only once
                        AtomicReferenceArray<E> newBuf = null;
                        // more cheaper is throw one object than create new backend array
                        bankId = nextBank;
                        newBuf = new AtomicReferenceArray<E>((int) newLength);

                        if (bankId == 0) {
                            bank0 = newBuf;
                        } else {
                            bank1 = newBuf;
                        }
                        boolean transpose = false;
                        long newBankTail = curTailPos + 1;
                        long newBankHead;
                        if (curTailPos < curHeadPos) {
                            // need transpose buffer
                            transpose = true;
                            newBankHead = curHeadPos + lastLength;
                        } else {
                            newBankHead = curHeadPos;
                        }
                        // fill new buffer
                        // fill current value first
                        newBuf.set((int) curTailPos, object);
                        // copy all previous from the head to tail
                        if (!transpose) {
                            // one block
                            for (int p = (int) curHeadPos; p < curTailPos; p++) {
                                E o = curBuf.get(p);
                                if (o != null) {
                                    newBuf.set(p, o);
                                }
                            }
                            if (mark.compareAndSet(m, ((newBankHead << 34) | (newBankTail << 4) | bankId))) {
                                // release old bank
                                if (bankId == 0) {
                                    bank1 = null;
                                } else {
                                    bank0 = null;
                                }
                                // finalize extend operation
                                nextBank = ((int) bankId) ^ 1;
                                bufferExtensionLock.unlock();
                                return;
                            } else {
                                // free allocated resources and try again
                                if (bankId == 0) {
                                    bank0 = null;
                                } else {
                                    bank1 = null;
                                }
                                bufferExtensionLock.unlock();
                                continue;
                            }
                        } else {
                            // two blocks
                            int np = (int) newBankHead;
                            for (int p = (int) curHeadPos; p < lastLength; p++) {
                                E o = curBuf.get(p);
                                if (o != null) {
                                    newBuf.set(np, o);
                                }
                                np++;
                            }
                            for (int p = 0; p < curTailPos; p++) {
                                E o = curBuf.get(p);
                                if (o != null) {
                                    newBuf.set(p, o);
                                }
                            }
                            if (mark.compareAndSet(m, ((newBankHead << 34) | (newBankTail << 4) | bankId))) {
                                // release old bank
                                if (bankId == 0) {
                                    bank1 = null;
                                } else {
                                    bank0 = null;
                                }
                                // finalize extend operation
                                nextBank = ((int) bankId) ^ 1;
                                bufferExtensionLock.unlock();
                                return;
                            } else {
                                // free allocated resources and try again
                                if (bankId == 0) {
                                    bank0 = null;
                                } else {
                                    bank1 = null;
                                }
                                bufferExtensionLock.unlock();
                                continue;
                            }
                        }
                    } else {
                        // wait for the other push operation finish
                        bufferExtensionLock.lock();
                        bufferExtensionLock.unlock();
                        continue;
                    }
                }
                // try write the value
                if (mark.compareAndSet(m, ((curHeadV << 34) | (nextTailV << 4) | bankId))) {
                    // fill the value there
                    for (;;) {
                        if (curBuf != null) {
                            curBuf.set((int)curTailPos,object);
                            if (bankId == (mark.get() & BANK_MASK)) {
                                return;
                            }
                        }
                        // the bank is changed during the operation, need to fill value to the new bank
                        bankId = mark.get() & BANK_MASK;
                        curBuf = (bankId == 0) ? bank0 : bank1;
                    }
                }
            }
        }
    }

    /**
     * Pops object from the FIFO queue.
     *
     * @return E - returns null if the queue is empty, otherwise it returns
     * poped object
     */
    public E pop() {
        for (;;) {
            long m = mark.get();
            long bankId = m & BANK_MASK;
            AtomicReferenceArray<E> curBuf = (bankId == 0) ? bank0 : bank1;
            if (curBuf != null) {
                long lengthMask = curBuf.length() - 1;
                long curTailV = (m >> 4) & POS_MASK;
                long curTailPos = curTailV & lengthMask;
                long curHeadV = (m >> 34) & POS_MASK;
                long curHeadPos = curHeadV & lengthMask;
                if (curHeadPos == curTailPos) {
                    // buffer is empty
                    return null;
                }
                long nextHeadV = (curHeadV + 1) & POS_MASK;
                E headObject = curBuf.get((int)curHeadPos);
                if (headObject == null) {
                    // buffer is not ready, push operation not completed
                    Thread.yield();
                    continue;
                }
                if (mark.compareAndSet(m, ((nextHeadV << 34) | (curTailV << 4) | bankId))) {
                    curBuf.set((int)curHeadPos,null);
                    return headObject;
                }
            }
        }
    }
}
