package aglobe.util.concurrent;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReferenceArray;


/**
 * <p>Title: A-Globe</p>
 *
 * <p>Description: NonblockingPoolArrayFIFO provides non-blocking FIFO
 * that holds elements internally in array. The size of the array starts on the 1024 and dynamically can grow up to 2^30-1 elements. Implementation is an
 * efficient wait-free algorithm. The maximal capacity is restricted to 2^30 - 1 elements,
 * which will use 4 GB RAM (32-bit JVM) or 8 GB RAM (64-bit JVM). There
 * cannot be null elements inserted. Pushed object can be not inserted if other thread call same operation before
 * and it starts reallocating process !!! Also during pop operation it can return no element if the array is
 * copied by other thread !!! So the NonblockingPoolArrayFIFO is best suitable for object pools because it is
 * faster than JAVA memory allocator.
</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Agent Technology Center, Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.9 $ $Date: 2009/02/12 07:47:48 $
 */
public class NonblockingPoolArrayFIFO<E> {
    /**
     * Position mask used for reading position 30-bit
     */
    private static final long POS_MASK = 0x3fffffffL;

    /**
     * Bank mask used for reading bank information 4-bit
     */
    private static final long BANK_MASK = 0x0f;

    /**
     * Initial back-end size
     */
    private static final int INIT_BACKEND_SIZE = 1024;

    /**
     * Next bank to use. -1 if no next bank available
     */
    private AtomicInteger nextBank = new AtomicInteger(1);

    /**
     * Back-end array of bank1
     */
    private volatile AtomicReferenceArray<E> bank0 = new AtomicReferenceArray<E>(INIT_BACKEND_SIZE);

    /**
     * Back-end array of bank2
     */
    private volatile AtomicReferenceArray<E> bank1;

    /**
     * Current mark position. Content 30-bit head pos, 30-bit tail pos and 4-bit current bank id.
     */
    private AtomicLong mark = new AtomicLong(0);

    /**
     * Max buffer capacity is this value -1
     */
    private final int maxCapacity;

    /**
     * Constructor
     *
     * @param maxCapacity int - the max capacity is set to the higher nearest 2^n - 1,
     * where n is integer n >= 1 and n <= 30 .
     */
    public NonblockingPoolArrayFIFO(int maxCapacity) {
        int c = 1;
        while (c < maxCapacity) {
            c <<= 1;
        }
        if (c > 1<<29) {
            throw new IndexOutOfBoundsException("Max capacity can be 2^30");
        }
        this.maxCapacity = c;
    }

    /**
     * Get current capacity of the buffer
     * @return int
     */
    public int capacity() {
        for (;;) {
            long m = mark.get();
            AtomicReferenceArray<E> curBuf = ((m & BANK_MASK) == 0) ? bank0 : bank1;
            if (curBuf != null) {
                return curBuf.length() - 1;
            }
        }
    }

    /**
     * Returns the number of elements currently stored in the FIFO. The method
     * is thread safe and lock-free. So, the value can be used only for the
     * informational purposes. It doesn't mean that there can be size() times called
     * successfully pop() operations.
     *
     * @return int
     */
    public int size() {
        for (;;) {
            long m = mark.get();
            AtomicReferenceArray<E> curBuf = ((m & BANK_MASK) == 0) ? bank0 : bank1;
            if (curBuf != null) {
                long lengthMask = curBuf.length() - 1;
                int curTail = (int) ((m >> 4) & lengthMask);
                int curHead = (int) ((m >> 34) & lengthMask);
                if (curTail == curHead) {
                    // no element there
                    return 0;
                } else {
                    // count the current size
                    return ((curTail | curBuf.length()) - curHead) & (int) lengthMask;
                }
            }
        }
    }

    /**
     * Pushes object to the FIFO queue.
     * @param object E - object cannot be null
     * @return boolean - returns true if object was successfully pushed to the queue,
     * otherwise it returns false (the case when the queue is
     * not released by previous pop operation, maximum capacity of buffer reached or
     * other thread tries to allocate larger buffer)
     */
    public boolean push(E object) {
        if (object == null) {
            throw new NullPointerException("FIFO cannot hold null object");
        }
        AtomicReferenceArray<E> newBuf = null;
        for (;;) {
            long m = mark.get();
            long bankId = m & BANK_MASK;
            AtomicReferenceArray<E> curBuf = (bankId == 0) ? bank0 : bank1;
            if (curBuf != null) {
                long lengthMask = curBuf.length() - 1;
                long curTailV = (m >> 4) & POS_MASK;
                long curTailPos = curTailV & lengthMask;
                long curHeadV = (m >> 34) & POS_MASK;
                long curHeadPos = curHeadV & lengthMask;
                long nextTailV = (curTailV + 1) & POS_MASK;
                long nextTailPos = nextTailV & lengthMask;
                if (curHeadPos == nextTailPos) {
                    // buffer is full, try allocate new one
                    long lastLength = curBuf.length();
                    long newLength = lastLength << 1;
                    if (newLength > maxCapacity) {
                        // capacity cannot be grown
                        return false;
                    }
                    // more cheaper is throw one object than create new back-end array
                    bankId = nextBank.get();
                    if ((bankId < 0) || (!nextBank.compareAndSet((int)bankId, -1))) {
                        // other thread tries to allocate new buffer
                        return false;
                    }
                    if ((newBuf == null) || (newBuf.length() != newLength)) {
                        newBuf = new AtomicReferenceArray<E>((int)newLength);
                    }
                    if (bankId == 0) {
                        bank0 = newBuf;
                    } else {
                        bank1 = newBuf;
                    }
                    boolean transpose = false;
                    long newBankTail = curTailPos + 1;
                    long newBankHead;
                    if (curTailPos < curHeadPos) {
                        // need transpose buffer
                        transpose = true;
                        newBankHead = curHeadPos + lastLength;
                    } else {
                        newBankHead = curHeadPos;
                    }
                    if (mark.compareAndSet(m, ((newBankHead << 34) | (newBankTail << 4) | bankId))) {
                        // ok, fill new buffer
                        // fill current value first
                        newBuf.set((int)curTailPos, object);
                        // copy all previous from the head to tail
                        if (!transpose) {
                            // one block
                            for (int p = (int)curHeadPos; p < curTailPos; p++) {
                                E o = curBuf.get(p);
                                if (o != null) {
                                    newBuf.set(p,o);
                                }
                            }
                            // release old bank
                            nextBank.set(((int)bankId) ^ 1);
                            return true;
                        } else {
                            // two blocks
                            int np = (int)newBankHead;
                            for (int p = (int)curHeadPos; p < lastLength; p++) {
                                E o = curBuf.get(p);
                                if (o != null) {
                                    newBuf.set(np,o);
                                }
                                np++;
                            }
                            for (int p = 0; p < curTailPos; p++) {
                                E o = curBuf.get(p);
                                if (o != null) {
                                    newBuf.set(p,o);
                                }
                            }
                            // release old bank
                            nextBank.set(((int)bankId) ^ 1);
                            return true;
                        }
                    }
                    // release bank id
                    nextBank.set((int)bankId);
                }
                E tailObject = curBuf.get((int)curTailPos);
                if ((tailObject != null) && (m == mark.get())) {
                    // buffer is full, not released by previous pop operation yet
                    return false;
                }
                if (mark.compareAndSet(m, ((curHeadV << 34) | (nextTailV << 4) | bankId))) {
                    // fill the value there
                    for (;;) {
                        if (curBuf != null) {
                            curBuf.set((int)curTailPos,object);
                            if (bankId == (mark.get() & BANK_MASK)) {
                                return true;
                            }
                        }
                        // the bank is changed during the operation, need to fill value to the new bank
                        bankId = mark.get() & BANK_MASK;
                        curBuf = (bankId == 0) ? bank0 : bank1;
                    }
                }
            }
        }
    }

    /**
     * Pops object from the FIFO queue.
     *
     * @return E - returns null if the queue is empty or next object is not ready
     * due to not finished push operation, otherwise it returns
     * popped object
     */
    public E pop() {
        for (;;) {
            long m = mark.get();
            long bankId = m & BANK_MASK;
            AtomicReferenceArray<E> curBuf = (bankId == 0) ? bank0 : bank1;
            if (curBuf != null) {
                long lengthMask = curBuf.length() - 1;
                long curTailV = (m >> 4) & POS_MASK;
                long curTailPos = curTailV & lengthMask;
                long curHeadV = (m >> 34) & POS_MASK;
                long curHeadPos = curHeadV & lengthMask;
                if (curHeadPos == curTailPos) {
                    // buffer is empty
                    return null;
                }
                long nextHeadV = (curHeadV + 1) & POS_MASK;
                E headObject = curBuf.get((int)curHeadPos);
                if (headObject == null) {
                    // buffer is not ready
                    return null;
                }
                if (mark.compareAndSet(m, ((nextHeadV << 34) | (curTailV << 4) | bankId))) {
                    curBuf.set((int)curHeadPos,null);
                    return headObject;
                }
            }
        }
    }
}
