package aglobe.util.gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.JScrollBar;

/**
 * @internal
 */
public class SearchableTextArea extends JPanel {

    private static final long serialVersionUID = -759002968573906208L;
    private JTextArea textArea = new JTextArea();
    private JScrollPane jScrollPane = new JScrollPane();
    private JPanel findPanel = new JPanel(new FlowLayout(FlowLayout.LEADING));
    private JLabel label = new JLabel("Find:");
    private JTextField textField = new JTextField(30);
    private JButton findButton = new JButton("Find");
    private JRadioButton forward = new JRadioButton("  Forward",true);
    private JRadioButton backward = new JRadioButton("  Backward",false);
    private JButton clearButton = new JButton("Clear");
    private JCheckBox lineWrap = new JCheckBox("  LineWrap",false);

    private BufferedWriter log = null;

    /**
     * Creates read-only text area with search panel at bottom
     */
    public SearchableTextArea() {
        this(false,true,null);
    }

    /**
     * Creates read-only text area with search panel
     *
     * @param textFile - defines text file, where text is written
     */
    public SearchableTextArea(String textFile) {
        this(false,true,textFile);
    }

    /**
     * Creates read-only text area with search panel
     *
     * @param isTop - defines if search panel is at top or bottom of text area
     */
    public SearchableTextArea(boolean isTop) {
        this(isTop,true,null);
    }

    /**
     * Creates read-only text area with search panel
     *
     * @param isTop - defines if search panel is at top or bottom of text area
     * @param textFile - defines text file, where text is written
     */
    public SearchableTextArea(boolean isTop, String textFile) {
        this(isTop,true,textFile);
    }

    /**
     * Creates read-only text area with search panel
     *
     * @param isTop - defines if search panel is at top or bottom of text area
     * @param lineWr - defines if text area use line wrap
     */
    public SearchableTextArea(boolean isTop, boolean lineWr) {
        this(isTop,lineWr,null);
    }

    /**
     * Creates read-only text area with search panel
     *
     * @param isTop - defines if search panel is at top or bottom of text area
     * @param lineWr - defines if text area use line wrap
     * @param textFile - defines text file, where text is written
     */
    public SearchableTextArea(boolean isTop, boolean lineWr, String textFile) {
        super(new BorderLayout());
        if (isTop)
            this.add(findPanel,BorderLayout.NORTH);
        else
            this.add(findPanel,BorderLayout.SOUTH);
        this.add(jScrollPane);
        jScrollPane.setViewportView(textArea);
        textArea.setEditable(false);
        textArea.setText("");
        jScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        if (!lineWr) {
            jScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        }
        findPanel.add(label);
        findPanel.add(textField);
        findPanel.add(findButton);
        findPanel.add(forward);
        findPanel.add(backward);
        findPanel.add(clearButton);
        findPanel.add(lineWrap);

        ButtonGroup group = new ButtonGroup();
        group.add(forward);
        group.add(backward);

        lineWrap.setSelected(lineWr);
        textArea.setLineWrap(lineWr);
        textArea.getCaret().setDot(0);

        lineWrap.addItemListener(new ItemListener(){
            @Override
			public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    lineWrap.setSelected(true);
                    textArea.setLineWrap(true);
                    jScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
                }
                else {
                    lineWrap.setSelected(false);
                    textArea.setLineWrap(false);
                    jScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
                }
            }
        });
        findButton.addActionListener(new ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                findButtonEvent(e);
            }
        });
        clearButton.addActionListener(new ActionListener() {
            @Override
			public void actionPerformed(ActionEvent arg0) {
                textArea.setText("");
            }
        });

        if ((textFile!=null) && (!textFile.equals(""))) {
            try {
                log = new BufferedWriter(new FileWriter(textFile));
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }
    }

    /**
     * adds text to the text area
     *
     * @param text String
     */
    public void append(final String text) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
			public void run() {
                textArea.append(text);
                JScrollBar vert = jScrollPane.getVerticalScrollBar();
                vert.setValue(vert.getMaximum() - vert.getVisibleAmount());

            }
        });
        if (log!=null) {
            try {
                log.write(text);
                log.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * adss text and new line to the text area
     *
     * @param text String
     */
    public void appendLine(String text) {
        append(text+"\n");
    }

    /**
     * @param e
     */
    private void findButtonEvent(ActionEvent e) {
        if (textField.getText().length()==0)
            return;
        int idx;
        if (forward.isSelected()) {
            idx = textArea.getText().indexOf(textField.getText(),textArea.getCaretPosition());
        }
        else {
            idx = textArea.getText().lastIndexOf(textField.getText(),textArea.getCaretPosition()-textField.getText().length()-1);
        }
        if (idx>=0) {
            textArea.getCaret().setDot(idx);
            textArea.getCaret().moveDot(idx+textField.getText().length());
            textArea.getCaret().setSelectionVisible(true);
        }
    }
}
