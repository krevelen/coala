package aglobe.util.gui;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;

import aglobe.container.Store;
import aglobe.container.StoreOwner;

/**
 * @internal
 * <p>Title: A-Globe</p>
 *
 * <p>Description: JFrame which remembers last window position and size.
 * Class also provides support for other window settings loading and saving by
 * overwriting methods loadWindowSettings() and saveWindowSettings().</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.12 $ $Date: 2010/07/04 16:53:27 $
 */
public abstract class RememberPositionJFrame
      extends JFrame {

    private static final long serialVersionUID = -1655259692296200305L;

    /**
     * Store key name used for storing GUI X position
     */
    protected final String GUI_X;

    /**
     * Store key name used for storing GUI Y position
     */
    protected final String GUI_Y;

    /**
     * Store key name used for storing GUI width
     */
    protected final String GUI_W;

    /**
     * Store key name used for storing GUI height
     */
    protected final String GUI_H;

    /**
     * Store key name used for storing splitter position
     */
    protected final String GUI_DIVIDER;
    protected final String GUI_DIVIDER1;
    protected final String GUI_DIVIDER2;

    /**
     * Store where position and size information about window is stored.
     */
    protected Store store;

    /**
     * true iff loadWindowPosition is active
     */
    private boolean loadingWindowPosition;

    /**
     * true iff frame is visible
     */
    private boolean visible = false;

    /**
     * Constructor
     *
     * @param storeOwner ElementaryEntity
     */
    public RememberPositionJFrame(StoreOwner storeOwner) {
        this(storeOwner,"");
    }

    /**
     * Constructor
     *
     * @param storeOwner ElementaryEntity
     * @param storePrefix String
     */
    public RememberPositionJFrame(StoreOwner storeOwner, String storePrefix) {
        super();

        GUI_X = "gui/"+storePrefix+"x";
        GUI_Y = "gui/"+storePrefix+"y";
        GUI_W = "gui/"+storePrefix+"w";
        GUI_H = "gui/"+storePrefix+"h";
        GUI_DIVIDER= "gui/"+storePrefix+"divider";
        GUI_DIVIDER1= "gui/"+storePrefix+"divider1";
        GUI_DIVIDER2= "gui/"+storePrefix+"divider2";


        store = storeOwner.getStore();

        this.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentMoved(ComponentEvent e) {
                this_componentMoved(e);
            }

            /**
             * Invoked when the component's size changes.
             *
             * @param e ComponentEvent
             */
            @Override
            public void componentResized(ComponentEvent e) {
                this_componentResized(e);
            }

        });

        this.addWindowListener(new WindowAdapter() {
            /**
             * Invoked when the user attempts to close the window from the
             * window's system menu.
             *
             * @param e WindowEvent
             */
            @Override
            public void windowClosing(WindowEvent e) {
                if (visible) {
                    saveWindowPosition();
                }
            }

        });

    }

    /**
     * Save other window settings
     */
    protected void saveWindowSettings() {

    }

    /**
     * Load other window settings
     */
    protected void loadWindowSettings() {

    }

    /**
     * load previous window position
     */
    private void loadWindowPosition() {
        loadingWindowPosition = true;
        Point p = getLocation();
        p.x = store.getInt(GUI_X, Integer.MIN_VALUE);
        p.y = store.getInt(GUI_Y, Integer.MIN_VALUE);
        if ((p.x != Integer.MIN_VALUE) || (p.y != Integer.MIN_VALUE)) {
        	setLocation(p);
        }

        Dimension d = getSize();
        d.width = store.getInt(GUI_W, Integer.MIN_VALUE);
        d.height = store.getInt(GUI_H, Integer.MIN_VALUE);
        if ((d.width != Integer.MIN_VALUE) || (d.height != Integer.MIN_VALUE)) {
        	setSize(d.width, d.height);
        }

        loadWindowSettings();

        loadingWindowPosition = false;
    }

    /**
     * Save current window position
     */
    protected void saveWindowPosition() {
        if (!loadingWindowPosition) {
            saveWindowSettings();

            Point p = getLocation();
            store.putInt(GUI_X, p.x);
            store.putInt(GUI_Y, p.y);

            Dimension d = getSize();
            store.putInt(GUI_W, d.width);
            store.putInt(GUI_H, d.height);
        }
    }

    /**
     * Shows or hides this component depending on the value of parameter
     * <code>b</code>.
     *
     * @param b if <code>true</code>, shows this component; otherwise, hides
     *   this component
     */
    @Override
    public void setVisible(boolean b) {
        if (!b) {
            saveWindowPosition();
        }
        else {
            loadWindowPosition();
        }
        visible = b;
        super.setVisible(b);
    }

    /**
     * Window moved.
     * @param e ComponentEvent
     */
    private void this_componentMoved(ComponentEvent e) {
        if (visible) {
            saveWindowPosition();
        }
    }

    /**
     * Window resized.
     * @param e ComponentEvent
     */
    private void this_componentResized(ComponentEvent e) {
        if (visible) {
            saveWindowPosition();
        }
    }

}
