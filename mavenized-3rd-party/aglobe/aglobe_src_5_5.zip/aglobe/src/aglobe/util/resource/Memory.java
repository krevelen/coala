package aglobe.util.resource;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.Deque;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @internal
 * Support for walking the JVM heap and counting the sizes occupied by a subtree of
 * objects.
 *
 * @author Pavel Novak
 */
public class Memory {
    private static final long REFERENCE_SIZE = 4;

    private Set<Object> ignoreObjects = new HashSet<Object>();
    private Set<Class<?>> ignoreClasses = new HashSet<Class<?>>();

    private Set<Object> visitedObjects = new HashSet<Object>();
    private Deque<Object> toVisitObjects = new LinkedList<Object>();

    private AtomicBoolean inUse = new AtomicBoolean(false);

    /**
     * Creates a new object for support of measuring the size occupied by a subtree of objects.
     */
    public Memory() {
        ignoreObjects.add(this);
    }

    private void lock() {
        if (!inUse.compareAndSet(false, true))
            throw new ConcurrentModificationException();
    }

    private void unlock() {
        inUse.set(false);
    }

    /**
     * Returns estimate number of bytes the tree of object occupies.
     * Since all the methods use shared objects list, this public method
     * (and all the others possibly introduced) should not be called
     * at the same time.
     * @param obj
     * @return Number of bytes.
     */
    public long getObjectTreeSize(Object obj) {
        lock();

        // initial element
        toVisitObjects.push(obj);

        long result = 0;
        while (toVisitObjects.size() > 0)
            result += visitNextObject();

        // purge visited objects to be ready for next measure
        visitedObjects.clear();

        unlock();
        return result;
    }

    /**
     * Ignores a specific object while inspecting the heap.
     * @param obj
     */
    public void addIgnore(Object obj) {
        lock();
        this.ignoreObjects.add(obj);
        unlock();
    }

    /**
     * Ignores a specific class while inspecting the heap.
     * @param cls
     */
    public void addIgnore(Class<?> cls) {
        lock();
        this.ignoreClasses.add(cls);
        unlock();
    }

    private long visitNextObject() {
        assert(toVisitObjects.size() > 0);

        Object obj = toVisitObjects.pop();

        // should we count this object?
        if (visitedObjects.contains(obj) || ignoreObjects.contains(obj))
            return 0;

        // yes, mark it as visited to avoid cycles
        visitedObjects.add(obj);

        long result = 2*REFERENCE_SIZE; // each object holds a lock and VMT reference

        result += visitFields(obj);
        return result;
    }

    private List<Field> getAllDeclaredFields(Class<?> cls) {
        List<Field> fields = new ArrayList<Field>();
        while (cls != null) { // walk parent classes
            Field[] currFields = cls.getDeclaredFields();
            for (int i = 0; i < currFields.length; i++)
                fields.add(currFields[i]);

            cls = cls.getSuperclass();
        }
        return fields;
    }

    private long visitFields(Object obj) {
        Class<?> cls = obj.getClass();
        List<Field> fields = getAllDeclaredFields(cls);

        long result = 0;
        for (Field f : fields) {
            if (!shouldBeChecked(f))
                continue;

            f.setAccessible(true); // allow access to private fields

            Object fieldValue = null;
            try {
                fieldValue = f.get(obj);
            } catch (IllegalArgumentException e1) {
                e1.printStackTrace();
            } catch (IllegalAccessException e1) {
                e1.printStackTrace();
            }

            if (fieldValue == null) {
                result += REFERENCE_SIZE;
                continue;
            }

            long primitiveSize = isPrimitive(f.getType());
            if (primitiveSize > 0) {
                result += primitiveSize;
                continue;
            }

            // is it an array?
            long arraySize = isArray(f.getType(), fieldValue);
            if (arraySize > 0) {
                result += REFERENCE_SIZE; // reference to the array
                result += arraySize; // array itself
                continue;
            }

            // next non-primitive object
            result += REFERENCE_SIZE;
            toVisitObjects.push(fieldValue);
        }

        return result;
    }

    /**
     * Returns a size of primitive type, or 0 if it is a custom complex class.
     * @param cls
     * @return
     */
    private long isPrimitive(Class<?> cls) {

        if (int.class.equals(cls)) {
            return 4;
        }
        if (char.class.equals(cls)) {
            return 2;
        }
        if (byte.class.equals(cls)) {
            return 1;
        }
        if (short.class.equals(cls)) {
            return 2;
        }
        if (long.class.equals(cls)) {
            return 8;
        }
        if (float.class.equals(cls)) {
            return 4;
        }
        if (double.class.equals(cls)) {
            return 8;
        }
        if (boolean.class.equals(cls)) {
            return 1;
        }

        // not known primitive type
        return 0;
    }

    private long isArray(Class<?> cls, Object obj) {
        long result = 0;

        // or is it an array?
        if (cls.isArray()) {
            int len = Array.getLength(obj);
            Class<?> type = cls.getComponentType();

            // is it array of object we should ignore?
            if (ignoreClasses.contains(type)) {
                result += len * REFERENCE_SIZE; // yes, count just array
            }
            else {
                // array of primitives?
                long primitiveSize = isPrimitive(type);
                if (primitiveSize > 0) {
                    result += len * primitiveSize;
                }
                else {
                    // no, array of some objects, inspect them later
                    result += len * REFERENCE_SIZE;
                    // array of objects or arrays.. proceed in next rounds
                    for (int i = 0; i < len; i++) {
                        this.toVisitObjects.push(obj);
                    }
                }
            }
        }

        return result;
    }

    /**
     * Returns true if this field should be added to the final object tree size.
     * @param f
     * @return
     */
    private boolean shouldBeChecked(Field f) {
        int modifiers = f.getModifiers();

        // do not include static fields
        if (Modifier.isStatic(modifiers))
            return false;

        // do not include classes we are ignoring
        if (ignoreClasses.contains(f.getType()))
            return false;

        return true;
    }
}
