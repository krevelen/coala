package aglobe.util;

import javax.xml.bind.annotation.adapters.XmlAdapter;
import java.io.File;

/**
 * @internal
 * <p>Title: Aglobe</p>
 *
 * <p>Description: todo</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Agent Technology Center, Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.1 $ $Date: 2009/12/16 12:24:21 $
 */
public class PathAdapter extends XmlAdapter<String,String> {
    private final File currentFilePath;
    private final String currentFilePathStr;

    public PathAdapter() {
        currentFilePath = new File("");
        currentFilePathStr = currentFilePath.getPath();
    }

    /**
     *
     * @param currentFile File
     */
    public PathAdapter(File currentFile) {
        currentFilePath = currentFile.getParentFile();
        currentFilePathStr = currentFilePath.getPath();
    }

    @Override
    public String unmarshal(String v) throws Exception {
        if (v.startsWith(currentFilePathStr)) {
            // avoid recursive add of the same path prefix
            return v;
        } else {
            return new File(currentFilePath, v).getPath();
        }
    }

    @Override
    public String marshal(String v) throws Exception {
        return v;
    }
}
