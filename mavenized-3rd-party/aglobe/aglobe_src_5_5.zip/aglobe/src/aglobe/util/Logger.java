package aglobe.util;

import java.io.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.locks.*;
import java.util.logging.*;
import java.util.regex.*;

import aglobe.container.*;
import aglobe.container.agent.*;
import aglobe.container.service.*;
import aglobe.ontology.*;
import aglobe.platform.*;
import aglobe.service.topics.TopicsHandler;
import aglobe.service.topics.TopicsService;
import aglobe.util.logging.*;
import aglobe.util.logging.LogRecord;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @internal
 * <p>Title: A-Globe</p>
 *
 * <p>Description: Logger provides logging function similar to the standard java logger except
 * if it is called from the agent/service thread,
 * it enables also distributed logging using LoggerAgent and it automatically add container, agent/service
 * name to the log record</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Agent Technology Center, Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.26 $ $Date: 2010/10/18 12:25:43 $
 */
public final class Logger {
    private final static String TOPICS_PREFIX = "!$";
    private static int TOPICS_CNT = 1;

    /**
     * Logger messages are distributed using this topic
     */
    public static final String TOPIC_LOGGER_MESSAGE = TOPICS_PREFIX + (TOPICS_CNT++);

    private static final String TOPIC_LOGGER_CONFIGURATION_DISTRIBUTION = TOPICS_PREFIX + (TOPICS_CNT++);
    private static final String TOPIC_LOGGER_CONFIGURATION_DISTRIBUTION_REQUEST = TOPICS_PREFIX + (TOPICS_CNT++);

    private static Pattern javaInternalLoggingFilter = Pattern.compile("^(javax?\\.)|(com\\.sun\\.)|(sun\\.)");

    /**
     * Agent thread pattern
     */
    private static Pattern agentThreadPattern = Pattern.compile("^([^:]+): ([^:]+): "+AgentManager.MAIN_AGENT_THREAD_NAME+"$");

    /**
     * Service thread pattern
     */
    private static Pattern serviceThreadPattern = Pattern.compile("^([^:]+): ([^:]+): "+ServiceManager.MAIN_SERVICE_THREAD_NAME+"$");

    /**
     * Time stamp provider
     */
    private static volatile TimeProvider timeProvider = new DefaultTimeProvider();

    /**
     * Console writer
     */
    private static OutputStreamWriter consoleWriter = new OutputStreamWriter(System.err);

    private static boolean master;


    private static ConcurrentHashMap<String, Boolean> logIt = new ConcurrentHashMap<String,Boolean>(1024);
    private static volatile LogFilter rootLogFilter = new LogFilter("INFO",null);

    private static boolean consoleLogging = true;

    private static volatile OutputStreamWriter logFile = null;
    private static volatile File lockFile = null;
    private static volatile FileOutputStream lockStream = null;

    private static LogConfiguration currentLogConfiguration;

    private static LinkedHashMap<String, AgentContainer> existingContainers = new LinkedHashMap<String,AgentContainer>();
    private static ReentrantLock syncLock = new ReentrantLock();
    private static TopicsService.Shell topicsShell = null;
    private static String subscribedVia = null;

    private static boolean initialized = false;

    /**
     * Singleton class. Cannot be created by the user
     */
    private Logger() {

    }

    private static void broadcastTopic(final String topic, final Object content, final String reason) {
        if (topicsShell != null) {
            topicsShell.sendTopic(topic, content, reason);
        }
    }

    @SuppressWarnings("serial")
    private static void makeSubscriptionIfNecessary() {
        if (subscribedVia != null) {
            return;
        }
        for (AgentContainer elem : existingContainers.values()) {
            topicsShell = (TopicsService.Shell) elem.getServiceManager().getService(null, TopicsService.SERVICENAME);
            if (topicsShell != null) {
                subscribedVia = elem.getContainerName();
                if (!master) {
                    topicsShell.subscribeHandlerSync(TOPIC_LOGGER_CONFIGURATION_DISTRIBUTION, new TopicsHandler() {

                        @Override
                        public void handleIncomingTopic(final String topic, final Object content, final String reason) {
                            LogConfiguration newLogConfiguration = (LogConfiguration) content;
                            initialize(newLogConfiguration, master);
                        }

                        @Override
                        public void addEvent(final Runnable e) {
                            e.run();
                        }

                    });
                    broadcastTopic(TOPIC_LOGGER_CONFIGURATION_DISTRIBUTION_REQUEST, null, null);
                } else {
                    topicsShell.subscribeHandlerAsync(TOPIC_LOGGER_CONFIGURATION_DISTRIBUTION_REQUEST, new TopicsHandler() {

                        @Override
                        public void handleIncomingTopic(String topic, Object content, String reason) {
                            broadcastTopic(TOPIC_LOGGER_CONFIGURATION_DISTRIBUTION, currentLogConfiguration, null);
                        }

                        @Override
                        public void addEvent(Runnable e) {
                            e.run();
                        }

                    });
                    topicsShell.subscribeHandlerAsync(TOPIC_LOGGER_MESSAGE, new TopicsHandler() {

                        @Override
                        public void handleIncomingTopic(String topic, Object content, String reason) {
                            if (reason == null) {
                                localLogOutput((LogRecord)content);
                            }
                        }

                        @Override
                        public void addEvent(Runnable e) {
                            e.run();
                        }

                    });
                    // push my configuration to others which are started before me
                    broadcastTopic(TOPIC_LOGGER_CONFIGURATION_DISTRIBUTION, currentLogConfiguration, null);
                }
                timeProvider.makeSubscription(topicsShell);
            }
        }
    }

    /**
     * Initialize Aglobe logger by parsing its configuration
     *
     * @param logConfiguration LogConfiguration
     * @param master boolean
     */
    public static void initialize(final LogConfiguration logConfiguration, final boolean master) {
        if ((logConfiguration != null) &&  (currentLogConfiguration == logConfiguration)) {
            return;
        }
        Logger.master = master;
        currentLogConfiguration = logConfiguration;
        if (!initialized) {

            Platform.registerContainerMonitor(new ContainerMonitor() {
                @Override
				public void containerStarted(AgentContainer container) {
                    syncLock.lock();
                    try {
                        existingContainers.put(container.getContainerName(), container);
                        makeSubscriptionIfNecessary();
                    } finally {
                        syncLock.unlock();
                    }
                }

                @Override
				public void containerRemoved(String containerName) {
                    syncLock.lock();
                    try {
                        existingContainers.remove(containerName);
                        if (containerName.equals(subscribedVia)) {
                            subscribedVia = null;
                            if (topicsShell != null) {
                                topicsShell.dispose();
                                topicsShell = null;
                            }
                            makeSubscriptionIfNecessary();
                        }
                    } finally {
                        syncLock.unlock();
                    }
                }
            });
            initialized = true;
        }

        if (logConfiguration != null) {
            rootLogFilter = new LogFilter(logConfiguration.getBasicLevel(), logConfiguration.getLogGroup());
            logIt.clear();
            consoleLogging = logConfiguration.isConsoleLogging();
        } else {
            rootLogFilter = new LogFilter("INFO",null);
            logIt.clear();
            consoleLogging = true;
        }

        if ((logFile == null) && ((logConfiguration == null) || (logConfiguration.isFileLogging()))) {
            // open file log
            int cnt = 0;
            String fileName;
            for (; ; ) {
                if (cnt > 100) {
                    java.util.logging.Logger.getAnonymousLogger().warning("Cannot create Aglobe log file");
                    return;
                }
                fileName = "aglobe" + cnt + ".log";
                lockFile = new File(fileName + ".lck");
                try {
                    lockStream = new FileOutputStream(lockFile);
                    if (lockStream.getChannel().tryLock() != null) {
                        // got it
                        break;
                    }
                } catch (IOException ex) {
                }

                if (lockStream != null) {
                    try {
                        lockStream.close();
                    } catch (IOException ex1) {
                    }
                    lockStream = null;
                }
                lockFile = null;

                cnt++;
            }

            try {
                logFile = new OutputStreamWriter(new BufferedOutputStream(new FileOutputStream(fileName)));
            } catch (FileNotFoundException ex2) {
                close();
                java.util.logging.Logger.getAnonymousLogger().warning("Cannot create Aglobe log file");
            }
        } else {
            // otherwise cancel file logging
            close();
        }

        // update time provider
        String requestedTimeProvider;
        if ((logConfiguration != null) && (logConfiguration.getTimeProvider() != null)) {
            requestedTimeProvider = logConfiguration.getTimeProvider();
        } else {
            // use default time provider
            requestedTimeProvider = DefaultTimeProvider.class.getName();
        }
        if (!requestedTimeProvider.equals(timeProvider.getClass().getName())) {
            try {
                ClassLoader cl = Platform.class.getClassLoader();
                Class<?> c = cl.loadClass(logConfiguration.getTimeProvider());
                if (!TimeProvider.class.isAssignableFrom(c)) {
                    throw new Exception("Class: " + logConfiguration.getTimeProvider() + " is not compatible with TimeProvider interface.");
                }
                timeProvider = (TimeProvider) c.newInstance();
            } catch (Exception ex3) {
                java.util.logging.Logger.getAnonymousLogger().warning("Cannot initialize requested time provider: "+ExceptionPrinter.toStringWithCause(ex3));
                timeProvider = new DefaultTimeProvider();
            }
            if (topicsShell != null) {
                timeProvider.makeSubscription(topicsShell);
            }
        }
    }

    /**
     * Close opened file connections
     */
    public static void close() {
        if (logFile != null) {
            try {
                logFile.close();
            }
            catch (IOException ex) {
            }
            logFile = null;
        }
        if (lockStream != null) {
            try {
                lockStream.close();
            }
            catch (IOException ex1) {
            }
            lockStream = null;
            lockFile.delete();
            lockFile = null;
        }
    }

    /**
     * Send finest log message to the logger. Automatically append container and agent
     * name to the output log message if it is called from agent/service thread
     *
     * @param message String - message
     * @return boolean - true (usable for calling assert Logger.logSth(...))
     */
    public static boolean logFinest(final String message) {
      log(Level.FINEST,message);

      return true;
    }

    /**
     * Send fine log message to the logger. Automatically append container and agent
     * name to the output log message if it is called from agent/service thread
     *
     * @param message String - message
     * @return boolean - true (usable for calling assert Logger.logSth(...))
     */
    public static boolean logFine(final String message) {
      log(Level.FINE,message);

      return true;
    }

    /**
     * Send info log message to the logger. Automatically append container and agent
     * name to the output log message if it is called from agent/service thread
     *
     * @param message String - message
     * @return boolean - true (usable for calling assert Logger.logSth(...))
     */
    public static boolean logInfo(final String message) {
      log(Level.INFO,message);

      return true;
    }

    /**
     * Send warning log message to the logger. Automatically append container and agent
     * name to the output log message if it is called from agent/service thread
     *
     * @param message String - message
     * @return boolean - true (usable for calling assert Logger.logSth(...))
     */
    public static boolean logWarning(final String message) {
      log(Level.WARNING,message);

      return true;
    }

    /**
     * Send severe log message to the logger. Automatically append container and agent
     * name to the output log message if it is called from agent/service thread
     *
     * @param message String - message
     * @return boolean - true (usable for calling assert Logger.logSth(...))
     */
    public static boolean logSevere(final String message) {
      log(Level.SEVERE,message);

      return true;
    }

    /**
     * Send finest log message to the logger. Automatically append container and agent
     * name to the output log message if it is called from agent/service thread.
     * Adds String representation of the exception and its causes to the message.
     *
     * @param message String - message
     * @return boolean - true (usable for calling assert Logger.logSth(...))
     * @param e Throwable
     */
    public static boolean logFinest(final String message, final Throwable e) {
      log(Level.FINEST,message,e);

      return true;
    }

    /**
     * Send fine log message to the logger. Automatically append container and agent
     * name to the output log message if it is called from agent/service thread.
     * Adds String representation of the exception and its causes to the message.
     *
     * @param message String - message
     * @return boolean - true (usable for calling assert Logger.logSth(...))
     * @param e Throwable
     */
    public static boolean logFine(final String message, final Throwable e) {
      log(Level.FINE,message,e);

      return true;
    }

    /**
     * Send info log message to the logger. Automatically append container and agent
     * name to the output log message if it is called from agent/service thread.
     * Adds String representation of the exception and its causes to the message.
     *
     * @param message String - message
     * @return boolean - true (usable for calling assert Logger.logSth(...))
     * @param e Throwable
     */
    public static boolean logInfo(final String message, final Throwable e) {
      log(Level.INFO,message,e);

      return true;
    }

    /**
     * Send warning log message to the logger. Automatically append container and agent
     * name to the output log message if it is called from agent/service thread.
     * Adds String representation of the exception and its causes to the message.
     *
     * @param message String - message
     * @return boolean - true (usable for calling assert Logger.logSth(...))
     * @param e Throwable
     */
    public static boolean logWarning(final String message, final Throwable e) {
      log(Level.WARNING,message,e);

      return true;
    }

    /**
     * Send severe log message to the logger. Automatically append container and agent
     * name to the output log message if it is called from agent/service thread.
     * Adds String representation of the exception and its causes to the message.
     *
     * @param message String - message
     * @return boolean - true (usable for calling assert Logger.logSth(...))
     * @param e Throwable
     */
    public static boolean logSevere(final String message, final Throwable e) {
      log(Level.SEVERE,message,e);

      return true;
    }

    /**
     * Create log, the message for logging is generated using specified
     * logProvider only if log passed all filtration rules
     *
     * @param level Level
     * @param logProvider LogProvider
     */
    public static boolean log(final Level level, final LogProvider logProvider) {
        log(level, logProvider, getElementaryEntity(), 0);

        return true;
    }

    /**
     * Create log, the message for logging is generated using specified
     * logProvider only if log passed all filtration rules
     *
     * @param level Level
     * @param logProvider LogProvider
     * @param entity ElementaryEntity
     * @param callsBack int
     */
    public static boolean log(final Level level, final LogProvider logProvider, final ContainerOwner entity, final int callsBack) {
        final LogRecord lr = prepareLogRecord(level, entity, callsBack);

        // do filtration
        if (!isLoggable(lr)) {
            return false;
        }

        lr.timeStamp = timeProvider.getTimeStamp();
        lr.message = logProvider.getLogMessage();

        log(lr);

        return true;
    }

    /**
     * Check if specified level is loggable in the current context
     *
     * @param level Level
     * @return boolean
     */
    public static boolean isLoggable(final Level level) {
        return isLoggable(level, getElementaryEntity(), 0);
    }

    /**
     * Check if specified level is loggable in the current context
     *
     * @param level Level
     * @param entity ElementaryEntity
     * @param callsBack int
     * @return boolean
     */
    public static boolean isLoggable(final Level level, final ContainerOwner entity, final int callsBack) {
        final LogRecord lr = prepareLogRecord(level, entity, callsBack);
        return isLoggable(lr);
    }

    /**
     * Send log message to the logger. Automatically append container and agent
     * name to the output log message if it is called from the agent/service thread.
     * Adds String representation of the exception and its causes to the message.
     * @param level Level
     * @param message String
     * @param e Throwable
     */
    private static void log(final Level level, final String message, final Throwable e) {
        if ((message != null) && (!message.equals(""))) {
                log(level, message + "\nCaused by: " + ExceptionPrinter.toStringWithCause(e));
            } else {
                log(level, message + ExceptionPrinter.toStringWithCause(e));
            }
    }

    /**
     * Returns elementary entity to which this thread belongs
     * @return ElementaryEntity
     */
    private static ElementaryEntity getElementaryEntity() {
        // Find agent or service instance
        final String currentThreadName = Thread.currentThread().getName();
        final Matcher agentMatcher = agentThreadPattern.matcher(currentThreadName);
        if (agentMatcher.find()) {
            // yes this is agent thread
            final String containerName = agentMatcher.group(1);
            final String agentName = agentMatcher.group(2);
            if ( (containerName != null) && (agentName != null)) {
                final AgentContainer ac = Platform.getContainer(containerName);
                if (ac != null) {
                    final Agent agent = ac.getAgentManager().getAgentInstance(agentName);
                    if (agent != null) {
                        // found
                        return agent;
                    }
                }
            }
        }
        final Matcher serviceMatcher = serviceThreadPattern.matcher(currentThreadName);
        if (serviceMatcher.find()) {
            // yes this is service thread
            final String containerName = serviceMatcher.group(1);
            final String serviceName = serviceMatcher.group(2);
            if ( (containerName != null) && (serviceName != null)) {
                final AgentContainer ac = Platform.getContainer(containerName);
                if (ac != null) {
                    final Service service = ac.getServiceManager().getServiceInstance(serviceName);
                    if (service != null) {
                        // found
                        return service;
                    }
                }
            }
        }
        // agent service not found
        return null;
    }

    /**
     * Send log message to the logger. Automatically append container and agent
     * name to the output log message if it is called from the agent/service thread
     * @param level Level
     * @param message String
     */
    private static void log(final Level level, final String message) {
        log(level, message, getElementaryEntity(), 0);
    }

    /**
     * Fill log record with originator specification
     * @param level Level
     * @param entity ElementaryEntity
     * @param callsBack int
     * @return LogRecord
     */
    private static LogRecord prepareLogRecord(final Level level, final ContainerOwner entity, final int callsBack) {
        final LogRecord lr = new LogRecord();
        lr.level = level;

        final StackTraceElement stack[] = Thread.currentThread().getStackTrace();
//        System.out.println(Arrays.toString(stack));
        // First, search back to a caller class.
        int ix = 0;
        StackTraceElement frame = stack[0];
        while (ix < stack.length) {
            frame = stack[ix];
            final String cname = frame.getClassName();
            if (cname.equals(Logger.class.getName())) {
                break;
            }
            ix++;
        }
        while (ix < stack.length) {
            frame = stack[ix];
            final String cname = frame.getClassName();
            if (!cname.equals(Logger.class.getName())) {
                break;
            }
            ix++;
        }
        ix += callsBack;
        if (ix < stack.length) {
            frame = stack[ix];
        }

        lr.className = frame.getClassName();
        lr.methodName = frame.getMethodName();
        lr.lineNumber = frame.getLineNumber();
        lr.fileName = frame.getFileName();

        if (entity != null) {
            lr.container = entity.getContainer().getContainerName();
            lr.elementaryEntityName = entity.getName();
        } else {
            lr.threadName = Thread.currentThread().getName();
        }

        return lr;
    }

    /**
     * Send log message to the logger. Automatically append container and agent name to the output log message if it is called from the agent/service thread
     *
     * @param level Level
     * @param message String
     * @param entity ElementaryEntity
     * @param callsBack int
     */
    public static boolean log(final Level level, final String message, final ContainerOwner entity, final int callsBack) {
        final LogRecord lr = prepareLogRecord(level, entity, callsBack);

        // do filtering
        if (!isLoggable(lr)) {
            return false;
        }

        lr.message = message;
        lr.timeStamp = timeProvider.getTimeStamp();

        log(lr);

        return true;
    }

    /**
     * Check if log is loggable
     * @param lr LogRecord
     * @return boolean
     */
    private static boolean isLoggable(final LogRecord lr) {
        final String id = new StringBuilder().append(lr.level.intValue()).append("$#$#$").
                           append((lr.container==null)?"N":lr.container).append("$#$#$").
                           append((lr.elementaryEntityName==null)?"N":lr.elementaryEntityName).append("$#$#$").
                           append((lr.className==null)?"N":lr.className).append("$#$#$").
                           append((lr.methodName==null)?"N":lr.methodName).toString();
        final Boolean yes = logIt.get(id);
        if (yes != null) {
            return yes;
        }
        if (!rootLogFilter.isLoggable(lr,lr.level.intValue())) {
            logIt.put(id, false);
            return false;
        }
        logIt.put(id, true);
        return true;
    }

    /**
     * Log method used for parsing messages from java.util.logging.Logger
     * @param originalLogRecord LogRecord
     */
    public static boolean log(final java.util.logging.LogRecord originalLogRecord) {
        if (javaInternalLoggingFilter.matcher(originalLogRecord.getSourceClassName()).find()) {
            // filter internal JAVA logging
            return false;
        }
        final LogRecord lr = new LogRecord();
        lr.level = originalLogRecord.getLevel();
        lr.className = originalLogRecord.getSourceClassName();
        lr.methodName = originalLogRecord.getSourceMethodName();
        lr.lineNumber = -1;

        final ElementaryEntity entity = getElementaryEntity();

        if (entity != null) {
            lr.container = entity.getContainer().getContainerName();
            lr.elementaryEntityName = entity.getName();
        } else {
            lr.threadName = Thread.currentThread().getName();
        }

        // do filtering
        if (!isLoggable(lr)) {
            return false;
        }

        lr.message = originalLogRecord.getMessage();
        lr.timeStamp = timeProvider.getTimeStamp();

        log(lr);

        return true;
    }

    public static String formatLogMessage(final LogRecord lr) {
        final StringBuilder msg = new StringBuilder(lr.timeStamp).append(" ");
        if (lr.container != null) {
            msg.append(lr.container).append(" ").append(lr.elementaryEntityName);
        } else {
            msg.append("thread:").append(lr.threadName);
        }
        msg.append(" ").append(lr.className).append(".").append(lr.methodName);
        if (lr.lineNumber >= 0) {
            msg.append("(").append(lr.fileName).append(":").append(lr.lineNumber).append(")");
        }
        msg.append("\n").append(lr.level.toString()).append(": ").append(lr.message).append("\n");

        return msg.toString();
    }

    /**
     * Do filtering, and distribute log if passed
     * @param lr LogRecord
     */
    private static void log(final LogRecord lr) {
        // distribute log record
        broadcastTopic(TOPIC_LOGGER_MESSAGE, lr, (master)?"":null);

        // local logging
        localLogOutput(lr);
    }

    private static void localLogOutput(final LogRecord lr) {
        String m = null;
        if (consoleLogging) {
            m = formatLogMessage(lr)+"\n";
            // do console logging
            try {
                consoleWriter.write(m);
                consoleWriter.flush();
            } catch (IOException ex) {
            }
        }

        if (logFile != null) {
            if (m == null) {
                m = formatLogMessage(lr)+"\n";
            }
            // do file logging
            try {
                logFile.write(m);
                logFile.flush();
            }
            catch (IOException ex1) {
            }
        }
    }

    /**
     *
     * <p>Title: Aglobe</p>
     *
     * <p>Description: Time provider providing current time in local format</p>
     *
     * <p>Copyright: Copyright (c) 2006</p>
     *
     * <p>Company: Agent Technology Center, Gerstner Laboratory</p>
     *
     * @author David Sislak
     * @version $Revision: 1.26 $ $Date: 2010/10/18 12:25:43 $
     */
    private final static class DefaultTimeProvider implements TimeProvider {

        private DateFormat dateFormat = DateFormat.getDateTimeInstance();


        /**
         * Get current time stamp
         * @return String
         */
        @Override
		public String getTimeStamp() {
            return dateFormat.format(new Date());
        }

        @Override
		public void makeSubscription(final TopicsService.Shell topicsShell) {
        }

    }

    /**
     *
     * <p>Title: Aglobe </p>
     *
     * <p>Description: Log filter defines one log group</p>
     *
     * <p>Copyright: Copyright (c) 2006</p>
     *
     * <p>Company: Agent Technology Center, Gerstner Laboratory</p>
     *
     * @author David Sislak
     * @version $Revision: 1.26 $ $Date: 2010/10/18 12:25:43 $
     */
    private final static class LogFilter {
        private Level level;
        private int levelVal;
        private Pattern containerName;
        private Pattern entityName;
        private Pattern className;
        private Pattern methodName;

        private ArrayList<LogFilter> childs;

        private LogFilter(final String rootLevel, final List<LogGroup> rootGroup) {
            level = Level.parse(rootLevel);
            levelVal = level.intValue();

            if ((rootGroup != null) && (rootGroup.size() != 0)) {
                childs = new ArrayList<LogFilter>();
                for (LogGroup elem : rootGroup) {
                    childs.add(new LogFilter(elem));
                }
            }
        }

        private LogFilter(final LogGroup logGroup) {
            this (logGroup.getLevel(), logGroup.getLogGroup());

            if (logGroup.getContainerName() != null) {
                containerName = Pattern.compile(logGroup.getContainerName(),Pattern.CASE_INSENSITIVE);
            }
            if (logGroup.getEntityName() != null) {
                entityName = Pattern.compile(logGroup.getEntityName(),Pattern.CASE_INSENSITIVE);
            }
            if (logGroup.getClassName() != null) {
                className = Pattern.compile(logGroup.getClassName(),Pattern.CASE_INSENSITIVE);
            }
            if (logGroup.getMethodName() != null) {
                methodName = Pattern.compile(logGroup.getMethodName(),Pattern.CASE_INSENSITIVE);
            }
        }

        private boolean isLoggable(final LogRecord lr, final int levelVal) {
            if (childs != null) {
                for (LogFilter elem : childs) {
                    if (elem.matches(lr)) {
                        return elem.isLoggable(lr, levelVal);
                    }
                }
            }
            return (levelVal >= this.levelVal);
        }

        private boolean matches(final LogRecord lr) {
            return ((containerName == null) || ((lr.container != null) && (containerName.matcher(lr.container).find()))) &&
                   ((entityName == null) || ((lr.elementaryEntityName != null) && (entityName.matcher(lr.elementaryEntityName).find()))) &&
                   ((className == null) || (className.matcher(lr.className).find())) &&
                   ((methodName == null) || (methodName.matcher(lr.methodName).find()));
        }
    }
}
