package aglobe.util.directory;

import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;

import aglobe.container.ElementaryEntity;
import aglobe.container.transport.Address;
import aglobe.service.directory.DirectoryException;
import aglobe.service.directory.DirectoryListener;
import aglobe.service.directory.DirectoryRecord;
import aglobe.service.directory.DirectoryService;

/**
 * <p>Title: A-Globe</p>
 *
 * <p>Description: Searches for agent address according to agent's container name.
 * Containers must have unique names. An agent with given service must be only in on a container.</p>
 *
 * <p>Copyright: Copyright (c) 2007</p>
 * <p>Company: Gerstner Laboratory</p>
 */
public class AddressFinderBasedOnDirectoryListener implements DirectoryListener, AddressFinder {

    /**
     * Service name
     */
    private final String service;

    /**
     * Owner of directory
     */
    private final ElementaryEntity owner;

    /**
     * Directory service shell
     */
    private DirectoryService.Shell dirShell;

    /**
     * Map of the visible agents indexed by their container name
     */
    private HashMap<String, Address> visibleAgents = new HashMap<String,Address>();

    /**
     * Waiting call-backs for addresses
     */
    private HashMap<String, LinkedList<Listener>> waitingCallbacks = new HashMap<String,LinkedList<Listener>>();

    /**
     *
     * @param owner ElementaryConversationEntity
     */
    public AddressFinderBasedOnDirectoryListener(ElementaryEntity owner, String serviceName) {
        this.owner = owner;
        service = serviceName;

        dirShell = (DirectoryService.Shell) owner.getContainer().getServiceManager().getService(owner, DirectoryService.SERVICENAME);
        if (dirShell == null) {
            owner.logSevere("Directory service is not running !!!");
            return;
        }

        // register own service
        try {
            dirShell.register(owner,
                              Arrays.asList(new String[] {service}));
        } catch (DirectoryException ex) {
            owner.logSevere(ex.toString());
        }

        // subscribe for others
        dirShell.subscribe(this, service);
    }

    /**
     * Handles new registration in the directory.
     *
     * @param containerName String - container name where the agent/service
     *   have been registered
     * @param records DirectoryRecord[] - array of the agents/services which
     *   are registered. An agent/service can handle its own registration too.
     * @param matchingFilter String - matching filter to which is this
     *   callback. Can be used if an someone has more subscriptions to the
     *   same listener with cross filter. In this case registration info
     *   about one agent/service can be handled two times
     */
    @Override
	public void handleNewRegister(String containerName,
                                  DirectoryRecord[] records,
                                  String matchingFilter) {
        // not used
    }

    /**
     * Handles deregistration of the agent/service.
     *
     * @param containerName String - container name where the agent/service
     *   have been de-registered
     * @param records DirectoryRecord[] - array of the agents/services which
     *   are de-registered. Only address and containerName fields are valid;
     *   services field couldn't have valid data. An agent/service can
     *   handle its own de-registration too.
     * @param matchingFilter String - matching filter to which is this
     *   callback. Can be used if an someone has more subscriptions to the
     *   same listener with cross filter.
     */
    @Override
	public void handleDeregister(String containerName,
                                 DirectoryRecord[] records,
                                 String matchingFilter) {
        // not used
    }

    /**
     * Handles that some agents/services becomes visible to me.
     *
     * @param containerName String - container name where agents/services
     *   become visible
     * @param records DirectoryRecord[] - array of the agents/services which
     *   become visible. Only address and containerName fields are valid;
     *   services field couldn't have valid data. An agent/service can
     *   handle its own visibility too.
     * @param matchingFilter String - matching filter to which is this
     *   callback. Can be used if an someone has more subscriptions to the
     *   same listener with cross filter.
     */
    @Override
	public void handleVisible(String containerName, DirectoryRecord[] records,
                              String matchingFilter) {
        //Logger.logFine("handleVisible "+Arrays.toString(records));
        if (!containerName.equals(owner.getContainer().getContainerName())) {
            for (int i = 0; i < records.length; i++) {
                visibleAgents.put(containerName, records[i].address);
                // search if there is some waiting callback for this object
                LinkedList<Listener> ll = waitingCallbacks.remove(containerName);
                if (ll != null) {
                    for (Listener elem : ll) {
                        elem.addressFound(records[i].address);
                    }
                }
            }
        }
    }

    /**
     * Handles that some agents/services becomes invisible to me.
     *
     * @param containerName String - container name where agents/services
     *   become invisible
     * @param records DirectoryRecord[] - array of the agents/services which
     *   become invisible. Only address and containerName fields are valid;
     *   services field couldn't have valid data. An agent/service can
     *   handle its own invisibility too.
     * @param matchingFilter String - matching filter to which is this
     *   callback. Can be used if an someone has more subscriptions to the
     *   same listener with cross filter.
     */
    @Override
	public void handleInvisible(String containerName, DirectoryRecord[] records,
                                String matchingFilter) {
        if (!containerName.equals(owner.getContainer().getContainerName())) {
            visibleAgents.remove(containerName);
        }
    }

    /**
     *
     * @param e Runnable
     */
    @Override
	public void addEvent(Runnable e) {
        owner.addEvent(e);
    }

    /**
     * Search for container address.
     *
     * @param containerName String - container name
     * @param callbackListener DirectoryListener
     */
    @Override
	public void searchForAddress(String containerName, Listener callbackListener) {
        Address retVal = visibleAgents.get(containerName);
        if (retVal != null) {
            callbackListener.addressFound(retVal);
        } else {
            LinkedList<Listener> ll = waitingCallbacks.get(containerName);
            if (ll == null) {
                ll = new LinkedList<Listener>();
                waitingCallbacks.put(containerName,ll);
            }
            ll.add(callbackListener);
        }
    }

    /**
     * Remove search callback.
     * @param containerName String - container name
     * @param callbackListener PilotDirectoryListener
     */
    @Override
	public void removeSearchCallback(String containerName, Listener callbackListener) {
        LinkedList<Listener> ll = waitingCallbacks.get(containerName);
        if (ll != null) {
            ll.remove(callbackListener);
            if (ll.size() == 0) {
                waitingCallbacks.remove(containerName);
            }
        }
    }
}
