package aglobe.util.directory;

import aglobe.container.transport.Address;

/**
 * <p>Title: A-Globe</p>
 *
 * <p>Description: Searches for agent or container address according to agent's or container's name.
 *
 * <p>Copyright: Copyright (c) 2007</p>
 * <p>Company: Gerstner Laboratory</p>
 */
public interface AddressFinder {
    /**
     * Search for address.
     *
     * @param objectName String - name of container or agent. Depends on implementation.
     * @param callbackListener DirectoryListener
     */
    public void searchForAddress(String name, Listener callbackListener);

    /**
     * Remove search call-back.
     * @param objectName String - name of container or agent. Depends on implementation.
     * @param callbackListener PilotDirectoryListener
     */
    public void removeSearchCallback(String name, Listener callbackListener);

    public interface Listener {
        /**
        * Requested address found
        * @param address Address address of container or agent. Depends on implementation.
        */
       public void addressFound(Address address);
   }
}
