package aglobe.util.directory;

import java.util.LinkedHashMap;
import java.util.regex.Pattern;
import java.util.Map;
import java.util.regex.Matcher;

/**
 * <p>Title: Aglobe</p>
 *
 * <p>Description: Property helper to better use of DirectoryService. Using this helper
 * there can be assigned several properties using different types to service provider. Searching
 * can be done using several filtration too.</p>
 *
 * <p>Copyright: Copyright (c) 2007</p>
 *
 * <p>Company: Agent Technology Center, Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.5 $ $Date: 2009/02/12 07:47:47 $
 */
public class PropertyHelper {
    private static final String PROPERTY_SEPARATOR = "&%&";
    private static final String TYPE_SEPARATOR = "&#&";
    private static final String VALUE_SEPARATOR = "&=&";

    private static final Pattern VALUES_TESTER = Pattern.compile("("+PROPERTY_SEPARATOR+"|"+TYPE_SEPARATOR+"|"+VALUE_SEPARATOR+"|&)");
    private static final Pattern EXTRACTOR = Pattern.compile(PROPERTY_SEPARATOR+"([^&]*)"+TYPE_SEPARATOR+"([^&]*)"+VALUE_SEPARATOR+"([^&]*)"+PROPERTY_SEPARATOR);

    private String prefix;

    private LinkedHashMap<String,Integer> ints = new LinkedHashMap<String,Integer>();
    private LinkedHashMap<String,Long> longs = new LinkedHashMap<String,Long>();
    private LinkedHashMap<String,Double> doubles = new LinkedHashMap<String,Double>();
    private LinkedHashMap<String,Boolean> booleans = new LinkedHashMap<String,Boolean>();
    private LinkedHashMap<String,String> strings = new LinkedHashMap<String,String>();

    /**
     * Create empty property holder
     *
     * @param prefix String - record prefix
     * @param noUseful boolean - anything
     */
    public PropertyHelper(String prefix, boolean noUseful) {
        this.prefix = prefix;
    }

    /**
     * Initialize property holder from the string received from directory services
     * @param directoryServiceString String
     */
    public PropertyHelper(String directoryServiceString) {
        Matcher m = EXTRACTOR.matcher(directoryServiceString);
        while (m.find()) {
            int nt = Integer.valueOf(m.group(1));
            Type t = Type.values()[nt];

            String key = m.group(2);
            switch (t) {
            case INT:
                int v = Integer.valueOf(m.group(3));
                ints.put(key,v);
                break;
            case LONG:
                long vl = Long.valueOf(m.group(3));
                longs.put(key,vl);
                break;
            case DOUBLE:
                double vd = Double.valueOf(m.group(3));
                doubles.put(key,vd);
                break;
            case BOOLEAN:
                boolean vb = Boolean.valueOf(m.group(3));
                booleans.put(key,vb);
                break;
            case STRING:
                String vs = m.group(3);
                strings.put(key,vs);
                break;
            }
        }
    }

    /**
     * Gets directory service filter string for defined properties
     * @return String
     */
    public String getDirectoryServiceFilterString() {
        return getDirectoryServiceString(true);
    }

    /**
     * Gets directory service string holding defined properties
     * @return String
     */
    public String getDirectoryServiceString() {
        return getDirectoryServiceString(false);
    }

    private String getDirectoryServiceString(boolean filter) {
        StringBuilder sb = new StringBuilder(prefix);
        sb.append(PROPERTY_SEPARATOR);
        if (filter) {
            sb.append(".*").append(PROPERTY_SEPARATOR);
        }
        if (ints.size() > 0) {
            for (Map.Entry<String,Integer> elem : ints.entrySet()) {
                sb.append(Type.INT.ordinal()).append(TYPE_SEPARATOR).append(elem.getKey()).append(VALUE_SEPARATOR).append(elem.getValue()).append(PROPERTY_SEPARATOR);
                if (filter) {
                    sb.append(".*").append(PROPERTY_SEPARATOR);
                }
            }
        }
        if (longs.size() > 0) {
            for (Map.Entry<String,Long> elem : longs.entrySet()) {
                sb.append(Type.LONG.ordinal()).append(TYPE_SEPARATOR).append(elem.getKey()).append(VALUE_SEPARATOR).append(elem.getValue()).append(PROPERTY_SEPARATOR);
                if (filter) {
                    sb.append(".*").append(PROPERTY_SEPARATOR);
                }
            }
        }
        if (doubles.size() > 0) {
            for (Map.Entry<String,Double> elem : doubles.entrySet()) {
                sb.append(Type.DOUBLE.ordinal()).append(TYPE_SEPARATOR).append(elem.getKey()).append(VALUE_SEPARATOR).append(elem.getValue()).append(PROPERTY_SEPARATOR);
                if (filter) {
                    sb.append(".*").append(PROPERTY_SEPARATOR);
                }
            }
        }
        if (booleans.size() > 0) {
            for (Map.Entry<String,Boolean> elem : booleans.entrySet()) {
                sb.append(Type.BOOLEAN.ordinal()).append(TYPE_SEPARATOR).append(elem.getKey()).append(VALUE_SEPARATOR).append(elem.getValue()).append(PROPERTY_SEPARATOR);
                if (filter) {
                    sb.append(".*").append(PROPERTY_SEPARATOR);
                }
            }
        }
        if (strings.size() > 0) {
            for (Map.Entry<String,String> elem : strings.entrySet()) {
                sb.append(Type.STRING.ordinal()).append(TYPE_SEPARATOR).append(elem.getKey()).append(VALUE_SEPARATOR).append(elem.getValue()).append(PROPERTY_SEPARATOR);
                if (filter) {
                    sb.append(".*").append(PROPERTY_SEPARATOR);
                }
            }
        }
        return sb.toString();
    }

    public void putIntProperty(String key, int val) {
        checkValue(key);
        ints.put(key,val);
    }

    public void putLongProperty(String key, long val) {
        checkValue(key);
        longs.put(key,val);
    }

    public void putDoubleProperty(String key, double val) {
        checkValue(key);
        doubles.put(key,val);
    }

    public void putBooleanProperty(String key, boolean val) {
        checkValue(key);
        booleans.put(key,val);
    }

    public void putStringProperty(String key, String val) {
        checkValue(key);
        checkValue(val);
        strings.put(key,val);
    }

    public int getIntProperty(String key) {
        Integer v = ints.get(key);
        if (v==null) {
            throw new IllegalArgumentException("No value for key: "+key);
        }
        return v;
    }

    public long getLongProperty(String key) {
        Long v = longs.get(key);
        if (v==null) {
            throw new IllegalArgumentException("No value for key: "+key);
        }
        return v;
    }

    public double getDoubleProperty(String key) {
        Double v = doubles.get(key);
        if (v==null) {
            throw new IllegalArgumentException("No value for key: "+key);
        }
        return v;
    }

    public boolean getBooleanProperty(String key) {
        Boolean v = booleans.get(key);
        if (v==null) {
            throw new IllegalArgumentException("No value for key: "+key);
        }
        return v;
    }

    public String getStringProperty(String key) {
        String v = strings.get(key);
        if (v==null) {
            throw new IllegalArgumentException("No value for key: "+key);
        }
        return v;
    }

    private void checkValue(String val) {
        if (VALUES_TESTER.matcher(val).find()) {
            throw new IllegalArgumentException("Contains at least one of the following not allowed sequence: "+
                                               PROPERTY_SEPARATOR+" or "+TYPE_SEPARATOR+" or "+
                                               VALUE_SEPARATOR+" or &");
        }
    }

    private static enum Type {
        INT,
        LONG,
        DOUBLE,
        BOOLEAN,
        STRING;
    }

}
