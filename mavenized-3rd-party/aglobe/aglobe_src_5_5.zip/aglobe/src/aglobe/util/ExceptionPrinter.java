package aglobe.util;

/**
 * Contains methods for printing Throwable to String.
 *
 * @author Jiri Samek
 *
 */
public final class ExceptionPrinter {

    private ExceptionPrinter() {
    }

    /**
     * Prints exception to string with use of toString method, then recursively does the same for its cause. The cause is printed
     * at the new line.
     *
     * @return string representation of exception or empty string if <code>e</code> is null
     */
    public static String toStringWithCause(Throwable e) {
        if (e == null)
            return "";
        StringBuilder sb = new StringBuilder();
        toStringWithCause(e, sb);
        return sb.toString();
    }

    /**
     * Prints exception to string with use of toString method, then recursively does the same for its cause. The cause is printed
     * at the new line. Then it append string representation of elements in stack trace. Each element is printed at new line.
     *
     * @return empty string if <code>e</code> is null
     */
    public static String toStringWithStackTrace(Throwable e) {
            return toStringWithStackTrace(e, new StringBuilder()).toString();
    }

        private static StringBuilder toStringWithStackTrace(Throwable e, StringBuilder sb) {
        if (e == null)
            return sb;

        StackTraceElement[] stack = e.getStackTrace();
//		toStringWithCause(e, sb);
                sb.append(e);
        sb.append("\nStack trace:\n");
        for (StackTraceElement elem: stack) {
            sb.append(elem);
            sb.append("\n");
        }
                Throwable cause = e.getCause();
                if (cause != null) {
                    sb.append("\nCaused by:\n");
                    toStringWithStackTrace(cause, sb);
                }
                return sb;
    }

    /**
     * Prints exception to string with use of toString method, then recursively does the same for its cause. The cause is printed
     * at the new line.
     */
    private static void toStringWithCause(Throwable e, StringBuilder sb) {
        sb.append(e);
        Throwable cause = e.getCause();
        if (cause != null) {
            sb.append("\nCaused by:\n");
            toStringWithCause(cause, sb);
        }
    }

    public static String printStackTraceToString(String exceptionText) {
    	try {
			throw new Exception(exceptionText);
		} catch (Exception e) {
			return toStringWithStackTrace(e);
		}
    }
    
    public static String printStackTraceToString() {
    	return printStackTraceToString("print stack trace");
    }
}
