
package aglobe.ontology;

import aglobe.container.library.LibraryObjectInputStream;
import aglobe.container.transport.Address;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.ObjectInput;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import aglobe.platform.transport.AddressReader;
import aglobe.platform.transport.AddressWriter;
import aglobe.platform.transport.MessageObjectOutputStream;
import aglobe.util.ConversionTools;
import aglobe.util.Logger;
import aglobe.util.concurrent.NonblockingPoolArrayFIFO;

/**
 *
 * <p>Title: A-Globe</p>
 *
 * <p>Description: MulticastCommunicationInfo object is used for passing information about
 * communication by the multicast message in the TOPIC_COMMUNICATION_INFO topic.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.12 $ $Date: 2010/08/04 11:48:05 $
 */
@SuppressWarnings("unused")
public final class MulticastCommunicationInfo implements PooledObject {
    /**
     * pool of the objects
     */
    private final static NonblockingPoolArrayFIFO<MulticastCommunicationInfo> pool = new NonblockingPoolArrayFIFO<MulticastCommunicationInfo>(1<<13);

    /**
     * Number of current holders
     */
    private final AtomicInteger holders = new AtomicInteger(1);

//    private final static AtomicInteger newInstances = new AtomicInteger(0);
//    private final static AtomicInteger releasedObjects = new AtomicInteger(0);
//    private final static ConcurrentHashMap<CommunicationInfo, CommunicationInfo> nonReleasedObjects = new ConcurrentHashMap<CommunicationInfo, CommunicationInfo>();
//
//    private StringBuilder holderDebug;
//    private void stackTraceToString(String prefix) {
//        final Exception e = new Exception();
//        final StackTraceElement[] stack = e.getStackTrace();
//        int skip = 2;
//        synchronized (holderDebug) {
//            holderDebug.append(prefix);
//            holderDebug.append(" (holders = ").append(holders.get()).append("):\n");
//            for (StackTraceElement elem: stack) {
//                if (skip-- > 0) {
//                    continue;
//                }
//                holderDebug.append(elem);
//                holderDebug.append("\n");
//            }
//            holderDebug.append("\n");
//        }
//    }

    /**
     * Communication from container address
     */
    private Address _From;

    /**
     * Message container receivers
     */
    private final LinkedHashSet<Address> _Receivers = new LinkedHashSet<Address>();

    /**
     * Message transmission length in Bytes.
     */
    private int _DataLength;

    private MulticastCommunicationInfo() {

    }

    public final static MulticastCommunicationInfo getInstance() {
        MulticastCommunicationInfo retVal = pool.pop();
        if (retVal == null) {
            retVal = new MulticastCommunicationInfo();
//            final int newInst = newInstances.incrementAndGet();
//            if (newInst % 10 == 0) {
//                Logger.logWarning("New Instances Cnt: "+newInst+" Cache size: "+pool.size()+" Released: "+releasedObjects.get());
////                Logger.logWarning("First non-released object:\n"+(nonReleasedObjects.keys().nextElement().holderDebug.toString()));
//            }
        }
        retVal.holders.set(1);
//        retVal.holderDebug = new StringBuilder();
//        retVal.stackTraceToString("Creation");
//        nonReleasedObjects.put(retVal, retVal);
        return retVal;
    }

    /* (non-Javadoc)
     * @see aglobe.ontology.PooledObject#registerHolder()
     */
    @Override
    public final void registerHolder() {
        holders.incrementAndGet();
//        stackTraceToString("Register holder");
    }

    /* (non-Javadoc)
     * @see aglobe.ontology.PooledObject#release()
     */
    @Override
    public final void release() {
        final int hold = holders.decrementAndGet();
//        stackTraceToString("Release holder");
        if (hold > 0) {
            return;
        }
        if (hold < 0) {
            throw new RuntimeException("Holders is under 0 !!!");
//            throw new RuntimeException("Holders is under 0 !!! Log:\n"+holderDebug.toString()+"\n End of log \n");
        }
        _Receivers.clear();
        pool.push(this);
//        releasedObjects.incrementAndGet();
//        nonReleasedObjects.remove(this);
    }

    public static MulticastCommunicationInfo getInstance(final Address from, final int dataLength) {
        final MulticastCommunicationInfo retVal = getInstance();
        retVal._From = from;
        retVal._DataLength = dataLength;
        return retVal;
    }

    /**
     * Gets source address of the communication
     * @return Address
     */
    public final Address getFrom() {
        return _From;
    }

    /**
     * Get all receivers of the multicast message. Do not make changes in the
     * collection !!!
     * @return Collection<Address>
     */
    public final Collection<Address> getReceivers() {
        return _Receivers;
    }

    /**
     * Get underlying message transmission length in Bytes.
     * @return int
     */
    public final int getDataLength() {
        return _DataLength;
    }

    /**
     * Tests if object equals to the ob object
     * @param ob Object
     * @return boolean
     */
    @Override
    public final boolean equals(final Object ob) {
        if (this == ob) {
            return true;
        }
        if (!(ob instanceof MulticastCommunicationInfo)) {
            return false;
        }
        final MulticastCommunicationInfo tob = ((MulticastCommunicationInfo) ob);
        if (_From != null) {
            if (tob._From == null) {
                return false;
            }
            if (!_From.equals(tob._From)) {
                return false;
            }
        } else {
            if (tob._From != null) {
                return false;
            }
        }
        if (_Receivers != null) {
            if (tob._Receivers == null) {
                return false;
            }
            if (!_Receivers.equals(tob._Receivers)) {
                return false;
            }
        } else {
            if (tob._Receivers != null) {
                return false;
            }
        }
        if (_DataLength != tob._DataLength) {
            return false;
        }
        return true;
    }

    /**
     * Returns hash code of the object
     * @return int
     */
    @Override
    public final int hashCode() {
        int h = 0;
        h = ((127 * h) + ((_From != null) ? _From.hashCode() : 0));
        h = ((127 * h) + ((_Receivers != null) ? _Receivers.hashCode() : 0));
        h = ((31 * h) + _DataLength);
        return h;
    }

    /**
     * Returns string representation of the object
     * @return String
     */
    @Override
    public final String toString() {
        final StringBuffer sb = new StringBuffer("<<CommunicationInfo");
        if (_From != null) {
            sb.append(" From=");
            sb.append(_From.toString());
        }
        if (_Receivers != null) {
            for (Address elem : _Receivers) {
                sb.append(" Receiver=");
                sb.append(elem.toString());
            }
        }
        sb.append(" DataLength=");
        sb.append(Integer.toString(_DataLength));
        sb.append(">>");
        return sb.toString();
    }

    /**
     * Used for externalization of the object to the output stream
     * @param out ObjectOutput
     * @throws IOException
     */
    @Override
	public final void writeExternal(final ObjectOutput out) throws IOException {
        if (out instanceof MessageObjectOutputStream) {
            final AddressWriter aw = ((MessageObjectOutputStream)out).adderessWriter;
            out.writeShort(aw.writeAddress(_From));
            out.writeShort(_Receivers.size());
            for (Address elem : _Receivers) {
                out.writeShort(aw.writeAddress(elem));
            }
        } else {
            out.writeLong(_From.getAddressId());
            out.writeShort(_Receivers.size());
            for (Address elem : _Receivers) {
                out.writeLong(elem.getAddressId());
            }
        }
        out.writeInt(_DataLength);
    }

    /**
     * Used for the reading of the object content from the input stream
     * @param in ObjectInput
     * @throws ClassNotFoundException
     * @throws IOException
     */
    @Override
	public final void readExternal(final ObjectInput in) throws ClassNotFoundException,
            IOException {
        if (in instanceof LibraryObjectInputStream) {
            final AddressReader ar = ((LibraryObjectInputStream)in).addressReader;
            _From = ar.readAddress(in.readShort());
            int cnt = in.readShort();
            while (cnt > 0) {
                _Receivers.add(ar.readAddress(in.readShort()));
                cnt--;
            }
        } else {
            _From = Address.getAddress(in.readLong());
            int cnt = in.readShort();
            while (cnt > 0) {
                _Receivers.add(Address.getAddress(in.readLong()));
                cnt--;
            }
        }
        _DataLength = in.readInt();
    }

}
