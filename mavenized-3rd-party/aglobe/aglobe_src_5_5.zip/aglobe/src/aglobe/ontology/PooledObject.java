package aglobe.ontology;

import java.io.Externalizable;

/**
 * <p>Title: A-Globe</p>
 *
 * <p>Description: If the content transmitted within A-globe implements this
 * interface, components call registerHolder and release methods on it.
 * Such objects are not cached in GIS. Such object must also implement
 * public static getInstance() method returning that object which is used to
 * effective usage of pooling mechanism also for transmitted objects via MessageTransport.
 * The constructor of implementing object should be private which ensures that no one will
 * create new object other way than by calling getInstance() method.</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Agent Technology Center, Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.1 $ $Date: 2009/02/27 15:14:22 $
 */
public interface PooledObject extends Externalizable {

    /**
     * Register another holder of the object
     */
    public void registerHolder();

    /**
     * Release one holder of the object
     */
    public void release();
}
