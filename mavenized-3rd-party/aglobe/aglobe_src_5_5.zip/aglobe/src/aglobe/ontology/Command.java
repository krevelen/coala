
package aglobe.ontology;

import aglobe.ontology.AglobeParam;
import java.io.IOException;
import java.util.List;
import java.io.Externalizable;
import java.io.ObjectOutput;
import java.io.ObjectInput;
import java.util.*;
import aglobe.util.ConversionTools;

/**
 *
 * <p>Title: A-Globe</p>
 *
 * <p>Description: Command object is used for remote control of aglobe containers.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.16 $ $Date: 2010/08/04 11:48:05 $
 */
public class Command implements Externalizable {

    /**
     * Command name
     */
    private String _Name;

    /**
     * Command params
     */
    private List<AglobeParam> _AglobeParam = new LinkedList<AglobeParam>();

    /**
     * Command result
     */
    private String _Result;

    /**
     * Get command name
     * @return String
     */
    public String getName() {
        return _Name;
    }

    /**
     * Set command name
     * @param _Name String
     */
    public void setName(String _Name) {
        this._Name = _Name;
    }

    /**
     * Get command params. Each list element holds one AglobeParam instance.
     * @return List
     */
    public List<AglobeParam> getAglobeParam() {
        return _AglobeParam;
    }

    /**
     * Get command result
     * @return String
     */
    public String getResult() {
        return _Result;
    }

    /**
     * Set command result
     * @param _Result String
     */
    public void setResult(String _Result) {
        this._Result = _Result;
    }

    /**
     * Test if the object equals to the ob object
     * @param ob Object
     * @return boolean - true iff equals
     */
    @Override
    public boolean equals(Object ob) {
        if (this == ob) {
            return true;
        }
        if (!(ob instanceof Command)) {
            return false;
        }
        Command tob = ((Command) ob);
        if (_Name!= null) {
            if (tob._Name == null) {
                return false;
            }
            if (!_Name.equals(tob._Name)) {
                return false;
            }
        } else {
            if (tob._Name!= null) {
                return false;
            }
        }
        if (_AglobeParam!= null) {
            if (tob._AglobeParam == null) {
                return false;
            }
            if (!_AglobeParam.equals(tob._AglobeParam)) {
                return false;
            }
        } else {
            if (tob._AglobeParam!= null) {
                return false;
            }
        }
        if (_Result!= null) {
            if (tob._Result == null) {
                return false;
            }
            if (!_Result.equals(tob._Result)) {
                return false;
            }
        } else {
            if (tob._Result!= null) {
                return false;
            }
        }
        return true;
    }

    /**
     * Returns object hash code
     * @return int
     */
    @Override
    public int hashCode() {
        int h = 0;
        h = ((127 *h)+((_Name!= null)?_Name.hashCode(): 0));
        h = ((127 *h)+((_AglobeParam!= null)?_AglobeParam.hashCode(): 0));
        h = ((127 *h)+((_Result!= null)?_Result.hashCode(): 0));
        return h;
    }

    /**
     * Get string representation of the object
     * @return String
     */
    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer("<<Command");
        if (_Name!= null) {
            sb.append(" Name=");
            sb.append(_Name);
        }
        if (_AglobeParam!= null) {
            sb.append(" AglobeParam=");
            sb.append(_AglobeParam.toString());
        }
        if (_Result!= null) {
            sb.append(" Result=");
            sb.append(_Result);
        }
        sb.append(">>");
        return sb.toString();
    }

    /**
     * The object implements the writeExternal method to save its contents by
     * calling the methods of DataOutput for its primitive values or calling
     * the writeObject method of ObjectOutput for objects, strings, and
     * arrays.
     *
     * @param out the stream to write the object to
     * @throws IOException Includes any I/O exceptions that may occur
     */
    @Override
	public void writeExternal(ObjectOutput out) throws IOException {
        ConversionTools.writeString(out,_Name);
        out.writeInt(_AglobeParam.size());
        for (AglobeParam elem : _AglobeParam) {
            out.writeObject(elem);
        }
        ConversionTools.writeString(out,_Result);
    }

    /**
     * The object implements the readExternal method to restore its contents
     * by calling the methods of DataInput for primitive types and readObject
     * for objects, strings and arrays.
     *
     * @param in the stream to read data from in order to restore the object
     * @throws IOException if I/O errors occur
     * @throws ClassNotFoundException If the class for an object being
     *   restored cannot be found.
     */
    @Override
	public void readExternal(ObjectInput in) throws IOException,
            ClassNotFoundException {
        _Name = ConversionTools.readString(in);
        int count = in.readInt();
        for (int i=0; i<count; i++) {
            _AglobeParam.add((AglobeParam)in.readObject());
        }
        _Result = ConversionTools.readString(in);
    }

}
