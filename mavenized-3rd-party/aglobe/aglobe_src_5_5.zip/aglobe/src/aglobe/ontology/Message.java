package aglobe.ontology;

import java.io.Externalizable;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Logger;

import aglobe.container.library.LibraryObjectInputStream;
import aglobe.container.transport.Address;
import aglobe.platform.transport.AddressReader;
import aglobe.platform.transport.AddressWriter;
import aglobe.platform.transport.MessageObjectOutputStream;
import aglobe.platform.transport.MessageReceiver;
import aglobe.util.AglobeXMLtools;
import aglobe.util.ConversionTools;
import aglobe.util.ExceptionPrinter;
import aglobe.util.concurrent.NonblockingPoolArrayFIFO;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: Messages use agents and service to communicate with
 *  each other. The object dosn't support direct serialization. The object must
 * be written and read from the stream by using serialize and deserialize methods.</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.70 $ $Date: 2010/10/13 10:43:05 $
 */
public final class Message implements PooledObject {

    /**
     * Pool of the free message objects
     */
    private static final NonblockingPoolArrayFIFO<Message> freeMessages = new NonblockingPoolArrayFIFO<Message>(1000000);

    /**
     * Pool of the free array list of addresses for multicast message
     */
    private static final NonblockingPoolArrayFIFO<ArrayList<Address>> freeArrayListAddress = new NonblockingPoolArrayFIFO<ArrayList<Address>>(10000);

    /**
     * Holds information about message content and flags about message attributes
     */
    private short _ContentInfo;

    /**
     * Mask used to obtain content type part from content info
     */
    private static final short CONTENT_TYPE_MASK = 0x7;

    /**
     * String content
     */
    private static final short STRING_CONTENT = 1;

    /**
     * Byte array content
     */
    private static final short BYTE_ARRAY_CONTENT = 2;

    /**
     * String array content
     */
    private static final short STRING_ARRAY_CONTENT = 3;

    /**
     * Shared object content
     */
    private static final short SHARED_OBJECT_CONTENT = 4;

    /**
     * The content is externalizable
     */
    private static final short EXTERNALIZABLE_CONTENT = 5;

    /**
     * Other serialized content
     */
    private static final short OTHER_SERIALIZED_CONTENT = 6;

    /**
     * Message has several receivers
     */
    private static final short IS_MULTICAST = 0x8;

    /**
     * Message has performative
     */
    private static final short HAS_PERFORMATIVE = 0x10;

    /**
     * Message has protocol
     */
    private static final short HAS_PROTOCOL = 0x20;

    /**
     * Message has reason
     */
    private static final short HAS_REASON = 0x40;

    /**
     * Message has conversation id
     */
    private static final short HAS_CONVERSATION_ID = 0x80;

    /**
     * Message has in reply to
     */
    private static final short HAS_IN_REPLY_TO = 0x100;

    /**
     * Message has reply with
     */
    private static final short HAS_REPLY_WITH = 0x200;

    /**
     * Do not sniff the message, it is service message used for sending
     * communication info or message copy
     */
    private static final short DO_NOT_SNIFF = 0x400;

    /**
     * Message is un-deliverable, can be set only once for one message
     */
    private static final short IS_UNDELIVERABLE = 0x800;

    private static final short MESSAGE_SIZE_REQUIRED = 0x1000;

    /**
     * Address of message sender.
     */
    private Address _Sender;

    /**
     * Address of message receiver.
     */
    private Address _Receiver;

    /**
     * List of the message receivers
     */
    private ArrayList<Address> _Receivers;

    /**
     * Performative of the message.
     */
    private String _Performative;

    /**
     * Content of the message.
     */
    private Object _Content;

    /**
     * Message protocol.
     */
    private String _Protocol;

    /**
     * Message ontology.
     */
    private String _Ontology;

    /**
     * ID of communication thread.
     */
    private String _ConversationID;

    /**
     * InReplyTo message slot
     */
    private String _InReplyTo;

    /**
     * ReplyWith message slot
     */
    private String _ReplyWith;

    /**
     * Reason of the message.
     */
    private String _Reason;

    /**
     * Is true if message is a reply.
     */
    private boolean _IsReply;

    /**
     * Visibility ID
     */
    private long _VisibilityID;
    
    /**
     * Power which is used to transmit the message
     */
    private double _TransmitPower = Double.NaN;

    /**
     * Holds information about predicted message size. If the value is 0, it is invalid.
     */
    private transient int messageSize = -1;

    private transient boolean _AsReference = false;
    /**
     * @internal
     * @return
     */
    public boolean getAsReference() { return _AsReference; }
    /**
     * @internal
     */
    public void setAsReference() { _AsReference = true; }

    /**
     * Holds information about number of object holders
     */
    private final AtomicInteger holders = new AtomicInteger(1);

//    private static AtomicInteger newMsg = new AtomicInteger(0);
//    private static AtomicInteger fromCache = new AtomicInteger(0);
//    private static AtomicInteger releasedOK = new AtomicInteger(0);
//    private static AtomicInteger throwAway = new AtomicInteger(0);

    /**
     * Message constructor
     */
    private Message() {
        _ContentInfo = 0;
        _IsReply = false;
        _Receivers = null;
    }

    /**
     * @internal
     * Method which is compatible with PooledObject interface
     * @return
     */
    public final static Message getInstance() {
        return newInstance();
    }

    /**
     * Get message instance
     * @return Message
     */
    public final static Message newInstance() {
        Message retVal = freeMessages.pop();
        if (retVal != null) {
            retVal.holders.set(1);
//            int cur = fromCache.incrementAndGet();
//            if ((cur & 0xfff) == 0) {
//                System.out.println("Msg stats: cache hits: "+cur+" new: "+newMsg.get()+" released OK: "+releasedOK.get()+" for GC: "+throwAway.get()+" cur cached objects: "+freeMessages.size()+" capacity: "+freeMessages.capacity());
//            }
            return retVal;
        }
//        newMsg.incrementAndGet();
        return new Message();
    }

    /**
     * Returns Message that has set attributes performative, sender and receiver.
     * The constructed message is standard message addressed to one receiver.
     *
     * @param _performative String
     * @param _sender Address
     * @param _receiver Address
     * @return Message
     */
    public final static Message newInstance(final String _performative, final Address _sender, final Address _receiver) {
        final Message retVal = newInstance();
        retVal._Performative = _performative;
        if (_performative != null) {
            retVal._ContentInfo = HAS_PERFORMATIVE;
        }
        retVal._Sender = _sender;
        retVal._Receiver = _receiver;

        return retVal;
    }

    /**
     * Returns Message that has set attributes performative, sender and
     * receivers. The constructed message is multicast message if there are more receivers addressed to all
     * receivers from the _receivers collection.
     *
     * @param _performative String
     * @param _sender Address
     * @param _receivers Collection
     * @return Message
     */
    public final static Message newInstance(final String _performative, final Address _sender, final Collection<Address> _receivers) {
        final Message retVal = newInstance();
        retVal._Performative = _performative;
        if (_performative != null) {
            retVal._ContentInfo = HAS_PERFORMATIVE;
        }
        retVal._Sender = _sender;
        switch (_receivers.size()) {
            case 0: break;
            case 1:
                retVal._Receiver = _receivers.iterator().next();
                break;
            default:
                retVal._ContentInfo |= IS_MULTICAST;
                retVal._Receivers = freeArrayListAddress.pop();
                if (retVal._Receivers == null) {
                    retVal._Receivers = new ArrayList<Address>(_receivers);
                } else {
                    retVal._Receivers.addAll(_receivers);
                }
                break;
        }
        return retVal;
    }

    /**
     * Message constructor with setting of performative attribute.
     *
     * @param _performative String
     * @return Message
     */
    public final static Message newInstance(final String _performative) {
        final Message retVal = newInstance();
        retVal._Performative = _performative;
        return retVal;
    }

    /**
     * Do not call this method. It is used internally to count number of current message
     * holders.
     */
    @Override
	public final void registerHolder() {
        holders.incrementAndGet();
    }

    /**
     * Release object for the future use. If there is pooled object in the Message
     * it is released too.
     */
    @Override
	public final void release() {
        if (holders.decrementAndGet() != 0) {
            // only once put the message in the pool

            // if caller call release method more times it has no sense
            return;
        }

        if ((_ContentInfo & CONTENT_TYPE_MASK) == SHARED_OBJECT_CONTENT) {
            // release shared object
            ((PooledObject)_Content).release();
        }

        _ContentInfo = 0;
        _IsReply = false;
        if (_Receivers != null) {
            _Receivers.clear();
            freeArrayListAddress.push(_Receivers);
            _Receivers = null;
        }

        _Sender = null;
        _Receiver = null;

        _Performative = null;
        _Content = null;
        _Protocol = null;
        _Ontology = null;
        _ConversationID = null;
        _InReplyTo = null;
        _ReplyWith = null;
        _Reason = null;

        _VisibilityID = 0;
        
        _TransmitPower = Double.NaN;

        messageSize = -1;
        _AsReference = false;

        if (!freeMessages.push(this)) {
//            throwAway.incrementAndGet();
        } else {
//            releasedOK.incrementAndGet();
        }
    }

    /**
     * This method returns a reply message from the standard message. The replay has the same conversation
     * ID. For the multicast message use getReply(Address sender) method instead.
     * The constructed message is standard message addressed to one receiver.
     * @return reply message
     */
    public final Message getReply() {
        if ((_ContentInfo & IS_MULTICAST) != 0) {
            throw new RuntimeException("getReply() method is not supported for the multicast message. Use getReply(Address sender) instead.");
        }
        final Message m = newInstance();
        m._IsReply = true;
        m._ConversationID = this._ConversationID;
        if (m._ConversationID != null) {
            m._ContentInfo |= HAS_CONVERSATION_ID;
        }
        m._InReplyTo = this._ReplyWith;
        if (m._InReplyTo != null) {
            m._ContentInfo |= HAS_IN_REPLY_TO;
        }
        m._Receiver = this._Sender;
        m._Sender = this._Receiver;
        m._Protocol = this._Protocol;
        if (m._Protocol != null) {
            m._ContentInfo |= HAS_PROTOCOL;
        }
        m._VisibilityID = this._VisibilityID;
        if (m._VisibilityID < 0) {
            m._ContentInfo |= DO_NOT_SNIFF;
        }

        return m;
    }

    /**
     * This method returns a reply message.
     * The constructed message is standard message addressed to one receiver.
     * @param sender Address - sender address for the reply message
     * @return Message
     */
    public final Message getReply(final Address sender) {
        final Message m = newInstance();
        m._IsReply = true;
        m._ConversationID = this._ConversationID;
        if (m._ConversationID != null) {
            m._ContentInfo |= HAS_CONVERSATION_ID;
        }
        m._InReplyTo = this._ReplyWith;
        if (m._InReplyTo != null) {
            m._ContentInfo |= HAS_IN_REPLY_TO;
        }
        m._Receiver = this._Sender;
        m._Sender = sender;
        m._Protocol = this._Protocol;
        if (m._Protocol != null) {
            m._ContentInfo |= HAS_PROTOCOL;
        }
        m._VisibilityID = this._VisibilityID;
        if (m._VisibilityID < 0) {
            m._ContentInfo |= DO_NOT_SNIFF;
        }

        return m;
    }

    /**
     * Returns true if message is un-deliverable
     * @return
     */
    public final boolean isUndeliverable() {
        return (_ContentInfo & IS_UNDELIVERABLE) != 0;
    }

    /**
     * Set message as un-deliverable
     */
    public final void setUndeliverable() {
        _ContentInfo |= IS_UNDELIVERABLE;
    }

    /**
     * @internal
     * Returns true iff message size for this message is required
     * @return
     */
    public final boolean isMessageSizeRequired() {
        return (_ContentInfo & MESSAGE_SIZE_REQUIRED) != 0;
    }

    /**
     * Set message size required
     */
    public final void setMessageSizeRequired() {
        _ContentInfo |= MESSAGE_SIZE_REQUIRED;
    }

    /**
     * Test iff message is multicast (has more receivers).
     * @return boolean - true iff the message has more receivers
     */
    public final boolean isMulticast() {
        return (_ContentInfo & IS_MULTICAST) != 0;
    }

    /**
     * The method returns the address of the message sender.
     * @return address to sender
     */
    public final Address getSender() {
        return _Sender;
    }

    /**
     * This method sets the message sender.
     * @param _Sender Address
     */
    public final void setSender(final Address _Sender) {
        this._Sender = _Sender;
        messageSize = -1;
    }

    /**
     * The method sets the power which is used to transmit the message.
     * @param power
     */
    public void setPower(double power){
    	this._TransmitPower = power;
    }
    /**
     * The message returns the power which was used to transmit the message.
     * @return power used for message transmission
     */
    public double getPower(){
    	return _TransmitPower;
    }
    
    /**
     * The method returns the address of the message receiver for the standard message.
     * The method is not supported for the multicast message. In such case use
     * getReceivers() method instead.
     * @return address - receiver address
     */
    public final Address getReceiver() {
        if ((_ContentInfo & IS_MULTICAST) != 0) {
            throw new RuntimeException("The method is not supported for the multicast message. Use getReceivers() method instead.");
        }
        return _Receiver;
    }

    /**
     * The method returns collection of the message receivers. Do not make changes
     * in the collection ! The method is supported only for  the multicast message.
     * For the standard message use getReceiver() method instead.
     *
     * @return Collection - collection of all message receivers
     */
    public final Collection<Address> getReceivers() {
        if ((_ContentInfo & IS_MULTICAST) == 0) {
            throw new RuntimeException("The method is supported only for the multicast message. Use getReceiver() for the standard message.");
        }
        return _Receivers;
    }

    /**
     * This method sets the message receiver. The message is denoted to be
     * standard message to the one receiver only.
     *
     * @param _Receiver Address
     */
    public final void setReceiver(final Address _Receiver) {
        this._Receiver = _Receiver;
        this._ContentInfo = (short) (this._ContentInfo & (0x7fff^IS_MULTICAST));
        if (this._Receivers != null) {
            this._Receivers.clear();
            freeArrayListAddress.push(this._Receivers);
            this._Receivers = null;
        }
        messageSize = -1;
    }

    /**
     * This method sets the message receivers. The message is denoted to be
     * multicast message if there are more receivers addressed to all specified receivers in the collection.
     * @param _Receivers Collection
     */
    public final void setReceivers(final Collection<Address> _Receivers) {
        switch (_Receivers.size()) {
            case 0:
                this._ContentInfo = (short) (this._ContentInfo & (0x7fff^IS_MULTICAST));
                this._Receiver = null;
                if (this._Receivers != null) {
                    this._Receivers.clear();
                    freeArrayListAddress.push(this._Receivers);
                    this._Receivers = null;
                }
                break;
            case 1:
                this._ContentInfo = (short) (this._ContentInfo & (0x7fff^IS_MULTICAST));
                this._Receiver = _Receivers.iterator().next();
                if (this._Receivers != null) {
                    this._Receivers.clear();
                    freeArrayListAddress.push(this._Receivers);
                    this._Receivers = null;
                }
                break;
            default:
                this._ContentInfo |= IS_MULTICAST;
                this._Receiver = null;
                this._Receivers = freeArrayListAddress.pop();
                if (this._Receivers == null) {
                    this._Receivers = new ArrayList<Address>(_Receivers);
                } else {
                    this._Receivers.addAll(_Receivers);
                }
                break;
        }
        messageSize = -1;
    }

    /**
     * Add a receiver. The message is then denoted to be multicast message if there is already at least one receiver for the message
     * to all receivers. If the message was standard message before calling
     * this method, the previous receiver is added to the list of receivers.
     * @param _Receiver Address
     */
    public final void addReceiver(final Address _Receiver) {
        if (_Receiver == null) {
            throw new IllegalArgumentException("Cannot add null receiver");
        }
        messageSize = -1;
        if ((this._ContentInfo & IS_MULTICAST) == 0) {
            if (this._Receiver == null) {
                this._Receiver = _Receiver;
            } else {
                this._ContentInfo |= IS_MULTICAST;
                this._Receivers = freeArrayListAddress.pop();
                if (this._Receivers == null) {
                    this._Receivers = new ArrayList<Address>();
                }
                this._Receivers.add(this._Receiver);
                this._Receiver = null;
                this._Receivers.add(_Receiver);
            }
        } else {
            this._Receivers.add(_Receiver);
        }
    }

    /**
     * Remove all message receivers. After calling this method the message is denoted
     * to be standard message, but without any specified receiver.
     */
    public final void clearReceivers() {
        this._ContentInfo = (short) (this._ContentInfo & (0x7fff ^ IS_MULTICAST));
        if (this._Receivers != null) {
            this._Receivers.clear();
            freeArrayListAddress.push(this._Receivers);
            this._Receivers = null;
        }
        this._Receiver = null;
        messageSize = -1;
    }

    /**
     * The method returns performative of the message.
     * @return performative
     */
    public final String getPerformative() {
        return _Performative;
    }

    /**
     * The method sets performative of the message.
     * @param _Performative String
     */
    public final void setPerformative(final String _Performative) {
        this._Performative = _Performative;
        if ((_ContentInfo & HAS_PERFORMATIVE) != ((_Performative != null)?HAS_PERFORMATIVE:0)) {
            _ContentInfo ^= HAS_PERFORMATIVE;
        }
        messageSize = -1;
    }

    /**
     * The method returns content of the message.
     * @return content
     */
    public final Object getContent() {
        return _Content;
    }

    /**
     * The method sets content of the message. If the content is PooledObject
     * the message registers as a holder automatically. The holder is released
     * if the message is released itself completely or other content is set.
     *
     * @param _Content Object
     */
    public final void setContent(final Object _Content) {
        messageSize = -1;
        this._Content = _Content;
        if ((_ContentInfo & CONTENT_TYPE_MASK) == SHARED_OBJECT_CONTENT) {
            // release previous shared object
            ((PooledObject)_Content).release();
        }
        _ContentInfo = (short) (_ContentInfo & (0x7fff^CONTENT_TYPE_MASK));
        if (_Content != null) {
            if (_Content instanceof String) {
                _ContentInfo |= STRING_CONTENT;
            } else if (_Content instanceof byte[]) {
                _ContentInfo |= BYTE_ARRAY_CONTENT;
            } else if (_Content instanceof String[]) {
                _ContentInfo |= STRING_ARRAY_CONTENT;
            } else if (_Content instanceof PooledObject) {
                _ContentInfo |= SHARED_OBJECT_CONTENT;
                ((PooledObject)_Content).registerHolder();
            } else if (_Content instanceof Externalizable) {
                _ContentInfo |= EXTERNALIZABLE_CONTENT;
            } else if (_Content instanceof Serializable) {
                _ContentInfo |= OTHER_SERIALIZED_CONTENT;
            } else {
                throw new RuntimeException("Content type: "+_Content.getClass().getName()+" is not allowed to be content of the A-globe message.");
            }
            _Ontology = _Content.getClass().getName();
        } else {
            _Ontology = null;
        }
    }

    /**
     * The method returns protocol of the message.
     * @return protocol
     */
    public final String getProtocol() {
        return _Protocol;
    }

    /**
     * The method set Protocol of the message.
     * @param _Protocol String
     */
    public final void setProtocol(final String _Protocol) {
        this._Protocol = _Protocol;
        if ((_ContentInfo & HAS_PROTOCOL) != ((_Protocol != null)?HAS_PROTOCOL:0)) {
            _ContentInfo ^= HAS_PROTOCOL;
        }
        messageSize = -1;
    }

    /**
     * The method returns ontology of the message.
     * @return ontology
     */
    public final String getOntology() {
        return _Ontology;
    }

    /**
     * The method returns conversation ID of the message.
     * @return conversation ID
     */
    public final String getConversationID() {
        return _ConversationID;
    }


    /**
     * The method sets conversation ID of the message.
     * @param _ConversationID String
     */
    public final void setConversationID(final String _ConversationID) {
        this._ConversationID = _ConversationID;
        if ((_ContentInfo & HAS_CONVERSATION_ID) != ((_ConversationID != null)?HAS_CONVERSATION_ID:0)) {
            _ContentInfo ^= HAS_CONVERSATION_ID;
        }
        messageSize = -1;
    }

    /**
     * The method returns InReplyTo message attribute.
     * @return String
     */
    public final String getInReplyTo() {
        return _InReplyTo;
    }

    /**
     * The method sets InReplyTo message attribute.
     * @param _InReplyTo String
     */
    public final void setInReplyTo(final String _InReplyTo) {
        this._InReplyTo = _InReplyTo;
        if ((_ContentInfo & HAS_IN_REPLY_TO) != ((_InReplyTo != null)?HAS_IN_REPLY_TO:0)) {
            _ContentInfo ^= HAS_IN_REPLY_TO;
        }
        messageSize = -1;
    }

    /**
     * The method returns ReplyWith message attribute.
     * @return String
     */
    public final String getReplyWith() {
        return _ReplyWith;
    }

    /**
     * The method sets ReplyWith message attribute.
     * @param _ReplyWith String
     */
    public final void setReplyWith(final String _ReplyWith) {
        this._ReplyWith = _ReplyWith;
        if ((_ContentInfo & HAS_REPLY_WITH) != ((_ReplyWith != null)?HAS_REPLY_WITH:0)) {
            _ContentInfo ^= HAS_REPLY_WITH;
        }
        messageSize = -1;
    }

    /**
     * The method returns message reason.
     * @return reason
     */
    public final String getReason() {
        return _Reason;
    }

    /**
     * The method sets message reason.
     * @param _Reason String
     */
    public final void setReason(final String _Reason) {
        this._Reason = _Reason;
        if ((_ContentInfo & HAS_REASON) != ((_Reason != null)?HAS_REASON:0)) {
            _ContentInfo ^= HAS_REASON;
        }
        messageSize = -1;
    }

    /**
     * This method can be called only from the Message Transport layer. DON'T use
     * it from Agent/Service.
     *
     * @param visibilityID long
     */
    public final void setVisibilityID(final long visibilityID) {
        this._VisibilityID = visibilityID;
        if (visibilityID < 0) {
            _ContentInfo |= DO_NOT_SNIFF;
        } else {
            _ContentInfo &= (0x7fff^DO_NOT_SNIFF);
        }
    }

    /**
     * The methods returns true if it is a reply message.
     * @return boolean
     */
    public final boolean getIsReply() {
        return _IsReply;
    }

    /**
     * The method return visibility ID
     *
     * @return long
     */
    public final long getVisibilityID() {
        return _VisibilityID;
    }

    /**
     * Test if message can be sniffed. The system service messages used for
     * sending communication info and message copy cannot be sniffed again to
     * avoid infinite loop.
     * @return boolean - true if the message is system service message
     */
    public final boolean getDoNotSniff() {
        return ((_ContentInfo & DO_NOT_SNIFF) != 0);
    }

    /**
     * Get message size. This method can be called only after sending the message and if the message size
     * was requested by setMessageSize() method
     * @return int - returns message size.
     */
    public final int getMessageSize() {
        if (!isMessageSizeRequired()) {
            throw new IllegalAccessError("Message size wasn't required");
        }

        if (messageSize < 0) {
            throw new IllegalAccessError("Message size is not filled yet. Maybe you don't call this methods after sending message");
        }
        return messageSize;
    }

    /**
     * @internal
     * Internal AGLOBE method
     *
     * @param messageSize
     * @return
     */
    public final void setMessageSize(final int messageSize) {
        this.messageSize = messageSize;
    }

    /**
     * The method compares two messages.
     * @param ob Object - message to which is this message compared
     * @return boolean - returns true iff messages have same content
     */
    @Override
    public final boolean equals(Object ob) {
        if (this == ob) {
            return true;
        }
        if (!(ob instanceof Message)) {
            return false;
        }
        final Message tob = ((Message) ob);
        if (_Sender != null) {
            if (tob._Sender == null) {
                return false;
            }
            if (!_Sender.equals(tob._Sender)) {
                return false;
            }
        } else {
            if (tob._Sender != null) {
                return false;
            }
        }
        if ((_ContentInfo & IS_MULTICAST) != (tob._ContentInfo & IS_MULTICAST)) {
            return false;
        }
        if ((_ContentInfo & IS_MULTICAST) != 0) {
            if (_Receivers != null) {
                if (tob._Receivers == null) {
                    return false;
                }
                if (!_Receivers.equals(tob._Receivers)) {
                    return false;
                }
            } else {
                if (tob._Receivers != null) {
                    return false;
                }
            }
        } else {
            if (_Receiver != null) {
                if (tob._Receiver == null) {
                    return false;
                }
                if (!_Receiver.equals(tob._Receiver)) {
                    return false;
                }
            } else {
                if (tob._Receiver != null) {
                    return false;
                }
            }
        }
        if (_Performative != null) {
            if (tob._Performative == null) {
                return false;
            }
            if (!_Performative.equals(tob._Performative)) {
                return false;
            }
        } else {
            if (tob._Performative != null) {
                return false;
            }
        }
        if (getContent() != null) {
            if (tob.getContent() == null) {
                return false;
            }
            if (!getContent().equals(tob.getContent())) {
                return false;
            }
        } else {
            if (tob.getContent() != null) {
                return false;
            }
        }
        if (_Protocol != null) {
            if (tob._Protocol == null) {
                return false;
            }
            if (!_Protocol.equals(tob._Protocol)) {
                return false;
            }
        } else {
            if (tob._Protocol != null) {
                return false;
            }
        }
        if (_Ontology != null) {
            if (tob._Ontology == null) {
                return false;
            }
            if (!_Ontology.equals(tob._Ontology)) {
                return false;
            }
        } else {
            if (tob._Ontology != null) {
                return false;
            }
        }
        if (_ConversationID != null) {
            if (tob._ConversationID == null) {
                return false;
            }
            if (!_ConversationID.equals(tob._ConversationID)) {
                return false;
            }
        } else {
            if (tob._ConversationID != null) {
                return false;
            }
        }
        if (_InReplyTo != null) {
            if (tob._InReplyTo == null) {
                return false;
            }
            if (!_InReplyTo.equals(tob._InReplyTo)) {
                return false;
            }
        } else {
            if (tob._InReplyTo != null) {
                return false;
            }
        }
        if (_ReplyWith != null) {
            if (tob._ReplyWith == null) {
                return false;
            }
            if (!_ReplyWith.equals(tob._ReplyWith)) {
                return false;
            }
        } else {
            if (tob._ReplyWith != null) {
                return false;
            }
        }
        if (_Reason != null) {
            if (tob._Reason == null) {
                return false;
            }
            if (!_Reason.equals(tob._Reason)) {
                return false;
            }
        } else {
            if (tob._Reason != null) {
                return false;
            }
        }
        if (_VisibilityID != tob._VisibilityID) {
            return false;
        }
        if ((_ContentInfo & DO_NOT_SNIFF) != (tob._ContentInfo & DO_NOT_SNIFF)) {
            return false;
        }
        return true;
    }


    /**
     * The method returns hash of the message.
     * @return int
     */
    @Override
    public final int hashCode() {
        int h = 0;
        h = ((127 * h) + ((_Sender != null) ? _Sender.hashCode() : 0));
        if ((_ContentInfo & IS_MULTICAST) != 0) {
            h = ((127 * h) + 1231);
            h = ((127 * h) + ((_Receivers != null) ? _Receivers.hashCode() : 0));
        } else {
            h = ((127 * h) + 1237);
            h = ((127 * h) + ((_Receiver != null) ? _Receiver.hashCode() : 0));
        }
        h = ((127 * h) + ((_Performative != null) ? _Performative.hashCode() : 0));
        h = ((127 * h) + ((getContent() != null) ? getContent().hashCode() : 0));
        h = ((127 * h) + ((_Protocol != null) ? _Protocol.hashCode() : 0));
        h = ((127 * h) + ((_Ontology != null) ? _Ontology.hashCode() : 0));
        h = ((127 * h) + ((_ConversationID != null) ? _ConversationID.hashCode() : 0));
        h = ((127 * h) + ((_InReplyTo != null) ? _InReplyTo.hashCode() : 0));
        h = ((127 * h) + ((_ReplyWith != null) ? _ReplyWith.hashCode() : 0));
        h = ((127 * h) + ((_Reason != null) ? _Reason.hashCode() : 0));
        h = ((127 * h) + ((int) _VisibilityID));
        h = ((127 * h) + (((_ContentInfo & DO_NOT_SNIFF) != 0) ? 1231:1237));
        return h;
    }

    /**
     * The method converts the message into readable string.
     * @return String
     */
    @Override
    public final String toString() {
        final StringBuffer sb = new StringBuffer("<<Message");
        sb.append(((_ContentInfo & IS_MULTICAST)!=0)?" Multicast":" Standard");
        if (_Sender != null) {
            sb.append(" Sender=");
            sb.append(_Sender.toString());
        }
        if ((_ContentInfo & IS_MULTICAST) != 0) {
            if (_Receivers != null) {
                for (Address elem : _Receivers) {
                    sb.append(" Receiver=");
                    sb.append(elem.toString());
                }
            }
        } else {
            if (_Receiver != null) {
                sb.append(" Receiver=");
                sb.append(_Receiver.toString());
            }
        }
        if (_Performative != null) {
            sb.append(" Performative=");
            sb.append(_Performative);
        }
        if (_Content != null) {
            sb.append(" Content=");
            sb.append(AglobeXMLtools.printObject(_Content));
        }
        if (_Protocol != null) {
            sb.append(" Protocol=");
            sb.append(_Protocol);
        }
        if (_Ontology != null) {
            sb.append(" Ontology=");
            sb.append(_Ontology);
        }
        if (_ConversationID != null) {
            sb.append(" ConversationID=");
            sb.append(_ConversationID);
        }
        if (_InReplyTo != null) {
            sb.append(" InReplyTo=");
            sb.append(_InReplyTo);
        }
        if (_ReplyWith != null) {
            sb.append(" ReplyWith=");
            sb.append(_ReplyWith);
        }
        if (_Reason != null) {
            sb.append(" Reason=");
            sb.append(_Reason);
        }
        sb.append(" VisibilityID=");
        sb.append(Long.toString(_VisibilityID));
        if ((_ContentInfo & DO_NOT_SNIFF) != 0) {
            sb.append(" DoNotSniff");
        }
        sb.append(">>");
        return sb.toString();
    }

    /**
     * This method clone the message in the standard way (copy references instead of cloning variables).
     * @return Object
     */
    @Override
    public final Object clone() {
        final Message m = newInstance();

        m._ContentInfo = this._ContentInfo;
        if (this._Receivers != null) {
            m._Receivers = freeArrayListAddress.pop();
            if (m._Receivers == null) {
                m._Receivers = new ArrayList<Address>(this._Receivers);
            } else {
                m._Receivers.addAll(this._Receivers);
            }
        }
        if (this._Receivers != null) {
            m._Receivers = freeArrayListAddress.pop();
            if (m._Receivers == null) {
                m._Receivers = new ArrayList<Address>(this._Receivers);
            } else {
                m._Receivers.addAll(this._Receivers);
            }
        }
        m._IsReply = this._IsReply;
        m._Sender = this._Sender;
        m._Receiver = this._Receiver;
        m._Performative = this._Performative;
        m._Protocol = this._Protocol;
        m._Ontology = this._Ontology;
        m._ConversationID = this._ConversationID;
        m._InReplyTo = this._InReplyTo;
        m._ReplyWith = this._ReplyWith;
        m._Reason = this._Reason;
        m._VisibilityID = this._VisibilityID;

        m._Content = this._Content;

        return m;
    }

    /**
     * The method serializes message to <code>outputStream</code>
     * @param _out OutputStream
     * @throws IOException - throws exception if there is some problem during serialization of the message
     */
    public final void serialize(final OutputStream _out, final AddressWriter addressWriter) throws IOException {
        final ObjectOutputStream out = new MessageObjectOutputStream(_out, addressWriter);
        this.writeExternal(out);
        out.close();
    }

    /**
     * The method deserializes message from <code>InputStream</code>
     *
     * @param _in InputStream - input stream from where message is deserialized
     * @param context ClassLoaderOwner - context in which message should be deserialized
     * @throws ClassNotFoundException - throws if some class is not found during
     *   deserialization
     * @throws IOException - throws exception if there is some problem during
     *   deserialization of the message
     * @return Message - deserialized message
     */
    public final static Message deserialize(final InputStream _in, final MessageReceiver context, final AddressReader addressReader) throws ClassNotFoundException, IOException {
        final ObjectInputStream in = new LibraryObjectInputStream(_in, context, addressReader);
        final Message m = newInstance();
        m.readExternal(in);
        return m;
    }


    /**
     * Used for externalization of the message
     * @param in ObjectInput
     * @throws IOException
     * @throws ClassNotFoundException
     */
    @Override
	public final void readExternal(final ObjectInput in) throws IOException,
            ClassNotFoundException {
        _VisibilityID = in.readLong();
        _ContentInfo = in.readShort();

        final AddressReader ar;
        if (in instanceof LibraryObjectInputStream) {
            ar = ((LibraryObjectInputStream)in).addressReader;
        } else {
            ar = null;
        }
        if (ar != null) {
            if ((_ContentInfo & IS_MULTICAST) != 0) {
                int cnt = in.readShort();
                _Receivers = freeArrayListAddress.pop();
                if (_Receivers == null) {
                    _Receivers = new ArrayList<Address>(cnt);
                }
                while (cnt>0) {
                    _Receivers.add(ar.readAddress(in.readShort()));
                    cnt--;
                }
            } else {
                _Receiver = ar.readAddress(in.readShort());
            }
            _Sender = ar.readAddress(in.readShort());
        } else {
            if ((_ContentInfo & IS_MULTICAST) != 0) {
                int cnt = in.readShort();
                _Receivers = freeArrayListAddress.pop();
                if (_Receivers == null) {
                    _Receivers = new ArrayList<Address>(cnt);
                }
                while (cnt>0) {
                    final Address adr = Address.getAddress(in.readLong());
                    if (adr == null) {
                        throw new RuntimeException("Required address not found");
                    }
                    _Receivers.add(adr);
                    cnt--;
                }
            } else {
                _Receiver = Address.getAddress(in.readLong());
                if (_Receiver == null) {
                    throw new RuntimeException("Required address not found");
                }
            }
            _Sender = Address.getAddress(in.readLong());
            if (_Sender == null) {
                throw new RuntimeException("Required address not found");
            }
        }

        if ((_ContentInfo & HAS_PERFORMATIVE) != 0) {
            _Performative = ConversionTools.readString(in);
            if (_Performative.startsWith("LOAD_PERFORMANCE_RESPONSE")) {
                int j=10;
                j++;
            }
        }
        if ((_ContentInfo & HAS_PROTOCOL) != 0) {
            _Protocol = ConversionTools.readString(in);
        }
        if ((_ContentInfo & HAS_REASON) != 0) {
            _Reason = ConversionTools.readString(in);
        }
        if ((_ContentInfo & HAS_CONVERSATION_ID) != 0) {
            _ConversationID = ConversionTools.readString(in);
        }
        if ((_ContentInfo & HAS_IN_REPLY_TO) != 0) {
            _InReplyTo = ConversionTools.readString(in);
        }
        if ((_ContentInfo & HAS_REPLY_WITH) != 0) {
            _ReplyWith = ConversionTools.readString(in);
        }

        switch (_ContentInfo & CONTENT_TYPE_MASK) {
            case STRING_CONTENT:
                // read string content
                _Content = ConversionTools.readString(in);
                _Ontology = _Content.getClass().getName();
                break;
            case BYTE_ARRAY_CONTENT:
                // read byte array content
                _Content = ConversionTools.readByteArray(in);
                _Ontology = _Content.getClass().getName();
                break;
            case STRING_ARRAY_CONTENT:
                // read string array content
                _Content = ConversionTools.readStringArray(in);
                _Ontology = _Content.getClass().getName();
                break;
            case SHARED_OBJECT_CONTENT:
                _Ontology = ConversionTools.readString(in);
                final PooledObject so;
                try {
                    ClassLoader cl;
                    if (in instanceof LibraryObjectInputStream) {
                        cl = ((LibraryObjectInputStream) in).getClassLoader();
                    } else {
                        cl = getClass().getClassLoader();
                    }
                    final Class<?> c = cl.loadClass(_Ontology);
                    final Method newInstance = c.getMethod("getInstance");
                    so = (PooledObject) newInstance.invoke(null);
                    so.readExternal(in);
                    _Content = so;
                } catch (Exception ex1) {
                    final String report = ExceptionPrinter.toStringWithStackTrace(ex1);
                    Logger.getLogger("Message").severe(
                            "Cannot deserialize message content (ontology: "+_Ontology+"): " + report+"\n"+toString());
                    _Content = "Cannot deserialize message content (ontology: "+_Ontology+"): " + report;
                    _Ontology = String.class.getName();
                }
                break;
            case EXTERNALIZABLE_CONTENT:
                _Ontology = ConversionTools.readString(in);
                final Externalizable e;
                try {
                    final ClassLoader cl;
                    if (in instanceof LibraryObjectInputStream) {
                        cl = ((LibraryObjectInputStream) in).getClassLoader();
                    } else {
                        cl = getClass().getClassLoader();
                    }
                    final Class<?> c = cl.loadClass(_Ontology);
                    e = (Externalizable) c.newInstance();
                    e.readExternal(in);
                    _Content = e;
                } catch (Exception ex1) {
                    final String report = ExceptionPrinter.toStringWithStackTrace(ex1);
                    Logger.getLogger("Message").severe(
                            "Cannot deserialize message content ("+_Ontology+"): " + report+"\n"+toString());
                    _Content = "Cannot deserialize message content: " + report;
                    _Ontology = String.class.getName();
                }
                break;
            case OTHER_SERIALIZED_CONTENT:
                // read other serialized content
                try {
                    _Content = in.readObject();
                    _Ontology = _Content.getClass().getName();
                } catch (Exception ex) {
                    final String report = ExceptionPrinter.toStringWithStackTrace(ex);
                    Logger.getLogger("Message").severe(
                            "Cannot deserialize message content: " + report+"\n"+toString());
                    _Content = "Cannot deserialize message content: " + report;
                    _Ontology = String.class.getName();
                }
            default:
                // null content
        }

        _IsReply = false;
    }

    /**
     * Used for read externalized content of the message.
     * @param out ObjectOutput
     * @throws IOException
     */
    @Override
	public final void writeExternal(final ObjectOutput out) throws IOException {
        out.writeLong(_VisibilityID);
        out.writeShort(_ContentInfo);

        if (out instanceof MessageObjectOutputStream) {
            final AddressWriter aw = ((MessageObjectOutputStream)out).adderessWriter;
            if ((_ContentInfo & IS_MULTICAST) != 0) {
                out.writeShort(_Receivers.size());
                for (Address elem : _Receivers) {
                    out.writeShort(aw.writeAddress(elem));
                }
            } else {
                out.writeShort(aw.writeAddress(_Receiver));
            }
            out.writeShort(aw.writeAddress(_Sender));
        } else {
            if ((_ContentInfo & IS_MULTICAST) != 0) {
                out.writeShort(_Receivers.size());
                for (Address elem : _Receivers) {
                    out.writeLong(elem.getAddressId());
                }
            } else {
                out.writeLong(_Receiver.getAddressId());
            }
            out.writeLong(_Sender.getAddressId());
        }

        if (_Performative != null) {
            ConversionTools.writeString(out, _Performative);
        }
        if (_Protocol != null) {
            ConversionTools.writeString(out, _Protocol);
        }
        if (_Reason != null) {
            ConversionTools.writeString(out, _Reason);
        }
        if (_ConversationID != null) {
            ConversionTools.writeString(out, _ConversationID);
        }
        if (_InReplyTo != null) {
            ConversionTools.writeString(out, _InReplyTo);
        }
        if (_ReplyWith != null) {
            ConversionTools.writeString(out, _ReplyWith);
        }

        switch (_ContentInfo & CONTENT_TYPE_MASK) {
            case STRING_CONTENT:
                ConversionTools.writeString(out, (String) _Content);
                break;
            case BYTE_ARRAY_CONTENT:
                byte[] c = (byte[]) _Content;
                ConversionTools.writeByteArray(out, c);
                break;
            case STRING_ARRAY_CONTENT:
                String[] s = (String[]) _Content;
                ConversionTools.writeStringArray(out, s);
                break;
            case EXTERNALIZABLE_CONTENT:
            case SHARED_OBJECT_CONTENT:
                ConversionTools.writeString(out, _Ontology);
                final Externalizable e = (Externalizable) _Content;
                e.writeExternal(out);
                break;
            case OTHER_SERIALIZED_CONTENT:
                out.writeObject(_Content);
                break;
        }
    }

    /**
     * Not supported. Use externalizable instead this.
     * @param s ObjectOutputStream
     * @throws Exception
     */
    private final void writeObject(final ObjectOutputStream s) throws Exception {
        throw new Exception("Not supported");
    }

    /**
     * Not supported. Use externalizable instead this.
     * @param s ObjectInputStream
     * @throws Exception
     */
    private final void readObject(final ObjectInputStream s) throws Exception {
        throw new Exception("Not supported");
    }

    /**
     * Called by the garbage collector on an object when garbage collection determines that there are no more references to the object.
     *
     * @throws Throwable the <code>Exception</code> raised by this method
     */
//    protected void finalize() throws Throwable {
//        System.out.println("GC msg: "+_Performative+" protocol: "+_Protocol+" sender: "+_SenderAsString+" receiver: "+_ReceiverAsString);
//    }


}

