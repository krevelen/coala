
package aglobe.ontology;

import java.util.List;
import java.util.Iterator;
import java.io.IOException;
import java.io.ObjectOutput;
import java.util.*;
import java.io.ObjectInput;
import aglobe.container.transport.Address;
import aglobe.util.AglobeXMLtools;
import java.io.Externalizable;
import aglobe.util.ConversionTools;

/**
 * <p>Title: A-globe</p>
 *
 * <p>Description: Ontology describing new container for startup. User can use addAgent and addService methods
 * for simple use.</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Agent Technology Center, Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.11 $ $Date: 2010/08/04 11:48:05 $
 */
public class ContainerStartup implements Externalizable {

    /**
     * List of the agents to run
     */
    private AgentList _AgentList;

    /**
     * List of the services to run
     */
    private ServiceList _ServiceList;

    /**
     * Startup attributes
     */
    private List<String> _Attribute = new LinkedList<String>();

    /**
     * Library source container address
     */
    private Address _LibrarySourceContainer;

    /**
     * Gets agent list to run
     * @return AgentList
     */
    public AgentList getAgentList() {
        return _AgentList;
    }

    /**
     * Set agent list to run
     * @param _agentList AgentList
     */
    public void setAgentList(AgentList _agentList) {
        this._AgentList = _agentList;
    }

    /**
     * Gets service list to run
     * @return ServiceList
     */
    public ServiceList getServiceList() {
        return _ServiceList;
    }

    /**
     * Set service list to run
     * @param _serviceList ServiceList
     */
    public void setServiceList(ServiceList _serviceList) {
        this._ServiceList = _serviceList;
    }

    /**
     * Get startup attributes
     * @return List
     */
    public List<String> getAttribute() {
        return _Attribute;
    }

    /**
     * Get library source container address
     * @return Address
     */
    public Address getLibrarySourceContainer() {
        return _LibrarySourceContainer;
    }

    /**
     * Set library source container address
     * @param _librarySourceContainer Address
     */
    public void setLibrarySourceContainer(Address _librarySourceContainer) {
        this._LibrarySourceContainer = _librarySourceContainer;
    }

    /**
     * Tests if object equals to the ob object
     * @param ob Object
     * @return boolean - true iff equals
     */
    @Override
    public boolean equals(Object ob) {
        if (this == ob) {
            return true;
        }
        if (!(ob instanceof ContainerStartup)) {
            return false;
        }
        ContainerStartup tob = ((ContainerStartup) ob);
        if (_AgentList != null) {
            if (tob._AgentList == null) {
                return false;
            }
            if (!_AgentList.equals(tob._AgentList)) {
                return false;
            }
        } else {
            if (tob._AgentList != null) {
                return false;
            }
        }
        if (_ServiceList != null) {
            if (tob._ServiceList == null) {
                return false;
            }
            if (!_ServiceList.equals(tob._ServiceList)) {
                return false;
            }
        } else {
            if (tob._ServiceList != null) {
                return false;
            }
        }
        if (_Attribute != null) {
            if (tob._Attribute == null) {
                return false;
            }
            if (!_Attribute.equals(tob._Attribute)) {
                return false;
            }
        } else {
            if (tob._Attribute != null) {
                return false;
            }
        }
        if (_LibrarySourceContainer != null) {
            if (tob._LibrarySourceContainer == null) {
                return false;
            }
            if (!_LibrarySourceContainer.equals(tob._LibrarySourceContainer)) {
                return false;
            }
        } else {
            if (tob._LibrarySourceContainer != null) {
                return false;
            }
        }
        return true;
    }

    /**
     * Returns hash code of the object
     * @return int
     */
    @Override
    public int hashCode() {
        int h = 0;
        h = ((127 * h) + ((_AgentList != null) ? _AgentList.hashCode() : 0));
        h = ((127 * h) + ((_ServiceList != null) ? _ServiceList.hashCode() : 0));
        h = ((127 * h) + ((_Attribute != null) ? _Attribute.hashCode() : 0));
        h = ((127 * h) + ((_LibrarySourceContainer != null) ? _LibrarySourceContainer.hashCode() : 0));
        return h;
    }

    /**
     * Returns string representation of the object
     * @return String
     */
    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer("<<ContainerStartup");
        if (_AgentList != null) {
            sb.append(" AgentList=");
            sb.append(_AgentList.toString());
        }
        if (_ServiceList != null) {
            sb.append(" ServiceList=");
            sb.append(_ServiceList.toString());
        }
        if (_Attribute != null) {
            sb.append(" Attribute=");
            sb.append(_Attribute.toString());
        }
        if (_LibrarySourceContainer != null) {
            sb.append(" LibrarySourceContainer=");
            sb.append(_LibrarySourceContainer.toString());
        }
        sb.append(">>");
        return sb.toString();
    }

    /**
     * The object implements the writeExternal method to save its contents by
     * calling the methods of DataOutput for its primitive values or calling
     * the writeObject method of ObjectOutput for objects, strings, and
     * arrays.
     *
     * @param out the stream to write the object to
     * @throws IOException Includes any I/O exceptions that may occur
     */
    @Override
	public final void writeExternal(final ObjectOutput out) throws IOException {
        if (_AgentList != null) {
            out.writeBoolean(true);
            out.writeObject(_AgentList);
        } else {
            out.writeBoolean(false);
        }
        if (_ServiceList != null) {
            out.writeBoolean(true);
            out.writeObject(_ServiceList);
        } else {
            out.writeBoolean(false);
        }
        out.writeInt(_Attribute.size());
        for (Iterator<String> iter = _Attribute.iterator(); iter.hasNext(); ) {
            String item = iter.next();
            ConversionTools.writeString(out, item);
        }
        if (_LibrarySourceContainer != null) {
            out.writeBoolean(true);
            _LibrarySourceContainer.serialize(out);
        } else {
            out.writeBoolean(false);
        }
    }


    /**
     * The object implements the readExternal method to restore its contents
     * by calling the methods of DataInput for primitive types and readObject
     * for objects, strings and arrays.
     *
     * @param in the stream to read data from in order to restore the object
     * @throws IOException if I/O errors occur
     * @throws ClassNotFoundException If the class for an object being
     *   restored cannot be found.
     */
    @Override
	public final void readExternal(final ObjectInput in) throws IOException,
            ClassNotFoundException {
        if (in.readBoolean()) {
            _AgentList = (AgentList)in.readObject();
        }
        if (in.readBoolean()) {
            _ServiceList = (ServiceList)in.readObject();
        }
        int count = in.readInt();
        for (int i = 0; i < count; i++) {
            _Attribute.add(ConversionTools.readString(in));
        }
        if (in.readBoolean()) {
            _LibrarySourceContainer = Address.deserialize(in);
        }
    }

    /**
     * Add agent to the agents list
     *
     * @param name String
     * @param mainClass String
     * @param libraries List - can be null
     * @param params LinkedHashMap - can be null
     */
    public void addAgent(String name, String mainClass, List<String> libraries, LinkedHashMap<String, String> params) {
        AgentInfo ai = new AgentInfo();
        ai.setName(name);
        ai.setReadableName(name);
        ai.setMainClass(mainClass);
        Libraries lib = new Libraries();
        ai.setLibraries(lib);
        if (libraries != null) {
            for (String elem : libraries) {
                lib.getLibrary().add(elem);
            }
        }
        if (params != null) {
            List<AglobeParam> ap = ai.getAglobeParam();
            for (Map.Entry<String, String> elem : params.entrySet()) {
                ap.add(AglobeXMLtools.makeAglobeParam(elem.getKey(), elem.getValue()));
            }
        }
        if (_AgentList == null) {
            _AgentList = new AgentList();
        }
        _AgentList.getAgentInfo().add(ai);
    }

    /**
     * Add service to the Services.
     * @param name String
     * @param mainClass String
     * @param libraries List - can be null
     */
    public void addService(String name, String mainClass, List<String> libraries) {
        ServiceInfo si = new ServiceInfo();
        si.setName(name);
        si.setMainClass(mainClass);
        Libraries lib = new Libraries();
        si.setLibraries(lib);
        if (libraries != null) {
            for (String elem : libraries) {
                lib.getLibrary().add(elem);
            }
        }
        if (_ServiceList == null) {
            _ServiceList = new ServiceList();
        }
        _ServiceList.getServiceInfo().add(si);
    }

}
