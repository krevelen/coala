package aglobe.ontology;

/**
 *
 * <p>Title: A-Globe</p>
 * <p>Description: String constants used in messages are defined here (such as protocols, performatives, etc.).</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.15 $ $Date: 2008/11/23 09:14:11 $
 *
 */
public interface MessageConstants
{
    /**
     * FIPA inform predicate
     */
    public final static String INFORM = "INFORM";

    /**
     * FIPA inform-T/F predicate
     */
    public final static String INFORM_TF = "INFORM-T/F";

    /**
     * FIPA inform-done predicate
     */
    public final static String INFORM_DONE = "INFORM-DONE";

    /**
     * FIPA inform-result predicate
     */
    public final static String INFORM_RESULT = "INFORM-RESULT";

    /**
     * FIPA subscribe predicate
     */
    public final static String SUBSCRIBE = "SUBSCRIBE";

    /**
     * FIPA request predicate
     */
    public final static String REQUEST = "REQUEST";

    /**
     * FIPA agree predicate
     */
    public final static String AGREE = "AGREE";

    /**
     * FIPA not-understood predicate
     */
    public final static String NOT_UNDERSTOOD = "NOT-UNDERSTOOD";

    /**
     * FIPA done predicate
     */
    public final static String DONE = "DONE";

    /**
     * FIPA failure predicate
     */
    public final static String FAILURE = "FAILURE";

    /**
     * FIPA refuse predicate
     */
    public final static String REFUSE = "REFUSE";

    /**
     * FIPA query predicate
     */
    public final static String QUERY = "QUERY";

    /**
     * FIPA query-ref predicate
     */
    public final static String QUERY_REF = "QUERY-REF";

    /**
     * FIPA query-if predicate
     */
    public final static String QUERY_IF = "QUERY-IF";

    /**
     * FIPA cfp predicate
     */
    public final static String CFP = "CFP";

    /**
     * FIPA proposal predicate
     */
    public final static String PROPOSAL = "PROPOSAL";

    /**
     * FIPA accept-proposal predicate
     */
    public final static String ACCEPT_PROPOSAL = "ACCEPT-PROPOSAL";

    /**
     * FIPA reject-proposal predicate
     */
    public final static String REJECT_PROPOSAL = "REJECT-PROPOSAL";

    /**
     * FIPA cancel predicate
     */
    public final static String CANCEL = "CANCEL";

    /**
     * FIPA Contract-net
     */
    public final static String CONTRACT_NET = "CONTRACT-NET";

    /**
     * FIPA cancel-meta-protocol
     */
    public final static String CANCEL_META_PROTOCOL = "CANCEL_META_PROTOCOL";
}
