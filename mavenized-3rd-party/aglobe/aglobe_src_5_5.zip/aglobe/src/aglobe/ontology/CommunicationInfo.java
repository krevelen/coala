
package aglobe.ontology;

import aglobe.container.library.LibraryObjectInputStream;
import aglobe.container.transport.Address;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.ObjectInput;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import aglobe.platform.transport.AddressReader;
import aglobe.platform.transport.AddressWriter;
import aglobe.platform.transport.MessageObjectOutputStream;
import aglobe.util.ConversionTools;
import aglobe.util.Logger;
import aglobe.util.concurrent.NonblockingPoolArrayFIFO;

/**
 *
 * <p>Title: A-Globe</p>
 *
 * <p>Description: Communication info object is used for passing information about
 * communication by the standard message in the TOPIC_COMMUNICATION_INFO topic.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.16 $ $Date: 2010/08/04 11:48:05 $
 */
@SuppressWarnings("unused")
public final class CommunicationInfo implements PooledObject {
    /**
     * pool of the objects
     */
    private final static NonblockingPoolArrayFIFO<CommunicationInfo> pool = new NonblockingPoolArrayFIFO<CommunicationInfo>(1<<13);

    /**
     * Number of current holders
     */
    private final AtomicInteger holders = new AtomicInteger(1);

//    private final static AtomicInteger newInstances = new AtomicInteger(0);
//    private final static AtomicInteger releasedObjects = new AtomicInteger(0);
//    private final static ConcurrentHashMap<CommunicationInfo, CommunicationInfo> nonReleasedObjects = new ConcurrentHashMap<CommunicationInfo, CommunicationInfo>();

//    private StringBuilder holderDebug;
//    private void stackTraceToString(String prefix) {
//        final Exception e = new Exception();
//        final StackTraceElement[] stack = e.getStackTrace();
//        int skip = 2;
//        synchronized (holderDebug) {
//            holderDebug.append(prefix);
//            holderDebug.append(" (holders = ").append(holders.get()).append("):\n");
//            for (StackTraceElement elem: stack) {
//                if (skip-- > 0) {
//                    continue;
//                }
//                holderDebug.append(elem);
//                holderDebug.append("\n");
//            }
//            holderDebug.append("\n");
//        }
//    }

    /**
     * Communication from container address
     */
    private Address _From;

    /**
     * Destination of to container communication
     */
    private Address _To;

    /**
     * Message transmission length in Bytes.
     */
    private int _DataLength;

    private CommunicationInfo() {

    }

    public final static CommunicationInfo getInstance() {
        CommunicationInfo retVal = pool.pop();
        if (retVal == null) {
            retVal = new CommunicationInfo();
//            final int newInst = newInstances.incrementAndGet();
//            if (newInst % 10 == 0) {
//                Logger.logWarning("New Instances Cnt: "+newInst+" Cache size: "+pool.size()+" Released: "+releasedObjects.get());
////                Logger.logWarning("First non-released object:\n"+(nonReleasedObjects.keys().nextElement().holderDebug.toString()));
//            }
        } else {
            retVal.holders.set(1);
        }
//        retVal.holderDebug = new StringBuilder();
//        retVal.stackTraceToString("Creation");
//        nonReleasedObjects.put(retVal, retVal);
        return retVal;
    }

    /* (non-Javadoc)
     * @see aglobe.ontology.PooledObject#registerHolder()
     */
    @Override
    public final void registerHolder() {
        holders.incrementAndGet();
//        stackTraceToString("Register holder");
    }

    /* (non-Javadoc)
     * @see aglobe.ontology.PooledObject#release()
     */
    @Override
    public final void release() {
        final int hold = holders.decrementAndGet();
//        stackTraceToString("Release holder");
        if (hold > 0) {
            return;
        }
        if (hold < 0) {
            throw new RuntimeException("Holders is under 0 !!!");
//            throw new RuntimeException("Holders is under 0 !!! Log:\n"+holderDebug.toString()+"\n End of log \n");
        }
        pool.push(this);
//        releasedObjects.incrementAndGet();
//        nonReleasedObjects.remove(this);
    }

    public static CommunicationInfo getInstance(final Address from, final Address to, final int dataLength) {
        final CommunicationInfo retVal = getInstance();
        retVal._From = from;
        retVal._To = to;
        retVal._DataLength = dataLength;
        return retVal;
    }


    /**
     * Gets source container address of the communication
     * @return Address
     */
    public final Address getFrom() {
        return _From;
    }

    /**
     * Get destination container of the communication
     * @return Address
     */
    public final Address getTo() {
        return _To;
    }

    /**
     * Get underlying message transmission length in Bytes.
     * @return int
     */
    public final int getDataLength() {
        return _DataLength;
    }

    /**
     * Tests if object equals to the ob object
     * @param ob Object
     * @return boolean
     */
    @Override
    public final boolean equals(final Object ob) {
        if (this == ob) {
            return true;
        }
        if (!(ob instanceof CommunicationInfo)) {
            return false;
        }
        final CommunicationInfo tob = ((CommunicationInfo) ob);
        if (_From != null) {
            if (tob._From == null) {
                return false;
            }
            if (!_From.equals(tob._From)) {
                return false;
            }
        } else {
            if (tob._From != null) {
                return false;
            }
        }
        if (_To != null) {
            if (tob._To == null) {
                return false;
            }
            if (!_To.equals(tob._To)) {
                return false;
            }
        } else {
            if (tob._To != null) {
                return false;
            }
        }
        if (_DataLength != tob._DataLength) {
            return false;
        }
        return true;
    }

    /**
     * Returns hash code of the object
     * @return int
     */
    @Override
    public final int hashCode() {
        int h = 0;
        h = ((127 * h) + ((_From != null) ? _From.hashCode() : 0));
        h = ((127 * h) + ((_To != null) ? _To.hashCode() : 0));
        h = ((31 * h) + _DataLength);
        return h;
    }

    /**
     * Returns string representation of the object
     * @return String
     */
    @Override
    public final String toString() {
        final StringBuffer sb = new StringBuffer("<<CommunicationInfo");
        if (_From != null) {
            sb.append(" From=");
            sb.append(_From.toString());
        }
        if (_To != null) {
            sb.append(" To=");
            sb.append(_To.toString());
        }
        sb.append(" DataLength=");
        sb.append(Integer.toString(_DataLength));
        sb.append(">>");
        return sb.toString();
    }

    /**
     * Used for externalization of the object to the output stream
     * @param out ObjectOutput
     * @throws IOException
     */
    @Override
	public final void writeExternal(final ObjectOutput out) throws IOException {
        if (out instanceof MessageObjectOutputStream) {
            final AddressWriter aw = ((MessageObjectOutputStream)out).adderessWriter;
            out.writeShort(aw.writeAddress(_From));
            out.writeShort(aw.writeAddress(_To));
        } else {
            out.writeLong(_From.getAddressId());
            out.writeLong(_To.getAddressId());
        }
        out.writeInt(_DataLength);
    }

    /**
     * Used for the reading of the object content from the input stream
     * @param in ObjectInput
     * @throws ClassNotFoundException
     * @throws IOException
     */
    @Override
	public final void readExternal(final ObjectInput in) throws ClassNotFoundException,
            IOException {
        if (in instanceof LibraryObjectInputStream) {
            final AddressReader ar = ((LibraryObjectInputStream)in).addressReader;
            _From = ar.readAddress(in.readShort());
            _To = ar.readAddress(in.readShort());
        } else {
            _From = Address.getAddress(in.readLong());
            _To = Address.getAddress(in.readLong());
        }
        _DataLength = in.readInt();
    }

}
