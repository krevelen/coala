/**
 *
 */
package aglobe.ontology;

import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.concurrent.atomic.AtomicInteger;

import aglobe.util.concurrent.NonblockingPoolArrayFIFO;

/**
 * <p>Title: A-globe</p>
 *
 * <p>Description: This class is here to provide support to send properly externalizable objects which contains
 * references to objects having reference back to the root externalizable object. The method itself implements
 * PooledObject interface and thus holder counts should be handled properly.</p>
 *
 * <p>Copyright: Copyright (c) 2009</p>
 *
 * <p>Company: Agent Technology Center</p>
 *
 * @author David Sislak
 * @version $Revision: 1.1 $ $Date: 2009/03/16 08:51:04 $
 *
 */
public final class ExternalizableToSerializableEnvelope implements PooledObject {
    private static final NonblockingPoolArrayFIFO<ExternalizableToSerializableEnvelope> pool = new NonblockingPoolArrayFIFO<ExternalizableToSerializableEnvelope>(1025);

    private final AtomicInteger holders = new AtomicInteger(1);

    private Object content;

    private ExternalizableToSerializableEnvelope() {

    }

    /**
     * Do not used this method, it is supposed to be used only during externalization
     * @return
     */
    public final static ExternalizableToSerializableEnvelope getInstance() {
        ExternalizableToSerializableEnvelope retVal = pool.pop();
        if (retVal == null) {
            retVal = new ExternalizableToSerializableEnvelope();
        } else {
            retVal.holders.set(1);
        }
        return retVal;
    }

    /**
     * Returns content
     * @param content
     * @return
     */
    public final static ExternalizableToSerializableEnvelope getInstance(final Object content) {
        final ExternalizableToSerializableEnvelope retVal = getInstance();
        retVal.content = content;
        return retVal;
    }

    /* (non-Javadoc)
     * @see aglobe.ontology.PooledObject#registerHolder()
     */
    @Override
    public final void registerHolder() {
        holders.incrementAndGet();
    }

    /* (non-Javadoc)
     * @see aglobe.ontology.PooledObject#release()
     */
    @Override
    public final void release() {
        final int hold = holders.decrementAndGet();
        if (hold > 0) {
            return;
        }
        if (hold < 0) {
            throw new RuntimeException("Holders is under 0 !!!");
        }
        content = null;
        pool.push(this);
    }

    public final Object getContent() {
        return content;
    }

    /* (non-Javadoc)
     * @see java.io.Externalizable#readExternal(java.io.ObjectInput)
     */
    @Override
    public final void readExternal(final ObjectInput in) throws IOException, ClassNotFoundException {
        content = in.readObject();
    }

    /* (non-Javadoc)
     * @see java.io.Externalizable#writeExternal(java.io.ObjectOutput)
     */
    @Override
    public final void writeExternal(final ObjectOutput out) throws IOException {
        out.writeObject(content);
    }


}
