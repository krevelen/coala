package aglobe.ontology;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.io.ObjectOutput;
import java.io.ObjectInput;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import aglobe.container.transport.Address;
import aglobe.util.ConversionTools;
import aglobe.util.Logger;
import aglobe.util.concurrent.NonblockingPoolArrayFIFO;

/**
 *
 * <p>Title: A-Globe</p>
 *
 * <p>Description: Visibility update is used for distribution visibility information among server and containers</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.16 $ $Date: 2010/08/04 11:48:05 $
 */
@SuppressWarnings("unused")
public class VisibilityUpdate implements PooledObject {

    public enum VisibilityUpdateType {
        FULL_UPDATE,
        DIFFERENTIAL_ADD,
        DIFFERENTIAL_REMOVE
    }

    /**
     * pool of the objects
     */
    private final static NonblockingPoolArrayFIFO<VisibilityUpdate> pool = new NonblockingPoolArrayFIFO<VisibilityUpdate>(1<<13);

    /**
     * Number of current holders
     */
    private final AtomicInteger holders = new AtomicInteger(1);

//    private final static AtomicInteger newInstances = new AtomicInteger(0);
//    private final static AtomicInteger releasedObjects = new AtomicInteger(0);
//    private final static ConcurrentHashMap<VisibilityUpdate, VisibilityUpdate> nonReleasedObjects = new ConcurrentHashMap<VisibilityUpdate, VisibilityUpdate>();
//
//    private StringBuilder holderDebug;
//    private void stackTraceToString(String prefix) {
//        final Exception e = new Exception();
//        final StackTraceElement[] stack = e.getStackTrace();
//        int skip = 2;
//        synchronized (holderDebug) {
//            holderDebug.append(prefix);
//            holderDebug.append(" (holders = ").append(holders.get()).append("):\n");
//            for (StackTraceElement elem: stack) {
//                if (skip-- > 0) {
//                    continue;
//                }
//                holderDebug.append(elem);
//                holderDebug.append("\n");
//            }
//            holderDebug.append("\n");
//        }
//    }

    /**
     * Visibility unique identifier
     */
    private long _VisibilityID = -1;


    private VisibilityUpdateType _visibilityUpdateType = VisibilityUpdateType.FULL_UPDATE;

    /**
     * List of visible container addresses
     */
    private ArrayList<Address> _VisibleContainerAddress = new ArrayList<Address>();

    /**
     * Cannot be called outside
     */
    private VisibilityUpdate() {

    }

    public final static VisibilityUpdate getInstance() {
        VisibilityUpdate retVal = pool.pop();
        if (retVal == null) {
            retVal = new VisibilityUpdate();
//            final int newInst = newInstances.incrementAndGet();
//            if (newInst % 10 == 0) {
//                Logger.logWarning("New Instances Cnt: "+newInst+" Cache size: "+pool.size()+" Released: "+releasedObjects.get());
////                Logger.logWarning("First non-released object:\n"+(nonReleasedObjects.keys().nextElement().holderDebug.toString()));
//            }
        } else {
            retVal.holders.set(1);
        }
//        retVal.holderDebug = new StringBuilder();
//        retVal.stackTraceToString("Creation");
//        nonReleasedObjects.put(retVal, retVal);
        return retVal;
    }


    /* (non-Javadoc)
     * @see aglobe.ontology.PooledObject#registerHolder()
     */
    @Override
    public void registerHolder() {
        holders.incrementAndGet();
//        stackTraceToString("Register holder");
    }

    /* (non-Javadoc)
     * @see aglobe.ontology.PooledObject#release()
     */
    @Override
    public void release() {
        final int hold = holders.decrementAndGet();
//        stackTraceToString("Release holder");
        if (hold > 0) {
            return;
        }
        if (hold < 0) {
          throw new RuntimeException("Holders is under 0 !!!");
//          throw new RuntimeException("Holders is under 0 !!! Log:\n"+holderDebug.toString()+"\n End of log \n");
        }
        // empty given reinitialize given object
        _VisibleContainerAddress.clear();
        _visibilityUpdateType = VisibilityUpdateType.FULL_UPDATE;
        _VisibilityID = -1;

//        releasedObjects.incrementAndGet();
//        nonReleasedObjects.remove(this);

        pool.push(this);
    }


    /**
     * Gets visibilityID
     * @return long
     */
    public long getVisibilityID() {
        return _VisibilityID;
    }

    /**
     * Set unique visibility identifier
     * @param _VisibilityID long
     */
    public void setVisibilityID(long _VisibilityID) {
        this._VisibilityID = _VisibilityID;
    }

    public VisibilityUpdateType getVisibilityUpdateType() {
        return _visibilityUpdateType;
    }

    public void setVisibilityUpdateType(VisibilityUpdateType type) {
        _visibilityUpdateType = type;
    }

    /**
     * Reads list of visible container addresses
     * @return List
     */
    public ArrayList<Address> getVisibleContainerAddress() {
        return _VisibleContainerAddress;
    }

    /**
     * Tests if object equals to the ob
     * @param ob Object
     * @return boolean - true if equals
     */
    @Override
    public boolean equals(Object ob) {
        if (this == ob) {
            return true;
        }
        if (!(ob instanceof VisibilityUpdate)) {
            return false;
        }
        VisibilityUpdate tob = ((VisibilityUpdate) ob);
        if (_VisibilityID != tob._VisibilityID) {
            return false;
        }
        if (_VisibleContainerAddress != null) {
            if (tob._VisibleContainerAddress == null) {
                return false;
            }
            if (!_VisibleContainerAddress.equals(tob._VisibleContainerAddress)) {
                return false;
            }
        } else {
            if (tob._VisibleContainerAddress != null) {
                return false;
            }
        }
        return true;
    }

    /**
     * Returns hash code of the object
     * @return int
     */
    @Override
    public int hashCode() {
        int h = 0;
        h = ((31 * h) + ((int) (_VisibilityID ^ (_VisibilityID >> 32))));
        h = ((67 * h) + ((_VisibleContainerAddress != null) ? _VisibleContainerAddress.hashCode() : 0));
        return h;
    }

    /**
     * Returns string representation of the object
     * @return String
     */
    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer("<<VisibilityUpdate");
        switch (_visibilityUpdateType) {
        case FULL_UPDATE:
            sb.append(" FULL_UPDATE");
            break;
        case DIFFERENTIAL_ADD:
            sb.append(" DIFFERENTIAL_ADD");
            break;
        case DIFFERENTIAL_REMOVE:
            sb.append(" DIFFERENTIAL_REMOVE");
            break;
        }
        sb.append(" VisibilityID=");
        sb.append(Long.toString(getVisibilityID()));
        if (_VisibleContainerAddress != null) {
            sb.append(" VisibleContainerAddress=");
            sb.append(_VisibleContainerAddress.toString());
        }
        sb.append(">>");
        return sb.toString();
    }

    /**
     * The object implements the writeExternal method to save its contents by
     * calling the methods of DataOutput for its primitive values or calling
     * the writeObject method of ObjectOutput for objects, strings, and
     * arrays.
     *
     * @param out the stream to write the object to
     * @throws IOException Includes any I/O exceptions that may occur
     */
    @Override
	public final void writeExternal(final ObjectOutput out) throws IOException {
        out.writeLong(_VisibilityID);
        out.writeObject(_visibilityUpdateType);
        final int cnt = _VisibleContainerAddress.size();
        out.writeInt(cnt);
        if (cnt > 0) {
            for (Address item : _VisibleContainerAddress) {
                item.serialize(out);
            }
        }
    }

    /**
     * The object implements the readExternal method to restore its contents
     * by calling the methods of DataInput for primitive types and readObject
     * for objects, strings and arrays.
     *
     * @param in the stream to read data from in order to restore the object
     * @throws IOException if I/O errors occur
     * @throws ClassNotFoundException If the class for an object being
     *   restored cannot be found.
     */
    @Override
	public final void readExternal(final ObjectInput in) throws IOException,
            ClassNotFoundException {
        _VisibilityID = in.readLong();
        _visibilityUpdateType = (VisibilityUpdateType) in.readObject();
        final int len = in.readInt();
        for (int i = 0; i < len; i++) {
            _VisibleContainerAddress.add(Address.deserialize(in));
        }
    }


}
