
package aglobe.ontology;

import java.io.IOException;
import java.io.Externalizable;
import java.io.ObjectOutput;
import java.io.ObjectInput;
import java.util.Arrays;

import aglobe.util.ConversionTools;

/**
 *
 * <p>Title: A-Globe</p>
 *
 * <p>Description: TheLibrary is used for library transfer between agent container during agent migration.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.17 $ $Date: 2010/08/04 11:48:04 $
 */
public class TheLibrary implements Externalizable {
    /**
     * Library file name
     */
    private String _Name;

    /**
     * Library version
     */
    private String _Version;

    /**
     * Library description
     */
    private String _Comment;

    /**
     * Library data content
     */
    private byte[] _Data;

    /**
     * Gets library file name
     * @return String
     */
    public String getName() {
        return _Name;
    }

    /**
     * Sets library file name
     * @param _Name String
     */
    public void setName(String _Name) {
        this._Name = _Name;
    }

    /**
     * Gets library version
     * @return String
     */
    public String getVersion() {
        return _Version;
    }

    /**
     * Sets library version
     * @param _Version String
     */
    public void setVersion(String _Version) {
        this._Version = _Version;
    }

    /**
     * Gets library description
     * @return String
     */
    public String getComment() {
        return _Comment;
    }

    /**
     * Sets library description
     * @param _Comment String
     */
    public void setComment(String _Comment) {
        this._Comment = _Comment;
    }

    /**
     * Get library data content
     * @return byte[]
     */
    public byte[] getData() {
        return _Data;
    }

    /**
     * Sets library data content
     * @param _Data byte[]
     */
    public void setData(byte[] _Data) {
        this._Data = _Data;
    }

    /**
     * Tests if the objects equals to the ob
     * @param ob Object
     * @return boolean - true iff equals
     */
    @Override
    public boolean equals(Object ob) {
        if (this == ob) {
            return true;
        }
        if (!(ob instanceof TheLibrary)) {
            return false;
        }
        TheLibrary tob = ((TheLibrary) ob);
        if (_Name != null) {
            if (tob._Name == null) {
                return false;
            }
            if (!_Name.equals(tob._Name)) {
                return false;
            }
        } else {
            if (tob._Name != null) {
                return false;
            }
        }
        if (_Version != null) {
            if (tob._Version == null) {
                return false;
            }
            if (!_Version.equals(tob._Version)) {
                return false;
            }
        } else {
            if (tob._Version != null) {
                return false;
            }
        }
        if (_Comment != null) {
            if (tob._Comment == null) {
                return false;
            }
            if (!_Comment.equals(tob._Comment)) {
                return false;
            }
        } else {
            if (tob._Comment != null) {
                return false;
            }
        }
        if (_Data != null) {
            if (tob._Data == null) {
                return false;
            }
            if (!Arrays.equals(_Data, tob._Data)) {
                return false;
            }
        } else {
            if (tob._Data != null) {
                return false;
            }
        }
        return true;
    }

    /**
     * Returns hash code of the object
     * @return int
     */
    @Override
    public int hashCode() {
        int h = 0;
        h = ((127 * h) + ((_Name != null) ? _Name.hashCode() : 0));
        h = ((127 * h) + ((_Version != null) ? _Version.hashCode() : 0));
        h = ((127 * h) + ((_Comment != null) ? _Comment.hashCode() : 0));
        h = ((127 * h) + ((_Data != null) ? Arrays.hashCode(_Data) : 0));
        return h;
    }

    /**
     * Returns string representation of the object
     * @return String
     */
    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer("<<TheLibrary");
        if (_Name != null) {
            sb.append(" Name=");
            sb.append(_Name);
        }
        if (_Version != null) {
            sb.append(" Version=");
            sb.append(_Version);
        }
        if (_Comment != null) {
            sb.append(" Comment=");
            sb.append(_Comment);
        }
        if (_Data != null) {
            sb.append(" Data= <contains data>");
//            sb.append(_Data.toString());
        }
        sb.append(">>");
        return sb.toString();
    }

    /**
     * The object implements the writeExternal method to save its contents by
     * calling the methods of DataOutput for its primitive values or calling
     * the writeObject method of ObjectOutput for objects, strings, and
     * arrays.
     *
     * @param out the stream to write the object to
     * @throws IOException Includes any I/O exceptions that may occur
     */
    @Override
	public void writeExternal(ObjectOutput out) throws IOException {
        ConversionTools.writeString(out, _Name);
        ConversionTools.writeString(out, _Version);
        ConversionTools.writeString(out, _Comment);
        ConversionTools.writeByteArray(out, _Data);
    }

    /**
     * The object implements the readExternal method to restore its contents
     * by calling the methods of DataInput for primitive types and readObject
     * for objects, strings and arrays.
     *
     * @param in the stream to read data from in order to restore the object
     * @throws IOException if I/O errors occur
     * @throws ClassNotFoundException If the class for an object being
     *   restored cannot be found.
     */
    @Override
	public void readExternal(ObjectInput in) throws IOException,
            ClassNotFoundException {
        _Name = ConversionTools.readString(in);
        _Version = ConversionTools.readString(in);
        _Comment = ConversionTools.readString(in);
        _Data = ConversionTools.readByteArray(in);
    }

}
