package aglobe.service.topics;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.TimerTask;
import java.util.concurrent.locks.ReentrantLock;

import aglobe.container.library.LibraryObjectInputStream;
import aglobe.container.transport.Address;
import aglobe.container.transport.InvisibleContainerException;
import aglobe.ontology.Message;
import aglobe.ontology.PooledObject;
import aglobe.platform.MessageTransportComponent;
import aglobe.platform.Platform;
import aglobe.platform.thread.AglobeThreadPool;
import aglobe.platform.transport.AddressReader;
import aglobe.platform.transport.AddressWriter;
import aglobe.platform.transport.MessageObjectOutputStream;
import aglobe.platform.transport.MessageReceiver;
import aglobe.platform.transport.MessageTransport;
import aglobe.platform.transport.RecepientNotFound;
import aglobe.util.ExceptionPrinter;
import aglobe.util.Logger;
import aglobe.util.concurrent.NonblockingPoolArrayFIFO;

/**
 * @internal
 * <p>Title: TopicsManager</p>
 *
 * <p>Description: Takes care about topics messaging within one Aglobe platform and one unique system name</p>
 *
 * <p>Copyright: Copyright (c) 2009</p>
 *
 * <p>Company: Agent Technology Center</p>
 *
 * @author David Sislak
 * @version $Revision: 1.28 $ $Date: 2010/11/30 09:12:27 $
 *
 */
final class TopicsManager implements MessageTransportComponent {
    private static final Object generalSync = new Object();
    private static TopicsManager theFirstTopicsManager = null;
    private static final HashMap<String, TopicsManager> topicsManagersBySystemNames = new HashMap<String, TopicsManager>();
    private static final HashMap<String, HashSet<TopicsService>> registeredTopicsServices = new HashMap<String, HashSet<TopicsService>>();

    private static final long TIMEOUT_MILLIS = 1000;
    private static final long SERVER_KEEP_ALIVE_INTERVAL = 4000;

    private static final boolean TOPIC_FLOW_ANALYZER_ENABLED = false;
    private static final int TOPIC_FLOW_STATS_EVERY_MILLIS = 5000;
    private static final String MANAGEMENT_TRAFFIC = "{management traffic}";


    private static final String REGISTERED_CONTAINER_PREFIX = "TOPICS_";
    private static final String SERVICE_NAME = "s";
    private static final String AGENT_NAME = "a";

    // management performatives
    private static final int PERFORMATIVE_SEARCH_FOR_NEIGHBORS = 1;
    private static final int PERFORMATIVE_SEARCH_RESPONSE = 2;
    private static final int PERFORMATIVE_REGISTER_REQUEST = 3;
    private static final int PERFORMATIVE_REGISTER_RESPONSE = 4;
    private static final int PERFORMATIVE_DEREGISTER = 8;
    private static final int PERFORMATIVE_REDIRECT_TO_SERVER = 5;
    private static final int PERFORMATIVE_ADD_NEIGHBOR = 6;
    private static final int PERFORMATIVE_REMOVE_NEIGHBOR = 7;
    private static final int PERFORMATIVE_KEEP_ALIVE = 9;
    private static final int PERFORMATIVE_CAN_BE_MASTER_QUERY = 10;
    private static final int PERFORMATIVE_CAN_BE_MASTER_RESPONSE = 11;

    // directory performatives
    private static final int PERFORMATIVE_SUBSCRIBE = 12;
    private static final int PERFORMATIVE_UNSUBSCRIBE = 13;
    private static final int PERFORMATIVE_REGISTER_NOTIFIER = 14;
    private static final int PERFORMATIVE_DEREGISTER_NOTIFIER = 15;
    private static final int PERFORMATIVE_NOTIFY_ADD_SUBSCRIBER = 16;
    private static final int PERFORMATIVE_NOTIFY_REMOVE_SUBSCRIBER = 17;
    private static final int PERFORMATIVE_NOTIFY_INITIAL_SUBSCRIBERS = 18;
    private static final int PERFORMATIVE_NOTIFY_NO_SUBSCRIBERS = 19;
    private static final int PERFORMATIVE_SUBSCRIBED_ACK = 20;

    private enum State {
        INIT,
        SEARCHING_FOR_NEIGHBORS,
        REGISTER_WITHIN_MASTER,
        REGISTERED,
        IS_MASTER,
        CAN_BE_MASTER_CHECK,
    }

    // general data
    private final String systemName;
    private final boolean topicsNoKeepAlive;
    private final String systemContainerName;
    private final Address myDataAddress;
    private final Address myManagementAddress;
    private Configurator myConfigurator = null;

    private final MessageReceiver dataCommunication;
    private final MessageReceiver managementCommunication;

    private ReentrantLock lock = new ReentrantLock();
    private State state = State.INIT;
    private TimerTask timerTask = null;
    private ArrayList<Message> delayedRequests = null;

    // client part - management
    private Address masterManagementCommunication = null;
    private final LinkedHashSet<Address> neighbors = new LinkedHashSet<Address>();
    private int keepAliveCnt = 0;
    private LinkedHashSet<Address> positiveCanBeMasterResponses = null;

    // directory part - management
    private final LinkedHashSet<Address> registered = new LinkedHashSet<Address>();

    // topics knowledge base
    private final LinkedHashMap<String, TopicRecord> topicsRecords = new LinkedHashMap<String, TopicRecord>();
    private final LinkedHashMap<String, DirectoryRecord> directoryRecords = new LinkedHashMap<String, DirectoryRecord>();

    // Analyzer part
    private LinkedHashMap<String, AnalyzerRecord> analyzerRecord;
    private TimerTask regularStatTask;
    private long lastTimeStamp;
    private int maxTopicName = 5;


    // -------------------------------------------
    // factory methods for accessing proper TopicsManager
    // -------------------------------------------

    static TopicsManager getTopicsManagerAndRegisterService(final TopicsService service, final String systemName, final ArrayList<Address> topicsPlatforms, final boolean topicsNoKeepAlive) {
        synchronized (generalSync) {
            TopicsManager tm = topicsManagersBySystemNames.get(systemName);
            if (tm == null) {
                // create new one
                tm = new TopicsManager(systemName, topicsPlatforms, topicsNoKeepAlive);
                topicsManagersBySystemNames.put(systemName, tm);
                if (theFirstTopicsManager == null) {
                	theFirstTopicsManager = tm;
                }
            }
            HashSet<TopicsService> regServices = registeredTopicsServices.get(systemName);
            if (regServices == null) {
                regServices = new HashSet<TopicsService>();
                registeredTopicsServices.put(systemName, regServices);
            }
            regServices.add(service);
            return tm;
        }
    }
    
    
    /**
     * @internal
     * 
     * Do not use this method to get TopicsShell from ElementaryEntities (Agent or Service). It is supposed to be used only by the 
     * internal Aglobe container. 
     * 
     * Warining: This method returns TopicsShell which is connected with the first system created in JVM. Do not use this method
     * when more than one systems are running within the same JVM process (using different SystemNames).
     * 
     * @return
     */
    static TopicsService.Shell getPlatformTopicsShell() {
    	final TopicsManager tm;
    	synchronized (generalSync) {
    		if (theFirstTopicsManager == null) {
    			throw new RuntimeException("There is no TopicsManager yet");
    		}
    		tm = theFirstTopicsManager;
    	}
    	
    	return new TopicsService.Shell(tm);
    }

    static void deregisterService(final TopicsService service, final String systemName) {
        synchronized (generalSync) {
            HashSet<TopicsService> regServices = registeredTopicsServices.get(systemName);
            if (regServices == null) {
                return;
            }
            regServices.remove(service);
            if (regServices.size() == 0) {
                registeredTopicsServices.remove(systemName);
                TopicsManager tm = topicsManagersBySystemNames.remove(systemName);
                if (tm == null) {
                    return;
                }
                tm.dispose();
            }
        }
    }

    //  -------------------------------------------
    //  Implementation of TopicsManager
    //  -------------------------------------------

    private TopicsManager(final String systemName, final ArrayList<Address> topicsPlatforms, final boolean topicsNoKeepAlive) {
        Logger.logFine("Creating new TopicsManager for '"+systemName+"'");

        if (topicsNoKeepAlive) {
            Logger.logWarning("Keep alive is disabled by using '-topicsNoKeepAlive' starting attribute");
        }
        
        this.systemName = systemName;
        this.topicsNoKeepAlive = topicsNoKeepAlive;
        this.systemContainerName = REGISTERED_CONTAINER_PREFIX + systemName;


        if (TOPIC_FLOW_ANALYZER_ENABLED) {
            // prepare periodical dump of topics stats
            lastTimeStamp = System.currentTimeMillis();
            analyzerRecord = new LinkedHashMap<String, AnalyzerRecord>();

            regularStatTask = new TimerTask() {
                @Override
                public void run() {
                    lock.lock();
                    try {
                        final long now = System.currentTimeMillis();
                        if (analyzerRecord.size() > 0) {
                            final double diffSec = (now - lastTimeStamp)/1000.;
                            StringBuilder sb = new StringBuilder("Analyzer stats:\n");
                            sb.append(String.format("%-"+maxTopicName+"s || %-9s | %-9s | %-9s | %-9s || %-12s | %-12s | %-12s | %-12s\n",
                                    "Topic","icnt[#/s]","ocnt[#/s]","in [B/s]","out [B/s]","icnt [#]","ocnt [#]","in [B]","out [B]"));
                            for (int i=0; i<(maxTopicName+110); i++) {
                                sb.append('=');
                            }
                            sb.append("\n");

                            int icntpersec = 0;
                            int ocntpersec = 0;
                            int inpersec = 0;
                            int outpersec = 0;
                            long icnt = 0;
                            long ocnt = 0;
                            long in = 0;
                            long out = 0;

                            for (AnalyzerRecord elem : analyzerRecord.values()) {
                                sb.append(String.format("%-"+maxTopicName+"s || % 9d | % 9d | % 9d | % 9d || % 12d | % 12d | % 12d | % 12d\n", elem.topic,
                                        (int)Math.ceil(elem.icntpersec/diffSec), (int)Math.ceil(elem.ocntpersec/diffSec),
                                        (int)Math.ceil(elem.inpersec/diffSec), (int)Math.ceil(elem.outpersec/diffSec),
                                        elem.icnt, elem.ocnt, elem.in, elem.out));
                                icntpersec += elem.icntpersec;
                                ocntpersec += elem.ocntpersec;
                                inpersec += elem.inpersec;
                                outpersec += elem.outpersec;
                                icnt += elem.icnt;
                                ocnt += elem.ocnt;
                                in += elem.in;
                                out += elem.out;
                                elem.icntpersec = 0;
                                elem.ocntpersec = 0;
                                elem.inpersec = 0;
                                elem.outpersec = 0;
                            }
                            for (int i=0; i<(maxTopicName+110); i++) {
                                sb.append('=');
                            }
                            sb.append("\n");
                            sb.append(String.format("%-"+maxTopicName+"s || % 9d | % 9d | % 9d | % 9d || % 12d | % 12d | % 12d | % 12d\n", "TOTAL",
                                    (int)Math.ceil(icntpersec/diffSec), (int)Math.ceil(ocntpersec/diffSec),
                                    (int)Math.ceil(inpersec/diffSec), (int)Math.ceil(outpersec/diffSec),
                                    icnt, ocnt, in, out));

                            Logger.logWarning(sb.toString());
                        }

                        lastTimeStamp = now;
                    } finally {
                        lock.unlock();
                    }
                }

            };
            try {
                Platform.TIMER.schedule(regularStatTask, TOPIC_FLOW_STATS_EVERY_MILLIS, TOPIC_FLOW_STATS_EVERY_MILLIS);
            } catch (Exception e) {
                // Timer is already canceled
            }
        }


        dataCommunication = new MessageReceiver() {
            @Override
            public void incomingMessage(final Message m) {
                lock.lock();
                try {
                    final String topic = m.getPerformative();
                    final TopicRecord tr = topicsRecords.get(topic);
                    if ((tr != null) && (tr.localSubscribers.size() > 0)) {
                        final Object content = m.getContent();
                        final String reason = m.getReason();
                        final PooledObject po;
                        if ((content != null) && (content instanceof PooledObject)) {
                            po = (PooledObject) content;
                        } else {
                            po = null;
                        }
                        for (final TopicsHandler handler : tr.localSubscribers) {
                            if (po != null) {
                                po.registerHolder();
                            }

                            handler.addEvent(new Runnable() {

                                @Override
                                public void run() {
                                    handler.handleIncomingTopic(topic, content, reason);
                                }

                            });
                        }
                    }


                } finally {
                    m.release();
                    lock.unlock();
                }
            }

        };

        managementCommunication = new MessageReceiver() {
            @Override
            public void incomingMessage(final Message m) {
                lock.lock();
                try {
                    switch (Integer.parseInt(m.getPerformative())) {
                        // -------------------------------------------------
                        // management part
                        // -------------------------------------------------

                        case PERFORMATIVE_SEARCH_FOR_NEIGHBORS: {
                            if ((state == State.IS_MASTER) || (state == State.REGISTERED)) {
                                final Message reply = m.getReply(myManagementAddress);
                                reply.setPerformative(Integer.toString(PERFORMATIVE_SEARCH_RESPONSE));
                                final AddressesExchanger ne = new AddressesExchanger();
                                ne.addresses.addAll((state == State.IS_MASTER)?registered:neighbors);
                                ne.addresses.add(myManagementAddress);
                                reply.setContent(ne);
                                try {
                                    sendMessage(reply);
                                } catch (InvisibleContainerException e) {
                                }
                                logForAnalyzer(MANAGEMENT_TRAFFIC, reply, false);
                                reply.release();
                            } else {
                                // wait until I will know
                                rememberRequest(m);
                                return;
                            }
                            break;
                        }
                        case PERFORMATIVE_SEARCH_RESPONSE: {
                            if (state != State.SEARCHING_FOR_NEIGHBORS) {
                                return;
                            }

                            neighbors.clear();
                            neighbors.addAll(((AddressesExchanger)m.getContent()).addresses);

                            // register there
                            serverLost();

                            break;
                        }
                        case PERFORMATIVE_REGISTER_REQUEST: {
                            if (state == State.IS_MASTER) {
                                // register new
                                registerNewParticipant(m.getSender());

                            } else if (state == State.REGISTERED) {
                                // send redirect
                                final Message reply = m.getReply(myManagementAddress);
                                reply.setPerformative(Integer.toString(PERFORMATIVE_REDIRECT_TO_SERVER));
                                reply.setContent(masterManagementCommunication);
                                try {
                                    sendMessage(reply);
                                } catch (InvisibleContainerException e) {
                                }
                                logForAnalyzer(MANAGEMENT_TRAFFIC, reply, false);
                                reply.release();
                            } else {
                                // remember request until I will know
                                rememberRequest(m);
                                return;
                            }

                            break;
                        }
                        case PERFORMATIVE_DEREGISTER: {
                            if (state == State.IS_MASTER) {
                                deregisterParticipant(m.getSender());
                            } else {
                                Logger.logSevere("Received deregister request in state: "+state);
                            }
                            break;
                        }

                        case PERFORMATIVE_REDIRECT_TO_SERVER: {
                            if (state == State.IS_MASTER) {
                                Logger.logSevere("I'm master, why am I redirected to: "+m.getReason());
                                break;
                            }
                            // register there
                            registerWithinMaster((Address)m.getContent());

                            break;
                        }

                        case PERFORMATIVE_REGISTER_RESPONSE: {
                            if (state != State.REGISTER_WITHIN_MASTER) {
                                Logger.logSevere("Received registration respons in state: "+state.toString());
                                return;
                            }

                            if (!masterManagementCommunication.equals(m.getSender())) {
                                Logger.logSevere("Got registration from different server: "+m.getSender()+" but expected from: "+masterManagementCommunication);
                                return;
                            }

                            newlyRegistered(((AddressesExchanger)m.getContent()).addresses);

                            break;
                        }

                        case PERFORMATIVE_ADD_NEIGHBOR: {
                            // got new neighbor address
                            neighbors.add((Address)m.getContent());

                            break;
                        }

                        case PERFORMATIVE_REMOVE_NEIGHBOR: {
                            neighbors.remove(m.getContent());

                            break;
                        }

                        case PERFORMATIVE_KEEP_ALIVE: {
                            if ((state == State.REGISTERED) && (m.getSender().equals(masterManagementCommunication))) {
                                keepAliveCnt++;
                            }

                            break;
                        }

                        case PERFORMATIVE_CAN_BE_MASTER_QUERY: {
                            final Message reply = m.getReply(myManagementAddress);
                            if (state == State.IS_MASTER) {
                                // no I'm master
                                reply.setPerformative(Integer.toString(PERFORMATIVE_REDIRECT_TO_SERVER));
                                reply.setContent(myManagementAddress);
                            } else {
                                final boolean yes = m.getSender().compareTo(myManagementAddress) > 0;
                                reply.setPerformative(Integer.toString(PERFORMATIVE_CAN_BE_MASTER_RESPONSE));
                                reply.setReason(Boolean.toString(yes));
                            }
                            try {
                                sendMessage(reply);
                            } catch (InvisibleContainerException e) {
                            }
                            logForAnalyzer(MANAGEMENT_TRAFFIC, reply, false);
                            reply.release();
                            break;
                        }

                        case PERFORMATIVE_CAN_BE_MASTER_RESPONSE: {
                            if (state == State.CAN_BE_MASTER_CHECK) {
                                final boolean yes = Boolean.parseBoolean(m.getReason());
                                if (yes) {
                                    positiveCanBeMasterResponses.add(m.getSender());
                                    if (positiveCanBeMasterResponses.size() == neighbors.size()) {
                                        // all responses
                                        if (timerTask != null) {
                                            timerTask.cancel();
                                            timerTask = null;
                                        }
                                        positiveCanBeMasterResponses = null;

                                        becomeMaster();
                                    }
                                } else {
                                    state = State.INIT;
                                    if (timerTask != null) {
                                        timerTask.cancel();
                                        timerTask = null;
                                    }
                                    positiveCanBeMasterResponses = null;
                                }

                            }
                            break;
                        }

                        // ------------------------------------------------
                        // Directory communication part - directory side
                        // ------------------------------------------------
                        case PERFORMATIVE_SUBSCRIBE: {
                            if (state == State.IS_MASTER) {
                                final String topic = m.getReason();
                                final Address dataReceiver = m.getSender();
                                DirectoryRecord dr = directoryRecords.get(topic);
                                if (dr == null) {
                                    dr = new DirectoryRecord();
                                    directoryRecords.put(topic,dr);
                                }

                                // first check for local first subscription notifiers
                                final int drdsSize =  dr.directorySubscription.size();
                                // add record
                                if (dr.directorySubscription.add(dataReceiver)) {

                                    // notify others about this subscriptions
                                    if (dr.directoryNotifiers.size() > 0) {
                                        // do not send SELF notifications !!!
                                        final LinkedHashSet<Address> toNotify = new LinkedHashSet<Address>(dr.directoryNotifiers);
                                        toNotify.remove(dataReceiver.deriveServiceAddress(SERVICE_NAME));
                                        if (toNotify.size() > 0) {
                                            final Message notify = Message.newInstance(Integer.toString(PERFORMATIVE_NOTIFY_ADD_SUBSCRIBER), myManagementAddress, toNotify);
                                            notify.setVisibilityID(-1);
                                            notify.setProtocol(topic);
                                            notify.setContent(dataReceiver);
                                            try {
                                                sendMessage(notify);
                                            } catch (InvisibleContainerException e) {
                                            }
                                            logForAnalyzer(MANAGEMENT_TRAFFIC, notify, false);
                                            notify.release();
                                        }
                                    }
                                }
                                
                                final TopicRecord tr = topicsRecords.get(topic);
                                if ((tr != null) && (drdsSize == 0) && (tr.localSubscribers.size() == 0) && (tr.localNotifiers.size() > 0)) {
                                    // the first subscription from local perspective
                                    for (final TopicsSubscriptionNotifier notifier : tr.localNotifiers) {
                                        notifier.addEvent(new Runnable() {
                                            @Override
                                            public void run() {
                                                notifier.hasSubscriber(topic);
                                            }
                                        });
                                    }
                                }

                                final String notifyId = m.getProtocol();
                                if (notifyId != null) {
                                    final Message reply = Message.newInstance(Integer.toString(PERFORMATIVE_SUBSCRIBED_ACK), myManagementAddress, dataReceiver.deriveServiceAddress(SERVICE_NAME));
                                    reply.setReason(topic);
                                    reply.setVisibilityID(-1);
                                    reply.setProtocol(notifyId);
                                    try {
                                        sendMessage(reply);
                                    } catch (InvisibleContainerException e) {
                                    }
                                    logForAnalyzer(MANAGEMENT_TRAFFIC, reply, false);
                                    reply.release();
                                }
                            }
                            break;
                        }

                        case PERFORMATIVE_UNSUBSCRIBE: {
                            if (state == State.IS_MASTER) {
                                final String topic = m.getReason();
                                final DirectoryRecord dr = directoryRecords.get(topic);
                                if (dr != null) {
                                    final Address dataReceiver = m.getSender();
                                    if (dr.directorySubscription.remove(dataReceiver)) {

                                        // first check for local subscription notifiers
                                        final TopicRecord tr = topicsRecords.get(topic);
                                        if ((tr != null) && (dr.directorySubscription.size() == 0) && (tr.localSubscribers.size() == 0) && (tr.localNotifiers.size() > 0)) {
                                            // the last subscription from local perspective has been removed
                                            for (final TopicsSubscriptionNotifier notifier : tr.localNotifiers) {
                                                notifier.addEvent(new Runnable() {

                                                    @Override
                                                    public void run() {
                                                        notifier.noSubscriber(topic);
                                                    }

                                                });
                                            }

                                        }

                                        // notify others about this unsubscription
                                        if (dr.directoryNotifiers.size() > 0) {
                                            // do not send SELF notifications !!!
                                            final LinkedHashSet<Address> toNotify = new LinkedHashSet<Address>(dr.directoryNotifiers);
                                            toNotify.remove(dataReceiver.deriveServiceAddress(SERVICE_NAME));
                                            if (toNotify.size() > 0) {
                                                final Message notify = Message.newInstance(Integer.toString(PERFORMATIVE_NOTIFY_REMOVE_SUBSCRIBER), myManagementAddress, toNotify);
                                                notify.setVisibilityID(-1);
                                                notify.setProtocol(topic);
                                                notify.setContent(dataReceiver);
                                                try {
                                                    sendMessage(notify);
                                                } catch (InvisibleContainerException e) {
                                                }
                                                logForAnalyzer(MANAGEMENT_TRAFFIC, notify, false);
                                                notify.release();
                                            }
                                        }

                                        if ((dr.directorySubscription.size() == 0) && (dr.directoryNotifiers.size() == 0)) {
                                            // remove unused record
                                            directoryRecords.remove(topic);
                                        }
                                    }
                                }
                            }
                            break;
                        }

                        case PERFORMATIVE_REGISTER_NOTIFIER: {
                            if (state == State.IS_MASTER) {
                                final String topic = m.getReason();
                                final Address receiver = m.getSender();

                                DirectoryRecord dr = directoryRecords.get(topic);
                                if (dr == null) {
                                    dr = new DirectoryRecord();
                                    directoryRecords.put(topic, dr);
                                }
                                if (dr.directoryNotifiers.add(receiver)) {

                                    final TopicRecord tr = topicsRecords.get(topic);

                                    // send initial notification
                                    if ((dr.directorySubscription.size() > 0) || ((tr != null) && (tr.localSubscribers.size() > 0))) {
                                        final AddressesExchanger ae = new AddressesExchanger();
                                        ae.addresses.addAll(dr.directorySubscription);
                                        if ((tr != null) && (tr.localSubscribers.size() > 0)) {
                                            ae.addresses.add(myDataAddress);
                                        }
                                        // do not send self information back
                                        ae.addresses.remove(receiver.deriveAgentAddress(AGENT_NAME));
                                        final Message reply = m.getReply();
                                        reply.setPerformative(Integer.toString(PERFORMATIVE_NOTIFY_INITIAL_SUBSCRIBERS));
                                        reply.setReason(topic);
                                        reply.setContent(ae);
                                        try {
                                            sendMessage(reply);
                                        } catch (InvisibleContainerException e) {
                                        }
                                        logForAnalyzer(MANAGEMENT_TRAFFIC, reply, false);
                                        reply.release();

                                    } else {
                                        final Message reply = m.getReply();
                                        reply.setPerformative(Integer.toString(PERFORMATIVE_NOTIFY_NO_SUBSCRIBERS));
                                        reply.setReason(topic);
                                        try {
                                            sendMessage(reply);
                                        } catch (InvisibleContainerException e) {
                                        }
                                        logForAnalyzer(MANAGEMENT_TRAFFIC, reply, false);
                                        reply.release();
                                    }
                                }
                            }
                            break;
                        }

                        case PERFORMATIVE_DEREGISTER_NOTIFIER: {
                            if (state == State.IS_MASTER) {
                                final String topic = m.getReason();

                                final DirectoryRecord dr = directoryRecords.get(topic);
                                if (dr != null) {
                                    final Address receiver = m.getSender();

                                    // just remove it
                                    if (dr.directoryNotifiers.remove(receiver)) {

                                        if ((dr.directoryNotifiers.size() == 0) && (dr.directorySubscription.size() == 0)) {
                                            // remove unused record
                                            directoryRecords.remove(topic);
                                    }
                                    }
                                }
                            }
                            break;
                        }

                        // ------------------------------------------------
                        // Directory communication part - registering side
                        // ------------------------------------------------
                        case PERFORMATIVE_SUBSCRIBED_ACK: {
                            if ((state == State.REGISTERED) && (m.getSender().equals(masterManagementCommunication))) {
                                final String topic = m.getReason();
                                final TopicRecord tr = topicsRecords.get(topic);
                                if ((tr != null) && (tr.blocker != null)) {
                                    final int ackId = Integer.parseInt(m.getProtocol());
                                    if (ackId == tr.subscribeBlockId) {
                                        // wake up all waiters
                                        tr.blocker.signalAll();
                                    }
                                }
                            }
                            break;
                        }

                        case PERFORMATIVE_NOTIFY_ADD_SUBSCRIBER: {
                            if ((state == State.REGISTERED) && (m.getSender().equals(masterManagementCommunication))) {
                                final String topic = m.getProtocol();
                                final TopicRecord tr = topicsRecords.get(topic);
                                if ((tr != null) && (!tr.unknownRemoteSubscription)) {
                                    if ((tr.remoteSubscribers.size() == 0) && (tr.localSubscribers.size() == 0) && (tr.localNotifiers.size() > 0)) {
                                        for (final TopicsSubscriptionNotifier notifier : tr.localNotifiers) {
                                            notifier.addEvent(new Runnable() {

                                                @Override
                                                public void run() {
                                                    notifier.hasSubscriber(topic);
                                                }

                                            });
                                        }
                                    }

                                    tr.remoteSubscribers.add((Address)m.getContent());
                                }
                            }
                            break;
                        }

                        case PERFORMATIVE_NOTIFY_REMOVE_SUBSCRIBER: {
                            if ((state == State.REGISTERED) && (m.getSender().equals(masterManagementCommunication))) {
                                final String topic = m.getProtocol();
                                final TopicRecord tr = topicsRecords.get(topic);
                                if ((tr != null) && (!tr.unknownRemoteSubscription)) {
                                    final Address ra = (Address)m.getContent();
                                    if (tr.remoteSubscribers.remove(ra)) {

                                        if ((tr.remoteSubscribers.size() == 0) && (tr.localSubscribers.size() == 0) && (tr.localNotifiers.size() > 0)) {
                                            for (final TopicsSubscriptionNotifier notifier : tr.localNotifiers) {
                                                notifier.addEvent(new Runnable() {

                                                    @Override
                                                    public void run() {
                                                        notifier.noSubscriber(topic);
                                                    }

                                                });
                                            }
                                        }
                                    }
                                }
                            }
                            break;
                        }

                        case PERFORMATIVE_NOTIFY_INITIAL_SUBSCRIBERS: {
                            if ((state == State.REGISTERED) && (m.getSender().equals(masterManagementCommunication))) {
                                final String topic = m.getReason();
                                final TopicRecord tr = topicsRecords.get(topic);
                                if ((tr != null) && (tr.unknownRemoteSubscription)) {
                                    tr.unknownRemoteSubscription = false;
                                    tr.remoteSubscribers.addAll(((AddressesExchanger)m.getContent()).addresses);

                                    // dispatch temporary messages
                                    if (tr.localTempTopicsCache.size() > 0) {
                                        for (HistoryRecord hr : tr.localTempTopicsCache) {
                                        	if (tr.remoteSubscribers.size() > 0) {
                                        		final Message history = Message.newInstance(topic, myDataAddress, tr.remoteSubscribers);
                                        		history.setVisibilityID(-1);
                                        		history.setContent(hr.content);
                                        		if (hr.po != null) {
                                        			hr.po.registerHolder();
                                        		}
                                        		history.setReason(hr.reason);
                                        		try {
                                        			sendMessage(history);
                                        		} catch (InvisibleContainerException e) {
                                        		}
                                        		logForAnalyzer(topic, history, false);
                                                history.release();
                                        	}
                                            // flush history
                                            hr.release();
                                        }
                                        tr.localTempTopicsCache.clear();
                                    }

                                    if (tr.localNotifiers.size() == 0) {
                                        if (tr.localTopicsProviders.size() == 0) {
                                            tr.unknownRemoteSubscription = true;
                                            tr.remoteSubscribers.clear();

                                            // remove notifying registration from server
                                            final Message reply = Message.newInstance(Integer.toString(PERFORMATIVE_DEREGISTER_NOTIFIER), myManagementAddress, masterManagementCommunication);
                                            reply.setVisibilityID(-1);
                                            reply.setReason(topic);
                                            try {
                                                sendMessage(reply);
                                            } catch (InvisibleContainerException e) {
                                                serverLost();
                                            }
                                            logForAnalyzer(MANAGEMENT_TRAFFIC, reply, false);
                                            reply.release();

                                            if (tr.localSubscribers.size() == 0) {
                                                // remove it as it was there only due to dispatch of temp topics
                                                topicsRecords.remove(topic);

                                            }
                                        }
                                    } else {
                                        if (tr.localSubscribers.size() == 0) {
                                            // the first subscribers
                                            for (final TopicsSubscriptionNotifier notifier : tr.localNotifiers) {
                                                notifier.addEvent(new Runnable() {

                                                    @Override
                                                    public void run() {
                                                        notifier.hasSubscriber(topic);
                                                    }

                                                });
                                            }
                                        }
                                    }
                                }
                            }

                            break;
                        }

                        case PERFORMATIVE_NOTIFY_NO_SUBSCRIBERS: {
                            // check that I'm waiting for it
                            if ((state == State.REGISTERED) && (m.getSender().equals(masterManagementCommunication))) {
                                final String topic = m.getReason();
                                final TopicRecord tr = topicsRecords.get(topic);
                                if ((tr != null) && (tr.unknownRemoteSubscription)) {
                                    tr.unknownRemoteSubscription = false;
                                    tr.remoteSubscribers.clear();
                                    tr.clearTempTopicsCache();

                                    if (tr.localNotifiers.size() == 0) {
                                        if (tr.localTopicsProviders.size() == 0) {
                                            tr.unknownRemoteSubscription = true;

                                            // remove notifying registration from server
                                            final Message reply = Message.newInstance(Integer.toString(PERFORMATIVE_DEREGISTER_NOTIFIER), myManagementAddress, masterManagementCommunication);
                                            reply.setVisibilityID(-1);
                                            reply.setReason(topic);
                                            try {
                                                sendMessage(reply);
                                            } catch (InvisibleContainerException e) {
                                                serverLost();
                                            }
                                            logForAnalyzer(MANAGEMENT_TRAFFIC, reply, false);
                                            reply.release();

                                            if (tr.localSubscribers.size() == 0) {
                                                // remove it as it was there only due to dispatch of temp topics
                                                topicsRecords.remove(topic);
                                            }
                                        }
                                    } else {
                                        if (tr.localSubscribers.size() == 0) {
                                            // dispatch information that there is no subscriber
                                            for (final TopicsSubscriptionNotifier notifier : tr.localNotifiers) {
                                                notifier.addEvent(new Runnable() {

                                                    @Override
                                                    public void run() {
                                                        notifier.noSubscriber(topic);
                                                    }

                                                });
                                            }
                                        }
                                    }
                                }
                            }

                            break;
                        }


                        default:
                            Logger.logWarning("Unexpected incoming message: "+m);
                    }
                    logForAnalyzer(MANAGEMENT_TRAFFIC, m, true);

                    m.release();
                } finally {
                    lock.unlock();
                }
            }

        };

        // register as a specific container for messaging
        try {
            MessageTransport.registerMessageTransport(systemContainerName, this);
        } catch (Exception e) {
            Logger.logSevere("This should never happen:\n"+ExceptionPrinter.toStringWithStackTrace(e));
        }
        myManagementAddress = Address.getServiceAddress(MessageTransport.localHostAddress,
                MessageTransport.localPort, systemContainerName, SERVICE_NAME);
        myDataAddress = Address.getAgentAddress(MessageTransport.localHostAddress,
                MessageTransport.localPort, systemContainerName, AGENT_NAME);

        // searches for at least one neighbor topics manager
        ArrayList<Address> candidates;
        if ((topicsPlatforms == null) || (topicsPlatforms.size() == 0)) {
            Address oneCand = Configurator.getNeighborAddress(this.systemName);
            if (oneCand == null) {
                // no response till 0.5 seconds, no server
                Logger.logWarning("Cannot find any other platform in '"+this.systemName+"'. I'm the first one. If you are sure that there is running other platform, check '-udp' vs. '-tcp', '-systemName' starting attributes, firewall setting for incoming UDP on the port 4444 and finally, you can use '-topicsPlatforms' attribute to suppress platform autodetection.");
                // set own auto responser
                myConfigurator = new Configurator(systemName, myManagementAddress);
                // continue as a master
                becomeMaster();
                return;
            }
            candidates = new ArrayList<Address>();
            candidates.add(oneCand);
        } else {
            candidates = new ArrayList<Address>();
            for (Address address : topicsPlatforms) {
                candidates.add(Address.getServiceAddress(address.getHost(), address.getPort(), systemContainerName, SERVICE_NAME));
            }
        }
        state = State.SEARCHING_FOR_NEIGHBORS;
        final Message m = Message.newInstance(Integer.toString(PERFORMATIVE_SEARCH_FOR_NEIGHBORS), myManagementAddress, candidates);
        m.setVisibilityID(-1); // do not sniff or filter
        try {
            sendMessage(m);

            // set-up response timer
            timerTask = new TimerTask() {
                @Override
                public void run() {
                    lock.lock();
                    try {
                        if ((state != State.SEARCHING_FOR_NEIGHBORS) || (timerTask != this)) {
                            return;
                        }
                        timerTask = null;
                        Logger.logWarning("No response from any topics neighbor. I'm the first one. Check for TCP / UDP settings and firewall settings at all platforms");
                        becomeMaster();
                    } finally {
                        lock.unlock();
                    }
                }
            };
            try {
                Platform.TIMER.schedule(timerTask, TIMEOUT_MILLIS);
            } catch (Exception e) {
                // Timer is already canceled
            }
        } catch (InvisibleContainerException e) {
            Logger.logWarning("No response from any topics neighbor. I'm the first one. Check for TCP / UDP settings ('-udp' vs. '-tcp' startup attributes) and firewall settings at all platforms.");
            becomeMaster();
        } finally {
            logForAnalyzer(MANAGEMENT_TRAFFIC, m, false);
            m.release();

            // set own auto responser
            myConfigurator = new Configurator(systemName, myManagementAddress);
        }
    }

    private void rememberRequest(final Message m) {
        if (delayedRequests == null) {
            delayedRequests = new ArrayList<Message>();
        }
        delayedRequests.add(m);
    }

    private void processRememberedRequests() {
        if (delayedRequests != null) {
            for (Message m : delayedRequests) {
                managementCommunication.incomingMessage(m);
            }
            delayedRequests.clear();
            delayedRequests = null;
        }
    }

    private void dispose() {
        lock.lock();
        try {
            // cancel timer
            if (timerTask != null) {
                timerTask.cancel();
                timerTask = null;
            }

            if (state == State.REGISTERED) {
                // deregister

                final Message m = Message.newInstance(Integer.toString(PERFORMATIVE_DEREGISTER), myManagementAddress, masterManagementCommunication);
                m.setVisibilityID(-1);
                try {
                    sendMessage(m);
                } catch (InvisibleContainerException e) {
                }
                logForAnalyzer(MANAGEMENT_TRAFFIC, m, false);
                m.release();

            }

            if (myConfigurator != null) {
                myConfigurator.kill();
                myConfigurator = null;
            }

            // remove container messaging
            MessageTransport.deregisterMessageTransport(systemContainerName);

            if (TOPIC_FLOW_ANALYZER_ENABLED) {
                if (regularStatTask != null) {
                    regularStatTask.cancel();
                    regularStatTask = null;
                }
                analyzerRecord.clear();
                analyzerRecord = null;
            }

        } finally {
            lock.unlock();
        }
    }

    private void registerNewParticipant(final Address adr) {
        if (registered.contains(adr)) {
            Logger.logSevere("Second registration: "+adr + "\nReplace the old subscription by new one");

            // remove old one from registered and neighbors
            registered.remove(adr);
            neighbors.remove(adr);

            // remove all its notifiers
            final Address hisManagementAddress = adr.deriveServiceAddress(SERVICE_NAME);
            final Iterator<Map.Entry<String, DirectoryRecord>> iter = directoryRecords.entrySet().iterator();
            while (iter.hasNext()) {
                final Map.Entry<String, DirectoryRecord> entry = iter.next();
                final DirectoryRecord dr = entry.getValue();
                if (dr.directoryNotifiers.remove(hisManagementAddress)) {
                    // remove unused record
                    if ((dr.directoryNotifiers.size() == 0) && (dr.directorySubscription.size() == 0)) {
                        iter.remove();
                    }
                }
            }

            // remove all its subscriptions and thus notify local and/or remote subscribers
            final Address hisDataAddress = adr.deriveAgentAddress(AGENT_NAME);
            final Iterator<Map.Entry<String, DirectoryRecord>> iter2 = directoryRecords.entrySet().iterator();
            while (iter2.hasNext()) {
                final Map.Entry<String, DirectoryRecord> entry = iter2.next();
                final String topic = entry.getKey();
                final DirectoryRecord dr = entry.getValue();
                if (dr.directorySubscription.remove(hisDataAddress)) {
                    // first check for local subscription notifiers
                    final TopicRecord tr = topicsRecords.get(topic);
                    if ((tr != null) && (dr.directorySubscription.size() == 0) && (tr.localSubscribers.size() == 0) && (tr.localNotifiers.size() > 0)) {
                        // the last subscription from local perspective has been removed
                        for (final TopicsSubscriptionNotifier notifier : tr.localNotifiers) {
                            notifier.addEvent(new Runnable() {
                                @Override
                                public void run() {
                                    notifier.noSubscriber(topic);
                                }
                            });
                        }
                    }

                    // notify others about this unsubscription
                    if (dr.directoryNotifiers.size() > 0) {
                        // do not send SELF notifications !!!
                        final LinkedHashSet<Address> toNotify = new LinkedHashSet<Address>(dr.directoryNotifiers);
                        toNotify.remove(hisManagementAddress);
                        if (toNotify.size() > 0) {
                            final Message notify = Message.newInstance(Integer.toString(PERFORMATIVE_NOTIFY_REMOVE_SUBSCRIBER), myManagementAddress, toNotify);
                            notify.setVisibilityID(-1);
                            notify.setProtocol(topic);
                            notify.setContent(hisDataAddress);
                            try {
                                sendMessage(notify);
                            } catch (InvisibleContainerException e) {
                            }
                            logForAnalyzer(MANAGEMENT_TRAFFIC, notify, false);
                            notify.release();
                        }
                    }

                    if ((dr.directorySubscription.size() == 0) && (dr.directoryNotifiers.size() == 0)) {
                        // remove unused record
                        iter2.remove();
                    }
                }
            }

            // then continue with new registration
        }

        final Message m = Message.newInstance(Integer.toString(PERFORMATIVE_REGISTER_RESPONSE), myManagementAddress, adr);
        m.setVisibilityID(-1);
        final AddressesExchanger ne = new AddressesExchanger();
        ne.addresses.addAll(registered);
        m.setContent(ne);
        try {
            sendMessage(m);


            final Message m2 = Message.newInstance(Integer.toString(PERFORMATIVE_ADD_NEIGHBOR), myManagementAddress, registered);
            m2.setVisibilityID(-1);
            m2.setContent(adr);
            try {
                sendMessage(m2);
            } catch (InvisibleContainerException e2) {

            }
            logForAnalyzer(MANAGEMENT_TRAFFIC, m2, false);
            m2.release();

            registered.add(adr);
            neighbors.add(adr);
        } catch (InvisibleContainerException e) {
        }
        logForAnalyzer(MANAGEMENT_TRAFFIC, m, false);
        m.release();
    }

    private void deregisterParticipant(final Address adr) {
        // clear all related registrations !!!
        final Address dataAddress = adr.deriveAgentAddress(AGENT_NAME);
        if (directoryRecords.size() > 0) {
            Iterator<Map.Entry<String, DirectoryRecord>> iter = directoryRecords.entrySet().iterator();
            while (iter.hasNext()) {
                final Map.Entry<String, DirectoryRecord> entry = iter.next();
                final DirectoryRecord dr = entry.getValue();
                final String topic = entry.getKey();
                dr.directoryNotifiers.remove(adr);
                if (dr.directorySubscription.remove(dataAddress)) {
                    if (dr.directoryNotifiers.size() > 0) {
                        // notify remote notifiers about removal
                        final Message m = Message.newInstance(Integer.toString(PERFORMATIVE_NOTIFY_REMOVE_SUBSCRIBER), myManagementAddress, dr.directoryNotifiers);
                        m.setVisibilityID(-1);
                        m.setProtocol(topic);
                        m.setContent(dataAddress);
                        try {
                            sendMessage(m);
                        } catch (InvisibleContainerException e) {
                        }
                        logForAnalyzer(MANAGEMENT_TRAFFIC, m, false);
                        m.release();
                    }

                    final TopicRecord tr = topicsRecords.get(topic);
                    if ((tr != null) && (tr.localSubscribers.size() == 0) && (tr.localNotifiers.size() > 0)) {
                        for (final TopicsSubscriptionNotifier notifier : tr.localNotifiers) {
                            notifier.addEvent(new Runnable() {

                                @Override
                                public void run() {
                                    notifier.noSubscriber(topic);
                                }

                            });
                        }
                    }

                    if ((dr.directorySubscription.size() == 0) && (dr.directoryNotifiers.size() == 0)) {
                        iter.remove();
                    }
                }
            }
        }

        registered.remove(adr);
        neighbors.remove(adr);

        final Message m = Message.newInstance(Integer.toString(PERFORMATIVE_REMOVE_NEIGHBOR), myManagementAddress, registered);
        m.setVisibilityID(-1);
        m.setContent(adr);
        try {
            sendMessage(m);
        } catch (InvisibleContainerException e) {
        }
        logForAnalyzer(MANAGEMENT_TRAFFIC, m, false);
        m.release();
    }

    private void registerWithinMaster(final Address serverAddress) {
        if (state == State.REGISTERED) {
            // release all known registrations
            if (topicsRecords.size() > 0) {
                for (TopicRecord tr : topicsRecords.values()) {
                    tr.unknownRemoteSubscription = true;
                    tr.remoteSubscribers.clear();
                }
            }
        } else if (state == State.REGISTER_WITHIN_MASTER) {
            if (serverAddress == masterManagementCommunication) {
                // already requesting registration for the same server
                return;
            }
        }

        registered.clear();

        positiveCanBeMasterResponses = null;

        if (timerTask != null) {
            timerTask.cancel();
            timerTask = null;
        }
        masterManagementCommunication = serverAddress;

        state = State.REGISTER_WITHIN_MASTER;
        final Message registering = Message.newInstance(Integer.toString(PERFORMATIVE_REGISTER_REQUEST), myManagementAddress, masterManagementCommunication);
        registering.setVisibilityID(-1);
        try {
            sendMessage(registering);
            // schedule timer
            timerTask = new TimerTask() {

                @Override
                public void run() {
                    lock.lock();
                    try {
                        if ((state != State.REGISTER_WITHIN_MASTER) || (timerTask != this)) {
                            return;
                        }
                        timerTask = null;
                        Logger.logWarning("Cannot register within: "+masterManagementCommunication+". Search for a new matchmaker.");
                        serverLost();
                    } finally {
                        lock.unlock();
                    }
                }
            };
            try {
                Platform.TIMER.schedule(timerTask, TIMEOUT_MILLIS);
            } catch (Exception e) {
                // Timer is already canceled
            }
        } catch (InvisibleContainerException e) {
            e.printStackTrace();
            serverLost();
        }
        logForAnalyzer(MANAGEMENT_TRAFFIC, registering, false);
        registering.release();
    }

    private void becomeMaster() {
        // create itself as a server
        Logger.logWarning("I became master for system: "+systemName);

        state = State.IS_MASTER;
        masterManagementCommunication = null;

        registered.clear();
        registered.add(myManagementAddress);

        // process delayed requests
        processRememberedRequests();

        if (!topicsNoKeepAlive) {
            // periodical keep alive
            timerTask = new TimerTask() {

                @Override
                public void run() {
                    lock.lock();
                    try {
                        if (state == State.IS_MASTER) {
                            final Message m = Message.newInstance(Integer.toString(PERFORMATIVE_KEEP_ALIVE), myManagementAddress, registered);
                            m.setVisibilityID(-1);
                            try {
                                sendMessage(m);
                            } catch (InvisibleContainerException e) {
                            }
                            logForAnalyzer(MANAGEMENT_TRAFFIC, m, false);
                            m.release();
                        }
                    } finally {
                        lock.unlock();
                    }
                }

            };
            try {
                Platform.TIMER.schedule(timerTask, SERVER_KEEP_ALIVE_INTERVAL, SERVER_KEEP_ALIVE_INTERVAL);
            } catch (Exception e1) {
                // Timer is already canceled
            }
        }

        if (neighbors.size() > 0) {
            // redirect known neighbors
            final Message m = Message.newInstance(Integer.toString(PERFORMATIVE_REDIRECT_TO_SERVER), myManagementAddress, neighbors);
            m.setVisibilityID(-1);
            m.setContent(myManagementAddress);
            try {
                sendMessage(m);
            } catch (InvisibleContainerException e) {
            }
            logForAnalyzer(MANAGEMENT_TRAFFIC, m, false);
            m.release();
        }

        // unblock all local waiters
        for (TopicRecord tr : topicsRecords.values()) {
            // wake up all possible synchronous subscribers
            if (tr.blocker != null) {
                tr.blocker.signalAll();
                tr.blocker = null;
            }
        }

    }

    private void newlyRegistered(final Collection<Address> newNeighbors) {
        Logger.logInfo("Registered within: "+masterManagementCommunication);

        if (timerTask != null) {
            timerTask.cancel();
            timerTask = null;
        }



        state = State.REGISTERED;
        neighbors.clear();
        neighbors.addAll(newNeighbors);

        processRememberedRequests();

        if (!topicsNoKeepAlive) {
            // build keep alive detector
            timerTask = new TimerTask() {

                @Override
                public void run() {
                    lock.lock();
                    try {
                        if (state == State.REGISTERED) {
                            if (keepAliveCnt > 0) {
                                // all ok
                                keepAliveCnt = 0;
                            } else {
                                // no server ?
                                Logger.logWarning("Haven't received keep alive from master TopicsManager within the last "+(2*SERVER_KEEP_ALIVE_INTERVAL + TIMEOUT_MILLIS)+" ms.");
                                serverLost();
                            }
                        }
                    } finally {
                        lock.unlock();
                    }
                }

            };
            try {
                Platform.TIMER.schedule(timerTask, 2*SERVER_KEEP_ALIVE_INTERVAL + TIMEOUT_MILLIS, 2*SERVER_KEEP_ALIVE_INTERVAL);
            } catch (Exception e1) {
                // Timer is already canceled
            }
        }

        //send all requests to new server
        if (topicsRecords.size() > 0) {
            for (Map.Entry<String, TopicRecord> entry : topicsRecords.entrySet()) {
                final String topic = entry.getKey();
                final TopicRecord tr = entry.getValue();
                if (tr.localSubscribers.size() > 0) {
                    final Message m = Message.newInstance(Integer.toString(PERFORMATIVE_SUBSCRIBE), myDataAddress, masterManagementCommunication);
                    m.setVisibilityID(-1);
                    m.setReason(topic);
                    try {
                        sendMessage(m);
                    } catch (InvisibleContainerException e) {
                        serverLost();
                        return;
                    } finally {
                        logForAnalyzer(MANAGEMENT_TRAFFIC, m, false);
                        m.release();
                    }
                }

                if ((tr.localNotifiers.size() > 0) || (tr.localTopicsProviders.size() > 0) || (tr.localTempTopicsCache.size() > 0)) {
                    final Message m = Message.newInstance(Integer.toString(PERFORMATIVE_REGISTER_NOTIFIER), myManagementAddress, masterManagementCommunication);
                    m.setVisibilityID(-1);
                    m.setReason(topic);
                    try {
                        sendMessage(m);
                    } catch (InvisibleContainerException e) {
                        serverLost();
                        return;
                    } finally {
                        logForAnalyzer(MANAGEMENT_TRAFFIC, m, false);
                        m.release();
                    }
                }
            }
        }
    }

    private void serverLost() {
        if (timerTask != null) {
            timerTask.cancel();
            timerTask = null;
        }

        if (state == State.REGISTERED) {
            // release all known registrations
            if (topicsRecords.size() > 0) {
                for (TopicRecord tr : topicsRecords.values()) {
                    if (!tr.unknownRemoteSubscription) {
                        tr.unknownRemoteSubscription = true;
                        tr.remoteSubscribers.clear();
                    }
                }
            }
        }

        state = State.CAN_BE_MASTER_CHECK;

        positiveCanBeMasterResponses = new LinkedHashSet<Address>();

        AglobeThreadPool.startInNewThread(new Runnable() {

            @Override
            public void run() {
                timerTask = new TimerTask() {

                    @Override
                    public void run() {
                        lock.lock();
                        try {
                            if (state == State.CAN_BE_MASTER_CHECK) {
                                // don't receive all responses
                                neighbors.clear();
                                neighbors.addAll(positiveCanBeMasterResponses);
                                positiveCanBeMasterResponses = null;

                                becomeMaster();
                            }
                        } finally {
                            lock.unlock();
                        }

                    }

                };
                try {
                    Platform.TIMER.schedule(timerTask, TIMEOUT_MILLIS);
                } catch (Exception e) {
                    // timer is already canceled
                }
                final Message m = Message.newInstance(Integer.toString(PERFORMATIVE_CAN_BE_MASTER_QUERY), myManagementAddress, neighbors);
                m.setVisibilityID(-1);
                try {
                    sendMessage(m);
                } catch (InvisibleContainerException e) {
                }
                if (TOPIC_FLOW_ANALYZER_ENABLED) {
                    lock.lock();
                    try {
                        logForAnalyzer(MANAGEMENT_TRAFFIC, m, false);
                    } finally {
                        lock.unlock();
                    }
                }
                m.release();
            }

        }, "Can be master");
    }

    // ---------------------------------------------------------------------
    // operation methods
    // ---------------------------------------------------------------------

    final void subscribe(final boolean sync, final String topic, final TopicsHandler handler) {
        lock.lock();
        try {
            TopicRecord tr = topicsRecords.get(topic);
            if (tr == null) {
                tr = new TopicRecord();
                topicsRecords.put(topic, tr);
            }

            if (tr.localSubscribers.size() == 0) {
            	// the first local subscription
                tr.localSubscribers.add(handler);
                
                if (state == State.IS_MASTER) {
                    // I'm master
                    final DirectoryRecord dr = directoryRecords.get(topic);
                    if ((dr == null) || (dr.directorySubscription.size() == 0)) {
                        // the first subscription ever
                        // notify local notifiers
                        if (tr.localNotifiers.size() > 0) {
                            for (final TopicsSubscriptionNotifier notifier : tr.localNotifiers) {
                                notifier.addEvent(new Runnable() {
                                    @Override
                                    public void run() {
                                        notifier.hasSubscriber(topic);
                                    }
                                });
                            }
                        }
                    }

                    // check notifiers
                    if (dr != null) {
                        if (dr.directoryNotifiers.size() > 0) {
                            // propagate subscription
                            final Message m = Message.newInstance(Integer.toString(PERFORMATIVE_NOTIFY_ADD_SUBSCRIBER), myManagementAddress, dr.directoryNotifiers);
                            m.setVisibilityID(-1);
                            m.setProtocol(topic);
                            m.setContent(myDataAddress);
                            try {
                                sendMessage(m);
                            } catch (InvisibleContainerException e) {
                            }
                            logForAnalyzer(MANAGEMENT_TRAFFIC, m, false);
                            m.release();
                        }
                    }

                } else if (state == State.REGISTERED) {
                    if (tr.remoteSubscribers.size() == 0) {
                        // the first subscription ever
                        // notify local notifiers
                        if (tr.localNotifiers.size() > 0) {
                            for (final TopicsSubscriptionNotifier notifier : tr.localNotifiers) {
                                notifier.addEvent(new Runnable() {
                                    @Override
                                    public void run() {
                                        notifier.hasSubscriber(topic);
                                    }
                                });
                            }
                        }
                    }
                    // registered within other master
                    // send subscription to the master
                    final Message m = Message.newInstance(Integer.toString(PERFORMATIVE_SUBSCRIBE), myDataAddress, masterManagementCommunication);
                    m.setVisibilityID(-1);
                    m.setReason(topic);
                    if (sync) {
                        tr.subscribeBlockId++;
                        m.setProtocol(Integer.toString(tr.subscribeBlockId));
                    }
                    try {
                        sendMessage(m);
                    } catch (InvisibleContainerException e) {
                        serverLost();
                    }
                    logForAnalyzer(MANAGEMENT_TRAFFIC, m, false);
                    m.release();
                    if (sync) {
                        // block till response about successful registration
                        if (tr.blocker == null) {
                            tr.blocker = lock.newCondition();
                        }
                        try {
                            tr.blocker.await();
                        } catch (InterruptedException e) {
                        }
                    }
                }
            }
            else {
                tr.localSubscribers.add(handler);
            }

        } finally {
            lock.unlock();
        }
    }

    final void unsubscribe(final String topic, final TopicsHandler handler) {
        lock.lock();
        try {
            final TopicRecord tr = topicsRecords.get(topic);
            if (tr != null) {
                if (tr.localSubscribers.remove(handler)) {

                    if (tr.localSubscribers.size() == 0) {
                        // the last local subscriber has been removed

                        if (state == State.IS_MASTER) {
                            // I'm master
                            final DirectoryRecord dr = directoryRecords.get(topic);
                            if ((dr == null) || (dr.directorySubscription.size() == 0)) {
                                // there is no subscription anymore
                                // notify local notifiers
                                if (tr.localNotifiers.size() > 0) {
                                    for (final TopicsSubscriptionNotifier notifier : tr.localNotifiers) {
                                        notifier.addEvent(new Runnable() {
                                            @Override
                                            public void run() {
                                                notifier.noSubscriber(topic);
                                            }
                                        });
                                    }
                                }
                            }
                            // check notifiers
                            if (dr != null) {
                                if (dr.directoryNotifiers.size() > 0) {
                                    final Message m = Message.newInstance(Integer.toString(PERFORMATIVE_NOTIFY_REMOVE_SUBSCRIBER), myManagementAddress, dr.directoryNotifiers);
                                    m.setVisibilityID(-1);
                                    m.setProtocol(topic);
                                    m.setContent(myDataAddress);
                                    try {
                                        sendMessage(m);
                                    } catch (InvisibleContainerException e) {
                                    }
                                    logForAnalyzer(MANAGEMENT_TRAFFIC, m, false);
                                    m.release();
                                }
                            }

                        } else if (state == State.REGISTERED) {
                            // registered within other master
                            if (tr.remoteSubscribers.size() == 0) {
                                // there is no subscription anymore
                                // notify local notifiers
                                if (tr.localNotifiers.size() > 0) {
                                    for (final TopicsSubscriptionNotifier notifier : tr.localNotifiers) {
                                        notifier.addEvent(new Runnable() {
                                            @Override
                                            public void run() {
                                                notifier.noSubscriber(topic);
                                            }
                                        });
                                    }
                                }
                            }

                            // send unsubscription to the master
                            final Message m = Message.newInstance(Integer.toString(PERFORMATIVE_UNSUBSCRIBE), myDataAddress, masterManagementCommunication);
                            m.setVisibilityID(-1);
                            m.setReason(topic);
                            try {
                                sendMessage(m);
                            } catch (InvisibleContainerException e) {
                                serverLost();
                            }
                            logForAnalyzer(MANAGEMENT_TRAFFIC, m, false);
                            m.release();
                        }

                        if ((tr.localNotifiers.size() == 0) && (tr.localTopicsProviders.size() == 0) && (tr.localTempTopicsCache.size() == 0)) {
                            // remove unused record
                            topicsRecords.remove(topic);
                        }
                    }
                }
            }
        } finally {
            lock.unlock();
        }
    }

    final void registerSubscriptionNotifier(final String topic, final TopicsSubscriptionNotifier notifier) {
        lock.lock();
        try {
            TopicRecord tr = topicsRecords.get(topic);
            if (tr == null) {
                tr = new TopicRecord();
                topicsRecords.put(topic, tr);
            }

            if (state == State.IS_MASTER) {
                final DirectoryRecord dr = directoryRecords.get(topic);
                if ((tr.localSubscribers.size() > 0) || ((dr != null) && (dr.directorySubscription.size() > 0))) {
                    notifier.addEvent(new Runnable() {
                        @Override
                        public void run() {
                            notifier.hasSubscriber(topic);
                        }

                    });
                } else {
                    notifier.addEvent(new Runnable() {
                        @Override
                        public void run() {
                            notifier.noSubscriber(topic);
                        }

                    });
                }
            } else {
                if ((state == State.REGISTERED) && (tr.localNotifiers.size() == 0) && (tr.localTopicsProviders.size() == 0) && (tr.localTempTopicsCache.size() == 0)) {
                    // the first registration
                    final Message m = Message.newInstance(Integer.toString(PERFORMATIVE_REGISTER_NOTIFIER), myManagementAddress, masterManagementCommunication);
                    m.setVisibilityID(-1);
                    m.setReason(topic);
                    try {
                        sendMessage(m);
                    } catch (InvisibleContainerException e) {
                        serverLost();
                    }
                    logForAnalyzer(MANAGEMENT_TRAFFIC, m, false);
                    m.release();
                }
                if ((tr.localSubscribers.size() > 0) || ((!tr.unknownRemoteSubscription) && (tr.remoteSubscribers.size() > 0))) {
                    notifier.addEvent(new Runnable() {
                        @Override
                        public void run() {
                            notifier.hasSubscriber(topic);
                        }

                    });
                } else if (!tr.unknownRemoteSubscription) {
                    notifier.addEvent(new Runnable() {
                        @Override
                        public void run() {
                            notifier.noSubscriber(topic);
                        }

                    });
                }
            }
            tr.localNotifiers.add(notifier);
        } finally {
            lock.unlock();
        }
    }

    final void deregisterSubscriptionNotifier(final String topic, final TopicsSubscriptionNotifier notifier) {
        lock.lock();
        try {
            final TopicRecord tr = topicsRecords.get(topic);
            if (tr != null) {
                if (tr.localNotifiers.remove(notifier)) {

                    if ((state == State.REGISTERED) && (tr.localNotifiers.size() == 0) && (tr.localTopicsProviders.size() == 0) && (tr.localTempTopicsCache.size() == 0)) {
                        tr.unknownRemoteSubscription = true;
                        tr.remoteSubscribers.clear();

                        // deregister notifier
                        final Message m = Message.newInstance(Integer.toString(PERFORMATIVE_DEREGISTER_NOTIFIER), myManagementAddress, masterManagementCommunication);
                        m.setVisibilityID(-1);
                        m.setReason(topic);
                        try {
                            sendMessage(m);
                        } catch (InvisibleContainerException e) {
                            serverLost();
                        }
                        logForAnalyzer(MANAGEMENT_TRAFFIC, m, false);
                        m.release();
                    }

                    if ((tr.localNotifiers.size() == 0) && (tr.localSubscribers.size() == 0) && (tr.localTopicsProviders.size() == 0)) {
                        // remove unused record
                        tr.clearTempTopicsCache();
                        topicsRecords.remove(topic);
                    }
                }
            }
        } finally {
            lock.unlock();
        }
    }

    final void sendTopic(final TopicsService.Shell provider, final String topic, final Object content, final String reason) {
        lock.lock();
        try {
            TopicRecord tr = topicsRecords.get(topic);
            if (tr == null) {
                tr = new TopicRecord();
                topicsRecords.put(topic, tr);
            }

            final PooledObject po;
            if ((content != null) && (content instanceof PooledObject)) {
                po = (PooledObject) content;
            } else {
                po = null;
            }

            if (tr.localSubscribers.size() > 0) {
                for (final TopicsHandler handler : tr.localSubscribers) {
                    if (po != null) {
                        po.registerHolder();
                    }
                    handler.addEvent(new Runnable() {

                        @Override
                        public void run() {
                            handler.handleIncomingTopic(topic, content, reason);
                        }

                    });
                }
            }

            if (state == State.IS_MASTER) {
                final DirectoryRecord dr = directoryRecords.get(topic);
                if ((dr != null) && (dr.directorySubscription.size() > 0)) {
                    final Message m = Message.newInstance(topic, myDataAddress, dr.directorySubscription);
                    m.setVisibilityID(-1);
                    m.setContent(content);
                    if (po != null) {
                        po.registerHolder();
                    }
                    m.setReason(reason);
                    try {
                        sendMessage(m);
                    } catch (InvisibleContainerException e) {
                    }
                    logForAnalyzer(topic, m, false);
                    m.release();
                }
            } else {
                if (state == State.REGISTERED) {
                    if ((tr.localTopicsProviders.size() == 0) && (tr.localNotifiers.size() == 0) && (tr.localTempTopicsCache.size() == 0)) {
                        final Message m = Message.newInstance(Integer.toString(PERFORMATIVE_REGISTER_NOTIFIER), myManagementAddress, masterManagementCommunication);
                        m.setVisibilityID(-1);
                        m.setReason(topic);
                        try {
                            sendMessage(m);
                        } catch (InvisibleContainerException e) {
                            serverLost();
                        }
                        logForAnalyzer(MANAGEMENT_TRAFFIC, m, false);
                        m.release();
                    }
                    if (tr.unknownRemoteSubscription) {
                        // remember it for later purposes
                        tr.localTempTopicsCache.addLast(HistoryRecord.getHistoryQueue(content, po, reason));
                    } else {
                        if (tr.remoteSubscribers.size() > 0) {
                            final Message m = Message.newInstance(topic, myDataAddress, tr.remoteSubscribers);
                            m.setVisibilityID(-1);
                            m.setContent(content);
                            if (po != null) {
                                po.registerHolder();
                            }
                            m.setReason(reason);
                            try {
                                sendMessage(m);
                            } catch (InvisibleContainerException e) {
                            }
                            logForAnalyzer(topic, m, false);
                            m.release();
                        }
                    }
                } else {
                    // Neither IS_MASTER nor REGISTERED
                    if (tr.unknownRemoteSubscription) {
                        // remember it for later purposes
                        tr.localTempTopicsCache.addLast(HistoryRecord.getHistoryQueue(content, po, reason));
                    }
                }
                tr.localTopicsProviders.add(provider);
            }

        } finally {
            lock.unlock();
        }
    }

    final void deregisterTopicProvider(final TopicsService.Shell provider, final String topic) {
        lock.lock();
        try {
            final TopicRecord tr = topicsRecords.get(topic);
            if (tr != null) {
                if (tr.localTopicsProviders.remove(provider)) {
                    if ((tr.localTopicsProviders.size() == 0) && (tr.localNotifiers.size() == 0) && (tr.localTempTopicsCache.size() == 0)) {
                        if (state == State.REGISTERED) {
                            tr.unknownRemoteSubscription = true;
                            tr.remoteSubscribers.clear();

                            // remove registration registration from server
                            final Message m = Message.newInstance(Integer.toString(PERFORMATIVE_DEREGISTER_NOTIFIER), myManagementAddress, masterManagementCommunication);
                            m.setVisibilityID(-1);
                            m.setReason(topic);
                            try {
                                sendMessage(m);
                            } catch (InvisibleContainerException e) {
                                serverLost();
                            }
                            logForAnalyzer(MANAGEMENT_TRAFFIC, m, false);
                            m.release();
                        }
                        if (tr.localSubscribers.size() == 0) {
                            // remove unused record
                            topicsRecords.remove(topic);
                        }
                    }
                }
            }
        } finally {
            lock.unlock();
        }
    }

    // -------------------------------------------------------
    //  internal methods
    // -------------------------------------------------------

    private final void logForAnalyzer(final String topic, final Message message, final boolean in) {
        if (TOPIC_FLOW_ANALYZER_ENABLED) {
            AnalyzerRecord ar = analyzerRecord.get(topic);
            if (ar == null) {
                ar = new AnalyzerRecord(topic);
                analyzerRecord.put(topic, ar);
            }
            final int topicNameLength = topic.length();
            if (topicNameLength > maxTopicName) {
                maxTopicName = topicNameLength;
            }

            final int size = message.getMessageSize();
            if (in) {
                ar.icnt++;
                ar.icntpersec++;
                ar.in += size;
                ar.inpersec += size;
            } else {
                ar.ocnt++;
                ar.ocntpersec++;
                ar.out += size;
                ar.outpersec += size;
            }
        }
    }


    private void sendMessage(final Message m) throws InvisibleContainerException {
        if (m.getSender() == null) {
            throw new IllegalArgumentException("Message has no sender: "+m);
        }
        if (TOPIC_FLOW_ANALYZER_ENABLED) {
            m.setMessageSizeRequired();
        }
        if (m.isMulticast()) {
            MessageTransport.sendMulticastMessage(m);
        } else {
            MessageTransport.sendStandardMessage(m);
        }
    }

    /* @internal
     * (non-Javadoc)
     * @see aglobe.platform.MessageTransportComponent#processReceivedMessage(aglobe.ontology.Message, aglobe.platform.transport.MessageReceiver)
     */
    @Override
    public void processReceivedMessage(Message msg, MessageReceiver receiver) {
        receiver.incomingMessage(msg);
    }

    /* @internal
     * (non-Javadoc)
     * @see aglobe.platform.transport.MessageReceiverSplitter#getMessageReceiver(aglobe.container.transport.Address)
     */
    @Override
    public MessageReceiver getMessageReceiver(Address receiver) throws RecepientNotFound {
        if (receiver.isAgent()) {
            // data exchange
            return dataCommunication;
        } else {
            // system exchange
            return managementCommunication;
        }
    }

    final static class HistoryRecord {
        private static final NonblockingPoolArrayFIFO<HistoryRecord> historyQueuePool = new NonblockingPoolArrayFIFO<HistoryRecord>(1000000);

        private Object content;
        private PooledObject po;
        private String reason;

        private static final HistoryRecord getHistoryQueue(final Object content, final PooledObject po, final String reason) {
            if (po != null) {
                po.registerHolder();
            }
            HistoryRecord hq = historyQueuePool.pop();
            if (hq == null) {
                return new HistoryRecord(content, po, reason);
            } else {
                hq.update(content, po, reason);
                return hq;
            }
        }

        private HistoryRecord(final Object content, final PooledObject po, final String reason) {
            update(content, po, reason);
        }

        private final void update(final Object content, final PooledObject po, final String reason) {
            this.content = content;
            this.po = po;
            this.reason = reason;
        }

        final void release() {
            this.content = null;
            this.reason = null;
            if (this.po != null) {
                this.po.release();
                this.po = null;
            }

            historyQueuePool.push(this);
        }
    }

    // --------------------------------------------------------
    // Analyzer
    // --------------------------------------------------------

    private final static class AnalyzerRecord {
        private final String topic;
        private int icntpersec;
        private int ocntpersec;
        private int inpersec;
        private int outpersec;
        private long icnt;
        private long ocnt;
        private long in;
        private long out;

        private AnalyzerRecord(final String topic) {
            this.topic = topic;
        }
    }

    // --------------------------------------------------------
    // Neighbor exchanger
    // --------------------------------------------------------

    public final static class AddressesExchanger implements Externalizable {
        private final LinkedHashSet<Address> addresses = new LinkedHashSet<Address>();

        /* (non-Javadoc)
         * @see java.io.Externalizable#readExternal(java.io.ObjectInput)
         */
        @Override
        public final void readExternal(final ObjectInput in) throws IOException, ClassNotFoundException {
            final int cnt = in.readInt();
            if (cnt > 0) {
                if (in instanceof LibraryObjectInputStream) {
                    final AddressReader ar = ((LibraryObjectInputStream)in).addressReader;
                    for (int i=0; i<cnt; i++) {
                        final Address adr = ar.readAddress(in.readShort());
                        if (adr == null) {
                            throw new IOException("Cannot resolve address");
                        }
                        addresses.add(adr);
                    }
                } else {
                    for (int i=0; i<cnt; i++) {
                        final Address adr = Address.getAddress(in.readLong());
                        if (adr == null) {
                            throw new IOException("Cannot resolve address");
                        }
                        addresses.add(adr);
                    }
                }
            }
        }

        /* (non-Javadoc)
         * @see java.io.Externalizable#writeExternal(java.io.ObjectOutput)
         */
        @Override
        public final void writeExternal(final ObjectOutput out) throws IOException {
            final int cnt = addresses.size();
            out.writeInt(cnt);
            if (cnt > 0) {
                if (out instanceof MessageObjectOutputStream) {
                    final AddressWriter aw = ((MessageObjectOutputStream)out).adderessWriter;
                    for (Address adr : addresses) {
                        out.writeShort(aw.writeAddress(adr));
                    }
                } else {
                    for (Address adr : addresses) {
                        out.writeLong(adr.getAddressId());
                    }
                }
            }
        }
    }

    @Override
    public Address translateMessageReceiver(Address receiver) {
        return receiver;
    }
}
