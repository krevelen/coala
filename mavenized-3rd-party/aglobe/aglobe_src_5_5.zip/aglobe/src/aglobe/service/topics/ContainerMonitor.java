/**
 *
 */
package aglobe.service.topics;

import java.io.Serializable;

import aglobe.container.ElementaryEntity;
import aglobe.container.transport.Address;

/**
 * <p>Title: ContainerMonitor</p>
 *
 * <p>Description: This monitor provides information about existence of container using
 * given ContainerHandler.</p>
 *
 * <p>Copyright: Copyright (c) 2009</p>
 *
 * <p>Company: Agent Technology Center</p>
 *
 * @author David Sislak
 * @version $Revision: 1.5 $ $Date: 2010/07/05 18:26:37 $
 *
 */
public final class ContainerMonitor implements Serializable {
	private static final long serialVersionUID = 7491043651885053049L;
	private static int sequenceNumber = 0;
    private TopicsService.Shell topicsShell;

    /**
     * Initialize container monitor. Containers' state is reported via provided
     * handler where all notifications are started within supplied owner's thread.
     * @param owner
     * @param handler
     * @throws Exception - is thrown when the owner is not running on the container
     * with topics service running
     */
    @SuppressWarnings("serial")
    public ContainerMonitor(final ElementaryEntity owner, final ContainerHandler handler) throws Exception {
        topicsShell = (TopicsService.Shell)owner.getContainer().getServiceManager().getService(owner, TopicsService.SERVICENAME);
        if (topicsShell == null) {
            throw new Exception("There is no topics service running on this container");
        }
        final String myTopicName = TopicsService.CONTAINER_MONITOR_PREFIX + owner.getAddress().getAddressId() + "_"+(sequenceNumber++);
        final TopicsHandler topicsHandler = new TopicsHandler() {

            @Override
            public void handleIncomingTopic(final String topic, final Object content, final String reason) {
                if (content != null) {
                    // new container
                    owner.addEvent(new Runnable() {

                        @Override
                        public void run() {
                            handler.containerStarted((Address)content);
                        }

                    });
                } else {
                    // container removed
                    owner.addEvent(new Runnable() {

                        @Override
                        public void run() {
                            handler.containerFinished(reason);
                        }

                    });
                }
            }

            @Override
            public void addEvent(Runnable e) {
                e.run();
            }

        };
        topicsShell.subscribeHandlerAsync(TopicsService.CONTAINER_MONITOR_ALL, topicsHandler);
        topicsShell.subscribeHandlerSync(myTopicName, topicsHandler);
        topicsShell.sendTopic(TopicsService.CONTAINER_IMPLEMENTOR_ALL, null, myTopicName);

    }

    public void dispose() {
        if (topicsShell != null) {
            topicsShell.dispose();
            topicsShell = null;
        }
    }
}
