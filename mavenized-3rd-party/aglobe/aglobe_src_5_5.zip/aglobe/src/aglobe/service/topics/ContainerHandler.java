/**
 *
 */
package aglobe.service.topics;

import java.io.Serializable;

import aglobe.container.transport.Address;


/**
 * <p>Title: ContainerHandler</p>
 *
 * <p>Description: The implementor of this interface is able to receive information
 * about newly started or finished containers by using ContainerMonitor. Methods
 * of this interface are invoked in the thread of owning ElementaryEntity supplied
 * for ContainerMonitor setup.</p>
 *
 * <p>Copyright: Copyright (c) 2009</p>
 *
 * <p>Company: Agent Technology Center</p>
 *
 * @author David Sislak
 * @version $Revision: 1.2 $ $Date: 2009/06/15 13:38:01 $
 *
 */
public interface ContainerHandler extends Serializable {
    /**
     * This methods is called when new container is started or identified.
     * @param containerAddress
     */
    public void containerStarted(final Address containerAddress);

    /**
     * This method is called when a container is finished.
     * @param containerName
     */
    public void containerFinished(final String containerName);
}
