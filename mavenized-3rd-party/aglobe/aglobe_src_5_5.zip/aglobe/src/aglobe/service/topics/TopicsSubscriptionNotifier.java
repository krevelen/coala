/**
 *
 */
package aglobe.service.topics;

import java.io.Serializable;

import aglobe.container.EventReceiver;

/**
 * <p>Title: TopicsSubscriptionNotifier</p>
 *
 * <p>Description: This interface is supposed to be used in the case of providing topics which
 * consume significant resources (both computational or memory). By this interface the producer of
 * these topics can be notified that it has sense to generate them because there is at least
 * one subscriber for them. After the initial registration of the notifier for some topic, the
 * hasSubscriber or noSubscriber is called. Then, methods are called only if the subscription
 * status is changed. Methods are invoked via Runnable passed through addEvent method of EventReceiver.</p>
 *
 * <p>Copyright: Copyright (c) 2009</p>
 *
 * <p>Company: Agent Technology Center</p>
 *
 * @author David Sislak
 * @version $Revision: 1.2 $ $Date: 2009/06/15 13:38:01 $
 *
 */
public interface TopicsSubscriptionNotifier extends EventReceiver, Serializable {

    /**
     * There is at least one subscriber for specified topic.
     * @param topic
     */
    public void hasSubscriber(final String topic);

    /**
     * There is no subscriber for specified topic.
     * @param topic
     */
    public void noSubscriber(final String topic);
}
