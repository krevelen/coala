/**
 *
 */
package aglobe.service.topics;

import java.util.LinkedHashSet;

import aglobe.container.transport.Address;

class DirectoryRecord {
    // contains data addresses
    LinkedHashSet<Address> directorySubscription = new LinkedHashSet<Address>();

    // contains management addresses
    LinkedHashSet<Address> directoryNotifiers = new LinkedHashSet<Address>();
}