/**
 *
 */
package aglobe.service.topics;

import java.util.ArrayDeque;
import java.util.LinkedHashSet;
import java.util.concurrent.locks.Condition;

import aglobe.container.transport.Address;
import aglobe.service.topics.TopicsManager.HistoryRecord;

class TopicRecord {
    // local knowledge base
    final LinkedHashSet<TopicsHandler> localSubscribers = new LinkedHashSet<TopicsHandler>();
    final LinkedHashSet<TopicsSubscriptionNotifier> localNotifiers = new LinkedHashSet<TopicsSubscriptionNotifier>();
    final LinkedHashSet<TopicsService.Shell> localTopicsProviders = new LinkedHashSet<TopicsService.Shell>();
    final ArrayDeque<HistoryRecord> localTempTopicsCache = new ArrayDeque<HistoryRecord>();
    int subscribeBlockId = 0;
    Condition blocker = null;

    // remote knowledge base
    boolean unknownRemoteSubscription = true;
    final LinkedHashSet<Address> remoteSubscribers = new LinkedHashSet<Address>();

    final void clearTempTopicsCache() {
        if (localTempTopicsCache.size() > 0) {
            for (HistoryRecord history : localTempTopicsCache) {
                history.release();
            }
            localTempTopicsCache.clear();
        }
    }
}
