/**
 *
 */
package aglobe.service.topics;

import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.concurrent.locks.ReentrantLock;

import aglobe.container.AgentContainer;
import aglobe.container.service.Service;
import aglobe.container.service.ServiceShell;
import aglobe.container.service.ShellOwner;
import aglobe.container.transport.Address;
import aglobe.ontology.Message;
import aglobe.util.ConversionTools;
import aglobe.util.Logger;

/**
 * <p>Title: TopicsService</p>
 *
 * <p>Description: Provides interface for working with topics</p>
 *
 * <p>Copyright: Copyright (c) 2009</p>
 *
 * <p>Company: Agent Technology Center</p>
 *
 * @author David Sislak
 * @version $Revision: 1.9 $ $Date: 2010/09/30 15:48:00 $
 *
 */
public final class TopicsService extends Service {
    /*
     * Topics service name
     */
    public final static String SERVICENAME = "topics";

    private final static String TOPICS_PREFIX = "!@";
    private static int TOPICS_CNT = 1;

    final static String CONTAINER_MONITOR_PREFIX = TOPICS_PREFIX + (TOPICS_CNT++);
    final static String CONTAINER_MONITOR_ALL = TOPICS_PREFIX + (TOPICS_CNT++);
    final static String CONTAINER_IMPLEMENTOR_ALL = TOPICS_PREFIX + (TOPICS_CNT++);

    private final String systemName;

    private String containerName;
    private Address containerAddress;

    private TopicsManager topicsManager = null;

    private ReentrantLock sync = new ReentrantLock();

    private LinkedHashSet<Shell> activeShells = new LinkedHashSet<Shell>();

    private Shell myContainerMonitorShell = null;

    /**
     * @internal
     * 
     * Do not use this method to get TopicsShell from ElementaryEntities (Agent or Service). It is supposed to be used only by the 
     * internal Aglobe container. 
     * 
     * Warining: This method returns TopicsShell which is connected with the first system created in JVM. Do not use this method
     * when more than one systems are running within the same JVM process (using different SystemNames).
     * 
     * @return
     */
    public static TopicsService.Shell getPlatformTopicsShell() {
    	return TopicsManager.getPlatformTopicsShell();
    }
    
    /**
     * @internal
     * @param systemName
     * @param topicsPlatforms
     */
    public TopicsService(final String systemName, final ArrayList<Address> topicsPlatforms, final boolean topicsNoKeepAlive) {
        this.systemName = systemName;
        topicsManager = TopicsManager.getTopicsManagerAndRegisterService(this, systemName, topicsPlatforms, topicsNoKeepAlive);
    }


    /* @internal
     * (non-Javadoc)
     * @see aglobe.container.service.Service#getServiceShell(aglobe.container.service.ShellOwner)
     */
    @Override
    protected ServiceShell getServiceShell(ShellOwner shellOwner) {
        Shell retVal = new Shell(shellOwner, this);
        registerActiveShell(retVal);
        return retVal;
    }

    private void registerActiveShell(Shell shell) {
        sync.lock();
        try {
            if (activeShells == null) {
                // during final clean-up
                return;
            }
            activeShells.add(shell);
        } finally {
            sync.unlock();
        }
    }

    private void removeActiveShell(Shell shell) {
        sync.lock();
        try {
            if (activeShells == null) {
                // during final clean-up
                return;
            }
            activeShells.remove(shell);
        } finally {
            sync.unlock();
        }
    }

    /* @internal
     * (non-Javadoc)
     * @see aglobe.container.service.Service#startService()
     */
    @Override
    public void init() {
        containerName = getContainer().getContainerName();
        containerAddress = getAddress().deriveContainerAddress();
    }

    /* @internal
     * (non-Javadoc)
     * @see aglobe.container.service.Service#stopService()
     */
    @Override
    public void finish() {
        if (myContainerMonitorShell != null) {
            myContainerMonitorShell.sendTopic(CONTAINER_MONITOR_ALL, null, containerName);
            myContainerMonitorShell.dispose();
            myContainerMonitorShell = null;
        }
        // first dispose all active shells
        final LinkedHashSet<Shell> currentShells;
        sync.lock();
        try {
            currentShells = activeShells;
            activeShells = null;
        } finally {
            sync.unlock();
        }
        for (Shell shell : currentShells) {
            shell.dispose();
        }

        // disconnect from the topics manager
        if (topicsManager != null) {
            TopicsManager.deregisterService(this, systemName);
            topicsManager = null;
        }
    }

    /**
     * @internal
     * Called from the AgentContainer after successful container initialization
     */
    @SuppressWarnings("serial")
    public void afterContainerInitialization() {
        myContainerMonitorShell = (Shell) getServiceShell(this);
        if (myContainerMonitorShell == null) {
            logSevere("Cannot get own shell");
            return;
        }
        myContainerMonitorShell.subscribeHandlerSync(CONTAINER_IMPLEMENTOR_ALL, new TopicsHandler() {

            @Override
            public void handleIncomingTopic(String topic, Object content, String reason) {
                myContainerMonitorShell.sendTopic(reason, containerAddress);
            }

            @Override
            public void addEvent(Runnable e) {
                TopicsService.this.addEvent(e);
            }

        });
        myContainerMonitorShell.sendTopic(CONTAINER_MONITOR_ALL, containerAddress);
    }

    /* @internal
     * (non-Javadoc)
     * @see aglobe.container.MessageHandler#handleIncomingMessage(aglobe.ontology.Message)
     */
    @Override
    public void handleIncomingMessage(Message m) {
        Logger.logWarning("Unexpected incoming message: "+m);
    }

    /**
     *
     * <p>Title: TopicsService.Shell</p>
     *
     * <p>Description: Provides proxy object used for interacting with TopicsMessaging in AGLOBE.
     * The proxy object is useful especially in the case of owner migration and final clean-up.
     * 
     * TopicsService.Shell is not thread-safe be default.</p>
     *
     * <p>Copyright: Copyright (c) 2009</p>
     *
     * <p>Company: Agent Technology Center</p>
     *
     * @author David Sislak
     * @version $Revision: 1.9 $ $Date: 2010/09/30 15:48:00 $
     *
     */
    public static final class Shell extends ServiceShell {

        private transient TopicsService theservice = null;
        
        private transient TopicsManager topicsManager = null;

        private final LinkedHashMap<String, LinkedHashSet<TopicsHandler>> handlers = new LinkedHashMap<String, LinkedHashSet<TopicsHandler>>();

        private final LinkedHashMap<String, LinkedHashSet<TopicsSubscriptionNotifier>> notifiers = new LinkedHashMap<String, LinkedHashSet<TopicsSubscriptionNotifier>>();

        private final LinkedHashSet<String> providedTopics = new LinkedHashSet<String>();

        /**
         * True iff shell is in the post initialize state
         */
        private transient boolean postInit = false;

        /**
         * @internal
         * Constructor used for serialization purposes. DO NOT USE THIS
         * constructor.
         */
        public Shell() {
            super();
        }

        private Shell(final ShellOwner shellOwner, final TopicsService theservice) {
            super(shellOwner);
            this.theservice = theservice;
        }
        
        Shell(final TopicsManager topicsManager) {
        	super();
        	this.topicsManager = topicsManager;
        }



        /*
         * (non-Javadoc)
         * @see aglobe.container.service.ServiceShell#dispose()
         */
        @Override
        public final void dispose() {
        	if ((theservice == null) && (topicsManager == null)) {
        		// already disposed, this can happen during shut down phase, when it is disposed from TopicsService
        		//  finish method
        		return;
        	}

        	final TopicsManager tm = (topicsManager != null) ? topicsManager : theservice.topicsManager;
        	
        	// unsubscribe all, unregister all, but do not clear as it is required for migration purposes
        	for (String elem : providedTopics) {
        		tm.deregisterTopicProvider(this, elem);
        	}
        	for (Map.Entry<String, LinkedHashSet<TopicsSubscriptionNotifier>> elem : notifiers.entrySet()) {
        		final String topic = elem.getKey();
        		final LinkedHashSet<TopicsSubscriptionNotifier> ntf = elem.getValue();
        		for (TopicsSubscriptionNotifier topicsSubscriptionNotifier : ntf) {
        			tm.deregisterSubscriptionNotifier(topic, topicsSubscriptionNotifier);
        		}
        	}
        	for (Map.Entry<String, LinkedHashSet<TopicsHandler>> elem : handlers.entrySet()) {
        		final String topic = elem.getKey();
        		final LinkedHashSet<TopicsHandler> hdl = elem.getValue();
        		for (TopicsHandler topicsHandler : hdl) {
        			tm.unsubscribe(topic, topicsHandler);
        		}
        	}

        	super.dispose();

        	if (theservice != null) {
        		theservice.removeActiveShell(this);
        		theservice = null;
        	} else {
        		topicsManager = null;
        	}
        }

        /**
         * @internal
         * Externalizable method
         *
         * @param out
         *            ObjectOutput
         * @throws IOException
         */
        @Override
        public final void writeExternal(final ObjectOutput out) throws IOException {
        	if (topicsManager != null) {
        		throw new RuntimeException("Migration is not supported for platform topics shell");
        	}
            super.writeExternal(out);
            final int cnt = handlers.size();
            out.writeInt(cnt);
            if (cnt > 0) {
                for (Map.Entry<String, LinkedHashSet<TopicsHandler>> elem : handlers.entrySet()) {
                    final LinkedHashSet<TopicsHandler> val = elem.getValue();
                    final int subSize = val.size();
                    ConversionTools.writeString(out, elem.getKey());
                    out.writeInt(subSize);
                    if (subSize > 0) {
                        for (TopicsHandler topicsHandler : val) {
                            out.writeObject(topicsHandler);
                        }
                    }
                }
            }
            final int cnt2 = notifiers.size();
            out.writeInt(cnt2);
            if (cnt2 > 0) {
                for (Map.Entry<String, LinkedHashSet<TopicsSubscriptionNotifier>> elem : notifiers.entrySet()) {
                    final LinkedHashSet<TopicsSubscriptionNotifier> val = elem.getValue();
                    final int subSize = val.size();
                    ConversionTools.writeString(out, elem.getKey());
                    out.writeInt(subSize);
                    if (subSize > 0) {
                        for (TopicsSubscriptionNotifier topicsSubscriptionNotifier : val) {
                            out.writeObject(topicsSubscriptionNotifier);
                        }
                    }
                }
            }
        }

        /**
         * @internal
         * Externalizable method
         *
         * @param in
         *            ObjectInput
         * @throws IOException
         * @throws ClassNotFoundException
         */
        @Override
        public final void readExternal(final ObjectInput in) throws IOException, ClassNotFoundException {
            super.readExternal(in);
            final int cnt = in.readInt();
            for (int i = 0; i < cnt; i++) {
                final String topics = ConversionTools.readString(in);
                final int cnt2 = in.readInt();
                final LinkedHashSet<TopicsHandler> val = new LinkedHashSet<TopicsHandler>((int) (cnt2 / 0.75 + 1));
                handlers.put(topics, val);
                for (int i2 = 0; i2 < cnt2; i2++) {
                    val.add((TopicsHandler)in.readObject());
                }
            }
            final int cnt2 = in.readInt();
            for (int i = 0; i < cnt2; i++) {
                final String topics = ConversionTools.readString(in);
                final int cnt3 = in.readInt();
                final LinkedHashSet<TopicsSubscriptionNotifier> val = new LinkedHashSet<TopicsSubscriptionNotifier>((int) (cnt3 / 0.75 + 1));
                notifiers.put(topics, val);
                for (int i2 = 0; i2 < cnt3; i2++) {
                    val.add((TopicsSubscriptionNotifier)in.readObject());
                }
            }
        }

        /* @internal
         * (non-Javadoc)
         * @see aglobe.container.service.ServiceShell#setContainer(aglobe.container.AgentContainer)
         */
        @Override
        public final void setContainer(final AgentContainer container) throws Exception {
        	if (theservice != null) {
        		throw new RuntimeException("Already linked to the service");
        	}
            Service s = container.getServiceManager().getServiceInstance(TopicsService.SERVICENAME);
            if ((s != null) && (s instanceof TopicsService)) {
                theservice = (TopicsService) s;
                // remember values
                postInit = true;
            } else {
                throw new Exception(container.getContainerName() + ": Cannot reconect to the TopicsService");
            }
        }

        /* @internal
         * (non-Javadoc)
         * @see aglobe.container.service.ServiceShell#postInit()
         */
        @Override
        public final void postInit() {
            if (!postInit) {
                return;
            }
            theservice.registerActiveShell(this);

            // subscribe back all handlers
            for (Map.Entry<String, LinkedHashSet<TopicsHandler>> elem : handlers.entrySet()) {
                final String topic = elem.getKey();
                final LinkedHashSet<TopicsHandler> hdl = elem.getValue();
                for (TopicsHandler topicsHandler : hdl) {
                    theservice.topicsManager.subscribe(false, topic, topicsHandler);
                }
            }

            // register back all notifiers
            for (Map.Entry<String, LinkedHashSet<TopicsSubscriptionNotifier>> elem : notifiers.entrySet()) {
                final String topic = elem.getKey();
                final LinkedHashSet<TopicsSubscriptionNotifier> ntf = elem.getValue();
                for (TopicsSubscriptionNotifier topicsSubscriptionNotifier : ntf) {
                    theservice.topicsManager.registerSubscriptionNotifier(topic, topicsSubscriptionNotifier);
                }
            }
            postInit = false;
        }


        /* (non-Javadoc)
         * @see aglobe.container.service.ServiceShell#isValid()
         */
        @Override
        public final boolean isValid() {
            return (theservice!=null) || (topicsManager!=null);
        }

        /**
         * Returns the system name under which this TopicsServiceShell works.
         * @returns null
         */
        public final String getSystemName() {
        	if (theservice == null) {
        		return null;
        	}
        	return theservice.systemName;
        }

        /**
         * Get container address where the service is running
         *
         * @return String
         */
        public final Address getContainerAddress() {
        	if (theservice == null) {
        		return null;
        	}
        	return theservice.getAddress().deriveContainerAddress();
        }

        /**
         * Add event to the service queue
         *
         * @param event
         *            Runnable
         */
        public final void addEvent(final Runnable event) {
        	if (topicsManager != null) {
        		throw new RuntimeException("Event cannot be added via a platform topics shell");
        	}
        	if (theservice == null) {
        		// it is already disposed
        		return;
        	}
        	theservice.addEvent(event);
        }


        /**
         * Subscribe given handler for receiving specified topic messages.
         * This call is asynchronous with the server and the method is returned
         * however it is not processed by the TopicsDirectory manager yet.
         * If the user require synchronous operation, he should use
         * subscribeHandlerSync instead.
         *
         * @param topic
         * @param handler
         */
        public final void subscribeHandlerAsync(final String topic, final TopicsHandler handler) {
        	if ((theservice == null) && (topicsManager == null)) {
        		// it is already disposed
        		return;
        	}
        	
        	final TopicsManager tm = (topicsManager != null) ? topicsManager : theservice.topicsManager;
        	
        	LinkedHashSet<TopicsHandler> hdls = handlers.get(topic);
        	if (hdls == null) {
        		hdls = new LinkedHashSet<TopicsHandler>();
        		handlers.put(topic, hdls);
        	}
        	if (hdls.add(handler)) {
        		tm.subscribe(false, topic, handler);
        	}
        }

        /**
         * Subscribe given handler for receiving specified topic messages. This
         * call block the calling thread until the request is fully processed by the
         * TopicsDirectory manager.
         *
         * @param topic
         * @param handler
         */
        public final void subscribeHandlerSync(final String topic, final TopicsHandler handler) {
        	if ((theservice == null) && (topicsManager == null)) {
        		// it is already disposed
        		return;
        	}
        	
        	final TopicsManager tm = (topicsManager != null) ? topicsManager : theservice.topicsManager;
        	
        	LinkedHashSet<TopicsHandler> hdls = handlers.get(topic);
        	if (hdls == null) {
        		hdls = new LinkedHashSet<TopicsHandler>();
        		handlers.put(topic, hdls);
        	}
        	if (hdls.add(handler)) {
        		tm.subscribe(true, topic, handler);
        	}
        }

        /**
         * Unsubscribe given handler to avoid receiving specified topic messages
         * @param topic
         * @param handler
         */
        public final void unsubscribeHandler(final String topic, final TopicsHandler handler) {
        	if ((theservice == null) && (topicsManager == null)) {
        		// it is already disposed
        		return;
        	}
        	
        	final TopicsManager tm = (topicsManager != null) ? topicsManager : theservice.topicsManager;
        	
        	final LinkedHashSet<TopicsHandler> hdls = handlers.get(topic);
        	if (hdls != null) {
        		if (hdls.remove(handler)) {
        			tm.unsubscribe(topic, handler);
        			if (hdls.size() == 0) {
        				handlers.remove(topic);
        			}
        		}
        	}
        }

        /**
         * Unsubscribe all handlers which were previously subscribed for given topic.
         * @param topic
         */
        public final void unsubscribeHandlers(final String topic) {
        	if ((theservice == null) && (topicsManager == null)) {
        		// it is already disposed
        		return;
        	}
        	
        	final TopicsManager tm = (topicsManager != null) ? topicsManager : theservice.topicsManager;
        	
        	final LinkedHashSet<TopicsHandler> hdls = handlers.remove(topic);
        	if (hdls != null) {
        		for (TopicsHandler topicsHandler : hdls) {
        			tm.unsubscribe(topic, topicsHandler);
        		}
        	}
        }

        /**
         * Unsubscribe all previously subscribed handlers via this proxy shell.
         */
        public final void unsubscribeAllHandlers() {
        	if ((theservice == null) && (topicsManager == null)) {
        		// it is already disposed
        		return;
        	}
        	
        	final TopicsManager tm = (topicsManager != null) ? topicsManager : theservice.topicsManager;
        	
        	for (Map.Entry<String, LinkedHashSet<TopicsHandler>> elem : handlers.entrySet()) {
        		final String topic = elem.getKey();
        		final LinkedHashSet<TopicsHandler> hdls = elem.getValue();
        		for (TopicsHandler topicsHandler : hdls) {
        			tm.unsubscribe(topic, topicsHandler);
        		}
        	}
        	handlers.clear();
        }

        /**
         * Register given notifier for receiving subscription status of topic
         * @param topic
         * @param notifier
         */
        public final void registerNotifier(final String topic, final TopicsSubscriptionNotifier notifier) {
        	if ((theservice == null) && (topicsManager == null)) {
        		// it is already disposed
        		return;
        	}
        	
        	final TopicsManager tm = (topicsManager != null) ? topicsManager : theservice.topicsManager;
        	
        	LinkedHashSet<TopicsSubscriptionNotifier> ntfs = notifiers.get(topic);
        	if (ntfs == null) {
        		ntfs = new LinkedHashSet<TopicsSubscriptionNotifier>();
        		notifiers.put(topic, ntfs);
        	}
        	if (ntfs.add(notifier)) {
        		tm.registerSubscriptionNotifier(topic, notifier);
        	}
        }

        /**
         * Cancel previous registration of given notifier for specified topic.
         * @param topic
         * @param notifier
         */
        public final void deregisterNotifier(final String topic, final TopicsSubscriptionNotifier notifier) {
        	if ((theservice == null) && (topicsManager == null)) {
        		// it is already disposed
        		return;
        	}
        	
        	final TopicsManager tm = (topicsManager != null) ? topicsManager : theservice.topicsManager;
        	
        	final LinkedHashSet<TopicsSubscriptionNotifier> ntfs = notifiers.get(topic);
        	if (ntfs != null) {
        		if (ntfs.remove(notifier)) {
        			tm.deregisterSubscriptionNotifier(topic, notifier);
        			if (ntfs.size() == 0) {
        				notifiers.remove(topic);
        			}
        		}
        	}
        }

        /**
         * Cancel all previous registrations of status notifiers of specified topic
         * @param topic
         */
        public final void deregisterNotifiers(final String topic) {
        	if ((theservice == null) && (topicsManager == null)) {
        		// it is already disposed
        		return;
        	}
        	
        	final TopicsManager tm = (topicsManager != null) ? topicsManager : theservice.topicsManager;
        	
        	final LinkedHashSet<TopicsSubscriptionNotifier> ntfs = notifiers.remove(topic);
        	if (ntfs != null) {
        		for (TopicsSubscriptionNotifier topicsSubscriptionNotifier : ntfs) {
        			tm.deregisterSubscriptionNotifier(topic, topicsSubscriptionNotifier);
        		}
        	}
        }

        /**
         * Cancel all previous registrations
         */
        public final void deregisterAllNotifiers() {
        	if ((theservice == null) && (topicsManager == null)) {
        		// it is already disposed
        		return;
        	}
        	
        	final TopicsManager tm = (topicsManager != null) ? topicsManager : theservice.topicsManager;
        	
        	for (Map.Entry<String, LinkedHashSet<TopicsSubscriptionNotifier>> elem : notifiers.entrySet()) {
        		final String topic = elem.getKey();
        		final LinkedHashSet<TopicsSubscriptionNotifier> ntfs = elem.getValue();
        		for (TopicsSubscriptionNotifier topicsSubscriptionNotifier : ntfs) {
        			tm.deregisterSubscriptionNotifier(topic, topicsSubscriptionNotifier);
        		}
        	}
        	notifiers.clear();
        }

        /**
         * Submit topic message
         * @param topic
         * @param content
         * @param reason
         */
        public final void sendTopic(final String topic, final Object content, final String reason) {
        	if ((theservice == null) && (topicsManager == null)) {
        		// it is already disposed
        		return;
        	}
        	
        	final TopicsManager tm = (topicsManager != null) ? topicsManager : theservice.topicsManager;
        	
        	providedTopics.add(topic);
        	tm.sendTopic(this, topic, content, reason);
        }

        /**
         * Submit topic message
         * @param topic
         * @param content
         */
        public final void sendTopic(final String topic, final Object content) {
            sendTopic(topic, content, null);
        }
    }
}
