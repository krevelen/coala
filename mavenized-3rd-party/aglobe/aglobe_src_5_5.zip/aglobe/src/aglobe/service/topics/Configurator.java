package aglobe.service.topics;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;

import aglobe.container.transport.Address;
import aglobe.platform.Platform;
import aglobe.platform.thread.AglobeThreadPool;
import aglobe.platform.transport.MessageTransport;
import aglobe.util.Logger;

/**
 * <p>Title: Configurator</p>
 *
 * <p>Description: Is used for automatic search for neighbor Topics managers</p>
 *
 * <p>Copyright: Copyright (c) 2009</p>
 *
 * <p>Company: Agent Technology Center</p>
 *
 * @author David Sislak
 * @version $Revision: 1.7 $ $Date: 2009/07/06 17:49:04 $
 *
 */
class Configurator implements Runnable {
    /**
     * Prefix of the broadcast UDP packet
     */
    private static final String REQUEST = "ServerAreYouThere?A-globe_ver" +
          Platform.MAJOR_VERSION + "_" + Platform.MINOR_VERSION +
          ".System_name:";

    /**
     * Base of the finder UDP port
     */
    private static final int AUTO_CONFIGURATOR_BASE_PORT = 4444;

    /**
     * Maximal number of server container running on the same host computer
     */
    private static final int AUTO_CONFIGURATOR_PORT_RANGE = 5;

    /**
     * Listening UDP socket
     */
    private DatagramSocket socket = null;

    /**
     * Request string on which this server will reply
     */
    private final String requestString;

    private final Address topicsManagerAddress;

    /**
     * true iff server should be finished
     */
    volatile private boolean killing = false;

    /**
     * true iff listening thread was stopped
     */
    volatile private boolean stopped = false;

    /**
     * Server thread
     */
    private Thread asThread = null;

    /**
     * Cannot be instantiated
     */
    Configurator(final String systemName, final Address topicsManagerAddress) {
        // create request string
        requestString = getRequest(systemName);
        this.topicsManagerAddress = topicsManagerAddress;
        // open listening socket
        int listeningPort = AUTO_CONFIGURATOR_BASE_PORT;
        while ( (asThread == null) &&
                (listeningPort < AUTO_CONFIGURATOR_BASE_PORT +
                 AUTO_CONFIGURATOR_PORT_RANGE)) {
             try {
                 socket = new DatagramSocket(listeningPort);
                 socket.setBroadcast(true);
                 socket.setSoTimeout(1000);

                 // create listening thread
                 asThread = AglobeThreadPool.getThread(Platform.getPlatformThreadGroup(),
                       this, "Configurator thread for systemName: "+systemName);
                 // set priority above normal
                 asThread.setPriority(Math.min(Thread.NORM_PRIORITY + 2,
                                               Thread.MAX_PRIORITY));
                 asThread.start();
             }
             catch (SocketException ex) {
                 listeningPort++;
             }
         }
         if (asThread == null) {
             Logger.logSevere("Configurator thread for systemName: "+systemName+": Cannot open any listening autoconfigurator port in range: "+
                     AUTO_CONFIGURATOR_BASE_PORT + " - " +
                     (AUTO_CONFIGURATOR_BASE_PORT +
                      AUTO_CONFIGURATOR_PORT_RANGE - 1));
         }

    }

    /* (non-Javadoc)
     * @see java.lang.Runnable#run()
     */
    @Override
    public void run() {
        byte[] buf = new byte[1024];
        DatagramPacket dp = new DatagramPacket(buf, buf.length);
        while (true) {
            try {
                socket.receive(dp);
                String s = new String(dp.getData(), 0, dp.getLength());
                if (s.equals(requestString)) {
                    byte[] replyBuf = topicsManagerAddress.toString().getBytes();
                    DatagramPacket reply = new DatagramPacket(replyBuf,
                          replyBuf.length, dp.getAddress(), dp.getPort());
                    socket.send(reply);
                }
                dp = new DatagramPacket(buf, buf.length);
            }
            catch (SocketTimeoutException ex) {
                //timeout expire
            }
            catch (IOException ex) {
                Logger.logSevere("Receiving exeption " + ex);
                dp = new DatagramPacket(buf, buf.length);
            }

            if (killing) {
                break;
            }
        }
        // close the listening socket
        socket.close();

        // notify requester about finish
        stopped = true;
        synchronized (this) {
            this.notify();
        }

    }


    /**
     * Terminate server.
     */
    public void kill() {
        killing = true;
        while (!stopped) {
            synchronized (this) {
                try {
                    this.wait(5000);
                }
                catch (InterruptedException ex) {
                }
            }
        }
    }

    /**
     * Returns request string used for auto-detection of the server container
     * @param systemName String
     * @return String
     */
    private static String getRequest(String systemName) {
        return REQUEST + systemName;
    }

    /**
     * Try find neighbor address representing specified system name
     * @param systemName String
     * @return Address
     */
    public static Address getNeighborAddress(final String systemName) {
        Address retVal = null;
        try {
            // prepare all local IPs
//            final InetAddress[] allMyIps = InetAddress.getAllByName(InetAddress.getLocalHost().getCanonicalHostName());
            // just use only the address to which this platform is bound
            final InetAddress[] allMyIps = new InetAddress[]{MessageTransport.localAddress.getAddress()};
            for (int ipnum=0; ipnum<allMyIps.length; ipnum++) {
                final InetAddress myIp = allMyIps[ipnum];

                // prepare socket
                DatagramSocket socket = new DatagramSocket(0, myIp); // allow to pick system empheral port
                socket.setReceiveBufferSize(100);
                socket.setBroadcast(true);
                socket.setSoTimeout(100);
                // prepare request string
                byte[] outBuf = getRequest(systemName).getBytes();
                DatagramPacket senddp;
                int portOffset;

                byte[] inBuf = new byte[1024];
                DatagramPacket recdp = new DatagramPacket(inBuf,inBuf.length);
                String recstr;

                // first send packet to the localhost
                portOffset = 0;
                while (portOffset < Configurator.AUTO_CONFIGURATOR_PORT_RANGE) {
                    senddp = new DatagramPacket(outBuf, outBuf.length,
                            myIp,
                            Configurator.AUTO_CONFIGURATOR_BASE_PORT+portOffset);
                    try {
                        socket.send(senddp);
                    }
                    catch (IOException ex1) {
                    }
                    portOffset++;
                }

                // wait for the response
                try {
                    socket.receive(recdp);
                    recstr = new String(recdp.getData(), 0, recdp.getLength());
                    retVal = Address.getAddress(recstr);
                    return retVal;
                } catch (SocketTimeoutException ex) {

                }

                // reset socket timeout for receiving responses from the local network
                socket.setSoTimeout(500);

                // send broadcast to the subnet broadcast address
                byte[] rawLocalAddress = myIp.getAddress();
                if (rawLocalAddress.length == 4) {
                    int firstnumber = rawLocalAddress[0] & 0xff;
                    int subnet = 0;
                    if (firstnumber <= 127) subnet = 3;        //class A
                    else if (firstnumber <= 191) subnet = 2;    //class B
                    else if (firstnumber <= 223) subnet = 1;    //class C

                    for (int i=4-subnet;i<4;i++) {
                        rawLocalAddress[i] = (byte) 255;
                    }

                    portOffset = 0;
                    while (portOffset < Configurator.AUTO_CONFIGURATOR_PORT_RANGE) {
                        senddp = new DatagramPacket(outBuf, outBuf.length,
                                InetAddress.getByAddress(rawLocalAddress),
                                Configurator.AUTO_CONFIGURATOR_BASE_PORT+portOffset);
                        try {
                            socket.send(senddp);
                        }
                        catch (IOException ex2) {
                        }
                        portOffset++;
                    }
                }

                // wait for the response
                try {
                    socket.receive(recdp);
                    recstr = new String(recdp.getData(), 0, recdp.getLength());
                    retVal = Address.getAddress(recstr);
                    return retVal;
                } catch (SocketTimeoutException ex) {

                }

                // send request to the global broadcast address
                portOffset = 0;
                while (portOffset < Configurator.AUTO_CONFIGURATOR_PORT_RANGE) {
                    senddp = new DatagramPacket(outBuf, outBuf.length,
                            InetAddress.getByName("255.255.255.255"),
                            Configurator.AUTO_CONFIGURATOR_BASE_PORT+portOffset);

                    try {
                        socket.send(senddp);
                    }
                    catch (IOException ex1) {
                    }
                    portOffset++;
                }

                // wait for the response
                try {
                    socket.receive(recdp);
                    recstr = new String(recdp.getData(),0,recdp.getLength());
                    retVal = Address.getAddress(recstr);
                    return retVal;
                } catch (SocketTimeoutException ex) {

                }
            }
        }
        catch (UnknownHostException ex) {
          Logger.logSevere("Cannot create broadcast packet " + ex);
        }
        catch (SocketException ex) {
          Logger.logSevere("Socket creation error" + ex);
        }
        catch (IOException ex) {
          Logger.logSevere("Socket send error" + ex);
        }

        return null;

    }

}
