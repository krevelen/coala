/**
 *
 */
package aglobe.service.topics;

import java.io.Serializable;

import aglobe.container.EventReceiver;

/**
 * <p>Title: TopicsHandler</p>
 *
 * <p>Description: The receiver of topics messaging has to implement TopicsHandler interface.
 * The subscribed topics will invoke handleIncomingTopic method via Runnable passed using
 * addEvent method of EventReceiver.</p>
 *
 * <p>Copyright: Copyright (c) 2009</p>
 *
 * <p>Company: Agent Technology Center</p>
 *
 * @author David Sislak
 * @version $Revision: 1.2 $ $Date: 2009/06/15 13:38:02 $
 *
 */
public interface TopicsHandler extends EventReceiver, Serializable {

    /**
     * Method called upon each incoming topic for which the implementor is subscribed.
     *
     * @param topic
     * @param content - can be null
     * @param reason - can be null
     */
    public void handleIncomingTopic(final String topic, final Object content, final String reason);

}
