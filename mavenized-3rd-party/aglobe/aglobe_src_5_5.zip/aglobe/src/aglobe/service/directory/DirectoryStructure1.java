package aglobe.service.directory;

import java.util.*;

import aglobe.container.transport.*;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: Internal directory service structure</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.2 $ $Date: 2009/06/15 13:38:01 $
 */

class DirectoryStructure1 {
    /**
     * Services in string representation
     */
    String services;

    /**
     * Corresponding directory record
     */
    DirectoryRecord directoryRecord;

    /**
     * Hash value of the instance
     */
    private int hashValue;

    /**
     * Constructor
     * @param address Address
     */
    DirectoryStructure1(final Address address) {
        this.services = DirectoryConstants.DIRECTORY_SERVICE_SEPARATOR;
        directoryRecord = new DirectoryRecord(address, new String[0]);
        updateHashValue();
    }

    /**
     * Test if all service names are valid, otherwise throw an exception
     *
     * @param services Collection
     * @throws DirectoryException
     */
    private void testServices(final Collection<String> services) throws
            DirectoryException {
        for (Iterator<String> iter = services.iterator(); iter.hasNext(); ) {
            String item = iter.next();
            if (item.indexOf(DirectoryConstants.DIRECTORY_SERVICE_SEPARATOR) >= 0) {
                throw new DirectoryException(
                        "Service string cannot contain this character '" +
                        DirectoryConstants.DIRECTORY_SERVICE_SEPARATOR + "' !!!");
            }
            if (item.indexOf(DirectoryConstants.DIRECTORY_REGULAR_EXPRESSION_DIVIDER) >=
                0) {
                throw new DirectoryException(
                        "Service string cannot contain this character '" +
                        DirectoryConstants.DIRECTORY_REGULAR_EXPRESSION_DIVIDER + "' !!!");
            }
        }
    }

    /**
     * Add services to the record
     *
     * @param services Collection - contains strings
     * @return String - added services joined in one string with DIRECTORY_SERVICE_SEPARATOR
     * @throws DirectoryException
     */
    String addServices(final Collection<String> services) throws
            DirectoryException {
        // test if services are valid
        testServices(services);
        // add to the record
        String retVal = DirectoryConstants.DIRECTORY_SERVICE_SEPARATOR;
        for (Iterator<String> iter = services.iterator(); iter.hasNext(); ) {
            String item = iter.next();
            this.services += (item + DirectoryConstants.DIRECTORY_SERVICE_SEPARATOR);
            retVal += (item + DirectoryConstants.DIRECTORY_SERVICE_SEPARATOR);
        }
        // add services to the directory record
        Collection<String> tmp = new LinkedHashSet<String>(Arrays.asList(directoryRecord.getServices()));
        tmp.addAll(services);
        directoryRecord.setServices(tmp.toArray(new String[tmp.size()]));
        updateHashValue();
        return retVal;
    }

    /**
     * Remove services from the record
     *
     * @param services Collection
     * @return String
     * @throws DirectoryException
     */
    String removeServices(final Collection<String> services) throws
            DirectoryException {
        //test if services are valid
        testServices(services);
        // remove services, update string
        String retVal = DirectoryConstants.DIRECTORY_SERVICE_SEPARATOR;
        Collection<String> tmp = new LinkedHashSet<String>(Arrays.asList(directoryRecord.getServices()));
        tmp.removeAll(services);
        String[] restServices = tmp.toArray(new String[tmp.size()]);
        directoryRecord.setServices(restServices);
        this.services = DirectoryConstants.DIRECTORY_SERVICE_SEPARATOR;
        for (int i = 0; i < restServices.length; i++) {
            this.services +=
                    (restServices[i] + DirectoryConstants.DIRECTORY_SERVICE_SEPARATOR);
        }
        for (Iterator<String> iter = services.iterator(); iter.hasNext(); ) {
            String item = iter.next();
            retVal += (item + DirectoryConstants.DIRECTORY_SERVICE_SEPARATOR);
        }
        updateHashValue();
        return retVal;
    }

    /**
     * Change provider services to newServices
     * @param newServices String
     */
    void changeServices(final String newServices) {
        Collection<String> newServ = convertServices(newServices);
        this.services = newServices;
        this.directoryRecord.setServices(newServ.toArray(new String[newServ.size()]));
        updateHashValue();
    }

    /**
     * Remove all provided services
     */
    void removeAllServices() {
        this.services = "";
        this.directoryRecord.setServices(new String[0]);
        updateHashValue();
    }

    /**
     * Convert services from the string representation to the set representation
     * @param services String
     * @return Collection
     */
    private Collection<String> convertServices(final String services) {
        Collection<String> retVal = new LinkedHashSet<String>();
        String[] tmp = services.split(DirectoryConstants.
                                      DIRECTORY_SERVICE_SEPARATOR);
        for (int i = 0; i < tmp.length; i++) {
            if (tmp[i].length() > 0) {
                retVal.add(tmp[i]);
            }
        }
        return retVal;
    }

    /**
     * Tests if this provider has some service
     * @return boolean - true iff provider has at least one service registred
     */
    boolean hasServices() {
        return directoryRecord.getServices().length > 0;
    }

    /**
     * Update local hash value
     */
    private void updateHashValue() {
        int retVal = 19;
        retVal = 37 * retVal + services.hashCode();
        retVal = 37 * retVal + directoryRecord.hashCode();
        hashValue = retVal;
    }

    /**
     * Returns hash value of this instance
     * @return int
     */
    @Override
    public int hashCode() {
        return hashValue;
    }

    /**
     * Test if instance is same as other object
     * @param other Object
     * @return boolean - true iff instances are same
     */
    @Override
    public boolean equals(Object other) {
        if (other instanceof DirectoryStructure1) {
            if (hashValue != other.hashCode())
                return false;
            DirectoryStructure1 o = (DirectoryStructure1) other;
            return services.equals(o.services) &&
                    directoryRecord.equals(o.directoryRecord);
        }
        return false;
    }
}
