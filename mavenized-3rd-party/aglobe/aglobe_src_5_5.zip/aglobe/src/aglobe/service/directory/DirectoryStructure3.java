package aglobe.service.directory;

import java.util.Map;
import aglobe.container.transport.Address;
import java.util.LinkedHashMap;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: Internal directory service structure</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.2 $ $Date: 2009/06/15 13:38:01 $
 */

class DirectoryStructure3 {

    /**
     * Remote directory address
     */
    final Address remoteDirectoryAddress;

    /**
     * If null, filter is up to date on the remote side. Otherwise this update needs to be
     * send out when remote container becomes visible for me
     */
    String invisibleMyFilterUpdate = null;

    /**
     * Contains known remote directories for me.
     */
    Map<Address, DirectoryStructure1> remoteDirectory = new LinkedHashMap<Address, DirectoryStructure1>();

    /**
     * Constructor
     * @param remoteContainerAddress Address - remote container address
     */
    DirectoryStructure3(final Address remoteContainerAddress) {
        this.remoteDirectoryAddress = remoteContainerAddress.deriveServiceAddress(
                DirectoryService.SERVICENAME);
    }
}
