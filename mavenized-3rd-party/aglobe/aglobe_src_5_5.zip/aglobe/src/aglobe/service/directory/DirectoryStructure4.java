package aglobe.service.directory;

import aglobe.container.transport.Address;
import java.util.Map;
import java.util.Collection;
import java.util.regex.Pattern;
import java.util.LinkedHashSet;
import java.util.LinkedHashMap;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: Internal directory service structure</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.2 $ $Date: 2009/06/15 13:38:01 $
 */

class DirectoryStructure4 {
    /**
     * Remote directory address
     */
    final Address remoteDirectoryAddress;

    /**
     * Remote subscriber last know filter
     */
    private Collection<String> currentFilter;

    /**
     * Remote subscriber last known filter in String
     */
    private String currentFilterInString;

    /**
     * Remote subscriber filter in reg exp
     */
    Pattern regexpCurrentFilter;

    /**
     * Queue of the record updates which is need to be send out when remote directory will be visible.
     */
    Map<Address, DirectoryTransmitionRecord> invisibleQueueRecordUpdates = new LinkedHashMap<Address, DirectoryTransmitionRecord>();

    /**
     * Constructor
     * @param remoteContainername String
     * @param remoteDirectoryAddress Address
     * @param filter String
     */
    DirectoryStructure4(final Address remoteDirectoryAddress,
                        final String filter) {
        this.remoteDirectoryAddress = remoteDirectoryAddress;
        this.currentFilterInString = filter;
        this.regexpCurrentFilter = Pattern.compile(this.currentFilterInString);
        currentFilter = convertFilter(filter);
    }

    /**
     * Gets current filter in string
     * @return String
     */
    String getCurrentFilterInString() {
        return currentFilterInString;
    }

    /**
     * Gets current filter
     * @return Collection
     */
    Collection<String> getCurrentFilter() {
        return currentFilter;
    }

    /**
     * Sets new filter in string
     * @param newFilter String
     */
    void setCurrentFilterInString(final String newFilter) {
        this.currentFilterInString = newFilter;
        this.regexpCurrentFilter = Pattern.compile(newFilter);
    }

    /**
     * Sets new filter
     * @param newFilter Collection
     */
    void setCurrentFilter(final Collection<String> newFilter) {
        this.currentFilter = newFilter;
    }

    /**
     * Convert filter form the string representation to the collection
     * @param filter String
     * @return Collection
     */
    static Collection<String> convertFilter(final String filter) {
        Collection<String> retVal = new LinkedHashSet<String>();
        String[] tmp = filter.split("\\" + DirectoryConstants.
                                    DIRECTORY_REGULAR_EXPRESSION_DIVIDER);
        for (int i = 0; i < tmp.length; i++) {
            retVal.add(tmp[i].substring(1, tmp[i].length() - 1));
        }
        return retVal;
    }
}
