package aglobe.service.directory;

import aglobe.container.EventReceiver;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: directory listener for users of the directory service</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.2 $ $Date: 2009/06/15 13:38:01 $
 */
public interface DirectoryListener extends EventReceiver {
    /**
     * Handles new registration in the directory. New registration of an agent/service can be called
     * only if the agent is not visible yet.
     * @param containerName String - container name where the agent/service have been registred
     * @param records DirectoryRecord[] - array of the agents/services which are registred. An agent/service can
     * handle its own registration too.
     * @param matchingFilter String - matching filter to which is this callback. Can be used if an someone
     * has more subscriptions to the same listener with cross filter. In this case registration info about one agent/service
     * can be handled two times
     */
    public void handleNewRegister(final String containerName, final DirectoryRecord[] records, String matchingFilter);

    /**
     * Handles deregistration of the agent/service. New registration of an agent/service can be called
     * only if the agent is not visible now.
     * @param containerName String - container name where the agent/service have been deregistred
     * @param records DirectoryRecord[] - array of the agents/services which are deregistred. Only address and containerName
     * fields are valid; services field couldn't have valid data. An agent/service can
     * handle its own deregistration too.
     * @param matchingFilter String - matching filter to which is this callback. Can be used if an someone
     * has more subscriptions to the same listener with cross filter.
     */
    public void handleDeregister(final String containerName, final DirectoryRecord[] records, String matchingFilter);

    /**
     * Handles that some agents/services becomes visible to me. Visible of an agent/service can be called
     * only if the agent is previously known to me. (register called before)
     * @param containerName String - container name where agents/services become visible
     * @param records DirectoryRecord[] - array of the agents/services which become visible. Only address and containerName
     * fields are valid; services field couldn't have valid data. An agent/service can
     * handle its own visibility too.
     * @param matchingFilter String - matching filter to which is this callback. Can be used if an someone
     * has more subscriptions to the same listener with cross filter.
     */
    public void handleVisible(final String containerName, final DirectoryRecord[] records, String matchingFilter);

    /**
     * Handles that some agents/services becomes invisible to me. Invisible of an agent/service can be called
     * only if the agent is previously known to me and was visible to me. (register called before)
     * @param containerName String - container name where agents/services become invisible
     * @param records DirectoryRecord[] - array of the agents/services which become invisible. Only address and containerName
     * fields are valid; services field couldn't have valid data. An agent/service can
     * handle its own invisibility too.
     * @param matchingFilter String - matching filter to which is this callback. Can be used if an someone
     * has more subscriptions to the same listener with cross filter.
     */
    public void handleInvisible(final String containerName, final DirectoryRecord[] records, String matchingFilter);
}
