package aglobe.service.directory;

import java.io.*;

import aglobe.container.transport.*;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: directory record used for internal representation and for inter-directory communication.</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.4 $ $Date: 2010/08/04 11:48:06 $
 */

public final class DirectoryTransmitionRecord implements Externalizable {

    // This number has to be changed, when DirectoryTransmitionRecord's variables are changed
    private static final long serialVersionUID = -6874631265550L;

    /**
     * Address in address form
     */
    private Address _Address;

    /**
     * list of the services provided by the agent/service separated by specific separator
     */
    String _Services;

    /**
     * Used for externalization. Don't use it.
     */
    public DirectoryTransmitionRecord() {
    }

    /**
     * Constructor
     * @param address Address
     * @param services String
     */
    DirectoryTransmitionRecord(final Address address, final String services) {
        _Address = address;
        _Services = services;
    }

    /**
     * Gets address
     * @return Address
     */
    final Address getAddress() {
        return _Address;
    }

    /**
     * Gets string representation of the instance
     * @return String
     */
    @Override
    public final String toString() {
        return "Address: " + _Address.toString() + " Services: " + _Services;
    }

    /**
     * Used for externalization of the instance
     *
     * @param in ObjectInput
     * @throws IOException
     * @throws ClassNotFoundException
     */
    @Override
	public final void readExternal(final ObjectInput in) throws IOException, ClassNotFoundException {
        _Address = Address.deserialize(in);
        _Services = (String) in.readObject();
    }

    /**
     * Used for externalization of the instance.
     *
     * @param out ObjectOutput
     * @throws IOException
     */
    @Override
	public final void writeExternal(final ObjectOutput out) throws IOException {
        _Address.serialize(out);
        out.writeObject(_Services);
    }

}
