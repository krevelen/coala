package aglobe.service.directory;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: directory constants used in the directory-to-directory communication</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.3 $ $Date: 2009/07/01 07:14:21 $
 */
abstract class DirectoryConstants {
    /**
     * Protocol constant used for subscribe or change subscription between directories
     */
    static final String PROTOCOL_SUBSCRIBE_CHANGE = "sc";

    /**
     * Protocol constant used for unsubscription between directories
     */
    static final String PROTOCOL_UNSUBSCRIBE = "us";

    /**
     * Protocol constant used notification about the fact, that the subscription has been released.
     * The main purpose is that the hosting container is in the shutdown phase.
     */
    static final String PROTOCOL_SUBSCRIPTION_RELEASED = "sr";

    /**
     * Protocol constant used for sending directory record update between directories
     */
    static final String PROTOCOL_HANDLE_DIRECTORY_RECORD_UPDATE = "hd";

    /**
     * Service separator used in string representation
     */
    static final String DIRECTORY_SERVICE_SEPARATOR = ";";

    /**
     * Regular expression divider
     */
    static final String DIRECTORY_REGULAR_EXPRESSION_DIVIDER = "|";
}
