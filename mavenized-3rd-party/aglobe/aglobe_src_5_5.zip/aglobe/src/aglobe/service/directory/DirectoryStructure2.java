package aglobe.service.directory;

import java.util.Map;
import java.util.regex.Pattern;
import aglobe.container.transport.Address;
import java.util.LinkedHashMap;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: Internal directory service structure</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.2 $ $Date: 2009/06/15 13:38:01 $
 */

class DirectoryStructure2 {
    /**
     * Subscriber directory listener
     */
    final DirectoryListener listener;

    /**
     * Subscriber filter
     */
    final String filter;

    /**
     * Regular expression pattern used for matching
     */
    final Pattern regexFilter;

    /**
     * Map of the service providers that are known for the subscriber.
     */
    final public Map<Address, DirectoryStructure1> knownProvides;

    /**
     * Map of the service providers that are visible for the subscriber.
     */
    final public Map<Address, DirectoryStructure1> visibleProviders;

    /**
     * Constructor
     * @param listener DirectoryListener - listener
     * @param filter String - filter
     */
    DirectoryStructure2(final DirectoryListener listener,
                        final String filter) {
        this.listener = listener;
        this.filter = filter;
        this.regexFilter = Pattern.compile(DirectoryConstants.DIRECTORY_SERVICE_SEPARATOR + filter +
                                           DirectoryConstants.DIRECTORY_SERVICE_SEPARATOR);
        knownProvides = new LinkedHashMap<Address, DirectoryStructure1>();
        visibleProviders = new LinkedHashMap<Address, DirectoryStructure1>();
    }

}
