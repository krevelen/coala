package aglobe.service.directory;

import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Logger;
import java.util.regex.Pattern;

import aglobe.container.AgentContainer;
import aglobe.container.ElementaryEntity;
import aglobe.container.service.Service;
import aglobe.container.service.ServiceShell;
import aglobe.container.service.ShellOwner;
import aglobe.container.transport.Address;
import aglobe.container.transport.InvisibleContainerException;
import aglobe.ontology.Message;
import aglobe.ontology.MessageConstants;
import aglobe.service.topics.ContainerHandler;
import aglobe.service.topics.ContainerMonitor;
import aglobe.service.visibility.VisibilityNotifier;
import aglobe.service.visibility.VisibilityService;
import aglobe.util.ConversionTools;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: Directory service. It provides the directory function. Each
 * agent/service can register provided services to this directory. It provides
 * search function by the subscribe mechanism. Agent subscribe listener for finding
 * all providers of such services fulfilling specified filter. Directory services
 * is responsible for collecting such information from all other visible DS running
 * in its network neighbor. It can also handle communication visibility and provides
 * this information to the subscriber listener.</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.5 $ $Date: 2010/08/04 11:48:06 $
 */
public class DirectoryService extends aglobe.container.service.Service {

    /**
     * Service name
     */
    public static final String SERVICENAME = "container/directory";

    private VisibilityService.Shell visShell = null;
    private ContainerMonitor containerMonitor = null;

    /**
     * United filter from all local subscribers
     */
    private Collection<String> currentUnitedFilter = new HashSet<String>();

    /**
     * United filter in string regular representation
     */
    private String currentUnitedFilterInString = "";

    /**
     * Local directory - contains information about locally registered agent/services.
     */
    private Map<Address, DirectoryStructure1> localDirectory = new
            LinkedHashMap<Address, DirectoryStructure1>();

    /**
     * Contains information about local subscribers.
     */
    private List<DirectoryStructure2> localSubscribers = new LinkedList<
            DirectoryStructure2>();

    /**
     * My remote subscriptions.
     */
    private Map<String, DirectoryStructure3> myRemoteSubscriptions = new
            LinkedHashMap<String, DirectoryStructure3>();

    /**
     * Contains current visible container names
     */
    private Collection<String> currentVisibleContainers = new LinkedHashSet<
            String>();

    /**
     * Container name to address
     */
    private Map<String, Address> containerNameToAddress = new HashMap<String,
            Address>();

    /**
     * Remote subscribers.
     */
    private Map<String, DirectoryStructure4> remoteSubscribers = new
            LinkedHashMap<String, DirectoryStructure4>();

    /**
     * Synchronization lock
     */
    private ReentrantLock sync = new ReentrantLock();

    private void becomeInvisible(final String containerName) {
    	sync.lock();
        try {
            if (currentVisibleContainers.contains(containerName)) {
                handleInvisible(containerName);
                currentVisibleContainers.remove(containerName);
            }
        } finally {
            sync.unlock();
        }
    }
    
    private void becomeVisible(final Address containerAddress) {
        sync.lock();
        try {
            if (!containerAddress.isSameContainer(getAddress())) {
                final String containerName = containerAddress.getContainerName();
                if (!currentVisibleContainers.contains(containerName)) { // test if it was invisible before
                    // test if I know this container directory
                    if (!containerNameToAddress.containsKey(containerName)) {
                        containerNameToAddress.put(containerName, containerAddress);
                    } else {
                        if (!containerNameToAddress.get(containerName).equals(containerAddress)) {
                            // different address than previous, it means that the remote container has been restarted
                            containerNameToAddress.put(containerName, containerAddress);
                            myRemoteSubscriptions.remove(containerName);
                        }
                    }
                    handleVisible(containerName);
                    currentVisibleContainers.add(containerName);
                }

            }
        } finally {
            sync.unlock();
        }
    }
    
    /**
     * This method is called by Agent Container after its MT subscribed for visibility info
     */
    @SuppressWarnings("serial")
    public void afterMTvisibilitySubscription() {
        visShell = (VisibilityService.Shell) getContainer().getServiceManager().getService(this, VisibilityService.SERVICENAME);
        if (visShell != null) {
            visShell.register(new VisibilityNotifier() {

                @Override
                public void becomeInvisible(final Address containerAddress) {
                    DirectoryService.this.becomeInvisible(containerAddress.getContainerName());
                }

                @Override
                public void becomeVisible(final Address containerAddress) {
                	DirectoryService.this.becomeVisible(containerAddress);
                }

                @Override
                public void addEvent(final Runnable e) {
                    DirectoryService.this.addEvent(e);
                }

            });
        }  else {
        
        	try {
        		containerMonitor = new ContainerMonitor(this, new ContainerHandler() {

        			@Override
        			public void containerStarted(Address containerAddress) {
        				becomeVisible(containerAddress);						
        			}

        			@Override
        			public void containerFinished(String containerName) {
        				becomeInvisible(containerName);
        			}
        		});
        	} catch (Exception e) {
        		e.printStackTrace();
        	}
        }
    }

    /**
     * Returns new service shell
     *
     * @return ServiceShell
     * @param shellOwner ElementaryEntity
     */
    @Override
    public ServiceShell getServiceShell(ShellOwner shellOwner) {
        return new Shell(shellOwner, this);
    }

    /**
     * Service is stopped
     */
    @Override
    public void finish() {
        sync.lock();
        try {
            if (visShell != null) {
                visShell.dispose();
                visShell = null;
            }
            if (containerMonitor != null) {
            	containerMonitor.dispose();
            	containerMonitor = null;
            }
            // unsubscribe all my subscriptions
            currentUnitedFilterInString = "";
            // go through my current subscriptions
            for (Map.Entry<String, DirectoryStructure3> item : myRemoteSubscriptions.entrySet()) {
                DirectoryStructure3 remoteSubscriptionRecord = item.getValue();
                try {
                    this.sendSubscribeChangeFilter(remoteSubscriptionRecord.
                            remoteDirectoryAddress,
                            currentUnitedFilterInString);
                } catch (InvisibleContainerException ex) {
                    // cannot be done anything
                }
            }

            // notify all subscribers that their subscription is released now
            Message m = null;
            for (DirectoryStructure4 elem : remoteSubscribers.values()) {
                if (m != null) {
                    m.addReceiver(elem.remoteDirectoryAddress);
                } else {
                    m = Message.newInstance(MessageConstants.INFORM, getAddress(),
                                            elem.remoteDirectoryAddress);
                    m.setProtocol(DirectoryConstants.PROTOCOL_SUBSCRIPTION_RELEASED);
                }
            }
            if (m != null) {
                try {
                    sendMessageAsReference(m);
                } catch (InvisibleContainerException ex1) {
                    // cannot do anything
                }
                m.release();
            }
        } finally {
            sync.unlock();
        }
    }

    /**
     * Handle local subscriber update.
     * @param directoryRecord DirectoryStructure1 - changed record
     */
    private void handleLocalSubscribersUpdate(final DirectoryStructure1
                                              directoryRecord) {
        // go through all local subscribers and try to find changes
        for (DirectoryStructure2 item : localSubscribers) {
            final String filter = item.filter;
            final DirectoryListener listener = item.listener;
            final DirectoryRecord record = directoryRecord.directoryRecord;
            if ((record.getServices().length > 0) && (item.regexFilter.matcher(directoryRecord.services).find())) {
                // matches
                if (!item.knownProvides.containsKey(record.address)) {
                    listener.addEvent(new Runnable() {
                        @Override
						public void run() {
                            listener.handleNewRegister(record.containerName,
                                    new DirectoryRecord[] {record}
                                    , filter);
                            listener.handleVisible(record.containerName,
                                    new DirectoryRecord[] {record}
                                    , filter);
                        }
                    });
                }
                // update record in the known providers and visible providers
                item.knownProvides.put(record.address, directoryRecord);
                item.visibleProviders.put(record.address, directoryRecord);
            } else {
                // not matches
                if (item.visibleProviders.containsKey(record.address)) {
                    // provider was visible and known
                    listener.addEvent(new Runnable() {
                        @Override
						public void run() {
                            listener.handleInvisible(record.containerName,
                                    new DirectoryRecord[] {record}
                                    , filter);
                            listener.handleDeregister(record.containerName,
                                    new DirectoryRecord[] {record}
                                    , filter);
                        }
                    });
                    // remove it from the know providers and visible providers
                    item.visibleProviders.remove(record.address);
                    item.knownProvides.remove(record.address);
                } else {
                    if (item.knownProvides.containsKey(record.address)) {
                        // provider was only known
                        listener.addEvent(new Runnable() {
                            @Override
							public void run() {
                                listener.handleDeregister(record.containerName,
                                        new DirectoryRecord[] {record}
                                        , filter);
                            }
                        });
                        // remove it from the know providers
                        item.knownProvides.remove(record.address);
                    }
                }
            }
        }
    }

    /**
     * Handle incoming message
     * @param m Message
     */
    @Override
	public void handleIncomingMessage(Message m) {
        sync.lock();
        try {
            if (MessageConstants.INFORM.equals(m.getPerformative()) &&
                m.getProtocol() != null) {
                String remoteContainerName = m.getSender().getContainerName();
                String protocol = m.getProtocol();
                if (DirectoryConstants.PROTOCOL_HANDLE_DIRECTORY_RECORD_UPDATE.
                    equals(protocol)) {
                    // update directory record
                    DirectoryTransmitionRecord updatedRecord = (
                            DirectoryTransmitionRecord)
                            m.getContent();
                    Address serviceProvider = updatedRecord.getAddress();
                    DirectoryStructure3 remoteSubscriptionRecord =
                            myRemoteSubscriptions.get(remoteContainerName);
                    if (remoteSubscriptionRecord != null) {
                        // subscription exists
                        DirectoryStructure1 providerRecord =
                                remoteSubscriptionRecord.remoteDirectory.get(
                                        serviceProvider);
                        if (providerRecord == null) {
                            providerRecord = new DirectoryStructure1(
                                    serviceProvider);
                            remoteSubscriptionRecord.remoteDirectory.put(
                                    serviceProvider,
                                    providerRecord);
                        }
                        providerRecord.changeServices(updatedRecord._Services);
                        // handle changes to local subscribers
                        this.handleLocalSubscribersUpdate(providerRecord);
                        if (!providerRecord.hasServices()) { // if no services remove record
                            remoteSubscriptionRecord.remoteDirectory.remove(
                                    serviceProvider);
                        }
                    }
                    // test if container is visible
                    if (!currentVisibleContainers.contains(remoteContainerName)) {
                        // update address cache
                        if (!containerNameToAddress.containsKey(remoteContainerName)) {
                            containerNameToAddress.put(remoteContainerName,
                                    m.getSender().deriveContainerAddress());
                        }
                        // removed because problem with inaccessibility of target container
//          currentVisibleContainers.add(remoteContainerName);
//          this.handleVisible(remoteContainerName);
                    }
                    m.release();
                    return;
                } else if (DirectoryConstants.PROTOCOL_SUBSCRIBE_CHANGE.equals(
                        protocol)) {
                    String findFilter = ""; // create filter which sould be send to remote subscriber
                    DirectoryStructure4 remoteSubscriberRecord;
                    if (remoteSubscribers.containsKey(remoteContainerName)) {
                        // remote subscription changed
                        remoteSubscriberRecord = remoteSubscribers.get(
                                remoteContainerName);
                        Collection<String> newFilter = DirectoryStructure4.
                                convertFilter((String)
                                              m.getContent());
                        Collection<String>
                                addedFilters = new LinkedHashSet<String>(newFilter);
                        addedFilters.removeAll(remoteSubscriberRecord.
                                               getCurrentFilter());
                        if (addedFilters.size() > 0) {
                            for (Iterator<String> iter = addedFilters.iterator();
                                    iter.hasNext(); ) {
                                String item = iter.next();
                                findFilter +=
                                        (DirectoryConstants.
                                         DIRECTORY_REGULAR_EXPRESSION_DIVIDER +
                                         DirectoryConstants.DIRECTORY_SERVICE_SEPARATOR +
                                         item +
                                         DirectoryConstants.DIRECTORY_SERVICE_SEPARATOR);
                            }
                            if (findFilter.length() > 1) {
                                findFilter = findFilter.substring(1);
                            }
                        }
                        // update current filter
                        remoteSubscriberRecord.setCurrentFilter(newFilter);
                        remoteSubscriberRecord.setCurrentFilterInString((String) m.
                                getContent());
                    } else {
                        // new remote subscription
                        remoteSubscriberRecord = new DirectoryStructure4(m.
                                getSender(), (String) m.getContent());
                        remoteSubscribers.put(remoteContainerName,
                                              remoteSubscriberRecord);
                        findFilter = remoteSubscriberRecord.
                                     getCurrentFilterInString();
                    }
                    if (findFilter.length() > 0) {
                        // are there something to send out from local providers?
                        Pattern regexpFilter = Pattern.compile(findFilter);
                        for (Iterator<DirectoryStructure1> iter = localDirectory.
                                values().iterator(); iter.hasNext(); ) {
                            DirectoryStructure1 item = iter.next();
                            if (regexpFilter.matcher(item.services).find()) {
                                // update this record
                                this.sendDirectoryRecordUpdate(item,
                                        remoteSubscriberRecord);
                            }
                        }
                    }
                    // test if container is visible
                    if (!currentVisibleContainers.contains(remoteContainerName)) {
                        // update address cache
                        if (!containerNameToAddress.containsKey(remoteContainerName)) {
                            containerNameToAddress.put(remoteContainerName,
                                    m.getSender().deriveContainerAddress());
                        }
                        // removed because problem with inaccessibility of target container
//          currentVisibleContainers.add(remoteContainerName);
//          this.handleVisible(remoteContainerName);
                    }
                    m.release();
                    return;
                } else if (DirectoryConstants.PROTOCOL_UNSUBSCRIBE.equals(protocol)) {
                    // remove remote subscriber
                    remoteSubscribers.remove(remoteContainerName);
                    m.release();
                    return;
                } else if (DirectoryConstants.PROTOCOL_SUBSCRIPTION_RELEASED.equals(
                        protocol)) {
                    // an information provider directory has been terminated
                    // remove also remote subscriber if not removed yet
                    remoteSubscribers.remove(remoteContainerName);
                    DirectoryStructure3 remoteSubscriptionRecord =
                            myRemoteSubscriptions.get(remoteContainerName);
                    if (remoteSubscriptionRecord != null) {
                        // subscription exists
                        for (DirectoryStructure1 elem :
                             remoteSubscriptionRecord.remoteDirectory.values()) {
                            elem.removeAllServices();
                            // handle changes to local subscribers
                            handleLocalSubscribersUpdate(elem);
                        }
                        remoteSubscriptionRecord.remoteDirectory.clear();
                    }
                    // remove my old subscription record
                    myRemoteSubscriptions.remove(remoteContainerName);
                    // clear address also from the cache
                    containerNameToAddress.remove(remoteContainerName);
                    m.release();
                    return;
                }
            }
            logWarning("Unexpected incoming message: " + m);
            m.release();
        } finally {
            sync.unlock();
        }
    }

    /**
     * Sends directory update to the remote subscriber
     * @param updatedRecord DirectoryRecord - updated directory record
     * @param remoteSubscriber DirectoryStructure4 - remote subscriber
     */
    private void sendDirectoryRecordUpdate(final DirectoryStructure1
                                           updatedRecord,
                                           final DirectoryStructure4
                                           remoteSubscriber) {
        String remoteContainerName = remoteSubscriber.remoteDirectoryAddress.
                                     getContainerName();
        DirectoryTransmitionRecord transmitionRecord = new
                DirectoryTransmitionRecord(updatedRecord.directoryRecord.address,
                                           updatedRecord.services);
        if (currentVisibleContainers.contains(remoteContainerName)) {
            // target container is visible
            try {
                this.sendDirectoryRecordUpdate(remoteSubscriber.
                                               remoteDirectoryAddress,
                                               transmitionRecord);
            } catch (InvisibleContainerException ex) {
                // target container is invisible
                currentVisibleContainers.remove(remoteContainerName);
                remoteSubscriber.invisibleQueueRecordUpdates.put(
                        transmitionRecord.
                        getAddress(), transmitionRecord);
                this.handleInvisible(remoteContainerName);
            }
        } else {
            // target container is invisible
            remoteSubscriber.invisibleQueueRecordUpdates.put(transmitionRecord.
                    getAddress(), transmitionRecord);
        }
    }

    /**
     * Register local services
     *
     * @param providerAddress Address
     * @param services Collection
     * @throws DirectoryException
     */
    private void register(Address providerAddress,
                                       Collection<String> services) throws
            DirectoryException {
        sync.lock();
        try {
            DirectoryStructure1 localDirectoryRecord = localDirectory.get(
                    providerAddress);
            // if record isn't exists, create new
            if (localDirectoryRecord == null) {
                localDirectoryRecord = new DirectoryStructure1(providerAddress);
                localDirectory.put(providerAddress, localDirectoryRecord);
            }
            String addedServices = localDirectoryRecord.addServices(services);
            final DirectoryRecord record = localDirectoryRecord.directoryRecord;

            // test local subscription for changes
            for (DirectoryStructure2 item : localSubscribers) {
                if (!item.knownProvides.containsKey(providerAddress)) {
                    // don't know provider yet
                    if (item.regexFilter.matcher(addedServices).find()) {
                        // matches the filter
                        final DirectoryListener listener = item.listener;
                        final String filter = item.filter;
                        listener.addEvent(new Runnable() {
                            @Override
							public void run() {
                                listener.handleNewRegister(record.containerName,
                                        new DirectoryRecord[] {record}
                                        , filter);
                                listener.handleVisible(record.containerName,
                                        new DirectoryRecord[] {record}
                                        , filter);
                            }
                        });
                        // update known and visible providers
                        item.knownProvides.put(record.address, localDirectoryRecord);
                        item.visibleProviders.put(record.address,
                                                  localDirectoryRecord);
                    }
                }
            }

            // test remote subscription for changes
            for (DirectoryStructure4 item : remoteSubscribers.values()) {
                if (item.regexpCurrentFilter.matcher(addedServices).find()) {
                    //matches filter
                    // send remote update
                    this.sendDirectoryRecordUpdate(localDirectoryRecord, item);
                }
            }
        } finally {
            sync.unlock();
        }
    }

    /**
     * Deregister services
     *
     * @param providerAddress Address
     * @param services Collection
     * @throws DirectoryException
     */
    private void deregister(Address providerAddress,
                                         Collection<String> services) throws
            DirectoryException {
        sync.lock();
        try {
            DirectoryStructure1 localDirectoryRecord = localDirectory.get(
                    providerAddress);
            if (localDirectoryRecord != null) { // if record exists, remove services
                String removedServices = localDirectoryRecord.removeServices(
                        services);
                if (!localDirectoryRecord.hasServices()) {
                    // provider has no other services, remove it from the directory
                    localDirectory.remove(providerAddress);
                }
                // invoke local handle updates
                this.handleLocalSubscribersUpdate(localDirectoryRecord);
                // update appropriate remote subscribers
                for (DirectoryStructure4 item : remoteSubscribers.values()) {
                    if (item.regexpCurrentFilter.matcher(removedServices).find()) {
                        // matches the filter
                        this.sendDirectoryRecordUpdate(localDirectoryRecord, item);
                    }
                }
            }
        } finally {
            sync.unlock();
        }
    }

    /**
     * Subscribe filter
     * @param listener DirectoryListener
     * @param filter String
     */
    private void subscribeLocal(final DirectoryListener listener,
                                             final String filter) {
        sync.lock();
        try {
            // add it to the subscribers
            DirectoryStructure2 localSubscriberRecord = new DirectoryStructure2(
                    listener, filter);
            localSubscribers.add(localSubscriberRecord);

            // update united local filter for remote subscriptions
            if (!currentUnitedFilter.contains(filter)) { // filter doesn't exists yet, add it there
                boolean updated = false;
                StringBuilder newPartOfUnitedFilter =
                        new StringBuilder(DirectoryConstants.
                                          DIRECTORY_SERVICE_SEPARATOR).append(filter).
                        append(DirectoryConstants.DIRECTORY_SERVICE_SEPARATOR);
                currentUnitedFilter.add(filter);

                if (currentUnitedFilterInString.length() > 0) {
                    // some filter already exists
                    // test if there is already generalized form of the new filter
                    Pattern testObject = Pattern.compile(
                            currentUnitedFilterInString);
                    if (!testObject.matcher(newPartOfUnitedFilter).find()) {
                        // there isn't any generalized form of the new filter
                        // add it to the end of the current united filter of this Directory Service
                        currentUnitedFilterInString = new StringBuilder(
                                currentUnitedFilterInString).
                                append(DirectoryConstants.
                                       DIRECTORY_REGULAR_EXPRESSION_DIVIDER).append(
                                               newPartOfUnitedFilter).toString();
                        // set updated
                        updated = true;
                    }
                } else {
                    // first local subcribed filter
                    currentUnitedFilterInString = newPartOfUnitedFilter.toString();
                    // set updated
                    updated = true;
                }
                // if updated, update my remote subscriptions
                if (updated) {
                    // update my remote subscriptions
                    this.updateMyRemoteSubscriptions();
                }
            }
            final Collection<DirectoryRecord> result = new LinkedHashSet<
                    DirectoryRecord>();
            // local directory result
            for (Iterator<DirectoryStructure1> iter = localDirectory.values().
                    iterator(); iter.hasNext(); ) {
                DirectoryStructure1 item = iter.next();
                if (localSubscriberRecord.regexFilter.matcher(item.services).find()) {
                    // matches
                    result.add(item.directoryRecord);
                    // add it to the known and visible providers
                    localSubscriberRecord.knownProvides.put(item.directoryRecord.
                            address,
                            item);
                    localSubscriberRecord.visibleProviders.put(item.directoryRecord.
                            address,
                            item);

                }
            }
            if (result.size() > 0) {
                final String containerName = getContainer().getContainerName();
                listener.addEvent(new Runnable() {
                    @Override
					public void run() {
                        listener.handleNewRegister(containerName,
                                result.toArray(new
                                               DirectoryRecord[result.size()]),
                                filter);
                        listener.handleVisible(containerName,
                                               result.toArray(new DirectoryRecord[
                                result.size()]),
                                               filter);
                    }
                });
            }
            // remote directories results, go through all remote directories
            for (Map.Entry<String, DirectoryStructure3> item : myRemoteSubscriptions.entrySet()) {
                DirectoryStructure3 remoteSubscriptionRecord = item.
                        getValue();
                final String remoteContainerName = item.getKey();
                final boolean visible = currentVisibleContainers.contains(
                        remoteContainerName);
                final Collection<DirectoryRecord> res = new LinkedHashSet<
                        DirectoryRecord>();
                // go through remote directory records
                for (DirectoryStructure1 item2 : remoteSubscriptionRecord.remoteDirectory.values()) {
                    if (localSubscriberRecord.regexFilter.matcher(item2.services).
                        find()) {
                        // match
                        res.add(item2.directoryRecord);
                        // add it to the known providers
                        localSubscriberRecord.knownProvides.put(item2.
                                directoryRecord.address,
                                item2);
                        // if remote container is visible, add it to the visible provider
                        if (visible) {
                            localSubscriberRecord.visibleProviders.put(item2.
                                    directoryRecord.
                                    address, item2);
                        }
                    }
                }
                if (res.size() > 0) {
                    listener.addEvent(new Runnable() {
                        @Override
						public void run() {
                            listener.handleNewRegister(remoteContainerName,
                                    res.toArray(new DirectoryRecord[res.size()]),
                                    filter);
                            if (visible) {
                                listener.handleVisible(remoteContainerName,
                                        res.toArray(new DirectoryRecord[res.size()]),
                                        filter);
                            }
                        }
                    });
                }
            }
        } finally {
            sync.unlock();
        }
    }

    /**
     * Unsubscriber filter
     * @param listener DirectoryListener
     * @param filter String
     */
    private void unsubscribeLocal(DirectoryListener listener,
                                               String filter) {
        sync.lock();
        try {
            // try to find this subscription and remove it
            for (Iterator<DirectoryStructure2> iter = localSubscribers.iterator();
                    iter.hasNext(); ) {
                DirectoryStructure2 item = iter.next();
                if (item.listener == listener && item.filter.equals(filter)) { // found
                    iter.remove();
                    // test if united filter changed
                    Collection<String> newUnitedFilter = new HashSet<String>();
                    StringBuilder newUnitedFilterBuilder = new StringBuilder();
                    boolean firstValue = true;
                    for (DirectoryStructure2 item2 : localSubscribers) {
                        // test if filter already exists
                        if (!newUnitedFilter.contains(item2.filter)) {
                            // add it there
                            newUnitedFilter.add(item2.filter);
                            // prepare filter expression
                            StringBuilder filterToAdd = new StringBuilder(
                                    DirectoryConstants.DIRECTORY_SERVICE_SEPARATOR).
                                    append(item2.filter).append(DirectoryConstants.
                                    DIRECTORY_SERVICE_SEPARATOR);
                            // test if this is first filter in united filter value
                            if (firstValue) {
                                // if first, don't append divider
                                firstValue = false;
                                newUnitedFilterBuilder.append(filterToAdd);
                            } else {
                                // otherwise test if there is already generalized filter
                                Pattern testObject = Pattern.compile(
                                        newUnitedFilterBuilder.toString());
                                if (!testObject.matcher(filterToAdd).find()) {
                                    // if no, add filter to united filter value
                                    newUnitedFilterBuilder.append(
                                            DirectoryConstants.
                                            DIRECTORY_REGULAR_EXPRESSION_DIVIDER).
                                            append(filterToAdd);
                                }
                            }
                        }
                    }
                    String newUnitedFilterInString = newUnitedFilterBuilder.
                            toString();
                    if (!currentUnitedFilterInString.equals(newUnitedFilterInString)) {
                        // update my remote subscriptions
                        this.updateMyRemoteSubscriptions();
                    }
                    // update current values
                    currentUnitedFilter = newUnitedFilter;
                    currentUnitedFilterInString = newUnitedFilterInString;
                    break;
                }
            }
        } finally {
            sync.unlock();
        }
    }

    /**
     * Update my remote subscriptions with new currentUnitedFilter.
     */
    private void updateMyRemoteSubscriptions() {
        //TODO: Optimize - first reads all keys and than accesses the collection again
        for (String item : myRemoteSubscriptions.keySet()) {
            DirectoryStructure3 remoteSubscriptionsRecord =
                    myRemoteSubscriptions.get(item);
            if (currentVisibleContainers.contains(item)) { // remote container is visible
                try {
                    sendSubscribeChangeFilter(remoteSubscriptionsRecord.
                                              remoteDirectoryAddress,
                                              currentUnitedFilterInString);
                } catch (InvisibleContainerException ex) {
                    // mark container as invisible and insert filter update to the queue
                    remoteSubscriptionsRecord.invisibleMyFilterUpdate =
                            currentUnitedFilterInString;
                    currentVisibleContainers.remove(item);
                    this.handleInvisible(item);
                }
            } else { // remote container is invisible
                // mark that filter must be updated after remote container gets visible
                remoteSubscriptionsRecord.invisibleMyFilterUpdate =
                        currentUnitedFilterInString;
            }
        }
    }

    /**
     * Sends filter subscribe, change or unsubscribe to the remote subscriber
     *
     * @param remoteDirectory Address
     * @param newFilter String - new subscription; if newFilter length is null, then unsubscribe is send
     * @throws InvisibleContainerException - if remote directory is not visible
     */
    private void sendSubscribeChangeFilter(final Address remoteDirectory,
                                           final String newFilter) throws
            InvisibleContainerException {
        Message m = Message.newInstance(MessageConstants.INFORM, this.getAddress(),
                                        remoteDirectory);
        if ((newFilter != null) && (newFilter.length() > 0)) {
            m.setProtocol(DirectoryConstants.PROTOCOL_SUBSCRIBE_CHANGE);
            m.setContent(newFilter);
        } else {
            m.setProtocol(DirectoryConstants.PROTOCOL_UNSUBSCRIBE);
        }
        sendMessageAsReference(m);
        m.release();
    }

    /**
     * Sends directory update to the remote subscriber
     *
     * @param remoteDirectory Address - remote directory address
     * @param record DirectoryTransmitionRecord - directory update in the
     *   DirectoryTransmitionRecord
     * @throws InvisibleContainerException
     */
    private void sendDirectoryRecordUpdate(final Address remoteDirectory,
                                           final DirectoryTransmitionRecord
                                           record) throws
            InvisibleContainerException {
        Message m = Message.newInstance(MessageConstants.INFORM, this.getAddress(),
                                        remoteDirectory);
        m.setProtocol(DirectoryConstants.
                      PROTOCOL_HANDLE_DIRECTORY_RECORD_UPDATE);
        m.setContent(record);
        sendMessageAsReference(m);
        m.release();
    }

    /**
     * Handles visible container. Tests if my subscription to that remote container exists, and sends handle visible
     * to the local subscribers
     * @param remoteContainerName String
     */
    private void handleVisible(final String remoteContainerName) {
        // test if remote container I see for the first time
        if (!myRemoteSubscriptions.containsKey(remoteContainerName)) {
            // create new structure
            DirectoryStructure3 remoteSubscriberRecord = new DirectoryStructure3(
                    containerNameToAddress.get(remoteContainerName));
            myRemoteSubscriptions.put(remoteContainerName,  remoteSubscriberRecord);

            // test if I have some current filter
            if (currentUnitedFilter.size() > 0) {
                try {
                    this.sendSubscribeChangeFilter(remoteSubscriberRecord.
                            remoteDirectoryAddress,
                            currentUnitedFilterInString);
                } catch (InvisibleContainerException ex) {
                    // target container not visible
                    remoteSubscriberRecord.invisibleMyFilterUpdate =
                            currentUnitedFilterInString;
                    currentVisibleContainers.remove(remoteContainerName);
                    return;
                }
            }
        } else { // already known container
            DirectoryStructure3 remoteSubscriberRecord = myRemoteSubscriptions.
                    get(remoteContainerName);
            // test if there is  some filter changes to send out
            if (remoteSubscriberRecord.invisibleMyFilterUpdate != null) {
                try {
                    this.sendSubscribeChangeFilter(remoteSubscriberRecord.
                            remoteDirectoryAddress,
                            remoteSubscriberRecord.
                            invisibleMyFilterUpdate);
                    remoteSubscriberRecord.invisibleMyFilterUpdate = null;
                } catch (InvisibleContainerException ex1) {
                    // target container is not visible
                    currentVisibleContainers.remove(remoteContainerName);
                    return;
                }
            }
            // send handle visible update to the local subscribers
            for (DirectoryStructure2 item : localSubscribers) {
                Collection<DirectoryStructure1>
                        getVisible = new LinkedHashSet<DirectoryStructure1>(
                                remoteSubscriberRecord.remoteDirectory.values());
                getVisible.retainAll(item.knownProvides.values());
                // remove already visible providers
                getVisible.removeAll(item.visibleProviders.values());
                // create visible update
                if (getVisible.size() > 0) { // there is something for update
                    final DirectoryRecord[] visible = new DirectoryRecord[
                            getVisible.size()];
                    int i = 0;
                    for (Iterator<DirectoryStructure1> iter2 = getVisible.
                            iterator(); iter2.hasNext(); ) {
                        DirectoryStructure1 item2 = iter2.next();
                        visible[i++] = item2.directoryRecord;
                    }
                    final String filter = item.filter;
                    final DirectoryListener listener = item.listener;
                    listener.addEvent(new Runnable() {
                        @Override
						public void run() {
                            listener.handleVisible(remoteContainerName, visible,
                                    filter);
                        }
                    });
                    // add all known providers to the visible providers
                    for (Iterator<DirectoryStructure1> iter2 = getVisible.
                            iterator(); iter2.hasNext(); ) {
                        DirectoryStructure1 item2 = iter2.next();
                        item.visibleProviders.put(item2.directoryRecord.address,
                                                  item2);
                    }
                }
            }
        }
        // test if remote subscriber has some queue to send out
        DirectoryStructure4 remoteSubscriber = remoteSubscribers.get(
                remoteContainerName);
        if (remoteSubscriber != null) {
            if (remoteSubscriber.invisibleQueueRecordUpdates.size() > 0) {
                // there are some queue for sending updates
                for (Iterator<DirectoryTransmitionRecord> iter =
                        remoteSubscriber.invisibleQueueRecordUpdates.
                        values().iterator(); iter.hasNext(); ) {
                    DirectoryTransmitionRecord item = iter.next();
                    try {
                        this.sendDirectoryRecordUpdate(remoteSubscriber.
                                remoteDirectoryAddress, item);
                    } catch (InvisibleContainerException ex2) {
                        //target container gets invisible
                        currentVisibleContainers.remove(remoteContainerName);
                        this.handleInvisible(remoteContainerName);
                        return;
                    }
                }
            }
        }
    }

    /**
     * Handles invisible container, send handle invisible to the local subscribers
     * @param remoteContainerName String
     */
    private void handleInvisible(final String remoteContainerName) {
        DirectoryStructure3 remoteSubscriptionRecord = myRemoteSubscriptions.
                get(remoteContainerName);
        if (remoteSubscriptionRecord != null) {
            // go through all local subscribers
            for (DirectoryStructure2 item : localSubscribers) {
                Collection<DirectoryStructure1> lastVisible = new LinkedHashSet<DirectoryStructure1>(remoteSubscriptionRecord.remoteDirectory.values());
                lastVisible.retainAll(item.visibleProviders.values());
                if (lastVisible.size() > 0) { // there is something for update
                    // create invisible array
                    final DirectoryRecord[] invisible = new DirectoryRecord[lastVisible.size()];
                    int i = 0;
                    for (DirectoryStructure1 item2 : lastVisible) {
                        invisible[i++] = item2.directoryRecord;
                    }
                    final String filter = item.filter;
                    final DirectoryListener listener = item.listener;
                    // send handle invisible for all visible providers
                    listener.addEvent(new Runnable() {
                        @Override
						public void run() {
                            listener.handleInvisible(remoteContainerName,
                                    invisible, filter);
                        }
                    });
                    // remove from visible agent list
                    for (DirectoryStructure1 item2 : lastVisible) {
                        item.visibleProviders.remove(item2.directoryRecord.address);
                    }
                }
            }
        }
    }

    /**
     *
     * <p>Title: A-Globe</p>
     * <p>Description: service shell of the DirectoryService</p>
     * <p>Copyright: Copyright (c) 2004</p>
     * <p>Company: Gerstner Laboratory</p>
     * @author David Sislak
     * @version $Revision: 1.5 $ $Date: 2010/08/04 11:48:06 $
     */
    public static class Shell extends ServiceShell {

        /**
         * Link to the directory service.
         */
        transient DirectoryService theservice = null;

        /**
         * Current registered services
         */
        private Collection<String> registredServices = new LinkedHashSet<String>();

        /**
         * Services provider
         */
        private ElementaryEntity serviceProvider = null;

        /**
         * Current subscribed services filters, position in the list correspond with the second list subscribedListeners
         */
        private List<String> subscribedFilters = new LinkedList<String>();

        /**
         * Current subscribed listeners, position in the list correspond with the second list subscribedFilters
         */
        private List<DirectoryListener> subscribedListeners = new LinkedList<
                DirectoryListener>();

        /**
         * true if shell is in post initialization mode
         */
        private transient boolean postInit = false;

        /**
         * remembered registered services. It is used after migration
         */
        private transient Collection<String> memRegistredServices;

        /**
         * remembered subscribed filters. It is used after migration
         */
        private transient List<String> memSubscribedFilters;

        /**
         * remembered subscribed listeners. It is used after migration
         */
        private transient List<DirectoryListener> memSubscribedListeners;

        /**
         * Constructor used for serialization purposes. DO NOT USE THIS constructor.
         */
        public Shell() {
            super();
        }

        /**
         * Private constructor of Shell. It is called from
         * <code>getServiceShell()</code> of <code>DirectoryService</code>.
         *
         * @param shellOwner ElementaryEntity - agent/service
         * @param _theservice DirectoryService
         */
        private Shell(ShellOwner shellOwner, DirectoryService _theservice) {
            super(shellOwner);
            theservice = _theservice;
        }

        /**
         * Register services provided by an agent
         *
         * @param serviceProvider ElementaryEntity
         * @param services Set - set of the strings; string cannot contains
         *   DirectoryConstants.DIRECTORY_SERVICE_SEPARATOR !!!
         * @throws DirectoryException
         */
        public void register(ElementaryEntity serviceProvider,
                             Collection<String> services) throws
                DirectoryException {
            if (this.serviceProvider != null &&
                this.serviceProvider != serviceProvider) {
                throw new DirectoryException(
                        "You try to register another service provider than before !!!");
            }
            this.serviceProvider = serviceProvider;
            Collection<String>
                    addServices = new LinkedHashSet<String>(services);
            addServices.removeAll(registredServices);
            if (addServices.size() > 0) {
                registredServices.addAll(addServices);
                theservice.register(serviceProvider.getAddress(), addServices);
            }
        }

        /**
         * Register services provided by an agent
         *
         * @param serviceProvider ElementaryEntity
         * @param services String[] - array of provided services; string cannot contains
         * DirectoryConstants.DIRECTORY_SERVICE_SEPARATOR !!!
         * @throws DirectoryException
         */
        public void register(ElementaryEntity serviceProvider,
                             String[] services) throws
                DirectoryException {
            if (this.serviceProvider != null &&
                this.serviceProvider != serviceProvider) {
                throw new DirectoryException(
                        "You try to register another service provider than before !!!");
            }
            this.serviceProvider = serviceProvider;
            Collection<String>
                    addServices = new LinkedHashSet<String>(services.length);
            for (String elem : services) {
                if (!registredServices.contains(elem)) {
                    addServices.add(elem);
                }
            }
            if (addServices.size() > 0) {
                registredServices.addAll(addServices);
                theservice.register(serviceProvider.getAddress(), addServices);
            }
        }

        /**
         * Deregister services provided by agent/service
         *
         * @param services Collection - set of the service which will be
         *   deregistered
         * @throws DirectoryException
         */
        public void deregister(Collection<String> services) throws
                DirectoryException {
            Collection<String>
                    removeServices = new LinkedHashSet<String>(services);
            removeServices.retainAll(registredServices);
            if (removeServices.size() > 0) {
                registredServices.removeAll(removeServices);
                theservice.deregister(serviceProvider.getAddress(),
                                      removeServices);
            }
        }

        /**
         * Deregister services provided by agent/service
         *
         * @param services String[] - set of the service which will be
         *   deregistered
         * @throws DirectoryException
         */
        public void deregister(String[] services) throws
                DirectoryException {
            Collection<String>
                    removeServices = new LinkedHashSet<String>(services.length);
            for (String elem : services) {
                if (registredServices.contains(elem)) {
                    removeServices.add(elem);
                }
            }
            if (removeServices.size() > 0) {
                registredServices.removeAll(removeServices);
                theservice.deregister(serviceProvider.getAddress(),
                                      removeServices);
            }
        }

        /**
         * Deregister all registered services
         */
        public void deregisterAll() {
            if (serviceProvider == null) {
                // nothing to deregister
                return;
            }
            try {
                theservice.deregister(serviceProvider.getAddress(),
                                      registredServices);
            } catch (DirectoryException ex) {
                Logger.getLogger(DirectoryService.SERVICENAME).warning(
                        "Problem with deregister service: " + ex);
            }
            registredServices.clear();
        }

        /**
         * Subscribe filter
         * @param listener DirectoryListener
         * @param filter String
         */
        public void subscribe(DirectoryListener listener,
                              String filter) {
            theservice.subscribeLocal(listener, filter);
            subscribedFilters.add(filter);
            subscribedListeners.add(listener);
        }

        /**
         * Unsubscribe filter. If it is possible prefer unsubscribeAll method
         * @param listener DirectoryListener
         * @param filter String
         */
        public void unsubscribe(DirectoryListener listener,
                                String filter) {
            Iterator<DirectoryListener> iter2 = subscribedListeners.iterator();
            for (Iterator<String> iter = subscribedFilters.iterator();
                                         iter.hasNext(); ) {
                String item = iter.next();
                DirectoryListener listener2 = iter2.next();
                if (listener == listener2 && item.equals(filter)) {
                    iter.remove();
                    iter2.remove();

                    theservice.unsubscribeLocal(listener, filter);
                    break;
                }
            }
        }

        /**
         * Unsubscribe all subscribed listeners
         */
        public void unsubscribeAll() {
            Iterator<DirectoryListener> iter2 = subscribedListeners.iterator();
            for (Iterator<String> iter = subscribedFilters.iterator();
                                         iter.hasNext(); ) {
                String item = iter.next();
                DirectoryListener listener = iter2.next();
                theservice.unsubscribeLocal(listener, item);
            }
            subscribedFilters.clear();
            subscribedListeners.clear();
        }

        /**
         *  Dispose this shell.
         */
        @Override
        public void dispose() {
            // unsubscribe all
            Iterator<DirectoryListener> iter2 = subscribedListeners.iterator();
            for (Iterator<String> iter = subscribedFilters.iterator();
                                         iter.hasNext(); ) {
                String item = iter.next();
                DirectoryListener listener = iter2.next();
                theservice.unsubscribeLocal(listener, item);
            }
            // deregister all
            if (serviceProvider != null) {
                try {
                    theservice.deregister(serviceProvider.getAddress(),
                                          registredServices);
                } catch (DirectoryException ex) {
                    Logger.getLogger(DirectoryService.SERVICENAME).warning(
                            "Problem with deregister service: " + ex);
                }
            }
            super.dispose();
        }

        /**
         * isValid
         * @return boolean
         */
        @Override
        public boolean isValid() {
            return theservice != null;
        }

        /**
         * This method assigns a container to the <code>Shell</code> of the
         * <code>DirectoryService</code>.
         *
         * @param container AgentContainer
         * @throws Exception
         */
        @Override
        public void setContainer(AgentContainer container) throws Exception {
            Service s = container.getServiceManager().getServiceInstance(DirectoryService.SERVICENAME);
            if ((s != null) && (s instanceof DirectoryService)) {
                theservice = (DirectoryService) s;
                // remember values
                postInit = true;
                memSubscribedFilters = new LinkedList<String>(
                        subscribedFilters);
                memSubscribedListeners = new LinkedList<DirectoryListener>(
                        subscribedListeners);
                memRegistredServices = new LinkedList<String>(registredServices);
            } else {
                throw new Exception(container.getContainerName() +
                                    ": Cannot reconect to the Directory Service");
            }
        }

        /**
         * Called after init of the owner agent
         */
        @Override
        public void postInit() {
            if (!postInit) {
                return;
            }
            // subscribe back all listeners
            Iterator<DirectoryListener> iter2 = memSubscribedListeners.iterator();
            for (Iterator<String> iter = memSubscribedFilters.iterator();
                                         iter.hasNext(); ) {
                String item = iter.next();
                DirectoryListener listener = iter2.next();
                theservice.subscribeLocal(listener, item);
            }
            if (serviceProvider != null) {
                // register back all services
                try {
                    theservice.register(serviceProvider.getAddress(),
                                        memRegistredServices);
                } catch (DirectoryException ex) {
                    Logger.getLogger(DirectoryService.SERVICENAME).warning(
                            "Problem with register service: " + ex);
                }
            }
        }

        /**
         * The object implements the writeExternal method to save its contents by
         * calling the methods of DataOutput for its primitive values or calling the
         * writeObject method of ObjectOutput for objects, strings, and arrays.
         *
         * @param out the stream to write the object to
         * @throws IOException Includes any I/O exceptions that may occur
         */
        @Override
        public void writeExternal(ObjectOutput out) throws IOException {
            super.writeExternal(out);
            out.writeInt(registredServices.size());
            for (String elem : registredServices) {
                ConversionTools.writeString(out, elem);
            }
            out.writeObject(serviceProvider);
            out.writeInt(subscribedFilters.size());
            for (String elem : subscribedFilters) {
                ConversionTools.writeString(out, elem);
            }
            out.writeInt(subscribedListeners.size());
            for (DirectoryListener elem : subscribedListeners) {
                out.writeObject(elem);
            }
        }

        /**
         * The object implements the readExternal method to restore its contents by
         * calling the methods of DataInput for primitive types and readObject for
         * objects, strings and arrays.
         *
         * @param in the stream to read data from in order to restore the object
         * @throws IOException if I/O errors occur
         * @throws ClassNotFoundException If the class for an object being restored
         *   cannot be found.
         */
        @Override
        public void readExternal(ObjectInput in) throws IOException,
                ClassNotFoundException {
            super.readExternal(in);
            int cnt = in.readInt();
            registredServices = new LinkedHashSet<String>();
            for (int i = 0; i < cnt; i++) {
                registredServices.add(ConversionTools.readString(in));
            }
            serviceProvider = (ElementaryEntity) in.readObject();
            cnt = in.readInt();
            subscribedFilters = new LinkedList<String>();
            for (int i = 0; i < cnt; i++) {
                subscribedFilters.add(ConversionTools.readString(in));
            }
            cnt = in.readInt();
            subscribedListeners = new LinkedList<DirectoryListener>();
            for (int i = 0; i < cnt; i++) {
                subscribedListeners.add((DirectoryListener) in.readObject());
            }
        }

    }
}
