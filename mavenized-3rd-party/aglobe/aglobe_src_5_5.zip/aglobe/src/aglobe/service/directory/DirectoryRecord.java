package aglobe.service.directory;

import java.util.Arrays;

import aglobe.container.transport.Address;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: contains directory information about agent</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.2 $ $Date: 2009/06/15 13:38:01 $
 */

public class DirectoryRecord {
    /**
     * Contains agent addres
     */
    public final Address address;

    /**
     * Container name where agent runs
     */
    public final String containerName;

    /**
     * Array of the services provided by the agent
     */
    private String[] services;

    /**
     * Hash value
     */
    private int hashValue;

    /**
     *
     * @param address Address
     * @param services String[]
     */
    public DirectoryRecord(final Address address,
                           final String[] services) {
        this.address = address;
        this.containerName = address.getContainerName();
        this.services = services;
        updateHashValue();
    }

    /**
     * Get array of the services provided by the agent
     * @return String[]
     */
    public String[] getServices() {
        return services;
    }

    /**
     * Set new array of the services. Can be called only from this package.
     * @param services String[]
     */
    void setServices(final String[] services) {
        this.services = services;
        updateHashValue();
    }

    /**
     * Tests if provider has specified service
     * @param service String - service for test
     * @return boolean - true iff it has that service
     */
    public boolean hasService(String service) {
        for (int i = 0; i < services.length; i++) {
            if (services[i].equals(service)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Used for updating hash value of the instance
     */
    private void updateHashValue() {
        int retVal = 19;
        retVal = 37 * retVal + address.hashCode();
        retVal = 37 * retVal + containerName.hashCode();
        retVal = 37 * retVal + Arrays.hashCode(services);
        hashValue = retVal;
    }

    /**
     * Returns hash value of this instance
     * @return int
     */
    @Override
    public int hashCode() {
        return hashValue;
    }

    /**
     * Test if instance is same as other object
     * @param other Object
     * @return boolean - true iff instances are same
     */
    @Override
    public boolean equals(Object other) {
        if (other instanceof DirectoryRecord) {
            if (hashValue != other.hashCode())
                return false;
            DirectoryRecord o = (DirectoryRecord) other;
            return address.equals(o.address) && containerName.equals(o.containerName) &&
                    Arrays.equals(services, o.services);
        }
        return false;
    }

    /**
     * Returns string representation of this instance
     * @return String
     */
    @Override
    public String toString() {
        String tmp = "";
        for (int i = 0; i < services.length; i++) {
            tmp += ("[" + services[i] + "]");
        }
        return "Address: " + address + " Container: " + containerName + " Services: " + tmp;
    }
}
