package aglobe.service.directory;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: Directory exception</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.2 $ $Date: 2009/06/15 13:38:01 $
 */

public class DirectoryException extends Exception {

    private static final long serialVersionUID = -6176062570911158570L;

    /**
     *
     * @param text String - exception reason
     */
    public DirectoryException(String text) {
        super(text);
    }
}
