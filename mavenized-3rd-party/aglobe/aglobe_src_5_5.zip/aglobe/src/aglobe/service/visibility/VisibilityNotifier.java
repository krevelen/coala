/**
 *
 */
package aglobe.service.visibility;

import java.io.Serializable;

import aglobe.container.EventReceiver;
import aglobe.container.transport.Address;

/**
 * <p>Title: VisibilityNotifier</p>
 *
 * <p>Description: The implementor can register to the VisibilityService for receiving
 * information about container neighbors.</p>
 *
 * <p>Copyright: Copyright (c) 2009</p>
 *
 * <p>Company: Agent Technology Center</p>
 *
 * @author David Sislak
 * @version $Revision: 1.2 $ $Date: 2009/06/15 13:38:02 $
 *
 */
public interface VisibilityNotifier extends EventReceiver, Serializable {
    /**
     * Specified container is newly visible form the container
     * @param containerAddress
     */
    public void becomeVisible(final Address containerAddress);

    /**
     * Specified container is not visible
     * @param containerAddress
     */
    public void becomeInvisible(final Address containerAddress);
}
