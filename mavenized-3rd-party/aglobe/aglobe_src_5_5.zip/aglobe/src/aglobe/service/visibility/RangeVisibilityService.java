package aglobe.service.visibility;

import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.lang.management.ManagementFactory;
import java.util.LinkedHashSet;

import aglobe.container.AgentContainer;
import aglobe.container.service.Service;
import aglobe.container.service.ServiceShell;
import aglobe.container.service.ShellOwner;
import aglobe.container.transport.Address;
import aglobe.container.transport.InvisibleContainerException;
import aglobe.container.transport.MessageTransport;
import aglobe.container.transport.SendMessageHookInterface;
import aglobe.ontology.Message;
import aglobe.ontology.VisibilityUpdate;
import aglobe.platform.Platform;
import aglobe.service.link.LinkNeighbourListener;
import aglobe.service.link.LinkService;
import aglobe.service.topics.TopicsHandler;
import aglobe.service.topics.TopicsService;
import aglobe.util.concurrent.NonblockingPoolArrayFIFO;

/**
 * @internal
 * This service monitors which containers are visible and allows messages sent out
 * from this container to go to only those that are visible.
 *
 * @version $Revision: 1.2 $ $Date: 2010/11/30 09:12:27 $
 */
public final class RangeVisibilityService extends VisibilityService implements SendMessageHookInterface {

    private final static NonblockingPoolArrayFIFO<LinkedHashSet<Address>> poolOfLinkedHashSets = new NonblockingPoolArrayFIFO<LinkedHashSet<Address>>(ManagementFactory.getOperatingSystemMXBean().getAvailableProcessors() * 2);

    /**
     * Message transport used for hook registration, notification about messages
     * thrown out etc.
     */
    private MessageTransport containerTransport = null;

    private TopicsService.Shell topicsShell = null;
    private LinkService.Shell linkShell = null;


    /**
     * True iff all outgoing messages must be tested on visibility restrictions.
     * First, we do not restrict anything (controlVisibility == false). In case
     * we receive some visibility update topic, than we switch to the mode
     * of checking the visibility for the messages.
     */
    private volatile boolean controlVisibility = false;

    /**
     * Get service shell of the Visibility service
     *
     * @return ServiceShell
     * @param shellOwner ElementaryEntity - agent/service
     */
    @Override
    protected final ServiceShell getServiceShell(final ShellOwner shellOwner) {
        vLock.lock();
        try {
            Shell retVal = new Shell(shellOwner, this);
            registerActiveShell(retVal);
            return retVal;
        } finally {
            vLock.unlock();
        }
    }

    /**
     * Called automatically by the Aglobe when the service is started.
     */
    @SuppressWarnings("serial")
    @Override
    public final void init() {

        // initialize transport
        this.containerTransport = getContainer().getMessageTransport();

        //connect to the local topics service
        topicsShell = (TopicsService.Shell) getContainer().getServiceManager().getService(this, TopicsService.SERVICENAME);
        if (topicsShell == null) {
            linkShell = (LinkService.Shell) getContainer().getServiceManager().getService(this, LinkService.SERVICENAME);
            if (linkShell == null) {
                logSevere("VisibilityService can run only on the container with TopicsService or LinkService running.");
                stop();
                return;
            }
            // add own container to the visible set
            thisContainerAddress = Address.getLocalContainerAddress(getContainer());
            visible.add(thisContainerAddress);
            // register link listener
            linkShell.subscribeNeighbour(new LinkNeighbourListener() {
                @Override
                public void handleDeregister(final Address containerAddress) {
                    vLock.lock();
                    try {
                        visible.remove(containerAddress);
                        if (activeShells.size() > 0) {
                            for (VisibilityService.Shell shell : activeShells) {
                                shell.removeVisible(containerAddress);
                            }
                        }
                    } finally {
                        vLock.unlock();
                    }
                }

                @Override
                public void handleRegister(final Address containerAddress) {
                    vLock.lock();
                    try {
                        visible.add(containerAddress);
                        if (activeShells.size() > 0) {
                            for (VisibilityService.Shell shell : activeShells) {
                                shell.addNewVisible(containerAddress);
                            }
                        }
                    } finally {
                        vLock.unlock();
                    }
                }

                @Override
                public void addEvent(final Runnable e) {
                    e.run();
                }

            });
            // register the hook
            containerTransport.registerMessageHook(RangeVisibilityService.this,null,null,VISIBILITY_HOOK_PRIORITY);
            controlVisibility = true;

        } else {

            // subscribe topics for being up to date with visibility restrictions
            final TopicsHandler topicsHandler = new TopicsHandler() {

                @Override
                public void handleIncomingTopic(final String topic, final Object content, final String reason) {
                    final VisibilityUpdate gi = (VisibilityUpdate) content;
                    // fill new visible containers
                    vLock.lock();
                    try {
                        switch (gi.getVisibilityUpdateType()) {
                        case FULL_UPDATE: {
                            visible.clear();
                            if (thisContainerAddress == null) {
                                thisContainerAddress = Address.getLocalContainerAddress(
                                        getContainer());
                            }
                            visible.add(thisContainerAddress);
                            visible.addAll(gi.getVisibleContainerAddress());
                            visibilityID = gi.getVisibilityID();
                            // notify all notifiers
                            if (activeShells.size() > 0) {
                                for (VisibilityService.Shell shell : activeShells) {
                                    shell.compareNewVisibility();
                                }
                            }
                        }
                        break;
                        case DIFFERENTIAL_ADD: {
                            boolean first = false;
                            if (visible.size() == 0) {
                                if (thisContainerAddress == null) {
                                    thisContainerAddress = Address.getLocalContainerAddress(
                                            getContainer());
                                }
                                visible.add(thisContainerAddress);
                                first = true;
                            }
                            visible.addAll(gi.getVisibleContainerAddress());
                            visibilityID = gi.getVisibilityID();
                            if (activeShells.size() > 0) {
                                for (VisibilityService.Shell shell : activeShells) {
                                    if (first) {
                                        shell.addNewVisible(thisContainerAddress);
                                    }
                                    for (Address adr : gi.getVisibleContainerAddress()) {
                                        shell.addNewVisible(adr);
                                    }
                                }
                            }
                        }
                        break;
                        case DIFFERENTIAL_REMOVE: {
                            visible.removeAll(gi.getVisibleContainerAddress());
                            visibilityID = gi.getVisibilityID();
                            if (activeShells.size() > 0) {
                                for (VisibilityService.Shell shell : activeShells) {
                                    for (Address adr : gi.getVisibleContainerAddress()) {
                                        shell.removeVisible(adr);
                                    }
                                }
                            }
                        }
                        break;
                        default:
                            throw new RuntimeException("Unsupported VisibilityUpdateType: "+gi.getVisibilityUpdateType().toString());
                        }
                        if (!controlVisibility) {
                            // and register the hook
                            containerTransport.registerMessageHook(RangeVisibilityService.this,null,null,VISIBILITY_HOOK_PRIORITY);
                            controlVisibility = true;
                        }
                    } finally {
                        vLock.unlock();
                    }
                    // release update
                    gi.release();            }

                @Override
                public void addEvent(Runnable e) {
                    // This has to be executed in the Topics thread, to be applied earlier than other receivers will use new
                    //   visibility information, e.g. Directory Service
                    e.run();
                }

            };
            topicsShell.subscribeHandlerAsync(TOPIC_VISIBILITY_UPDATES_ALL, topicsHandler);
            topicsShell.subscribeHandlerAsync(TOPIC_VISIBILITY_UPDATES_PREFIX + getContainer().getContainerName(), topicsHandler);
        }

    }

    /**
     * Called by A-globe kernel when the service is being shut down.
     */
    @Override
    public final void finish() {
        if (topicsShell != null) {
            topicsShell.dispose();
            topicsShell = null;
        }
        if (linkShell != null) {
            linkShell.dispose();
            linkShell = null;
        }
        if (controlVisibility) {
            getContainer().getMessageTransport().unregisterMessageHook(this);
            controlVisibility = false;
        }
    }

    /**
     * Processes messages. Not used in SnifferService.
     */
    @Override
    public final void handleIncomingMessage(final Message m) {
        throw new RuntimeException("SnifferService should not receive any message.");
    }

    /* (non-Javadoc)
     * @see aglobe.container.transport.SendMessageHookInterface#processOutgoingMessage(aglobe.ontology.Message)
     */
    @Override
    public final void processOutgoingMessage(final Message m) throws InvisibleContainerException {
        vLock.lock();
        try {
            // (visibility checking is enabled and message is new or reply has older visibility ID than my)
            if (!m.getIsReply() || (m.getVisibilityID() < visibilityID)) {
                // update message visibility ID
                m.setVisibilityID(visibilityID);
                // we need to check visibility differently for uni-cast and multicast
                if (m.isMulticast()) {
                    if (!checkMulticastVisibility(m)) {
                        // not visible
                        m.setUndeliverable();
                    }
                } else {
                    if (!checkUnicastVisibility(m)) {
                        // not visible
                        m.setUndeliverable();
                    }
                }
            }
        } finally {
            vLock.unlock();
        }

        // visible, continue sending
        containerTransport.forwardOutgoingMessage(m, VISIBILITY_HOOK_PRIORITY);
    }

    /**
     * @param m Message that is about to be sent.
     * @return true if the message should be sent out, false otherwise
     */
    private final boolean checkUnicastVisibility(final Message m) {
        final boolean msgVisible = visible.contains(m.getReceiver().deriveContainerAddress());
        if (!msgVisible) {
            // inform about discarding the message
            if (Platform.SHOW_UNDELIVERED_MESSAGES) {
                logWarning(containerTransport.getContainerAddress().getContainerName() +
                               ": Target container not reachable due to visibility restrictions: " +
                               m.getReceiver());
            }
        }

        return msgVisible;
    }

    /**
     * Might change the message receivers - remove those that are not visible.
     *
     * @param m Message that is about to be sent.
     * @return true if the message should be sent out, false otherwise.
     */
    private final boolean checkMulticastVisibility(final Message m) {
        // we want to remove not visible addresses from the list of receivers, however,
        // we cannot iterate through the collection and modify it at the same time.
        // Multiple iterations or copying (done here) is necessary.
        LinkedHashSet<Address> receiversCopy = poolOfLinkedHashSets.pop();
        if (receiversCopy == null) {
            receiversCopy = new LinkedHashSet<Address>(m.getReceivers().size());
        }

        receiversCopy.addAll(m.getReceivers());
        for (Address receiver : receiversCopy) {
            final boolean msgVisible = visible.contains(receiver.deriveContainerAddress());
            if (!msgVisible) {
                m.getReceivers().remove(receiver);
            }
        }

        if (receiversCopy.size() > m.getReceivers().size()) { // some receivers were dropped, inform
            if (Platform.SHOW_UNDELIVERED_MESSAGES) {
                receiversCopy.removeAll(m.getReceivers());
                // receiversCopy now contain those that are invisible
                logWarning(containerTransport.getContainerAddress().getContainerName() +
                        ": (Multicast) Target container not reachable due to visibility restrictions: " +
                        "sending to: " + m.getReceivers() + "; ignoring: " + receiversCopy);
            }

        }

        return m.getReceivers().size() > 0;
    }

    /**
     *
     * <p>Title: Shell</p>
     *
     * <p>Description: Provides proxy object for operation with RangeVisibilityService.</p>
     *
     * <p>Copyright: Copyright (c) 2009</p>
     *
     * <p>Company: Agent Technology Center</p>
     *
     * @author David Sislak
     * @version $Revision: 1.2 $ $Date: 2010/11/30 09:12:27 $
     *
     */
    public final static class Shell extends VisibilityService.Shell {

        private transient boolean postInit = false;

        /**
         * @internal
         * Constructor used for serialization purposes. DO NOT USE THIS
         * constructor.
         */
        public Shell() {
            super();
        }

        private Shell(final ShellOwner shellOwner, final RangeVisibilityService theservice) {
            super(shellOwner);
            this.theservice = theservice;
            this.visibleContainers.addAll(theservice.visible);
        }

        /* (non-Javadoc)
         * @see aglobe.container.service.ServiceShell#dispose()
         */
        @Override
        public void dispose() {
            super.dispose();

            theservice.removeActiveShell(this);
            theservice = null;
        }

        /**
         * @internal
         * Externalizable method
         *
         * @param out
         *            ObjectOutput
         * @throws IOException
         */
        @Override
        public final void writeExternal(final ObjectOutput out) throws IOException {
            super.writeExternal(out);
            final int cnt = visibleContainers.size();
            out.writeInt(cnt);
            if (cnt > 0) {
                for (Address visible : visibleContainers) {
                    visible.serialize(out);
                }
            }
            final int cnt2 = notifiers.size();
            out.writeInt(cnt2);
            if (cnt2 > 0) {
                for (VisibilityNotifier notifier : notifiers) {
                    out.writeObject(notifier);
                }
            }
        }

        /**
         * @internal
         * Externalizable method
         *
         * @param in
         *            ObjectInput
         * @throws IOException
         * @throws ClassNotFoundException
         */
        @Override
        public final void readExternal(final ObjectInput in) throws IOException, ClassNotFoundException {
            super.readExternal(in);
            final int cnt = in.readInt();
            for (int i = 0; i < cnt; i++) {
                visibleContainers.add(Address.deserialize(in));
            }
            final int cnt2 = in.readInt();
            for (int i = 0; i < cnt2; i++) {
                notifiers.add((VisibilityNotifier)in.readObject());
            }
        }

        /* (non-Javadoc)
         * @see aglobe.container.service.ServiceShell#setContainer(aglobe.container.AgentContainer)
         */
        @Override
        public void setContainer(AgentContainer container) throws Exception {
            Service s = container.getServiceManager().getServiceInstance(VisibilityService.SERVICENAME);
            if ((s != null) && (s instanceof RangeVisibilityService)) {
                theservice = (RangeVisibilityService) s;
                // remember values
                postInit = true;
            } else {
                throw new Exception(container.getContainerName() + ": Cannot reconect to the VisibilityService");
            }
        }

        /* @internal
         * (non-Javadoc)
         * @see aglobe.container.service.ServiceShell#postInit()
         */
        @Override
        public void postInit() {
            if (!postInit) {
                return;
            }
            // compare against current visibility
            theservice.vLock.lock();
            try {
            	((RangeVisibilityService)theservice).registerActiveShell(this);
                compareNewVisibility();
            } finally {
                theservice.vLock.unlock();
            }
            postInit = false;
        }

        
    } 
}
