package aglobe.service.visibility;

import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.LinkedHashSet;
import java.util.concurrent.locks.ReentrantLock;

import aglobe.container.AgentContainer;
import aglobe.container.service.Service;
import aglobe.container.service.ServiceShell;
import aglobe.container.service.ShellOwner;
import aglobe.container.transport.Address;
import aglobe.container.transport.InvisibleContainerException;
import aglobe.container.transport.SendMessageHookInterface;
import aglobe.ontology.Message;

/**
 * @internal
 * This service monitors which containers are visible and allows messages sent out
 * from this container to go to only those that are visible.
 *
 * @version $Revision: 1.15 $ $Date: 2009/11/25 13:19:43 $
 */
public abstract class VisibilityService extends Service implements SendMessageHookInterface {
    private final static String TOPICS_PREFIX = "!%";
    private static int TOPICS_CNT = 1;

    /**
     * @internal
     * Visibility service name
     */
    public static final String SERVICENAME = "container/visibility";

    /**
     * @internal
     * Topic name used for sending visibility updates via Topics services. In the content there is
     * VisibilityUpdate object with the list of the Address objects. The list contains all
     * visible remote agent container details which are visible from my agent container to
     * the time when receive new TOPIC_VISIBILITY_UPDATE.
     */
    public static final String TOPIC_VISIBILITY_UPDATES_PREFIX = TOPICS_PREFIX + (TOPICS_CNT++) + "_";

    /**
     * @internal
     * Topics name used for sending visibility updates via Topics services. Using this topic,
     * given VisibilityUpdate is delivered to all Visibility receivers
     */
    public static final String TOPIC_VISIBILITY_UPDATES_ALL = TOPICS_PREFIX + (TOPICS_CNT++);

    public static final int VISIBILITY_HOOK_PRIORITY = 2;

    /**
     * Lock used for synchronization of visible set. That is:
     * visibilityID, visible, consequentServerAddresses.
     */
    protected final ReentrantLock vLock = new ReentrantLock();
    

    protected LinkedHashSet<Shell> activeShells = new LinkedHashSet<Shell>();    

    /**
     * Set of the visible container addresses
     */
    protected final LinkedHashSet<Address> visible = new LinkedHashSet<Address>();
    
    /**
     * Visibility ID of current visible list. Visibility ID grows up with each update,
     * it allows us to ignore older updates.
     */
    protected long visibilityID = 0;

    /**
     * This container address, local messages are not restricted
     */
    protected Address thisContainerAddress;

    /**
     * Get service shell of the Visibility service
     *
     * @return ServiceShell
     * @param shellOwner ElementaryEntity - agent/service
     */
    @Override
    protected abstract ServiceShell getServiceShell(final ShellOwner shellOwner);

    protected void registerActiveShell(Shell shell) {
        vLock.lock();
        try {
            activeShells.add(shell);
        } finally {
            vLock.unlock();
        }
    }
    
    
    /**
     * Called automatically by the Aglobe when the service is started.
     */
    @Override
    public abstract void init();

    /**
     * Called by A-globe kernel when the service is being shut down.
     */
    @Override
    public abstract void finish();
    

    protected void removeActiveShell(Shell shell) {
        vLock.lock();
        try {
            if (activeShells == null) {
                // during final clean-up
                return;
            }
            activeShells.remove(shell);
        } finally {
            vLock.unlock();
        }
    }

    /**
     * Processes messages. Not used in SnifferService.
     */
    @Override
    public abstract void handleIncomingMessage(final Message m);

    /* (non-Javadoc)
     * @see aglobe.container.transport.SendMessageHookInterface#processOutgoingMessage(aglobe.ontology.Message)
     */
    @Override
    public abstract void processOutgoingMessage(final Message m) throws InvisibleContainerException;

    /**
     *
     * <p>Title: Shell</p>
     *
     * <p>Description: Provides proxy object for operation with VisibilityService.</p>
     *
     * <p>Copyright: Copyright (c) 2009</p>
     *
     * <p>Company: Agent Technology Center</p>
     *
     * @author David Sislak
     * @version $Revision: 1.15 $ $Date: 2009/11/25 13:19:43 $
     *
     */
    public abstract static class Shell extends ServiceShell {

        protected transient VisibilityService theservice = null;

        protected LinkedHashSet<Address> visibleContainers = new LinkedHashSet<Address>();
        protected LinkedHashSet<VisibilityNotifier> notifiers = new LinkedHashSet<VisibilityNotifier>();

        /**
         * @internal
         * Constructor used for serialization purposes. DO NOT USE THIS
         * constructor.
         */
        public Shell() {
            super();
        }

        protected Shell(final ShellOwner shellOwner) {
            super(shellOwner);
        }

        /* (non-Javadoc)
         * @see aglobe.container.service.ServiceShell#dispose()
         */
        @Override
        public void dispose() {
            super.dispose();
        }

        /**
         * @internal
         * Externalizable method
         *
         * @param out
         *            ObjectOutput
         * @throws IOException
         */
        @Override
        public void writeExternal(final ObjectOutput out) throws IOException {
            super.writeExternal(out);
        }

        /**
         * @internal
         * Externalizable method
         *
         * @param in
         *            ObjectInput
         * @throws IOException
         * @throws ClassNotFoundException
         */
        @Override
        public void readExternal(final ObjectInput in) throws IOException, ClassNotFoundException {
            super.readExternal(in);
        }

        /* (non-Javadoc)
         * @see aglobe.container.service.ServiceShell#setContainer(aglobe.container.AgentContainer)
         */
        @Override
        public abstract void setContainer(AgentContainer container) throws Exception;

        /* @internal
         * (non-Javadoc)
         * @see aglobe.container.service.ServiceShell#postInit()
         */
        @Override
        public abstract void postInit();

        
        protected void compareNewVisibility() {
            final LinkedHashSet<Address> set = new LinkedHashSet<Address>(visibleContainers);
            set.removeAll(theservice.visible);
            // notify about removal of these containers
            for (final Address address : set) {
                for (final VisibilityNotifier notifier : notifiers) {
                    notifier.addEvent(new Runnable() {

                        @Override
                        public void run() {
                            notifier.becomeInvisible(address);
                        }

                    });
                }
                visibleContainers.remove(address);
            }
            set.clear();
            set.addAll(theservice.visible);
            set.removeAll(visibleContainers);
            // notify about new containers
            for (final Address address : set) {
                for (final VisibilityNotifier notifier : notifiers) {
                    notifier.addEvent(new Runnable() {

                        @Override
                        public void run() {
                            notifier.becomeVisible(address);
                        }

                    });
                }
                visibleContainers.add(address);
            }
        }

        protected void addNewVisible(final Address adr) {
            if (visibleContainers.add(adr)) {
                for (final VisibilityNotifier notifier : notifiers) {
                    notifier.addEvent(new Runnable() {

                        @Override
                        public void run() {
                            notifier.becomeVisible(adr);
                        }

                    });
                }
            }
        }

        protected void removeVisible(final Address adr) {
            if (visibleContainers.remove(adr)) {
                for (final VisibilityNotifier notifier : notifiers) {
                    notifier.addEvent(new Runnable() {

                        @Override
                        public void run() {
                            notifier.becomeInvisible(adr);
                        }

                    });
                }
            }
        }
        
        
        
        /* (non-Javadoc)
         * @see aglobe.container.service.ServiceShell#isValid()
         */
        @Override
        public boolean isValid() {
            return theservice!=null;
        }

        /**
         * Register new VisibilityNotifier for receiving information about
         * newly visible neighbors. Just after new subscription it will
         * receive the currently visible neighbors by several calls of
         * becomeVisible method.
         * @param notifier
         */
        public void register(final VisibilityNotifier notifier) {
            theservice.vLock.lock();
            try {
                if (notifiers.add(notifier)) {
                    // notify about current visibility status
                    for (final Address adr : visibleContainers) {
                        notifier.addEvent(new Runnable() {

                            @Override
                            public void run() {
                                notifier.becomeVisible(adr);
                            }

                        });
                    }
                }
            } finally {
                theservice.vLock.unlock();
            }
        }

        /**
         * Deregister given VisibilityNotifier.
         * @param notifier
         */
        public void deregister(final VisibilityNotifier notifier) {
            theservice.vLock.lock();
            try {
                notifiers.remove(notifier);
            } finally {
                theservice.vLock.unlock();
            }
        }
    }
}
