package aglobe.service.link;

import aglobe.container.EventReceiver;
import aglobe.ontology.Message;

/**
 * @internal
 * <p>Title: A-Globe</p>
 *
 * <p>Description: LinkNeighbourListener is used by the LinkService for notifying the subscribers
 * about received message copy.</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.7 $ $Date: 2009/05/15 08:46:58 $
 */
public interface LinkMessageCopyListener extends EventReceiver {
    /**
     * Pass the message copy to the subscriber
     *
     * @param serializedMessage byte[]
     * @param undeliverable String
     */
    void handleMessageCopy(final Message originalMessage);
}
