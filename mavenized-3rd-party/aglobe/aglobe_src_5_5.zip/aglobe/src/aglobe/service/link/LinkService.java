package aglobe.service.link;

import aglobe.container.*;
import aglobe.container.service.*;
import aglobe.ontology.*;
import aglobe.service.sniffer.SnifferService;

import java.io.ObjectOutput;
import java.io.IOException;
import java.io.ObjectInput;
import aglobe.container.transport.Address;
import java.util.LinkedHashSet;
import aglobe.container.transport.*;
import java.util.*;
import java.util.concurrent.locks.ReentrantLock;

/**
 * @internal
 * <p>Title: A-Globe</p>
 *
 * <p>Description: The <code>LinkService</code> is used for connection bridge among multiple
 * A-globe containers. The service allow to work directory service properly and also
 * sniffer tool, or communication analyzer tool can be started on any container.</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.21 $ $Date: 2010/10/05 07:11:40 $
 */
public final class LinkService extends Service {
    /**
     * Link service name
     */
    public static final String SERVICENAME = "container/link";

    /**
     * Subscribe constant
     */
    private static final String SUBSCRIBE = "LINK_SUBSCRIBE";

    /**
     * Unsubscribe constant
     */
    private static final String UNSUBSCRIBE = "LINK_UNSUBSCRIBE";

    /**
     * Shutdown listener of the container
     */
    protected AgentContainer.Shutdown containerShutdownListener;

    /**
     * Link name
     */
    private String linkName;

    /**
     * True iff the service is registered within the LinkConnector
     */
    private boolean isRegistered = false;

    /**
     * Contains current visible containers
     */
    private final LinkedHashSet<Address> currentVisibleContainers = new LinkedHashSet<
            Address>();

    /**
     * Neighbor listeners
     */
    private final LinkedHashSet<LinkNeighbourListener> neighbourSubscribers = new
            LinkedHashSet<LinkNeighbourListener>();

    /**
     * Local message copy subscribers
     */
    private final LinkedHashSet<LinkMessageCopyListener> localMessageCopySubscribers = new
            LinkedHashSet<LinkMessageCopyListener>();

    /**
     * Remote message copy subscribers
     */
    private final LinkedHashSet<Address> remoteMessageCopySubscribers = new
            LinkedHashSet<Address>();

    /**
     * Has some message copy subscriber?
     */
    private boolean hasSomeMessageCopySubscriber = false;

    /**
     * Containers to removal
     */
    final LinkedList<Address> toRemove = new LinkedList<Address>();

    /**
     * Synchronization
     */
    private final ReentrantLock sync = new ReentrantLock();

    /**
     * Constructor
     *
     * @param linkName String
     * @param containerShutdownListener ShutdownListener
     */
    public LinkService(String linkName,
                       AgentContainer.Shutdown containerShutdownListener) {
        super();

        this.containerShutdownListener = containerShutdownListener;
        this.linkName = linkName;
    }

    /**
     * Get service shell of the Link service
     *
     * @return ServiceShell
     * @param shellOwner ElementaryEntity - agent/service
     */
    @Override
    public ServiceShell getServiceShell(ShellOwner shellOwner) {
        return new Shell(shellOwner, this);
    }
    

    /**
     * Called by A-globe kernel when the service is shuted down.
     */
    @Override
    public final void finish() {
        if (isRegistered) {
            try {
                LinkConnector.deregisterLinkService(linkName,
                        getAddress().deriveContainerAddress());
            } catch (Exception ex) {
                logSevere("Problem during deregister: " + ex.toString());
            }
            isRegistered = false;
        }

    }

    /**
     * This method is called after the container initialization on container.
     * The LinkService registers to the master service.
     */
    public final void afterContainerInit() {
        if (!isRegistered) {
            try {
                LinkConnector.registerLinkService(linkName,
                                                  getAddress().
                                                  deriveContainerAddress(),
                                                  new LinkConnectorListener() {
                    @Override
					public void register(Address containerAddress) {
//            logInfo("Register: "+containerAddress);
                        LinkService.this.register(containerAddress);
                    }

                    @Override
					public void deregister(Address containerAddress) {
//            logInfo("Deregister: "+containerAddress);
                        LinkService.this.deregister(containerAddress);
                    }

                    @Override
					public void addEvent(Runnable run) {
                        LinkService.this.addEvent(run);
                    }
                });
            } catch (Exception ex) {
                logSevere("Cannot register LinkService: " + ex.toString());
                containerShutdownListener.shutdownContainer();
                return;
            }
            isRegistered = true;
        }

    }

    /**
     * Register new container
     * @param containerAddress Address
     */
    private final void register(final Address containerAddress) {
        sync.lock();
        try {
            if (currentVisibleContainers.contains(containerAddress)) {
                return;
            }
            currentVisibleContainers.add(containerAddress);
            for (final LinkNeighbourListener elem : neighbourSubscribers) {
                elem.addEvent(new Runnable() {
                    @Override
					public void run() {
                        elem.handleRegister(containerAddress);
                    }
                });
            }

            // if there is some local message copy subsriber send subsribe message
            if (localMessageCopySubscribers.size() > 0) {
                final Message m = Message.newInstance(SUBSCRIBE, getAddress(),
                                                containerAddress.deriveServiceAddress(
                        SERVICENAME));
                m.setProtocol(SnifferService.TOPIC_OUTGOING_MESSAGE_COPY);

                try {
                    sendMessageAsReference(m);
                } catch (InvisibleContainerException ex) {
                    deregister(containerAddress);
                }
                m.release();
            }
        } finally {
            sync.unlock();
        }
    }

    /**
     * Deregister visible container
     * @param containerAddress Address
     */
    private final void deregister(final Address containerAddress) {
        sync.lock();
        try {
            if (!currentVisibleContainers.contains(containerAddress)) {
                return;
            }
            currentVisibleContainers.remove(containerAddress);
            for (final LinkNeighbourListener elem : neighbourSubscribers) {
                elem.addEvent(new Runnable() {
                    @Override
					public void run() {
                        elem.handleDeregister(containerAddress);
                    }
                });
            }

            remoteMessageCopySubscribers.remove(containerAddress);
            if ((hasSomeMessageCopySubscriber) &&
                (remoteMessageCopySubscribers.size() == 0) &&
                (localMessageCopySubscribers.size() == 0)) {
                hasSomeMessageCopySubscriber = false;
            }
        } finally {
            sync.unlock();
        }
    }

    /**
     * Must be overridden if the service is interested in incoming Messages.
     *
     * @param m The Message.
     */
    @Override
	public final void handleIncomingMessage(final Message m) {
        sync.lock();
        try {
            if (SnifferService.TOPIC_OUTGOING_MESSAGE_COPY.equals(m.getProtocol())) {
                if (MessageConstants.INFORM.equals(m.getPerformative())) {
                    final Message originalMessage = (Message) m.getContent();
                    for (final LinkMessageCopyListener elem :
                         localMessageCopySubscribers) {
                        originalMessage.registerHolder();
                        elem.addEvent(new Runnable() {
                            @Override
							public void run() {
                                elem.handleMessageCopy(originalMessage);
                            }
                        });
                    }
                    m.release();
                    return;
                } else if (SUBSCRIBE.equals(m.getPerformative())) {
                    remoteMessageCopySubscribers.add(m.getSender().
                            deriveContainerAddress());
                    if (!hasSomeMessageCopySubscriber) {
                        hasSomeMessageCopySubscriber = true;
                    }
                    m.release();
                    return;
                } else if (UNSUBSCRIBE.equals(m.getPerformative())) {
                    remoteMessageCopySubscribers.remove(m.getSender().
                            deriveContainerAddress());
                    if ((hasSomeMessageCopySubscriber) &&
                        (localMessageCopySubscribers.size() == 0) &&
                        (remoteMessageCopySubscribers.size() == 0)) {
                        hasSomeMessageCopySubscriber = false;
                    }
                    m.release();
                    return;
                }
            }
            logWarning("Unexpected incoming message: " + m);
            m.release();
        } finally {
            sync.unlock();
        }
    }

    /**
     * Subscribe neighbor listener
     * @param listener LinkNeighbourListener
     */
    private final void subscribeNeighbour(final LinkNeighbourListener
                                                 listener) {
        sync.lock();
        try {
            if (neighbourSubscribers.contains(listener)) {
                return;
            }
            neighbourSubscribers.add(listener);
            for (final Address elem : currentVisibleContainers) {
                listener.addEvent(new Runnable() {
                    @Override
					public void run() {
                        listener.handleRegister(elem);
                    }
                });
            }
        } finally {
            sync.unlock();
        }
    }

    /**
     * Unsubscribe neighbor listener
     * @param listener LinkNeighbourListener
     */
    private final void unsubscribeNeighbour(final LinkNeighbourListener
            listener) {
        sync.lock();
        try {
            neighbourSubscribers.remove(listener);
        } finally {
            sync.unlock();
        }
    }

    /**
     * Subscribe message copy listener
     * @param listener LinkMessageCopyListener
     */
    private final void subsribeMessageCopy(final LinkMessageCopyListener
                                                  listener) {
        sync.lock();
        try {
            if (localMessageCopySubscribers.contains(listener)) {
                return;
            }
            final boolean n = localMessageCopySubscribers.size() == 0;
            localMessageCopySubscribers.add(listener);
            if (n) {
                hasSomeMessageCopySubscriber = true;

                final Message m = Message.newInstance(SUBSCRIBE, getAddress(),
                                                getAddress());
                m.setProtocol(SnifferService.TOPIC_OUTGOING_MESSAGE_COPY);
                for (Address elem : currentVisibleContainers) {
                    m.setReceiver(elem.deriveServiceAddress(SERVICENAME));
                    try {
                        sendMessageAsReference(m);
                    } catch (InvisibleContainerException ex) {
                        toRemove.add(elem);
                    }
                }
                m.release();

                if (toRemove.size() != 0) {
                    for (Address elem : toRemove) {
                        deregister(elem);
                    }
                    toRemove.clear();
                }
            }
        } finally {
            sync.unlock();
        }
    }

    /**
     * Unsubscribe message listener
     * @param listener LinkMessageCopyListener
     */
    private final void unsubsribeMessageCopy(final LinkMessageCopyListener
            listener) {
        sync.lock();
        try {
            if (!localMessageCopySubscribers.contains(listener)) {
                return;
            }
            localMessageCopySubscribers.remove(listener);
            if (localMessageCopySubscribers.size() == 0) {

                final Message m = Message.newInstance(UNSUBSCRIBE, getAddress(),
                                                getAddress());
                m.setProtocol(SnifferService.TOPIC_OUTGOING_MESSAGE_COPY);
                for (Address elem : currentVisibleContainers) {
                    m.setReceiver(elem.deriveServiceAddress(SERVICENAME));

                    try {
                        sendMessageAsReference(m);
                    } catch (InvisibleContainerException ex) {
                        toRemove.add(elem);
                    }
                }
                m.release();
                if (toRemove.size() != 0) {
                    for (Address elem : toRemove) {
                        deregister(elem);
                    }
                    toRemove.clear();
                }

            }
        } finally {
            sync.unlock();
        }
    }

    /**
     * Distribute message copy to all message copy listeners
     * @param serializedMessage byte[]
     * @param undeliverable String
     */
    private final void distributeMessageCopy(final Message originalMessage) {
        sync.lock();
        try {
            int i = 0;
            // to local first
            for (final LinkMessageCopyListener elem : localMessageCopySubscribers) {
                originalMessage.registerHolder(); // register receiver as a holder
                elem.addEvent(new Runnable() {
                    @Override
					public void run() {
                        elem.handleMessageCopy(originalMessage);
                    }
                });
                i++;
            }

            // to remote
            final Message m = Message.newInstance(MessageConstants.INFORM, getAddress(),
                                            getAddress());
            m.setProtocol(SnifferService.TOPIC_OUTGOING_MESSAGE_COPY);
            m.setContent(originalMessage);
            for (Address elem : remoteMessageCopySubscribers) {
                m.setReceiver(elem.deriveServiceAddress(SERVICENAME));
                try {
                    sendMessageAsReference(m);
                    i++;
                } catch (InvisibleContainerException ex) {
                    toRemove.add(elem);
                }
            }
            m.release();
            if (toRemove.size() != 0) {
                for (Address elem : toRemove) {
                    deregister(elem);
                }
                toRemove.clear();
            }

            if (i == 0) {
                hasSomeMessageCopySubscriber = false;
            }
        } finally {
            sync.unlock();
        }
    }

    /**
     *
     * <p>Title: A-Globe</p>
     *
     * <p>Description: LinkService shell proxy object. It is used for accessing
     * functions provided by the LinkService.</p>
     *
     * <p>Copyright: Copyright (c) 2006</p>
     *
     * <p>Company: Gerstner Laboratory</p>
     *
     * @author David Sislak
     * @version $Revision: 1.21 $ $Date: 2010/10/05 07:11:40 $
     */
    public static class Shell extends ServiceShell {
        // This number has to be changed, when Agent's variables are changed
        private static final long serialVersionUID = -7803144135776937L;

        /**
         * Link to the service
         */
        private transient LinkService theservice = null;

        /**
         * List of the neighbors subscribers
         */
        private LinkedHashSet<LinkNeighbourListener> subscribersForNeighbours = new
                LinkedHashSet<LinkNeighbourListener>();

        /**
         * List of the message copy listeners
         */
        private LinkedHashSet<LinkMessageCopyListener>
                subscribersForMessageCopy = new LinkedHashSet<
                        LinkMessageCopyListener>();

        /**
         * Constructor used for serialization purposes. DO NOT USE THIS constructor.
         */
        public Shell() {
            super();
        }

        /**
         * Service shell constructor
         * @param shellOwner ElementaryEntity
         * @param _theservice LinkService
         */
        private Shell(ShellOwner shellOwner, LinkService _theservice) {
            super(shellOwner);
            theservice = _theservice;
        }

        /**
         * Test if the shell is connected to the service
         * @return boolean - true if there is my mother service, otherwise false
         */
        @Override
        public boolean isValid() {
            return theservice != null;
        }

        public void addEvent(Runnable event) {
            theservice.addEvent(event);
        }
        
        /**
         * Get name of the Link service
         * @return linkName
         */
        public String getLinkName(){
        	return theservice.linkName;
        }

        /**
         * Externalizable method
         * @param out ObjectOutput
         * @throws IOException
         */
        @Override
        public void writeExternal(ObjectOutput out) throws IOException {
            throw new RuntimeException(
                    "LinkService doesn't support migration of shell owner !!!");
        }

        /**
         * Externalizable method
         * @param in ObjectInput
         * @throws IOException
         * @throws ClassNotFoundException
         */
        @Override
        public void readExternal(ObjectInput in) throws IOException,
                ClassNotFoundException {
            throw new RuntimeException(
                    "LinkService doesn't support migration of shell owner !!!");
        }

        /**
         * This method is called automatically by the A-globe after agent migration.
         *
         * @param container AgentContainer
         * @throws Exception
         */
        @Override
        public void setContainer(AgentContainer container) throws Exception {
            throw new RuntimeException(
                    "LinkService doesn't support migration of shell owner !!!");
        }

        /**
         * Called after initialization of the owner agent
         */
        @Override
        public void postInit() {
        }

        /**
         * Dispose this shell. It automatically unsubscribe all subscribed listeners.
         */
        @Override
        public void dispose() {
            unsubscribeAll();

            super.dispose();
        }

        /**
         * Subscribe information about neighbor changes
         * @param listener LinkNeighbourListener
         */
        public void subscribeNeighbour(LinkNeighbourListener listener) {
            if (subscribersForNeighbours.contains(listener)) {
                return;
            }
            subscribersForNeighbours.add(listener);
            theservice.subscribeNeighbour(listener);
        }

        /**
         * Subscribe information with message copy
         * @param listener LinkMessageCopyListener
         */
        public void subsribeMessageCopy(LinkMessageCopyListener listener) {
            if (subscribersForMessageCopy.contains(listener)) {
                return;
            }
            subscribersForMessageCopy.add(listener);
            theservice.subsribeMessageCopy(listener);
        }

        /**
         * Unsubscribe all
         */
        public void unsubscribeAll() {
            for (LinkNeighbourListener elem : subscribersForNeighbours) {
                theservice.unsubscribeNeighbour(elem);
            }
            for (LinkMessageCopyListener elem : subscribersForMessageCopy) {
                theservice.unsubsribeMessageCopy(elem);
            }
            subscribersForNeighbours.clear();
            subscribersForMessageCopy.clear();
        }

        /**
         * Distribute serialized message
         *
         * @param serializedMessage byte[]
         * @param undeliverable String
         */
        public final void distributeMessageCopy(final Message originalMessage) {
            theservice.distributeMessageCopy(originalMessage);
        }

        /**
         * Test if there is some message copy subscriber
         * @return boolean
         */
        public boolean hasSomeMessageCopySubscriber() {
            return theservice.hasSomeMessageCopySubscriber;
        }
    }
}
