package aglobe.service.link;

import aglobe.container.transport.Address;
import aglobe.container.EventReceiver;

/**
 * @internal
 * <p>Title: A-Globe</p>
 *
 * <p>Description: LinkListener is used by the LinkService. The LinkConnector uses it for notifying the subscribers
 * about the existence of the other link services</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.5 $ $Date: 2009/05/15 08:46:58 $
 */
interface LinkConnectorListener extends EventReceiver {

    /**
     * Used for notification about new registred container with running LinkService
     * @param containerAddress Address
     */
    void register(Address containerAddress);

    /**
     * Used for notification about the fact that the container with running LinkService was deregistred
     * @param containerAddress Address
     */
    void deregister(Address containerAddress);
}
