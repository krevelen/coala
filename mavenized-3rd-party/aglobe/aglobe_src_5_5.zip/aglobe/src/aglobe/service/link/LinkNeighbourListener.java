package aglobe.service.link;

import aglobe.container.transport.Address;
import aglobe.container.EventReceiver;

/**
 * @internal
 * <p>Title: A-Globe</p>
 *
 * <p>Description: LinkNeighbourListener is used by the LinkService for notifying the subscribers
 * about the existence of the other containers.</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.5 $ $Date: 2009/05/15 08:46:58 $
 */
public interface LinkNeighbourListener extends EventReceiver {
    /**
     * Distribution of information about new container in the system
     * @param containerAddress Address
     */
    void handleRegister(final Address containerAddress);

    /**
     * Distribution of information about removing container from the system
     * @param containerAddress Address
     */
    void handleDeregister(final Address containerAddress);

}
