package aglobe.service.link;

import aglobe.container.transport.Address;
import aglobe.platform.Platform;
import aglobe.platform.thread.AglobeThreadPool;

import java.io.IOException;
import java.net.*;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Logger;

/**
 * @internal
 * <p>Title: A-Globe</p>
 *
 * <p>Description: Internal class for the LinkService. It is used for automatic
 * finding of other link services adresses.</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.12 $ $Date: 2010/10/26 12:06:47 $
 */
class LinkConnector {

    /**
     * Exchanger
     */
    private static Exchanger exchanger = null;

    /**
     * Synchronization
     */
    private static ReentrantLock synch = new ReentrantLock();

    /**
     * Information about all known link names
     */
    private static LinkedHashMap<String, LinkedHashSet<Address>> knownLinkNames = new
            LinkedHashMap<String, LinkedHashSet<Address>>();

    /**
     * Information about local containers
     */
    private static LinkedHashMap<Address, LinkConnectorListener>
            localContainers = new LinkedHashMap<Address, LinkConnectorListener>();

    /**
     * Knowledge base containing information about remote containers
     */
    private static LinkedHashMap<InetSocketAddress,
                                 LinkedHashMap<String, LinkedHashSet<Address>>>
            remoteKB = new LinkedHashMap<InetSocketAddress,
                                         LinkedHashMap<String,
            LinkedHashSet<Address>>>();

    /**
     * Register new link service
     *
     * @param linkName String
     * @param containerAddress Address
     * @param linkListener LinkListener
     * @throws Exception
     */
    static void registerLinkService(String linkName, Address containerAddress,
                                    final LinkConnectorListener linkListener) throws
            Exception {
        synch.lock();
        try {
            if (linkName == null) {
                throw new Exception("Unspecified linkName");
            }
            LinkedHashSet<Address> known = knownLinkNames.get(linkName);
            if (known == null) {
                known = new LinkedHashSet<Address>();
                knownLinkNames.put(linkName, known);
            }
            if (known.contains(containerAddress) ||
                localContainers.containsKey(containerAddress)) {
                throw new Exception("Already known container");
            }
            // remember it
            known.add(containerAddress);
            // register new listener
            localContainers.put(containerAddress, linkListener);

            // start exchanger if not running yet
            if (exchanger == null) {
                exchanger = new Exchanger();
            }

            // distribute information to others
            distributeRegisterToLocal(linkName, containerAddress);

            if (exchanger != null) {
                exchanger.sendRegister(linkName, containerAddress);
            }

            // distribute local information to this
            for (final Address elem : knownLinkNames.get(linkName)) {
                if (!elem.equals(containerAddress)) {
                    linkListener.addEvent(new Runnable() {
                        @Override
						public void run() {
                            linkListener.register(elem);
                        }
                    });
                }
            }

            // distribute remote information to this
            for (LinkedHashMap<String, LinkedHashSet<Address>> elem :
                 remoteKB.values()) {
                if (elem.containsKey(linkName)) {
                    for (final Address elem1 : elem.get(linkName)) {
                        linkListener.addEvent(new Runnable() {
                            @Override
							public void run() {
                                linkListener.register(elem1);
                            }
                        });
                    }
                }
            }
        } finally {
            synch.unlock();
        }
    }

    /**
     * Deregister the container address
     *
     * @param linkName String
     * @param containerAddress Address
     * @throws Exception
     */
    static void deregisterLinkService(String linkName, Address containerAddress) throws
            Exception {
        synch.lock();
        try {
            if (linkName == null) {
                throw new Exception("Unspecified linkName");
            }
            LinkedHashSet<Address> known = knownLinkNames.get(linkName);
            if (known != null) {
                if (known.contains(containerAddress)) {
                    known.remove(containerAddress);
                    if (known.size() == 0) {
                        knownLinkNames.remove(linkName);
                    }
                }
            }
            if (localContainers.containsKey(containerAddress)) {
                localContainers.remove(containerAddress);
                // distribute deregister
                distributeDeregisterToLocal(linkName, containerAddress);

                if (exchanger != null) {
                    exchanger.sendDeregister(linkName, containerAddress);
                }
            }

            if ((knownLinkNames.size() == 0) && (exchanger != null)) {
                // empty, clean up
                exchanger.kill();
                exchanger = null;
                remoteKB.clear();
            }
        } finally {
            synch.unlock();
        }
    }

    /**
     * Distribute register to the local subscribers
     *
     * @param linkName String
     * @param registered Address
     */
    private static void distributeRegisterToLocal(String linkName,
                                                  final Address registered) {
        if (!knownLinkNames.containsKey(linkName)) {
            return;
        }
        for (Address elem : knownLinkNames.get(linkName)) {
            if (!elem.equals(registered)) {
                final LinkConnectorListener ll = localContainers.get(elem);
                if (ll != null) {
                    ll.addEvent(new Runnable() {
                        @Override
						public void run() {
                            ll.register(registered);
                        }
                    });
                }
            }
        }
    }

    /**
     * Distribute deregister to the local subscribers
     *
     * @param linkName String
     * @param deregistered Address
     */
    private static void distributeDeregisterToLocal(String linkName,
            final Address deregistered) {
        if (!knownLinkNames.containsKey(linkName)) {
            return;
        }
        for (Address elem : knownLinkNames.get(linkName)) {
            if (!elem.equals(deregistered)) {
                final LinkConnectorListener ll = localContainers.get(elem);
                if (ll != null) {
                    ll.addEvent(new Runnable() {
                        @Override
						public void run() {
                            ll.deregister(deregistered);
                        }
                    });
                }
            }
        }
    }

    /**
     * Called when new remote linked container is registered
     * @param remote InetSocketAddress - its address
     * @param linkName String - link name
     * @param containerAddress Address - conatiner address
     */
    private static void remoteRegistered(InetSocketAddress remote,
                                         String linkName,
                                         Address containerAddress) {
        // add to the knowledge
        LinkedHashMap<String, LinkedHashSet<Address>> rn = remoteKB.get(remote);
        if (rn == null) {
            rn = new LinkedHashMap<String, LinkedHashSet<Address>>();
            remoteKB.put(remote, rn);
        }
        LinkedHashSet<Address> rsn = rn.get(linkName);
        if (rsn == null) {
            rsn = new LinkedHashSet<Address>();
            rn.put(linkName, rsn);
        }
        if (!rsn.contains(containerAddress)) {
            rsn.add(containerAddress);
            // distribute new knowledge
            distributeRegisterToLocal(linkName, containerAddress);
        }
    }

    /**
     * Called when linked container is removed from the system
     * @param remote InetSocketAddress
     * @param linkName String
     * @param containerAddress Address
     */
    private static void remoteDeregistered(InetSocketAddress remote,
                                           String linkName,
                                           Address containerAddress) {
        LinkedHashMap<String, LinkedHashSet<Address>> rn = remoteKB.get(remote);
        if (rn == null) {
            return;
        }
        LinkedHashSet<Address> rsn = rn.get(linkName);
        if (rsn == null) {
            return;
        }
        if (rsn.contains(containerAddress)) {
            rsn.remove(containerAddress);

            distributeDeregisterToLocal(linkName, containerAddress);

            if (rsn.size() == 0) {
                rn.remove(linkName);
            }
            if (rn.size() == 0) {
                remoteKB.remove(remote);
            }
        }
    }

    /**
     *
     * <p>Title: A-Globe</p>
     *
     * <p>Description: Inner class of the LinkConnector used for exchange the information about local containers.</p>
     *
     * <p>Copyright: Copyright (c) 2006</p>
     *
     * <p>Company: Gerstner Laboratory</p>
     *
     * @author David Sislak
     * @version $Revision: 1.12 $ $Date: 2010/10/26 12:06:47 $
     */
    private static class Exchanger implements Runnable {
        /**
         * Prefix of the broadcast autofinder UDP packet
         */
        public static final String REQUEST =
                "LinkConnectorAreYouThere?A-globe_ver" + Platform.MAJOR_VERSION +
                "_" + Platform.MINOR_VERSION;

        /**
         * Base of the auto linker UDP port
         */
        public static final int AUTO_CONFIGURATOR_BASE_PORT = 4444;

        /**
         * Maximal number of server container running on the same host computer
         */
        public static final int AUTO_CONFIGURATOR_PORT_RANGE = 200;

        /**
         * Listening udp socket
         */
        private DatagramSocket socket = null;

        /**
         * Logger
         */
        private final Logger logger;

        /**
         * true iff server should be finished
         */
        volatile private boolean killing = false;

        /**
         * true iff listening thread was stopped
         */
        volatile private boolean stopped = false;

        /**
         * Thread for the AutoConfiguratorServer
         */
        private Thread asThread = null;

        /**
         * Local address of the linked container
         */
        private InetSocketAddress localAddress = null;

        /**
         * Finalization sync
         */
        private ReentrantLock finSync = new ReentrantLock();
        private Condition finCond = finSync.newCondition();

        /**
         * Constructor
         *
         * @throws Exception
         */
        private Exchanger() throws Exception {
            // create logger
            logger = Logger.getLogger("LinkConnectorServer");
            // open listening socket
            int listeningPort = AUTO_CONFIGURATOR_BASE_PORT;

            while ((asThread == null) &&
                   (listeningPort < AUTO_CONFIGURATOR_BASE_PORT +
                    AUTO_CONFIGURATOR_PORT_RANGE)) {
                try {
                    socket = new DatagramSocket(listeningPort);
                    socket.setBroadcast(true);
                    socket.setSoTimeout(1000);

                    localAddress = new InetSocketAddress(InetAddress.
                            getLocalHost(), listeningPort);

                    // create listening thread
                    asThread = AglobeThreadPool.getThread(Platform.
                            getPlatformThreadGroup(), this,
                            "LinkConnectorThread");
                    // set priority above normal
                    asThread.setPriority(Math.min(Thread.NORM_PRIORITY + 1,
                                                  Thread.MAX_PRIORITY));
                    asThread.start();
                } catch (SocketException ex) {
                    listeningPort++;
                }
            }
            if (asThread == null) {
                throw new Exception("LinkConnector server: Cannot open any listening autoconfigurator port in range: " +
                                    AUTO_CONFIGURATOR_BASE_PORT + " - " +
                                    (AUTO_CONFIGURATOR_BASE_PORT +
                                     AUTO_CONFIGURATOR_PORT_RANGE - 1));
            }

            // find others
            findOthers();
        }

        /**
         * Main run method of the LinkConnector used for automatic finding of new
         * linked containers
         */
        @Override
		public void run() {
            while (true) {
                byte[] buf = new byte[1024];
                DatagramPacket dp = new DatagramPacket(buf, buf.length);
                try {
                    socket.receive(dp);
                    String s = new String(dp.getData(), 0, dp.getLength());
                    InetSocketAddress sender = (InetSocketAddress) dp.
                                               getSocketAddress();
                    synch.lock();
                    try {
                        if (sender.equals(localAddress)) {
                            continue;
                        }
                        if (s.equals(REQUEST)) {
                            // test if this is unknown server and different from local
                            if (!remoteKB.containsKey(sender)) {
                                // unknown server, remember it
                                remoteKB.put(sender,
                                             new LinkedHashMap<String,
                                        LinkedHashSet<Address>>());
                                // distribute all my local information
                                sendAllMyKB(sender);
                            }
                        } else {
                            StringTokenizer st = new StringTokenizer(s, ";");
                            String action = st.nextToken();
                            int ac = 0;
                            if (action.equals("R")) {
                                ac = 1;
                            } else if (action.equals("D")) {
                                ac = 2;
                            }
                            if (ac > 0) {
                                String linkName = null;
                                Address containerAddress = null;
                                if (st.hasMoreTokens()) {
                                    linkName = st.nextToken();
                                }
                                if (st.hasMoreTokens()) {
                                    try {
                                        containerAddress = Address.getAddress(
                                                st.nextToken());
                                    } catch (Exception ex1) {
                                        // wrong address
                                    }
                                }
                                if ((linkName != null) && (containerAddress != null) &&
                                    (containerAddress.isContainerAddress())) {
                                    boolean known = remoteKB.containsKey(sender);
                                    // parse information
                                    if (ac == 1) {
                                        remoteRegistered(sender, linkName,
                                                containerAddress);
                                    } else {
                                        remoteDeregistered(sender, linkName,
                                                containerAddress);
                                    }
                                    // check known
                                    if (!known) {
                                        sendAllMyKB(sender);
                                    }
                                }
                            } else {
                                // unknown action or platform
                            }
                        }
                    } finally {
                        synch.unlock();
                    }
                } catch (SocketTimeoutException ex) {
                    //timeout expired
                } catch (IOException ex) {
                    logger.severe("Receiving exeption " + ex);
                }

                if (killing)
                    break;
            }
            // close the listening socket
            socket.close();

            // notify requester about finish
            finSync.lock();
            try {
                stopped = true;
                finCond.signal();
            } finally {
                finSync.unlock();
            }
        }

        /**
         * Find others
         */
        private void findOthers() {
            byte[] outBuf = REQUEST.getBytes();
            DatagramPacket senddp;
            int portOffset;

            // first send packet to the localhost
            portOffset = 0;
            while (portOffset < AUTO_CONFIGURATOR_PORT_RANGE) {
                try {
                    senddp = new DatagramPacket(outBuf, outBuf.length,
                                                InetAddress.getLocalHost()
                                                ,
                                                AUTO_CONFIGURATOR_BASE_PORT +
                                                portOffset);

                    socket.send(senddp);
                } catch (IOException ex1) {
                }
                portOffset++;
            }

            // send broadcast to the subnet broadcast address
            try {
                byte[] rawLocalAddress = InetAddress.getLocalHost().getAddress();
                if (rawLocalAddress.length == 4) {
                    int firstnumber = rawLocalAddress[0] & 0xff;
                    int subnet = 0;
                    if (firstnumber <= 127) {
                        subnet = 3; //class A
                    } else if (firstnumber <= 191) {
                        subnet = 2; //class B
                    } else if (firstnumber <= 223) {
                        subnet = 1; //class C
                    }

                    for (int i = 4 - subnet; i < 4; i++) {
                        rawLocalAddress[i] = (byte) 255;
                    }

                    portOffset = 0;
                    while (portOffset < AUTO_CONFIGURATOR_PORT_RANGE) {
                        senddp = new DatagramPacket(outBuf, outBuf.length,
                                InetAddress.
                                getByAddress(rawLocalAddress),
                                AUTO_CONFIGURATOR_BASE_PORT +
                                portOffset);
                        try {
                            socket.send(senddp);
                        } catch (IOException ex2) {
                        }
                        portOffset++;
                    }
                }
            } catch (UnknownHostException ex) {
            }

            // send request to the global broadcast address
            portOffset = 0;
            while (portOffset < AUTO_CONFIGURATOR_PORT_RANGE) {
                try {
                    senddp = new DatagramPacket(outBuf, outBuf.length,
                                                InetAddress.getByName(
                            "255.255.255.255")
                                                ,
                                                AUTO_CONFIGURATOR_BASE_PORT +
                                                portOffset);

                    socket.send(senddp);
                } catch (IOException ex1) {
                }
                portOffset++;
            }
        }

        /**
         * Terminate server.
         */
        private void kill() {
            killing = true;
            finSync.lock();
            try {
                while (!stopped) {
                    try {
                        finCond.await(5, TimeUnit.SECONDS);
                    } catch (InterruptedException ex1) {
                    }
                }
            } finally {
                finSync.unlock();
            }
        }

        /**
         * Sends all my local KB to specified destination
         * @param to InetSocketAddress
         */
        private void sendAllMyKB(InetSocketAddress to) {
            for (Map.Entry<String, LinkedHashSet<Address>> elem :
                 knownLinkNames.entrySet()) {
                for (Address elem1 : elem.getValue()) {
                    try {
                        byte[] replyBuf = ("R;" + elem.getKey() + ";" +
                                           elem1.toString()).
                                          getBytes();
                        DatagramPacket reply = new DatagramPacket(replyBuf,
                                replyBuf.length, to);
                        socket.send(reply);
                    } catch (Exception ex) {
                    }
                }
            }
        }

        /**
         * Send register of the linked container
         * @param linkName String
         * @param containerAddress Address
         */
        private void sendRegister(String linkName, Address containerAddress) {
            sendStringToAll("R;" + linkName + ";" + containerAddress.toString());
        }

        /**
         * Send deregister of the linked container
         * @param linkName String
         * @param containerAddress Address
         */
        private void sendDeregister(String linkName, Address containerAddress) {
            sendStringToAll("D;" + linkName + ";" + containerAddress.toString());
        }

        /**
         * Send specific string to all linked container
         * @param str String
         */
        private void sendStringToAll(String str) {
            byte[] sendBuf = str.getBytes();
            for (InetSocketAddress elem : remoteKB.keySet()) {
                try {
                    DatagramPacket m = new DatagramPacket(sendBuf,
                            sendBuf.length, elem);
                    socket.send(m);
                } catch (Exception ex) {
                }
            }
        }
    }
}
