package aglobe.service.sniffer;

import java.util.Collection;

import aglobe.container.service.Service;
import aglobe.container.service.ServiceShell;
import aglobe.container.service.ShellOwner;
import aglobe.container.transport.Address;
import aglobe.container.transport.InvisibleContainerException;
import aglobe.container.transport.MessageTransport;
import aglobe.container.transport.ReceiveMessageHookInterface;
import aglobe.container.transport.SendMessageHookInterface;
import aglobe.ontology.CommunicationInfo;
import aglobe.ontology.Message;
import aglobe.ontology.MulticastCommunicationInfo;
import aglobe.platform.transport.MessageReceiver;
import aglobe.service.link.LinkService;
import aglobe.service.topics.TopicsService;
import aglobe.service.topics.TopicsSubscriptionNotifier;

/**
 * @internal
 * This service monitors the messages being sent and provides data to the sniffer agent.
 *
 * @version $Revision: 1.15 $ $Date: 2010/11/30 09:12:27 $
 */
public final class SnifferService extends Service implements SendMessageHookInterface, ReceiveMessageHookInterface {
    private final static String TOPICS_PREFIX = "!#";
    private static int TOPICS_CNT = 1;

    /**
     * Sniffer service name
     */
    public static final String SERVICENAME = "container/sniffer";

    /**
     * Sniffer is always the first just before the transport.
     */
    public static final int SNIFFER_HOOK_PRIORITY = 1;

    /**
     * @internal
     * Topic name used for sending communication information about outgoing message
     * sent between different containers. In the content there is CommunicationInfo object which
     * contains from, to container address. Or there is MulticastCommunicationInfo object with from and all
     * receivers for the multicast message. Both objects implements PooledObject interfaces and
     * there need to be carefully handled their holding.
     */
    public static final String TOPIC_COMMUNICATION_INFO = TOPICS_PREFIX + (TOPICS_CNT++);

    /**
     * @internal
     * Topic name used for sending outgoing message copy. In the content there is Message object.
     * In the reason there is un-deliverable flag. It is true if the message is successfully sent otherwise it is false. For the
     * multicast message the outgoing message copy is sent only if the message was
     * sent at least to the one receiver.
     */
    public static final String TOPIC_OUTGOING_MESSAGE_COPY = TOPICS_PREFIX + (TOPICS_CNT++);

    /**
     * @internal
     * Topic name used for the sending incoming message copy. In the content there is original Message object.
     */
    public static final String TOPIC_INCOMING_MESSAGE_COPY = TOPICS_PREFIX + (TOPICS_CNT++);


    /**
     * Message transport used for hook registration, notification about messages
     * thrown out etc.
     */
    private MessageTransport containerTransport = null;

    private volatile TopicsService.Shell topicsShell = null;

    /**
     * LinkService shell
     */
    private volatile LinkService.Shell linkShell = null;

    private volatile boolean hookRegistered = false;
    private volatile boolean dispatchCommunicationInfo = false;
    private volatile boolean dispatchOutgoingMessageCopy = false;
    private volatile boolean dispatchIncomingMessageCopy = false;

    /**
     * Get service shell of the Sniffer service
     *
     * @return ServiceShell
     * @param shellOwner ElementaryEntity - agent/service
     */
    @Override
    protected final ServiceShell getServiceShell(final ShellOwner shellOwner) {
        return null;
    }

    /**
     * Called automatically by the Aglobe when the service is started.
     */
    @SuppressWarnings("serial")
    @Override
    public final void init() {

        // initialize transport
        this.containerTransport = getContainer().getMessageTransport();


        // get appropriate service shell
        topicsShell = (TopicsService.Shell) getContainer().getServiceManager().getService(this, TopicsService.SERVICENAME);
        if (topicsShell == null) {
            linkShell = (LinkService.Shell) getContainer().getServiceManager().
            getService(null, LinkService.SERVICENAME);
            if (linkShell != null) {
                // and register the hook
                registerHook();
            }
        } else {
            topicsShell.registerNotifier(TOPIC_COMMUNICATION_INFO, new TopicsSubscriptionNotifier() {

                @Override
                public void hasSubscriber(String topic) {
                    dispatchCommunicationInfo = true;
                    registerHook();
                }

                @Override
                public void noSubscriber(String topic) {
                    dispatchCommunicationInfo = false;
                    if ((!dispatchIncomingMessageCopy) && (!dispatchOutgoingMessageCopy)) {
                        deregisterHook();
                    }
                }

                @Override
                public void addEvent(Runnable e) {
                    e.run();
                }
            });

            topicsShell.registerNotifier(TOPIC_OUTGOING_MESSAGE_COPY, new TopicsSubscriptionNotifier() {

                @Override
                public void hasSubscriber(String topic) {
                    dispatchOutgoingMessageCopy = true;
                    registerHook();
                }

                @Override
                public void noSubscriber(String topic) {
                    dispatchOutgoingMessageCopy = false;
                    if ((!dispatchIncomingMessageCopy) && (!dispatchCommunicationInfo)) {
                        deregisterHook();
                    }
                }

                @Override
                public void addEvent(Runnable e) {
                    e.run();
                }

            });

            topicsShell.registerNotifier(TOPIC_INCOMING_MESSAGE_COPY, new TopicsSubscriptionNotifier() {

                @Override
                public void hasSubscriber(String topic) {
                    dispatchIncomingMessageCopy = true;
                    registerHook();
                }

                @Override
                public void noSubscriber(String topic) {
                    dispatchIncomingMessageCopy = false;
                    if ((!dispatchOutgoingMessageCopy) && (!dispatchCommunicationInfo)) {
                        deregisterHook();
                    }
                }

                @Override
                public void addEvent(Runnable e) {
                    e.run();
                }

            });
        }
    }

    /**
     * Called by A-globe kernel when the service is being shut down.
     */
    @Override
    public final void finish() {
        deregisterHook();
        if (topicsShell != null) {
            topicsShell.dispose();
            topicsShell = null;
        }
        if (linkShell != null) {
            linkShell.dispose();
            linkShell = null;
        }
    }

    private final void registerHook() {
        if (!hookRegistered) {
            containerTransport.registerMessageHook(this,this,null,SNIFFER_HOOK_PRIORITY);
            hookRegistered = true;
        }
    }

    private final void deregisterHook() {
        if (hookRegistered) {
            containerTransport.unregisterMessageHook((SendMessageHookInterface)this);
            containerTransport.unregisterMessageHook((ReceiveMessageHookInterface)this);
            hookRegistered = false;
        }
    }

    /**
     * Main method that processes the message.
     * @param m
     */
    @Override
    public final void processOutgoingMessage(final Message m) throws InvisibleContainerException {
        final TopicsService.Shell ts = topicsShell;
        final LinkService.Shell ls = linkShell;
        if (dispatchCommunicationInfo) {
            // require message size before processing
            m.setMessageSizeRequired();
            containerTransport.forwardOutgoingMessage(m, SNIFFER_HOOK_PRIORITY);
            if (!m.isUndeliverable()) {
                final int msgSize = m.getMessageSize();

                if (ts == null) {
                    return;
                }
                final Address sender = m.getSender().deriveContainerAddress();
                if (!m.isMulticast()) {
                    final Address receiver = m.getReceiver().deriveContainerAddress();
                    if (!sender.isSameContainer(receiver)) {
                        final CommunicationInfo gc = CommunicationInfo.getInstance(sender, receiver.deriveContainerAddress(), msgSize);
                        ts.addEvent(new Runnable() {

                            @Override
                            public void run() {
                                ts.sendTopic(TOPIC_COMMUNICATION_INFO, gc);
                                gc.release();
                            }

                        });
                    }
                } else {
                    final MulticastCommunicationInfo gc = MulticastCommunicationInfo.getInstance(sender, msgSize);
                    final Collection<Address> recs = gc.getReceivers();
                    for (Address address : m.getReceivers()) {
                        recs.add(address.deriveContainerAddress());
                    }
                    recs.remove(sender);
                    if (recs.size() > 0) {
                        ts.addEvent(new Runnable() {

                            @Override
                            public void run() {
                                ts.sendTopic(TOPIC_COMMUNICATION_INFO, gc);
                                gc.release();
                            }

                        });
                    } else {
                        // there are no other containers
                        gc.release();
                    }
                }
            }
        } else {
            // just process the message
            containerTransport.forwardOutgoingMessage(m, SNIFFER_HOOK_PRIORITY);
        }
        if (dispatchOutgoingMessageCopy) {
            if (ts == null) {
                return;
            }
            m.registerHolder();
            ts.addEvent(new Runnable() {

                @Override
                public void run() {
                    ts.sendTopic(TOPIC_OUTGOING_MESSAGE_COPY, m);
                    m.release();
                }

            });
        }
        if ((ls != null) && (ls.hasSomeMessageCopySubscriber())) {
            m.registerHolder(); // register itself
            ls.addEvent(new Runnable() {
                @Override
				public void run() {
                    ls.distributeMessageCopy(m);
                    m.release(); // release itself
                }
            });
        }
    }

    /* (non-Javadoc)
     * @see aglobe.container.transport.ReceiveMessageHookInterface#processIncomingMessage(aglobe.ontology.Message, aglobe.container.MessageReceiver)
     */
    @Override
    public final void processIncomingMessage(final Message m, final MessageReceiver receiver) {
        final TopicsService.Shell ts = topicsShell;
        if (dispatchIncomingMessageCopy) {
            m.registerHolder();
            ts.addEvent(new Runnable() {

                @Override
                public void run() {
                    ts.sendTopic(TOPIC_INCOMING_MESSAGE_COPY, m);
                    m.release();
                }

            });
        }
        containerTransport.forwardIncomingMessage(m, receiver, SNIFFER_HOOK_PRIORITY);
    }

    /**
     * Processes messages. Not used in SnifferService.
     */
    @Override
    public final void handleIncomingMessage(final Message m) {
        throw new RuntimeException("SnifferService should not receive any message.");
    }



}
