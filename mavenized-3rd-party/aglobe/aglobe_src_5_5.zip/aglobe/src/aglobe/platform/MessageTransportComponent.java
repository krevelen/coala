/**
 *
 */
package aglobe.platform;

import aglobe.container.transport.Address;
import aglobe.ontology.Message;
import aglobe.platform.transport.MessageReceiver;
import aglobe.platform.transport.MessageReceiverSplitter;

/**
 * <p>Title: A-globe</p>
 *
 * <p>Description: Implementing object can be registered as a message transport receiver.</p>
 *
 * <p>Copyright: Copyright (c) 2009</p>
 *
 * <p>Company: Agent Technology Center</p>
 *
 * @author David Sislak
 * @version $Revision: 1.3 $ $Date: 2010/11/30 09:12:27 $
 *
 */
public interface MessageTransportComponent extends MessageReceiverSplitter {

    /**
     * Called to process received message
     * @param msg
     * @param receiver
     */
    public void processReceivedMessage(final Message msg, final MessageReceiver receiver);

    /**
     * Translates the message receiver.
     * 
     * @param receiver address of the receiver to be translated
     * @return translated receiver address
     */
    public Address translateMessageReceiver(final Address receiver);
}
