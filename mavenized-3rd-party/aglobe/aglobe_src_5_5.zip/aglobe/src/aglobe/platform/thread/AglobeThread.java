package aglobe.platform.thread;

import aglobe.platform.Platform;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.Condition;

/**
 * @internal
 * <p>Title: A-Globe</p>
 *
 * <p>Description: Aglobe thread for thread pool</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.15 $ $Date: 2009/05/15 08:46:59 $
 */
public class AglobeThread extends Thread {
    /**
     * Thread name of ready pool thread
     */
    final static String READY_TRHEAD_NAME = "Ready pool thread";

    /**
     * Client target which should be ran
     */
    private Runnable clientTarget;

    /**
     * Thread group
     */
    private ThreadGroup group;

    /**
     * set true if this thread should be finished
     */
    private boolean finish = false;

    /**
     * Synchronization lock
     */
    private ReentrantLock rLock = new ReentrantLock();

    /**
     * Waiter condition
     */
    private Condition waiter = rLock.newCondition();

    /**
     * true iff thread should be started
     */
    private boolean started = false;

    /**
     * true iff thread is marked as shared
     */
    boolean isSharedThread = true;


    /**
     *
     * @param group ThreadGroup - can be null
     * @param target Runnable - target which should be started
     * @param name String
     */
    AglobeThread(ThreadGroup group, Runnable target, String name) {
        super(AglobeThreadPool.threadPoolGroup, null, name, Platform.THREAD_STACK_SIZE);
        setNewTarget(target);
        setNewThreadGroup(group);
    }

    /**
     * Prepare ready thread
     */
    AglobeThread() {
        super(AglobeThreadPool.threadPoolGroup, null, READY_TRHEAD_NAME, Platform.THREAD_STACK_SIZE);
    }

    /**
     * Start JVM thread
     */
    void threadStart() {
        super.start();
    }

    /**
     * Finish the thread
     */
    void threadFinish() {
        rLock.lock();
        try {
            finish = true;
            waiter.signal();
        } finally {
            rLock.unlock();
        }
    }

    /**
     * Set new thread target
     * @param target Runnable
     */
    void setNewTarget(Runnable target) {
        if (clientTarget != null) {
            throw new RuntimeException("Cannot set new thread target for running thread");
        }
        this.clientTarget = target;
    }

    /**
     * Set new thread group
     * @param group ThreadGroup - can be null
     */
    void setNewThreadGroup(ThreadGroup group) {
        if (group != null) {
            this.group = group;
        } else {
            Thread curThread = Thread.currentThread();
            if (curThread instanceof AglobeThread) {
                this.group = ((AglobeThread) curThread).getAglobeThreadGroup();
            } else {
                this.group = curThread.getThreadGroup();
            }

        }
    }

    /**
     * Causes this thread to begin execution; the Java Virtual Machine calls the
     * <code>run</code> method of this thread.
     *
     */
    @Override
    public synchronized void start() {
        if (clientTarget == null) {
            throw new RuntimeException("Thread was already finished. Cannot be started again.");
        }
        if (started) {
            throw new RuntimeException("Thread is already started.");
        }
        // start thread
        rLock.lock();
        try {
            started = true;
            waiter.signal();
        } finally {
            rLock.unlock();
        }
    }

    /**
     * Clear thread name for future use
     */
    void clearForPool() {
        group = null;
        setName(READY_TRHEAD_NAME);
    }

    /**
     * When an object implementing interface <code>Runnable</code> is used to
     * create a thread, starting the thread causes the object's <code>run</code>
     * method to be called in that separately executing thread.
     *
     */
    @Override
    public void run() {
        rLock.lock();
        try {
            while ((!started) && (!finish)) {
                try {
                    waiter.await();
                } catch (InterruptedException ex1) {
                }
            }
        } finally {
            rLock.unlock();
        }

        while (!finish) {
            // wait for start
            if (clientTarget != null) {
                // start client target run method
                clientTarget.run();
            }
            // client thread was finished, remove it
            clientTarget = null;
            started = false;
            // clear interrupted state
            Thread.interrupted();
            // set priority back to the normal if it is other now
            if (getPriority() != Thread.NORM_PRIORITY) {
                setPriority(Thread.NORM_PRIORITY);
            }

            // put itself back to the queue of free threads in the thread pool
            AglobeThreadPool.putThreadToTheQueue(this);
            // wait for next job or finish
            rLock.lock();
            try {
                while ((!started)&&(!finish)) {
                    try {
                        waiter.await();
                    } catch (InterruptedException ex2) {
                    }
                }
            } finally {
                rLock.unlock();
            }
        }
    }

    /**
     * Get thread group of this thread, can return null if thread is died
     * @return ThreadGroup
     */
    public ThreadGroup getAglobeThreadGroup() {
        return group;
    }
}
