package aglobe.platform.thread;

import java.lang.management.ManagementFactory;
import java.util.*;
import aglobe.platform.Platform;
import aglobe.util.concurrent.ArrayFIFO;
import aglobe.util.concurrent.NonblockingPoolArrayFIFO;
import java.util.concurrent.atomic.AtomicLong;

/**
 * @internal
 * <p>Title: A-Globe</p>
 *
 * <p>Description: A-globe thread pool</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.24 $ $Date: 2010/12/03 12:29:26 $
 */
public class AglobeThreadPool {

  /**
   * The number of shared thread that should be used per CPU.
   */
  private final static int SHARED_THREADS_PER_CPU = 10;

  /**
   * The total number of shared thread that should be used. Max can be max 2^13.
   */
  private final static int USE_SHARED_THREADS = SHARED_THREADS_PER_CPU * ManagementFactory.getOperatingSystemMXBean().getAvailableProcessors();

  /**
   * Maximal number of thread which should be prepared.
   * MAX_READY_THREADS must be greater than USE_SHARED_THREADS. Max can be max 2^13.
   */
  private final static int MAX_READY_THREADS = Math.min(USE_SHARED_THREADS * 50, 1<<13);

  /**
   * Used for masking the number of elements in the waiting queue
   */
  private final static long WAITING_QUEUE_MASK = 0x3fffffffL;

  /**
   * Used for masking the number of ready threads in ThreadPool
   */
  private final static long THREAD_POOL_MASK = 0xfffffL;

  /**
   * Used for masking the number of shared threads
   */
  private final static long SHARED_THREADS_MASK = 0x1fffL;

  /**
   * Used for reading initialized mask
   */
  private final static long INITIALIZED_MASK = 1L;

  /**
   * Used for masking the number of elements in the waiting queue
   */
  private final static long WAITING_QUEUE_MASK_ROT = WAITING_QUEUE_MASK<<1;

  /**
   * Used for masking the number of ready threads in thread pool
   */
  private final static long THREAD_POOL_MASK_ROT = THREAD_POOL_MASK<<31;

  /**
   * Used for masking the number of shared threads
   */
  private final static long SHARED_THREADS_MASK_ROT = SHARED_THREADS_MASK<<51;

  /**
   * Holds thread pool status: 13-bit number of shared threads, 20-bit number of ready threads in thread pool,
   * 30-bit number of waiting to run in thread and 1-bit if the thread pool is initialized
   */
  private static AtomicLong status = new AtomicLong(0);

  /**
   * JVM thread group for all thread pool threads
   */
  static final ThreadGroup threadPoolGroup = new ThreadGroup("A-globe thread pool");

  /**
   * Free threads which are ready for use. All thread are ready with normal priority. The maximum number is 2^20
   */
  private static ArrayFIFO<AglobeThread> threadPool = new ArrayFIFO<AglobeThread>(1<<19);

  /**
   * Preallocation thread
   */
  private static Preallocation prealocation;

  /**
   * Pool of the ToRunInThread objects. Max holds 2^30 objects
   */
  private static NonblockingPoolArrayFIFO<ToRunInThread> toRunInThreadPool = new NonblockingPoolArrayFIFO<ToRunInThread>(1<<29);

  /**
   * waiting targets to run in new thread. Maximum waiting targets is 2^30
   */
  private static ArrayFIFO<ToRunInThread> waitingQueue = new ArrayFIFO<ToRunInThread>(1<<29);

  /**
   * AglobeThreadPool cannot be created
   */
  private AglobeThreadPool() {

  }

  /**
   * Initialization method of Aglobe thread pool.
   */
  public static void initialize() {
      for (;;) {
          long curStatus = status.get();
          if ((curStatus & INITIALIZED_MASK) != 0) {
              // already initialized
              return;
          }
          if (status.compareAndSet(curStatus, INITIALIZED_MASK)) {
              break;
          }
      }
      // initialize thread pool
      prealocation = new Preallocation();
      Thread prealocationThread = new Thread(threadPoolGroup, prealocation, "Preallocation thread", Platform.THREAD_STACK_SIZE);
      prealocationThread.setPriority(Thread.MIN_PRIORITY);
      prealocationThread.setDaemon(true);
      prealocationThread.start();
  }

  /**
   * Finalize all unused threads
   */
  public static void finish() {
      for (;;) {
          long curStatus = status.get();
          if ((curStatus & INITIALIZED_MASK) == 0) {
              // not initialized
              return;
          }
          if (status.compareAndSet(curStatus, curStatus^INITIALIZED_MASK)) {
              break;
          }
      }
      // finalize all threads
      for (;;) {
          final AglobeThread at = threadPool.pop();
          if (at == null) {
              break;
          }
          at.threadFinish();
      }
      
      // release prealocation thread
      prealocation = null;
      
      // remove all waiting targets
      for (;;) {
          final ToRunInThread r = waitingQueue.pop();
          if (r == null) {
              break;
          }
      }
      
      // clear status
      status.set(0);
  }

  /**
   * Start target in new thread with specified name in specified group. If there is no
   * native thread available. The thread will be started when other will be released.
   * @param target Runnable
   * @param name String
   */
  public static void startInNewThread(Runnable target, String name) {
      startInNewThread(null, target, name);
  }


  /**
   * Start target in new thread with specified name in specified group. If there is no
   * native thread available. The thread will be started when other will be released.
   * @param group ThreadGroup - iff null, current thread group is assigned
   * @param target Runnable
   * @param name String
   */
  public static void startInNewThread(ThreadGroup group, Runnable target, String name) {
      long curStatus = status.get();
      if ((curStatus & INITIALIZED_MASK) ==  0) {
          // not initialized
          return;
      }
      if (group == null) {
          group = Thread.currentThread().getThreadGroup();
      }

      // try obtain free thread
      Thread t = null;
      try {
          t = getThread(group, target, name, true);
      } catch (Throwable ex) {
          // too many allocated threads
      }
      if (t != null) {
          // got thread, so start it now
          t.start();
          return;
      }

      // prepare waiting structure
      ToRunInThread toRunStructure = toRunInThreadPool.pop();
      if (toRunStructure != null) {
          toRunStructure.set(group, target, name);
      } else {
          toRunStructure = new ToRunInThread(group, target, name);
      }

      // insert waiting structure into the queue
      try {
          waitingQueue.push(toRunStructure);
      } catch (Exception ex1) {
          throw new RuntimeException("Cannot insert into waiting queue", ex1);
      }

      // increment number of waiting runnable
      for (;;) {
          long noWaiting = (curStatus >> 1) & WAITING_QUEUE_MASK;
          long newWaiting = (noWaiting + 1) & WAITING_QUEUE_MASK;
          if (status.compareAndSet(curStatus, (curStatus & (SHARED_THREADS_MASK_ROT | THREAD_POOL_MASK_ROT | INITIALIZED_MASK)) | (newWaiting << 1))) {
              // incremented
              long noReadyThreads = (curStatus >> 31) & THREAD_POOL_MASK;
              if (noReadyThreads > 0) {
                  // yes there is thread available now
                  testAndAssignThreadForWaiting();
              }
              // done
              return;
          }

          // try again
          curStatus = status.get();
          if ((curStatus & INITIALIZED_MASK) == 0) {
              // not initialized
              return;
          }

      }
  }

  /**
   * Get new thread
   * @param group ThreadGroup
   * @param target Runnable
   * @param name String
   * @param sharedOnly boolean - iff true, request only shared thread
   * @return Thread - can return null if there is
   */
  private static Thread getThread(ThreadGroup group, Runnable target, String name, boolean sharedOnly) {
      if (target == null) {
          throw new RuntimeException("Target for new thread is null.");
      }
      for (;;) {
          long curStatus = status.get();
          if ((curStatus & INITIALIZED_MASK) == 0) {
              // not initialized
              throw new RuntimeException("Thread cannont be allocated now. Thread pool is being finalized.");
          }
          long noReadyThreads = (curStatus >> 31) & THREAD_POOL_MASK;
          long noSharedThreads = (curStatus >> 51) & SHARED_THREADS_MASK;

          if (noReadyThreads > 0) {
              // yes there is some thread available
              long newReadyThreads = (noReadyThreads - 1) & THREAD_POOL_MASK;
              if (status.compareAndSet(curStatus, (curStatus & (SHARED_THREADS_MASK_ROT | WAITING_QUEUE_MASK_ROT | INITIALIZED_MASK)) | (newReadyThreads << 31))) {
                  // I got the thread
                  AglobeThread newThread = threadPool.pop();
                  if (newThread != null) {
                      newThread.setName(name);
                      newThread.setNewTarget(target);
                      newThread.setNewThreadGroup(group);
                      if (sharedOnly) {
                          return newThread;
                      }
                      // not shared thread
                      newThread.isSharedThread = false;
                      // decrement number of shared threads
                      for (;;) {
                          curStatus = status.get();
                          noSharedThreads = (curStatus >> 51) & SHARED_THREADS_MASK;
                          long newSharedThreads = (noSharedThreads - 1) & SHARED_THREADS_MASK;
                          if (status.compareAndSet(curStatus, (curStatus & (THREAD_POOL_MASK_ROT | WAITING_QUEUE_MASK_ROT | INITIALIZED_MASK)) | (newSharedThreads << 51))) {
                              // done
//                                  System.out.println("returns persistent thread. Cur thread: "+((curStatus>>31)&THREAD_POOL_MASK)+" cur shared: "+newSharedThreads);

                              // create new shared thread if there is not enough shared thread and some
                              //   runnable are waiting
                              if (newSharedThreads >= USE_SHARED_THREADS) {
                                  return newThread;
                              }
                              long noWaiting = (curStatus >> 1) & WAITING_QUEUE_MASK;
                              if (noWaiting > 0) {
                                  testAndCreateNewSharedThread();
                              }

                              return newThread;
                          }
                      }
                  } else {
                      throw new IllegalStateException("No thread in the thread pool");
                  }
              }
              // try again
              continue;
          }

          if (sharedOnly && (noReadyThreads == 0) && (noSharedThreads >= USE_SHARED_THREADS)) {
              // too enough shared threads allocated
              return null;
          }

          // create new thread
          AglobeThread newThread = new AglobeThread(group, target, name);
          newThread.setPriority(Thread.NORM_PRIORITY);
          newThread.threadStart();
          if (sharedOnly) {
              // increment the number of shared threads
              for (;;) {
                  curStatus = status.get();
                  noSharedThreads = (curStatus >> 51) & SHARED_THREADS_MASK;
                  long newSharedThreads = (noSharedThreads+1)&SHARED_THREADS_MASK;
                  if (status.compareAndSet(curStatus, (curStatus & (THREAD_POOL_MASK_ROT | WAITING_QUEUE_MASK_ROT | INITIALIZED_MASK)) | (newSharedThreads << 51))) {
                      // done, return the thread
//                      System.out.println("New shared thread. Cur ready: "+((curStatus >> 31) & THREAD_POOL_MASK)+" cur shared: "+newSharedThreads);
                      return newThread;
                  }
              }
          } else {
              // create non shared thread
              newThread.isSharedThread = false;
          }
          return newThread;
      }
  }

  /**
   * Get new thread
   * @param group ThreadGroup
   * @param target Runnable
   * @param name String - thread name
   * @return Thread -
   */
  public static Thread getThread(ThreadGroup group, Runnable target, String name) {
      if ((status.get() & INITIALIZED_MASK) == 0) {
          throw new RuntimeException("Thread cannont be allocated now. Thread pool is being finalized.");
      }
      return getThread(group, target, name, false);
  }

  /**
   * Get new thread
   * @param target Runnable
   * @param name String
   * @return Thread
   */
  public static Thread getThread(Runnable target, String name) {
      if ((status.get() & INITIALIZED_MASK) == 0) {
          throw new RuntimeException("Thread cannont be allocated now. Thread pool is being finalized.");
      }
      return getThread(null, target, name, false);
  }

  /**
   * Test if there is waiting runnable and ready thread, if yes start waiting
   */
  private static void testAndAssignThreadForWaiting() {
      for (;;) {
          long curStatus = status.get();
          long noWaiting = (curStatus >> 1) & WAITING_QUEUE_MASK;
          long noReadyThreads = (curStatus >> 31) & THREAD_POOL_MASK;

          if ((noWaiting == 0) || (noReadyThreads == 0)) {
              // no waiting runnable or no thread available
              return;
          }

          long newWaiting = (noWaiting - 1) & WAITING_QUEUE_MASK;
          long newReadyThreads = (noReadyThreads - 1) & THREAD_POOL_MASK;
          if (status.compareAndSet(curStatus, (curStatus & (SHARED_THREADS_MASK_ROT | INITIALIZED_MASK)) | (newReadyThreads << 31) | (newWaiting << 1))) {
              // yes, got it
              AglobeThread thread = threadPool.pop();
              if (thread == null) {
                  throw new IllegalStateException("No thread in the thread pool");
              }

              ToRunInThread to = waitingQueue.pop();
              if (to != null) {
                  // start it
                  thread.setName(to.threadName);
                  thread.setNewTarget(to.target);
                  thread.setNewThreadGroup(to.group);

                  // free the waiting structure
                  toRunInThreadPool.push(to);

                  // start thread
                  thread.start();
                  // finish
                  return;
              } else {
                  throw new IllegalStateException("No waiting runnable in the queue");
              }
          }
          // try again
      }
  }

  /**
   * Create new shared thread
   * @return boolean - true if thread is successfully created
   */
  private static boolean createNewSharedThread() {
      AglobeThread newThread;
      try {
          // yes, create it
          newThread = new AglobeThread();
          newThread.setPriority(Thread.NORM_PRIORITY);
          newThread.threadStart();
      } catch (Throwable ex) {
          // there is not enough native threads
          // decrement shared threads now
          for (;;) {
              long curStatus = status.get();
              long noSharedThreads = (curStatus >> 51) & SHARED_THREADS_MASK;
              long newSharedThreads = (noSharedThreads - 1) & SHARED_THREADS_MASK;
              if (status.compareAndSet(curStatus, (curStatus & (THREAD_POOL_MASK_ROT | WAITING_QUEUE_MASK_ROT | INITIALIZED_MASK)) | (newSharedThreads<<51))) {
                  // decremented
                  return false;
              }
              // try again
          }
      }

      try {
          threadPool.push(newThread);
      } catch (Exception ex2) {
          throw new IllegalStateException("Cannot push thread to the trhead pool",ex2);
      }

      // increment the number of threads now
      for (;;) {
          long curStatus = status.get();
          long noReadyThreads = (curStatus >> 31) & THREAD_POOL_MASK;
          long newReadyThreads = (noReadyThreads + 1) & THREAD_POOL_MASK;
          if (status.compareAndSet(curStatus, (curStatus & (SHARED_THREADS_MASK_ROT | WAITING_QUEUE_MASK_ROT | INITIALIZED_MASK)) | (newReadyThreads<<31))) {
              // incremented
              long noWaiting = (curStatus >> 1) & WAITING_QUEUE_MASK;
              if (noWaiting > 0) {
                  testAndAssignThreadForWaiting();
              }
              return true;
          }
          // try again
      }
  }

  /**
   * Test if there is number of shared threads below limit and some waiting object,
   * if yes, create thread and start waiting in it
   */
  private static void testAndCreateNewSharedThread() {
      for (;;) {
          long curStatus = status.get();
          long noSharedThreads = (curStatus >> 51) & SHARED_THREADS_MASK;

          if (noSharedThreads >= USE_SHARED_THREADS) {
              // cannot create new shared thread
              return;
          }

          long noWaiting = (curStatus >> 1) & WAITING_QUEUE_MASK;
          if (noWaiting == 0) {
              // not necessary now, thread will be created by preallocation
              return;
          }

          long newSharedThreads = (noSharedThreads + 1) & SHARED_THREADS_MASK;
          if (status.compareAndSet(curStatus, (curStatus & (THREAD_POOL_MASK_ROT | WAITING_QUEUE_MASK_ROT | INITIALIZED_MASK)) | (newSharedThreads << 51))) {
              // create new thread
              createNewSharedThread();

              return;
          }
          // test again
      }
  }

  /**
   * Adjust thread mode
   * @param isShared boolean - true if thread should become shared otherwise remove from shared group
   */
  public static void adjustThreadMode(boolean isShared) {
      Thread t = Thread.currentThread();
      if (t instanceof AglobeThread) {
          AglobeThread at = (AglobeThread) t;
          if (isShared != at.isSharedThread) {
              at.isSharedThread = isShared;
              if (isShared) {
                  // increment the number of shared threads
                  for (;;) {
                      long curStatus = status.get();
                      long noSharedThreads = (curStatus >> 51) & SHARED_THREADS_MASK;
                      long newSharedThreads = (noSharedThreads+1)&SHARED_THREADS_MASK;
                      if (status.compareAndSet(curStatus, (curStatus & (THREAD_POOL_MASK_ROT | WAITING_QUEUE_MASK_ROT | INITIALIZED_MASK)) | (newSharedThreads << 51))) {
                          // done
//                          System.out.println("Thread moved to the shared environment. Cur shared: "+newSharedThreads);
                          return;
                      }
                  }
              } else {
                  // decrement the number of shared threads
                  for (;;) {
                      long curStatus = status.get();
                      long noSharedThreads = (curStatus >> 51) & SHARED_THREADS_MASK;
                      long newSharedThreads = (noSharedThreads-1)&SHARED_THREADS_MASK;
                      if (status.compareAndSet(curStatus, (curStatus & (THREAD_POOL_MASK_ROT | WAITING_QUEUE_MASK_ROT | INITIALIZED_MASK)) | (newSharedThreads << 51))) {
                          // done
//                          System.out.println("Thread moved to the persistent environment. Cur shared: "+newSharedThreads);

                          // check if there is some waiting object and the number of shared threads is below the limit
                          if (newSharedThreads >= USE_SHARED_THREADS) {
                              // cannot create new shared thread
                              return;
                          }
                          long noWaiting = (curStatus >> 1) & WAITING_QUEUE_MASK;
                          if (noWaiting == 0) {
                              // not necessary now, thread will be created by preallocation
                              return;
                          }

                          testAndCreateNewSharedThread();
                          return;

                      }
                  }
              }
          }
      }
  }

  /**
   * Get an array of threads, that are in the specified <code>threadGroup</code>,
   * including all sub-groups.
   *
   * @param threadGroup Thread - source thread group
   * @return Thread[] - sibling threads array (array is <code>null</code>
   *   terminated)
   */
  public static Thread[] enumerateThreads(ThreadGroup threadGroup) {
      //parameters check
      if (threadGroup == null) {
          return new Thread[] {};
      }

      // if needed, obtain thread sub-groups
      ThreadGroup threadSubGroups[] = null;
      int threadSubGroupsCount = threadGroup.activeGroupCount();
      if (threadSubGroupsCount != 0) {
          threadSubGroups = new ThreadGroup[threadSubGroupsCount];
          threadGroup.enumerate(threadSubGroups, true);
      }

      // enumerate native Java thread
      Thread threadList[] = new Thread[threadGroup.activeCount() + threadPoolGroup.activeCount()];
      int offset = threadGroup.enumerate(threadList, true);

      // enumerate Aglobe pool threads
      Thread threadPoolList[] = new Thread[threadPoolGroup.activeCount()];
      threadPoolGroup.enumerate(threadPoolList, false);
      for (int i = 0, iList = offset; i < threadPoolList.length; ++i) {
          // add only aglobe threads from pool (non-Aglobe-threads in pool has
          // unknown group)
          if (threadPoolList[i] instanceof AglobeThread) {
              boolean isSubThread = false;
              ThreadGroup tg = ((AglobeThread) threadPoolList[i]).getAglobeThreadGroup();

              if (threadSubGroups == null) {
                  // subthread test with only one thread group
                  isSubThread = (tg == threadGroup);
              } else {
                  // subthread test with more thread groups
                  isSubThread = (Arrays.binarySearch(threadSubGroups, tg) >= 0);
              }

              // add thread into return array
              if (isSubThread) {
                  threadList[iList] = threadPoolList[i];
                  ++iList;
              }
          }
      }

      return threadList;
  }

  /**
   * Put finished thread back to the queue
   * @param thread AglobeThread
   */
  static void putThreadToTheQueue(AglobeThread thread) {
      if (!thread.isSharedThread) {
          thread.isSharedThread = true;
          // increment the number of shared threads first
          for (;;) {
              long curStatus = status.get();
              if ((curStatus & INITIALIZED_MASK) == 0) {
                  return;
              }
              long noSharedThreads = (curStatus >> 51) & SHARED_THREADS_MASK;
              long newSharedThreads = (noSharedThreads+1)&SHARED_THREADS_MASK;
              if (status.compareAndSet(curStatus, (curStatus & (THREAD_POOL_MASK_ROT | WAITING_QUEUE_MASK_ROT | INITIALIZED_MASK)) | (newSharedThreads << 51))) {
                  // done
//                  System.out.println("free persistent thread. Cur thread: "+((curStatus>>31)&THREAD_POOL_MASK)+" cur shared: "+newSharedThreads);
                  break;
              }
          }
      }

      for (;;) {
          long curStatus = status.get();
          if ((curStatus & INITIALIZED_MASK) == 0) {
              return;
          }

          long noWaiting = (curStatus >> 1) & WAITING_QUEUE_MASK;
          if (noWaiting == 0) {
              // there is no waiting object to start now
              // put thread to the ready pool
              thread.clearForPool();
              try {
                  threadPool.push(thread);
              } catch (Exception ex) {
                  throw new IllegalStateException("Cannot insert thread in the queue", ex);
              }
              for (;;) {
                  long noReadyThreads = (curStatus >> 31) & THREAD_POOL_MASK;
                  long newReadyThreads = (noReadyThreads + 1) & THREAD_POOL_MASK;
                  if (status.compareAndSet(curStatus, (curStatus & (SHARED_THREADS_MASK_ROT | WAITING_QUEUE_MASK_ROT | INITIALIZED_MASK)) | (newReadyThreads << 31))) {
                      // incremented
                      noWaiting = (curStatus >> 1) & WAITING_QUEUE_MASK;
                      if (noWaiting > 0) {
                          // try assign it for new object
                          testAndAssignThreadForWaiting();
                      }
                      // done
                      return;
                  }
                  // try again
                  curStatus = status.get();
              }
          } else {
              // try obtain waiting object
              long newWaiting = (noWaiting - 1) & WAITING_QUEUE_MASK;
              if (status.compareAndSet(curStatus, (curStatus & (SHARED_THREADS_MASK_ROT | THREAD_POOL_MASK_ROT | INITIALIZED_MASK)) | (newWaiting << 1))) {
                  // got it
                  ToRunInThread to = waitingQueue.pop();
                  if (to != null) {
                      thread.setName(to.threadName);
                      thread.setNewTarget(to.target);
                      thread.setNewThreadGroup(to.group);

                      // free the waiting structure
                      toRunInThreadPool.push(to);

                      // start thread
                      thread.start();
                      return;
                  } else {
                      throw new IllegalStateException("No waiting runnable in the queue");
                  }
              }
              // try again
          }
      }
  }

  /**
   * <p>Title: A-Globe</p>
   *
   * <p>Description: Internal class responsible for thread preallocation</p>
   *
   * <p>Copyright: Copyright (c) 2006</p>
   *
   * <p>Company: Gerstner Laboratory</p>
   *
   * @author David Sislak
   * @version $Revision: 1.24 $ $Date: 2010/12/03 12:29:26 $
   */
  private static class Preallocation implements Runnable {

      /**
       * Main method
       */
      @Override
	public void run() {
          // thread is finished because this is daemon thread
          while (true) {
              long curStatus = status.get();
              if ((curStatus & INITIALIZED_MASK) == 0) {
                  // finish
                  return;
              }
              long noReadyThreads = (curStatus >> 31) & THREAD_POOL_MASK;
              long noSharedThreads = (curStatus >> 51) & SHARED_THREADS_MASK;

              if (noSharedThreads < AglobeThreadPool.USE_SHARED_THREADS) {
                  // not enough ready threads, try make new
                  long newSharedThreads = (noSharedThreads + 1) & SHARED_THREADS_MASK;
                  if (status.compareAndSet(curStatus, (curStatus & (THREAD_POOL_MASK_ROT | WAITING_QUEUE_MASK_ROT | INITIALIZED_MASK)) | (newSharedThreads<<51))) {
                      if (createNewSharedThread()) {
//                        System.out.println("Prealocation: NEW thread. Cur ready: "+newReadyThreads+" cur shared: "+newSharedThreads);
                      }
                  }
                  // next round
                  continue;
              } else if (noReadyThreads > MAX_READY_THREADS) {
                  // more than allowed number of threads -> remove one thread

                  // decrement the number of threads and shared and finalize
                  for (;;) {
                      curStatus = status.get();
                      noReadyThreads = (curStatus >> 31) & THREAD_POOL_MASK;
                      noSharedThreads = (curStatus >> 51) & SHARED_THREADS_MASK;
                      if (noReadyThreads <= MAX_READY_THREADS) {
                          break;
                      }
                      long newReadyThreads = (noReadyThreads - 1) & THREAD_POOL_MASK;
                      long newSharedThreads = (noSharedThreads - 1) & SHARED_THREADS_MASK;
                      if (status.compareAndSet(curStatus, (curStatus & (WAITING_QUEUE_MASK_ROT | INITIALIZED_MASK)) | (newReadyThreads<<31) | (newSharedThreads<<51))) {
                          // thread taken, finalize it
                          AglobeThread at = threadPool.pop();
                          if (at != null) {
//                               System.out.println("Prealocation: finalize thread. Cur ready: "+newReadyThreads+" cur shared: "+newSharedThreads);
                              // finalize thread
                              at.threadFinish();
                              break;
                          } else {
                              throw new IllegalStateException("No thread in the thread pool");
                          }
                      }

                  }
                  // next round
                  continue;
              }
              // sleep 2 seconds
              try {
//                  System.out.println("Stats: cur ready: "+noReadyThreads+" cur shared: "+noSharedThreads+" true thread pool size: "+threadPool.size()+ " waiting: "+waitingQueue.size());
                  Thread.sleep(2000);
              } catch (InterruptedException ex) {
              }
          }
      }

  }


  /**
   *
   * <p>Title: A-globe</p>
   *
   * <p>Description: internal object used for storing information in the waiting queue for start
   * in the new thread.</p>
   *
   * <p>Copyright: Copyright (c) 2006</p>
   *
   * <p>Company: Agent Technology Center, Gerstner Laboratory</p>
   *
   * @author David Sislak
   * @version $Revision: 1.24 $ $Date: 2010/12/03 12:29:26 $
   */
  private static class ToRunInThread {
      private ThreadGroup group;
      private Runnable target;
      private String threadName;

      private ToRunInThread(ThreadGroup group, Runnable target, String threadName) {
          set(group, target, threadName);
      }

      private void set(ThreadGroup group, Runnable target, String threadName) {
          this.group = group;
          this.target = target;
          this.threadName = threadName;
      }
  }
}
