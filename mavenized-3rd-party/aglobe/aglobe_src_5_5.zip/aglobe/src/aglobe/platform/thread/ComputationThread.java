package aglobe.platform.thread;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;

import aglobe.container.EventReceiver;
import aglobe.container.LoggerOwner;
import aglobe.util.ExceptionPrinter;
import aglobe.util.Logger;
import aglobe.util.concurrent.NonblockingPoolArrayFIFO;
import aglobe.util.logging.LogProvider;

/**
 * @internal
 * <p>
 * Title: A-Globe
 * </p>
 *
 * <p>
 * Description: Allows user to control thread and also terminate computation
 * when timeout expired.
 *
 * Used in CollisionSolverManagerImpl. Collision solver manager computation
 * thread is shared by all solver plug-ins running within particular CSM.
 * </p>
 *
 * <p>
 * Copyright: Copyright (c) 2006
 * </p>
 *
 * <p>
 * Company: Agent Technology Center, Gerstner Laboratory
 * </p>
 *
 * @author David Sislak
 * @version $Revision: 1.55 $ $Date: 2010/08/04 11:48:05 $
 */
public class ComputationThread implements Runnable {

    /**
     * Set false for debug purposes only !!!
     */
    private final static boolean USE_THREAD = true;

    /**
     * Link to Owner
     */
    protected LoggerOwner loggerOwner;

    /**
     * Event receiver
     */
    protected EventReceiver eventReceiver;

    /**
     * Computation thread
     */
    public AglobeThread computationThread;

    /**
     * iff true computation thread should be finished
     */
    private boolean finish = false;

    /**
     * iff true thread is suspended
     */
    private boolean suspended = false;

    /**
     * true iff resume is requested
     */
    private boolean resumeRequested = false;

    /**
     * true means that thread is killed, and waits for suspending
     */
    private volatile boolean killed = false;

    /**
     * true means that user wants to stop running thread
     */
    private volatile boolean killing = false;

    private volatile boolean selfKill = false;

    /**
     * Computation thread name
     */
    private String name;

    /**
     * Method to run by computation thread
     */
    private Runnable methodToRun;

    /**
     * Run thread counter. Number of tasks started within the computation thread
     */
    private long counter = 0;

    /**
     * This method should be started just before suspending of computation
     * thread
     */
    private Runnable methodToRunBeforeSuspend;

    /**
     * Critical section counter
     */
    private int criticalSection = 0;

    /**
     * True if there is thread waiting for critical section end
     */
    private boolean waitForCritical = false;

    /**
     * Computation thread pool
     */
    private static NonblockingPoolArrayFIFO<ComputationThread> computationThreadPool = new NonblockingPoolArrayFIFO<ComputationThread>(1000);

    /**
     * HashMap of active threads
     */
    private static ConcurrentHashMap<Thread, ComputationThread> activeComputationThreads = new ConcurrentHashMap<Thread, ComputationThread>();

    /**
     * True if there is stop methods executed
     */
    private volatile boolean inStop = false;

    /**
     * Main synchronization log
     */
    private ReentrantLock mainLock = new ReentrantLock();

    /**
     * Main waiting condition
     */
    private Condition threadLockCondition = mainLock.newCondition();

    /**
     * User lock condition
     */
    private Condition userLockCondition = mainLock.newCondition();

    /**
     * If > 0 the stop and interrupt method of the computation thread cannot be
     * stopped.
     */
    private AtomicInteger numberOfNotStoppable = new AtomicInteger(0);

    private static Boolean fineLoggable = null;
    private static Boolean warningLoggable = null;
    private static Boolean severeLoggable = null;

    private static boolean isFineLoggable() {
        if (fineLoggable == null) {
            fineLoggable = Logger.isLoggable(Level.FINE);
        }
        return fineLoggable;
    }

    private static boolean isWarningLoggable() {
        if (warningLoggable == null) {
            warningLoggable = Logger.isLoggable(Level.WARNING);
        }
        return warningLoggable;
    }

    private static boolean isSevereLoggable() {
        if (severeLoggable == null) {
            severeLoggable = Logger.isLoggable(Level.SEVERE);
        }
        return severeLoggable;
    }

    /**
     * Request computation thread.
     *
     * @param eventReceiver
     *            EventReceiver
     * @param logger
     *            LoggerOwner
     * @param name
     *            String
     * @return ComputationThread
     */
    public static ComputationThread getComputationThread(EventReceiver eventReceiver, LoggerOwner logger, String name) {
        ComputationThread retVal = computationThreadPool.pop();
        if (retVal == null) {
            retVal = new ComputationThread(eventReceiver, logger, name);
            if (ComputationThread.USE_THREAD) {
                activeComputationThreads.put(retVal.computationThread, retVal);
            }
            return retVal;
        } else {
            retVal.loggerOwner = logger;
            retVal.name = name;
            if (ComputationThread.USE_THREAD) {
                retVal.computationThread.setName(name);
                retVal.computationThread.setNewThreadGroup(null);
                activeComputationThreads.put(retVal.computationThread, retVal);
            }
            return retVal;
        }
    }

    /**
     * Constructor
     *
     * @param owner
     *            Owner - owner containing this computation thread (can be owner
     *            of CollisionSolverManager containing this computation thread)
     * @param eventReceiver
     *            EventReceiver
     * @param name
     *            String - name for the computation thread
     */
    private ComputationThread(EventReceiver eventReceiver, LoggerOwner owner, String name) {
        this.loggerOwner = owner;
        this.eventReceiver = eventReceiver;
        this.name = name;

        // create thread if requested
        if (ComputationThread.USE_THREAD) {
            createThread(name);
        }
    }

    /**
     * Create new computation thread
     *
     * @param name
     *            String
     */
    private void createThread(String name) {
        // use thread pool
        computationThread = (AglobeThread) AglobeThreadPool.getThread(this,name);
        // set priority -2 below normal
        computationThread.setPriority(Math.max(Thread.MIN_PRIORITY,computationThread.getPriority() - 2));
        mainLock.lock();
        try {
            // start thread
            computationThread.start();

            // wait for its initialization
            try {
                userLockCondition.await();
            } catch (InterruptedException ex) {
            }
        } finally {
            mainLock.unlock();
        }
    }

    /**
     * Main computation thread method. It is started in computation thread.
     */
    @Override
	public void run() {
        //System.out.println("!!! Computation started: "+cnt.incrementAndGet());
        while (true) {
            try {
                logFine("CompThread - run: main loop", 0);
                // clear interrupted flag if it is set
                AglobeThread.interrupted();

                while (!finish && !computationThread.isInterrupted()) {
                    // wait for new data
                    logFine("CompThread - run: suspending.....", 0);
                    suspendThread();
                    // if there is method to run, start it
                    if (methodToRun != null) {
                        logFine("CompThread - Run BEGIN: " + name, 0);
                        methodToRun.run();
                        methodToRun = null;
                        logFine("CompThread - Run END: " + name, 0);
                    }
                }
                // check if thread is interrupted
                if (computationThread.isInterrupted()) {
                    while (true) {
                        int val = numberOfNotStoppable.get();
                        if (val < 0) {
                            Thread.yield();
                            continue;
                        }
                        if (numberOfNotStoppable.compareAndSet(val, val + 1)) {
                            break;
                        }
                    }
                    AglobeThread.interrupted(); // clear flag
                    mainLock.lock();
                    try {
                        if (isFineLoggable()) {
                            loggerOwner.logFine("CompThread - run: thread was interrupted");
                        }
                        // wait for synchronization with stopping method
                        killed = true;
                        // clear interrupted flag
                        AglobeThread.interrupted();
                        userLockCondition.signal();
                        while (killing) {
                            if (isWarningLoggable()) {
                                loggerOwner.logWarning("CompThread - run: interrupted: waiting for killed response synchronization");
                            }
                            try {
                                threadLockCondition.await(100,TimeUnit.MILLISECONDS);
                            } catch (InterruptedException ex) {
                            }
                        }
                        if (isWarningLoggable()) {
                            loggerOwner.logWarning("CompThread - run: interrupted: killed response synchronized");
                        }
                    } finally {
                        mainLock.unlock();
                        numberOfNotStoppable.decrementAndGet();
                    }
                }
                // if thread should be finished, finish it
                if (finish) {
                    break;
                }
            } catch (final ThreadDeath th) {
                // catching thread stop exception
                while (true) {
                    int val = numberOfNotStoppable.get();
                    if (val < 0) {
                        Thread.yield();
                        continue;
                    }
                    if (numberOfNotStoppable.compareAndSet(val, val + 1)) {
                        break;
                    }
                }
                AglobeThread.interrupted(); // clear flag
                selfKill = false;
                mainLock.lock();
                try {
                    if (isFineLoggable()) {
                        loggerOwner.log(Level.FINE, new LogProvider() {
                            @Override
							public String getLogMessage() {
                                StringBuilder sb = new StringBuilder("CompThread - run: catching thread stop exception\n");
                                sb.append(ExceptionPrinter.toStringWithStackTrace(th));
                                return sb.toString();
                            }
                        });
                    }
                    while (killing) {
                        try {
                            // clear interrupted flag if is set
                            killed = true;
                            AglobeThread.interrupted();
                            userLockCondition.signal();
                            // wait for synchronization with stopping method
                            while (killing) {
                                if (isWarningLoggable()) {
                                    loggerOwner.logWarning("CompThread - run: waiting for killed response synchronization");
                                }
                                try {
                                    threadLockCondition.await(100,
                                            TimeUnit.MILLISECONDS);
                                } catch (InterruptedException ex) {
                                }
                            }
                        } catch (final ThreadDeath th2) {
                            // catch tread stop exception during catching
                            // previous one
                            if (isSevereLoggable()) {
                                loggerOwner.log(Level.SEVERE,
                                        new LogProvider() {
                                            @Override
											public String getLogMessage() {
                                                StringBuilder sb = new StringBuilder("CompThread - run: catched second thread stop exception during the parsing first one\n");
                                                sb.append(ExceptionPrinter.toStringWithStackTrace(th2));
                                                return sb.toString();
                                            }
                                        });
                            }
                        }
                    }
                } finally {
                    mainLock.unlock();
                    numberOfNotStoppable.decrementAndGet();
                }
            } catch (NoSuchMethodError err1) {
                // catching thread stop exception, which is just before
                // synchronized, it throws
                // java.lang.NoSuchMethodError: java.lang.ThreadDeath: method
                // <init>(Ljava/lang/String;)V not found
                // so handle it as thread deatch above
                while (true) {
                    int val = numberOfNotStoppable.get();
                    if (val < 0) {
                        Thread.yield();
                        continue;
                    }
                    if (numberOfNotStoppable.compareAndSet(val, val + 1)) {
                        break;
                    }
                }
                AglobeThread.interrupted();
                selfKill = false;
                mainLock.lock();
                try {
                    if (isFineLoggable()) {
                        loggerOwner.logFine("CompThread - run: catching thread stop exception, which is just before synchronized");
                    }
                    while (killing) {
                        try {
                            // wait for synchronization with stopping method
                            killed = true;
                            // clear interrupted flag if is set
                            AglobeThread.interrupted();
                            userLockCondition.signal();
                            while (killing) {
                                try {
                                    threadLockCondition.await(100,TimeUnit.MILLISECONDS);
                                } catch (InterruptedException ex) {
                                }
                            }
                        } catch (final ThreadDeath th2) {
                            // catch tread stop exception during catching
                            // previous one
                            if (isSevereLoggable()) {
                                loggerOwner.log(Level.SEVERE,
                                        new LogProvider() {
                                            @Override
											public String getLogMessage() {
                                                StringBuilder sb = new StringBuilder("CompThread - run: catched second thread stop exception during the parsing first one\n");
                                                sb.append(ExceptionPrinter.toStringWithStackTrace(th2));
                                                return sb.toString();
                                            }
                                        });
                            }
                        }
                    }
                    break;
                } finally {
                    mainLock.unlock();
                    numberOfNotStoppable.decrementAndGet();
                }
            } catch (final Throwable th3) {
                while (true) {
                    int val = numberOfNotStoppable.get();
                    if (val < 0) {
                        Thread.yield();
                        continue;
                    }
                    if (numberOfNotStoppable.compareAndSet(val, val + 1)) {
                        break;
                    }
                }
                AglobeThread.interrupted();
                mainLock.lock();
                try {
                    if (isFineLoggable()) {
                        loggerOwner.logFine("CompThread - run: throwable");
                    }
                    try {
                        methodToRun = null;
                        if (isSevereLoggable()) {
                            loggerOwner.log(Level.SEVERE, new LogProvider() {
                                @Override
								public String getLogMessage() {
                                    StringBuilder sb = new StringBuilder("CompThread - Catch throwable: ");
                                    sb.append(ExceptionPrinter.toStringWithStackTrace(th3));
                                    return sb.toString();
                                }
                            });
                        }
                        System.out.println("CompThread - Catch throwable at: " + name);
                        th3.printStackTrace();

                        // finish computation thread
                        return;
                    } catch (ThreadDeath th) {
                        // catching thread stop exception
                        while (killing) {
                            try {
                                // wait for synchronization with stopping method
                                killed = true;
                                // clear interrupted flag if is set
                                AglobeThread.interrupted();
                                userLockCondition.signal();
                                while (killing) {
                                    try {
                                        threadLockCondition.await();
                                    } catch (InterruptedException ex) {
                                    }
                                }
                            } catch (final ThreadDeath th2) {
                                // catch tread stop exception during catching
                                // previous one
                                if (isSevereLoggable()) {
                                    loggerOwner.log(Level.SEVERE,
                                            new LogProvider() {
                                                @Override
												public String getLogMessage() {
                                                    StringBuilder sb = new StringBuilder("CompThread - run: catched second thread stop exception during the parsing first one\n");
                                                    sb.append(ExceptionPrinter.toStringWithStackTrace(th2));
                                                    return sb.toString();
                                                }
                                            });
                                }
                            }
                        }
                    }
                    break;
                } finally {
                    mainLock.unlock();
                    numberOfNotStoppable.decrementAndGet();
                }
            }
        }
    }

    /**
     * Request to compute new runnable within computation thread
     *
     * @param method
     *            Runnable - runnable to start in computation thread
     */
    public void compute(Runnable method) {
        if (ComputationThread.USE_THREAD) {
            mainLock.lock();
            try {
                if (loggerOwner == null) {
                    aglobe.util.Logger.logSevere("CompThread - Request for compute when computation thread has been disposed");
                    throw new RuntimeException("CompThread - Request for compute when computation thread has been disposed");
                }

                // check if thread is ready for starting new job
                if (!suspended) {
                    if (isSevereLoggable()) {
                        loggerOwner.logSevere("CompThread - Cannot start computation in running thread: "+ Thread.currentThread());
                    }
                    return;
                }
                methodToRun = method;
                counter++;
                // resume thread
                resumeThread();
            } finally {
                mainLock.unlock();
            }
        } else {
            // if runs in the debug mode, start job in the agent thread
            eventReceiver.addEvent(method);
        }
    }

    /**
     * Stop current job running by computation thread. Method will finish after
     * stoppin, so computation thread is ready for next new job.
     */
    @SuppressWarnings("deprecation")
    public void stopThread() {
        if (ComputationThread.USE_THREAD) {
            mainLock.lock();
            try {
                inStop = true;
                if (isFineLoggable()) {
                    loggerOwner.logFine("CompThread - stopThread: start stopping after sync: " + name);
                }
                // check if thread is not stopped by itself
                if (computationThread == Thread.currentThread()) {
                    if (isSevereLoggable()) {
                        loggerOwner.logSevere("CompThread - Stop thread by itself !!!: " + name);
                    }
                    new RuntimeException().printStackTrace();
                    throw new RuntimeException("CompThread - Stopping computation thread by itself");
                }
                if (finish || suspended) {
                    // finished or suspende thread
                    if (isFineLoggable()) {
                        loggerOwner.logFine("CompThread - stopThread: finished ("+ finish + ") or suspended ("+ suspended + "): " + name);
                    }
                    inStop = false;
                    return;
                }
                waitForCritical = true;
                if (isFineLoggable()) {
                    loggerOwner.logFine("CompThread - stopThread: wait for critical - begin: " + criticalSection);
                }
                while (criticalSection > 0) {
                    if (isFineLoggable()) {
                        loggerOwner.log(Level.FINE, new LogProvider() {
                            @Override
							public String getLogMessage() {
                                StringBuilder sb = new StringBuilder("CompThread - ");
                                StackTraceElement[] f = computationThread.getStackTrace();
                                for (int j = 0; j < f.length; j++) {
                                    sb.append("Computation:").append(name).append(": ").append(f[j].getClassName())
                                            .append(": ").append(f[j].getMethodName());
                                    sb.append(": ").append(f[j].getLineNumber());
                                    sb.append("\n");
                                }
                                return sb.toString();
                            }
                        });
                    }
                    try {
                        userLockCondition.await(1000, TimeUnit.MILLISECONDS);
                    } catch (InterruptedException ex) {
                    }
                }
                waitForCritical = false;
                if (isFineLoggable()) {
                    loggerOwner.logFine("CompThread - stopThread: wait for critical: finished");
                }
                if ((!suspended) && (resumeRequested)) {
                    // thread stop is requested before thread is resumed
                    if (isFineLoggable()) {
                        loggerOwner.logFine("CompThread - stopThread: is still suspended -- clear resume flags only");
                    }
                    // leave thread suspended
                    suspended = true;
                    resumeRequested = false;
                    methodToRun = null;
                }
                if (!suspended) {
                    if (isFineLoggable()) {
                        loggerOwner.logFine("CompThread - stopThread: Stopping thread: " + name + " by: " + Thread.currentThread().getName());
                        loggerOwner.log(Level.FINE, new LogProvider() {
                            @Override
							public String getLogMessage() {
                                StringBuilder sb2 = new StringBuilder("CompThread - ");
                                StackTraceElement[] f2 = computationThread.getStackTrace();
                                for (int j = 0; j < f2.length; j++) {
                                    sb2.append("Computation before stopping:").append(name).append(": ").append(f2[j].getClassName())
                                            .append(": ").append(f2[j].getMethodName());
                                    sb2.append(": ").append(f2[j].getLineNumber());
                                    sb2.append("\n");
                                }
                                return sb2.toString();
                            }
                        });
                    }
                    // stop computation thread-
                    killing = true;
                    int i = 0;
                    while ((!killed) && (!suspended)) {
                        final StackTraceElement[] f = computationThread.getStackTrace();
                        if (isFineLoggable()) {
                            loggerOwner.log(Level.FINE, new LogProvider() {
                                @Override
								public String getLogMessage() {
                                    StringBuilder sb = new StringBuilder("CompThread - ");
                                    for (int j = 0; j < f.length; j++) {
                                        sb.append("Computation in stopping:").append(name).append(": ")
                                                .append(f[j].getClassName()).append(": ").append(f[j].getMethodName());
                                        sb.append(": ").append(f[j].getLineNumber());
                                        sb.append("\n");
                                    }
                                    return sb.toString();
                                }
                            });
                        }
                        if ((f != null)
                                && (f.length > 0)
                                && (f[0].getClassName().equals(ComputationThread.class.getName()))) {
                            if (isFineLoggable()) {
                                loggerOwner.logFine("CompThread - stopThread: " + name + ": is in one of computation thread methods -- unblock it for a while");
                            }
                        } else {
                            Thread.State compState = computationThread.getState();
                            int val = numberOfNotStoppable.get();
                            if ((val != 0)
                                    || (selfKill)
                                    || (computationThread.isInterrupted())
                                    || (compState == Thread.State.BLOCKED)
                                    || (compState == Thread.State.WAITING)
                                    || (!numberOfNotStoppable.compareAndSet(val, -1))) {
                                if (isFineLoggable()) {
                                    loggerOwner.logFine("CompThread - stopThread: " + name + ": is blocked, waiting or cannot be stopped now -- unblock it for a while");
                                }
                            } else {
                                i++;
                                if (i % 2 == 1) {
                                    computationThread.interrupt();
                                    if (isFineLoggable()) {
                                        loggerOwner.logFine("CompThread - stopThread: " + name + ": interrupt called for thread state: " + compState
                                                        + "( new "+ computationThread.getState() + ")");
                                    }
                                } else {
                                    computationThread.stop();
                                    if (isFineLoggable()) {
                                        loggerOwner.logFine("CompThread - stopThread: " + name + ": stop called for thread state: " + compState + "( new "+ computationThread.getState()+ ")");
                                    }
                                }
                                if (!numberOfNotStoppable.compareAndSet(-1, 0)) {
                                    if (isSevereLoggable()) {
                                        loggerOwner.logSevere("CompThread - stopThread: wrong numberOfNotStoppable state !!!");
                                    }
                                }
                            }
                        }
                        try {
                            userLockCondition.await(100, TimeUnit.MILLISECONDS);
                        } catch (InterruptedException ex1) {
                        }
                    }
                    killing = false;
                    methodToRun = null;
                    // wait for suspended thread
                    if (isFineLoggable()) {
                        loggerOwner.logFine("CompThread - stopThread: wait for suspended thread");
                    }
                    while (!suspended) {
                        threadLockCondition.signal();
                        try {
                            userLockCondition.await(100, TimeUnit.MILLISECONDS);
                        } catch (InterruptedException ex1) {
                        }
                    }
                }
                inStop = false;
                if (isFineLoggable()) {
                    loggerOwner.logFine("CompThread - stopThread: return");
                }
            } finally {
                mainLock.unlock();
            }
        }
    }

    /**
     * Suspend thread. Method is called by computation thread.
     */
    private void suspendThread() {
        // do not suspend interrupted thread
        if (computationThread.isInterrupted()) {
            return;
        }
        while (true) {
            int val = numberOfNotStoppable.get();
            if (val < 0) {
                Thread.yield();
                continue;
            }
            if (numberOfNotStoppable.compareAndSet(val, val + 1)) {
                break;
            }
        }
        AglobeThread.interrupted();
        mainLock.lock();
        try {
            // start method requested to run just before suspending if there is
            // some
            if (methodToRunBeforeSuspend != null) {
                if ((!killed) && (!inStop)) {
                    try {
                        if (isFineLoggable()) {
                            loggerOwner.logFine("CompThread - suspendThread: Starting method to run before supspend");
                        }
                        methodToRunBeforeSuspend.run();
                        if (isFineLoggable()) {
                            loggerOwner.logFine("CompThread - suspendThread: Finished run before supspend");
                        }
                    } catch (Exception ex1) {
                        logSevere("Exception thrown from the runnable scheduled before suspend: "+ ExceptionPrinter.toStringWithStackTrace(ex1), 0);
                    }
                }
                methodToRunBeforeSuspend = null;
            }
            // suspend current thread
            suspended = true;
            userLockCondition.signal();
            if (isFineLoggable()) {
                loggerOwner.logFine("CompThread - suspendThread: Just before suspend. Critical = "+ criticalSection);
            }
            while (suspended && !finish) {
                if (isFineLoggable()) {
                    loggerOwner.logFine("CompThread - suspend in while loop");
                }
                try {
                    threadLockCondition.await();
                } catch (InterruptedException ex) {
                }
            }
            resumeRequested = false;
            killed = false;
            // notify resumer
            userLockCondition.signal();
            if (isFineLoggable()) {
                loggerOwner.logFine("CompThread - suspendThread: Just after suspend. Critical = " + criticalSection);
            }
        } finally {
            mainLock.unlock();
            numberOfNotStoppable.decrementAndGet();
        }
    }

    /**
     * Resume computation thread.
     */
    private void resumeThread() {
        while (true) {
            int val = numberOfNotStoppable.get();
            if (val < 0) {
                Thread.yield();
                continue;
            }
            if (numberOfNotStoppable.compareAndSet(val, val + 1)) {
                break;
            }
        }
        mainLock.lock();
        try {
            // resume it
            if (isFineLoggable()) {
                loggerOwner.logFine("CompThread - resumeThread: Request resume of the computation thread.");
            }
            suspended = false;
            resumeRequested = true;
            threadLockCondition.signal();
            while (resumeRequested) {
                if (isFineLoggable()) {
                    loggerOwner.logFine("CompThread - resumeThread: Waiting for resume");
                }
                try {
                    userLockCondition.await();
                } catch (InterruptedException ex) {
                }
            }
            if (isFineLoggable()) {
                loggerOwner.logFine("CompThread - resumeThread: Resumed");
            }
        } finally {
            mainLock.unlock();
            numberOfNotStoppable.decrementAndGet();
        }
    }

    /**
     * Destroy computation thread. Stop it first if it is still running
     */
    public void dispose() {
        mainLock.lock();
        try {
            if (loggerOwner == null) {
                return;
            }
            stopThread();

            // remove owners
            loggerOwner = null;
            eventReceiver = null;
            if (ComputationThread.USE_THREAD) {
                activeComputationThreads.remove(computationThread);
                computationThread.setName("Ready Computation Thread");
                computationThreadPool.push(this);
            }
        } finally {
            mainLock.unlock();
        }
    }

    /**
     * Run toRun runnable thread dead safely against stopping thread. So
     * computation thread cannot be stopped during running toRon run method.
     * This method should be called from the computation thread itself, to avoid
     * unexpected result of stop. E.g. it need to be called for all operation
     * working with external data from the computation thread including
     * calling agent's methods.
     *
     * @param toRun
     *            Runnable
     */
    public void runThreadDeadSafely(Runnable toRun) {
        while (true) {
            int val = numberOfNotStoppable.get();
            if (val < 0) {
                Thread.yield();
                continue;
            }
            if (numberOfNotStoppable.compareAndSet(val, val + 1)) {
                break;
            }
        }
        mainLock.lock();
        try {
            if (inStop) {
                return;
            }
            toRun.run();
        } finally {
            mainLock.unlock();
            numberOfNotStoppable.decrementAndGet();
        }
    }

    /**
     * Run specified toRun runnable just before suspending computation thread to
     * perform special clean up operations. Requested code is started within
     * computation thread itself and cannot be interrupted by stop operation.
     *
     * @param toRun
     *            Runnable
     */
    public void runThreadDeadSafelyBeforeSuspend(Runnable toRun) {
        while (true) {
            int val = numberOfNotStoppable.get();
            if (val < 0) {
                Thread.yield();
                continue;
            }
            if (numberOfNotStoppable.compareAndSet(val, val + 1)) {
                break;
            }
        }
        mainLock.lock();
        try {
            if (inStop) {
                return;
            }
            if (ComputationThread.USE_THREAD) {
                methodToRunBeforeSuspend = toRun;
            } else {
                toRun.run();
            }
        } finally {
            mainLock.unlock();
            numberOfNotStoppable.decrementAndGet();
        }
    }

    /**
     * Thread dead safe log operation. It must be used in every log case from
     * the code running within computation thread.
     *
     * @param log
     * @param callsBack
     */
    public void logThreadDeadSafely(String log, int callsBack) {
        while (true) {
            int val = numberOfNotStoppable.get();
            if (val < 0) {
                Thread.yield();
                continue;
            }
            if (numberOfNotStoppable.compareAndSet(val, val + 1)) {
                break;
            }
        }
        mainLock.lock();
        try {
            if (inStop) {
                return;
            }
            loggerOwner.logInfo(log, callsBack + 1);
        } finally {
            mainLock.unlock();
            numberOfNotStoppable.decrementAndGet();
        }
    }

    /**
     * Log finest. Method is thread dead safe and must be used in code running
     * within computation thread to avoid unexpected JVM crash.
     *
     * @param message
     * @param callsBack
     */
    public void logFinest(String message, int callsBack) {
        while (true) {
            int val = numberOfNotStoppable.get();
            if (val < 0) {
                Thread.yield();
                continue;
            }
            if (numberOfNotStoppable.compareAndSet(val, val + 1)) {
                break;
            }
        }
        mainLock.lock();
        try {
            if (inStop) {
                return;
            }
            loggerOwner.logFinest(message, callsBack + 1);
        } finally {
            mainLock.unlock();
            numberOfNotStoppable.decrementAndGet();
        }
    }

    /**
     * Log fine. Method is thread dead safe and must be used in code running
     * within computation thread to avoid unexpected JVM crash.
     *
     * @param message
     * @param callsBack
     */
    public void logFine(String message, int callsBack) {
        while (true) {
            int val = numberOfNotStoppable.get();
            if (val < 0) {
                Thread.yield();
                continue;
            }
            if (numberOfNotStoppable.compareAndSet(val, val + 1)) {
                break;
            }
        }
        mainLock.lock();
        try {
            if (inStop) {
                return;
            }
            loggerOwner.logFine(message, callsBack + 1);
        } finally {
            mainLock.unlock();
            numberOfNotStoppable.decrementAndGet();
        }
    }

    /**
     * Log info. Method is thread dead safe and must be used in code running
     * within computation thread to avoid unexpected JVM crash.
     *
     * @param message
     * @param callsBack
     */
    public void logInfo(String message, int callsBack) {
        while (true) {
            int val = numberOfNotStoppable.get();
            if (val < 0) {
                Thread.yield();
                continue;
            }
            if (numberOfNotStoppable.compareAndSet(val, val + 1)) {
                break;
            }
        }
        mainLock.lock();
        try {
            if (inStop) {
                return;
            }
            loggerOwner.logInfo(message, callsBack + 1);
        } finally {
            mainLock.unlock();
            numberOfNotStoppable.decrementAndGet();
        }
    }

    /**
     * Log warning. Method is thread dead safe and must be used in code running
     * within computation thread to avoid unexpected JVM crash.
     *
     * @param message
     * @param callsBack
     */
    public void logWarning(String message, int callsBack) {
        while (true) {
            int val = numberOfNotStoppable.get();
            if (val < 0) {
                Thread.yield();
                continue;
            }
            if (numberOfNotStoppable.compareAndSet(val, val + 1)) {
                break;
            }
        }
        mainLock.lock();
        try {
            if (inStop) {
                return;
            }
            loggerOwner.logWarning(message, callsBack + 1);
        } finally {
            mainLock.unlock();
            numberOfNotStoppable.decrementAndGet();
        }
    }

    /**
     * Log severe. Method is thread dead safe and must be used in code running
     * within computation thread to avoid unexpected JVM crash.
     *
     * @param message
     * @param callsBack
     */
    public void logSevere(String message, int callsBack) {
        while (true) {
            int val = numberOfNotStoppable.get();
            if (val < 0) {
                Thread.yield();
                continue;
            }
            if (numberOfNotStoppable.compareAndSet(val, val + 1)) {
                break;
            }
        }
        mainLock.lock();
        try {
            if (inStop) {
                return;
            }
            loggerOwner.logSevere(message, callsBack + 1);
        } finally {
            mainLock.unlock();
            numberOfNotStoppable.decrementAndGet();
        }
    }

    /**
     * Create log, the message for logging is generated using specified
     * logProvider only if log passed all filtration rules
     *
     * @param level
     * @param logProvider
     * @param callsBack
     */
    public void log(Level level, LogProvider logProvider, int callsBack) {
        while (true) {
            int val = numberOfNotStoppable.get();
            if (val < 0) {
                Thread.yield();
                continue;
            }
            if (numberOfNotStoppable.compareAndSet(val, val + 1)) {
                break;
            }
        }
        mainLock.lock();
        try {
            if (inStop) {
                return;
            }
            loggerOwner.log(level, logProvider, callsBack + 1);
        } finally {
            mainLock.unlock();
            numberOfNotStoppable.decrementAndGet();
        }
    }

    /**
     * Check if specified level should be logged in the current context
     *
     * @param level
     * @param callsBack
     * @return boolean
     */
    public boolean isLoggable(Level level, int callsBack) {
        return loggerOwner.isLoggable(level, callsBack + 1);
    }

    /**
     * Start of critical section
     */
    public static void startOfCriticalSection() {
        Thread curThread = Thread.currentThread();
        final ComputationThread compThread = activeComputationThreads.get(curThread);
        if (compThread != null) {
            while (true) {
                int val = compThread.numberOfNotStoppable.get();
                if (val < 0) {
                    Thread.yield();
                    continue;
                }
                if (compThread.numberOfNotStoppable.compareAndSet(val, val + 1)) {
                    break;
                }
            }
            compThread.mainLock.lock();
            try {
                if (compThread.killing) {
                    if (isFineLoggable()) {
                        compThread.loggerOwner.logFine("CompThread - self thread death from start critical section");
                    }
                    compThread.selfKill = true;
                    // kill thread
                    throw new ThreadDeath();
                }
                compThread.criticalSection++;
                if (isFineLoggable()) {
                    compThread.loggerOwner.log(Level.FINE, new LogProvider() {
                        @Override
						public String getLogMessage() {
                            StringBuilder sb = new StringBuilder("CompThread - start critical (");
                            sb.append(compThread.criticalSection);
                            sb.append("): ");
                            sb.append(ExceptionPrinter.toStringWithStackTrace(new Exception()));
                            return sb.toString();
                        }
                    });
                }
            } finally {
                compThread.mainLock.unlock();
                compThread.numberOfNotStoppable.decrementAndGet();
            }
        }
    }

    /**
     * End of critical section
     */
    public static void endOfCriticalSection() {
        Thread curThread = Thread.currentThread();
        final ComputationThread compThread = activeComputationThreads.get(curThread);
        if (compThread != null) {
            while (true) {
                int val = compThread.numberOfNotStoppable.get();
                if (val < 0) {
                    Thread.yield();
                    continue;
                }
                if (compThread.numberOfNotStoppable.compareAndSet(val, val + 1)) {
                    break;
                }
            }
            compThread.mainLock.lock();
            try {
                compThread.criticalSection--;
                if (isFineLoggable()) {
                    compThread.loggerOwner.log(Level.FINE, new LogProvider() {
                        @Override
						public String getLogMessage() {
                            StringBuilder sb = new StringBuilder("CompThread - end critical (");
                            sb.append(compThread.criticalSection);
                            sb.append("): ");
                            sb.append(ExceptionPrinter.toStringWithStackTrace(new Exception()));
                            return sb.toString();
                        }
                    });
                }
                if (compThread.waitForCritical && (compThread.criticalSection == 0)) {
                    compThread.userLockCondition.signal();
                }
            } finally {
                compThread.mainLock.unlock();
                compThread.numberOfNotStoppable.decrementAndGet();
            }
        }
    }
}
