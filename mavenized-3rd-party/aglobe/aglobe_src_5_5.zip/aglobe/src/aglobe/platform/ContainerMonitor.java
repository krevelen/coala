package aglobe.platform;

import aglobe.container.AgentContainer;

/**
 * <p>Title: A-globe</p>
 *
 * <p>Description: Provide information about containers startup/shutdown. Register
 * a monitor with platform.</p>
 *
 * <p>Copyright: Copyright (c) 2007</p>
 *
 * <p>Company: Agent Technology Center, Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.5 $ $Date: 2009/05/15 08:46:59 $
 */
public interface ContainerMonitor {

    /**
     * Method is called after initialization of system services before startup of agents
     * @param container AgentContainer
     */
    public void containerStarted(AgentContainer container);

    /**
     * Method is called just before shutting down the A-globe container
     * @param containerName String
     */
    public void containerRemoved(String containerName);
}
