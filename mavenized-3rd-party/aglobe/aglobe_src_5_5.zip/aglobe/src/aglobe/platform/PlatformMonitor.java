package aglobe.platform;

/**
 * Implemented by the classes that wish to know about the platform status. Register
 * the monitor with platform.
 */
public interface PlatformMonitor {

    public enum PlatformState { STARTED, INITIALIZED, SHUTTING_DOWN, STOPPED }

    public void platformStateChanged(PlatformState currentState);
}
