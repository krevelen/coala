/**
 *
 */
package aglobe.platform.transport;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

/**
 * @internal
 * <p>Title: MessageObjectOutputStream</p>
 *
 * <p>Description: Internal AGLOBE class used for message serialization purposes</p>
 *
 * <p>Copyright: Copyright (c) 2009</p>
 *
 * <p>Company: Agent Technology Center</p>
 *
 * @author David Sislak
 * @version $Revision: 1.2 $ $Date: 2009/06/26 11:34:22 $
 *
 */
public class MessageObjectOutputStream extends ObjectOutputStream {
    /**
     * @internal
     */
    public final AddressWriter adderessWriter;

    /**
     * @internal
     * @param out
     * @throws IOException
     */
    public MessageObjectOutputStream(final OutputStream out, final AddressWriter addressWriter) throws IOException {
        super(out);

        this.adderessWriter = addressWriter;
    }

}
