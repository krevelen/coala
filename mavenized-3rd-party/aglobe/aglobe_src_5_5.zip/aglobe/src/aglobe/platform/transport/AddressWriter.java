/**
 *
 */
package aglobe.platform.transport;

import aglobe.container.transport.Address;

/**
 * @internal
 * <p>Title: AddressWriter</p>
 *
 * <p>Description: Internal AGLOBE interface for writing addresses</p>
 *
 * <p>Copyright: Copyright (c) 2009</p>
 *
 * <p>Company: Agent Technology Center</p>
 *
 * @author David Sislak
 * @version $Revision: 1.2 $ $Date: 2009/06/26 11:34:22 $
 *
 */
public interface AddressWriter {

    /**
     * Write specified address. The method returns unique address handler which should be used
     * during restoring via AddressReader
     *
     * @param address
     * @return
     */
    public short writeAddress(final Address address);
}
