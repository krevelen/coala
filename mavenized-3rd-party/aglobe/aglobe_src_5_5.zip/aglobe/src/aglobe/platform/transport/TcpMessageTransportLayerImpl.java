package aglobe.platform.transport;

import java.io.IOException;
import java.lang.ref.SoftReference;
import java.net.ConnectException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.BufferOverflowException;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.concurrent.locks.ReentrantLock;

import aglobe.container.transport.Address;
import aglobe.ontology.Message;
import aglobe.platform.MessageTransportComponent;
import aglobe.platform.Platform;
import aglobe.platform.thread.AglobeThreadPool;
import aglobe.util.ExceptionPrinter;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: Internal class used for low-level I/O MessageTransport operations over TCP</p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.38 $ $Date: 2010/11/30 09:12:27 $
 */
final class TcpMessageTransportLayerImpl extends MessageTransportLayerImpl implements Runnable {

    /**
     * TCP/IP connection open timeout in milliseconds
     */
    private static final int CONNECTION_OPEN_TIMEOUT = 500;

    /**
     * TCP/IP connection buffer size, 20 000kB
     */
    private static final int TCP_SOCKET_BUFFER_SIZE = 2048000;

    private final static long WAIT_FOR_MSG_MILLIS = 120000;

    /**
     * Length of the message header
     */
    private static final int HEADER_LENGTH = 4;

    private final InetAddress address;

    /**
     * Port where the MessageTransport listens for incoming messages from outside of the Platform
     */
    private final int port;

    /**
     * Receiving thread
     */
    private final Thread receivingThread;

    /**
     * Accept thread
     */
    private Thread acceptThread;

    /**
     * Socket channel where MT listens for incoming messages
     */
    private ServerSocketChannel ssc;

    /**
     * Selector for blocking incoming operation
     */
    private final Selector selector;

    /**
     * True if wake is set
     */
    private volatile boolean wake = false;

    /**
     * Selector for accept connections
     */
    private Selector acceptSelector;

    /**
     * Lock object used during message transport shutdown
     */
    private final Object stopLock = new Object();

    /**
     * true if receiving thread may be stopped
     */
    private boolean stop;

    /**
     * sets to true after receiving thread finish
     */
    private boolean finished;

    /**
     * set to true after accept thread finish
     */
    private boolean finishedAccept;

    /**
     * true if connection should be closed after each message
     */
    private boolean hwMode;

    /**
     * Internal synchronization object for registering to the selector,
     * stopping receiving thread and closing all opened connections
     */
    private final Object lock = new Object();

    /**
     * Internal synchronization object for multiple registration to the
     * same selector.
     */
    private final Object registerNewLock = new Object();

    /**
     * HashMap of the Connection instances where key is String destination composed as IP:port
     */
    private final HashMap<String, Connection> connectionByDestination = new HashMap<String, Connection> ();

    private final ReentrantLock connectionByDestinationLock = new ReentrantLock();

    /**
     * HashMap of the Connection instances where key is socket Channel for that connection
     */
    private final HashMap<SocketChannel, Connection> connectionByChannel = new HashMap<SocketChannel, Connection> ();

    // used for reading in one thread
    private final ArrayDeque<long[]> longArraysPool = new ArrayDeque<long[]>();
    private final ArrayDeque<Address[]> addressArraysPool = new ArrayDeque<Address[]>();
    private final ArrayDeque<ArrayList<AddressWaiter>> arrayListAddressWaiterPool = new ArrayDeque<ArrayList<AddressWaiter>>();

    private final HashMap<Long, Integer> debugAddressCounter = new HashMap<Long, Integer>();

    /**
     * Starts receiving thread
     *
     * @param address InetAddress
     * @param _port int - port where MT will listens for incoming messages
     * @param hwMode boolean - true if MT should run in special HW mode, it means that connection between containers is used only for one particular message
     *   and then it is closed
     * @throws IOException - throws if there is some problem with binding receiving port
     * @throws Exception
     */
    TcpMessageTransportLayerImpl(final InetAddress address, final int _port, final boolean hwMode) throws IOException, Exception {
        this.address = address;
        port = _port;
        stop = false;
        finished = false;
        finishedAccept = false;
        this.hwMode = hwMode;

        // create selector for receiving messages
        selector = Selector.open();

        // start receiving thread
        receivingThread = AglobeThreadPool.getThread(Platform.getPlatformThreadGroup(), this, "TCP Message transport: Receiving Thread");
        receivingThread.setPriority(Math.min(Thread.NORM_PRIORITY + 3, Thread.MAX_PRIORITY));
        receivingThread.start();

        // start accept thread
        new AcceptLayer();
    }

    /**
     * Returns local MessageTransport address where message transport listens for the new incoming messages
     * @throws UnknownHostException
     * @return InetSocketAddress
     */
    @Override
    public final InetSocketAddress getLocalAddress() throws UnknownHostException {
        return new InetSocketAddress((address != null)?address:InetAddress.getLocalHost(), ssc.socket().getLocalPort());
    }

    /**
     * Stops receiving thread and close all opened connections
     */
    @Override
    public final void stopMessageTransport() {
        synchronized (registerNewLock) {
            synchronized (lock) {
                wake = true;
                selector.wakeup();
                try {
                    lock.wait();
                }
                catch (InterruptedException ex2) {
                }
                wake = false;
                stop = true;
                lock.notify();
            }
        }
        acceptSelector.wakeup();
        synchronized (stopLock) {
            while (! (finished && finishedAccept)) {
                try {
                    stopLock.wait();
                }
                catch (InterruptedException ex) {
                }
            }
        }
        try {
            selector.close();
            ssc.close();
            closeAllConnection();
        }
        catch (IOException ex1) {
            MessageTransport.logger.severe("Can't close listening socket.");
        }
    }

    /**
     * Inner class for accepting socket connections
     * <p>Title: A-Globe</p>
     * <p>Description: </p>
     * <p>Copyright: Copyright (c) 2005</p>
     * <p>Company: Gerstner Laboratory</p>
     * @author David Sislak
     * @version $Revision: 1.38 $ $Date: 2010/11/30 09:12:27 $
     */
    private final class AcceptLayer implements Runnable {
        private AcceptLayer() throws Exception {
            try {
                ssc = ServerSocketChannel.open();
                ssc.configureBlocking(false);
                final ServerSocket ss = ssc.socket();
                acceptSelector = Selector.open();
                ss.setReuseAddress(true);
                ss.bind(new InetSocketAddress(port), 1000);
                ssc.register(acceptSelector, SelectionKey.OP_ACCEPT);

                // start accepting thread on the high priority level
                acceptThread = AglobeThreadPool.getThread(Platform.getPlatformThreadGroup(), this, "TCP Message transport: Accept Thread");
                acceptThread.setPriority(Thread.MAX_PRIORITY);
                acceptThread.start();
            } catch (IOException ex) {
                throw new Exception("Accept thread exception: " + ex);
            }
        }

        /**
         * Accept thread main loop
         */
        @Override
		public final void run() {
            while (!stop) {
                try {
                    if (acceptSelector.select() > 0) {
                        final Iterator<SelectionKey> it = acceptSelector.selectedKeys().iterator();
                        while (it.hasNext()) {
                            final SelectionKey sk = it.next();
                            final int skOps = sk.readyOps();
                            if ((skOps & SelectionKey.OP_ACCEPT) == SelectionKey.OP_ACCEPT) {
                                final SocketChannel remote = ssc.accept();
                                getConnection(remote);
                                it.remove();
                            }
                        }
                    }
                } catch (IOException ex1) {
                    MessageTransport.logger.severe("Accept thread exception: " + ex1);
                }
            }
            synchronized (stopLock) {
                finishedAccept = true;
                stopLock.notify();
            }
        }
    }

    /**
     * Main receiving thread function. Waits for incoming message until stop is true
     */
    @Override
	public final void run() {
        int numKeys, rskOps;
        SelectionKey rsk;
        Connection connection;
        try {
            while (!stop) {
                // wait for incoming event
                if (!wake) {
                    numKeys = selector.select();
                } else {
                    numKeys = 0;
                }
                if (numKeys > 0) {
                    // iterate through events
                    final Iterator<SelectionKey> it = selector.selectedKeys().iterator();
                    while (it.hasNext()) {
                        rsk = it.next();
                        rskOps = rsk.readyOps();
                        if ((rskOps & SelectionKey.OP_READ) == SelectionKey.OP_READ) {
                            // incoming data
                            connection = getConnection((SocketChannel) rsk.channel());
                            it.remove();
                            try {
                                if (connection.socketChannel.read(connection.inputBuffer) < 0) {
                                    // connection closed
                                    rsk.cancel();
                                    closeConnection(connection);
                                    removeConnection(connection);
                                } else {
                                    // parse received data
                                    connection.parseAllAvailable();
                                }
                            } catch (IOException ex2) {
                                // force closed
                                rsk.cancel();
                                closeConnection(connection);
                                removeConnection(connection);
                            }
                        }
                    }
                } else {
                    if (wake) {
                        try {
                            synchronized (lock) {
                                // resume blocked thread
                                lock.notify();
                                // wait for changes within selector
                                lock.wait();
                            }
                        } catch (InterruptedException ex1) {
                        }
                    }
                }
            }
            synchronized (stopLock) {
                finished = true;
                stopLock.notify();
            }
        } catch (Throwable ex) {
            MessageTransport.logger.severe("TCP Message Transport Layer Throwable:\n" + ExceptionPrinter.toStringWithStackTrace(ex));
        }
    }

    /**
     * Close connection
     * @param con Connection
     */
    private final void closeConnection(final Connection con) {
        try {
            if (con.socket.isConnected()) {
                con.socket.shutdownInput();
                con.socket.shutdownOutput();
            }
            if (!con.socket.isClosed()) {
                con.socket.close();
                con.socketChannel.close();
            }
        }
        catch (IOException ex) {
            MessageTransport.logger.severe("Cannot close socket " + ex);
        }
    }

    /**
     * Closes all opened connection
     */
    private final void closeAllConnection() {
        connectionByDestinationLock.lock();
        try {
            for (final Iterator<Connection> iter = connectionByChannel.values().iterator(); iter.hasNext(); ) {
                Connection item = iter.next();
                closeConnection(item);
            }
            connectionByDestination.clear();
            connectionByChannel.clear();
        } finally {
            connectionByDestinationLock.unlock();
        }
    }

    /**
     * Returns connection for the requested SocketChannel
     * @param _socketChannel SocketChannel
     * @throws SocketException
     * @throws IOException
     * @return Connection
     */
    private final Connection getConnection(final SocketChannel _socketChannel) throws SocketException, IOException {
        Connection con;
        connectionByDestinationLock.lock();
        try {
            if (connectionByChannel.containsKey(_socketChannel)) {
                return connectionByChannel.get(_socketChannel);
            }
            else {
                _socketChannel.configureBlocking(false);
                final Socket socket = _socketChannel.socket();
                socket.setTcpNoDelay(true);
                socket.setReuseAddress(true);
                socket.setTrafficClass(0x18);
                socket.setSendBufferSize(TCP_SOCKET_BUFFER_SIZE);
                socket.setReceiveBufferSize(TCP_SOCKET_BUFFER_SIZE);
                if (socket.getSendBufferSize() != TCP_SOCKET_BUFFER_SIZE) {
                    MessageTransport.logger.warning("Cannot set stream socket send buffer size ! Will use only current buffer size "+socket.getSendBufferSize()+" Bytes which will have negative impact to communication performance. System administrator can allow setting large socket buffers.");
                }
                if (socket.getReceiveBufferSize() != TCP_SOCKET_BUFFER_SIZE) {
                    MessageTransport.logger.warning("Cannot set stream socket send buffer size ! Will use only current buffer size "+socket.getReceiveBufferSize()+" Bytes which will have negative impact to communication performance. System administrator can allow setting large socket buffers.");
                }
                final String destination = socket.getInetAddress().getHostAddress() + ":" + socket.getPort();
                con = new Connection(socket, _socketChannel, destination);
                if (!hwMode) {
                    connectionByDestination.put(destination, con);
                }
                connectionByChannel.put(_socketChannel, con);
            }
        } finally {
            connectionByDestinationLock.unlock();
        }
        // register read operation selection
        synchronized (registerNewLock) {
            synchronized (lock) {
                wake = true;
                selector.wakeup();
                try {
                    // wait for new wait
                    lock.wait();
                }
                catch (InterruptedException ex) {
                }
                wake = false;
                // register channel for read
                _socketChannel.register(selector, SelectionKey.OP_READ);
                // notify main receiving thread
                lock.notify();
            }
        }
        return con;
    }

    /**
     * Returns Connection for the destinationAddress
     *
     * @param destinationAddress Address - target address for which Connection
     *   is requested
     * @throws IOException - throws if some connection problem, e.g. connection
     *   refused
     * @return Connection
     */
    private final Connection getConnection(final Address destinationAddress) throws IOException {
        try {
            final String destination = destinationAddress.getHost() + ":" + destinationAddress.getPort();
            SocketChannel sch;
            Connection con;
            connectionByDestinationLock.lock();
            try {
                if ((!hwMode) && (connectionByDestination.containsKey(destination))) {
                    return connectionByDestination.get(destination);
                } else {
                    sch = SocketChannel.open();
                    final Socket socket = sch.socket();
                    socket.setReuseAddress(true);
                    socket.connect(new InetSocketAddress(destinationAddress.getHost(), destinationAddress.getPort()),
                                   TcpMessageTransportLayerImpl.CONNECTION_OPEN_TIMEOUT);
                    if (!hwMode) {
                        // no blocking mode for not HW mode
                        sch.configureBlocking(false);
                    }
                    socket.setTcpNoDelay(true);
                    socket.setTrafficClass(0x18);
                    socket.setSendBufferSize(TCP_SOCKET_BUFFER_SIZE);
                    socket.setReceiveBufferSize(TCP_SOCKET_BUFFER_SIZE);
                    if (socket.getSendBufferSize() != TCP_SOCKET_BUFFER_SIZE) {
                        MessageTransport.logger.warning("Cannot set socket send buffer size !");
                    }
                    if (socket.getReceiveBufferSize() != TCP_SOCKET_BUFFER_SIZE) {
                        MessageTransport.logger.warning("Cannot set socket receive buffer size !");
                    }                    
                    con = new Connection(socket, sch, destination);
                    if (!hwMode) {
                        connectionByDestination.put(destination, con);
                    }
                    connectionByChannel.put(sch, con);
                }
            } finally {
                connectionByDestinationLock.unlock();
            }
            if (!hwMode) {
                synchronized (registerNewLock) {
                    synchronized (lock) {
                        wake = true;
                        selector.wakeup();
                        try {
                            // wait for main selector thread to wait
                            lock.wait();
                        }
                        catch (InterruptedException ex1) {
                        }
                        wake = false;
                        // register new channel for read
                        sch.register(selector, SelectionKey.OP_READ);
                        // notify main reading thread
                        lock.notify();
                    }
                }
            }
            return con;
        }
        catch (ConnectException ex) {
            throw ex;
        }
    }

    /**
     * Removes connection from the hash maps
     * @param connection Connection
     */
    private final void removeConnection(final Connection connection) {
        connectionByDestinationLock.lock();
        try {
            if (!hwMode) {
                connectionByDestination.remove(connection.destination);
            }
            connectionByChannel.remove(connection.socketChannel);
            // release selector
            if (connection.writeSelector != null) {
                try {
                    connection.writeSelector.close();
                }
                catch (IOException ex) {
                    MessageTransport.logger.warning("Problem with closing write selector: " + ex.toString());
                }
                connection.writeSelector = null;
            }
        } finally {
            connectionByDestinationLock.unlock();
        }
    }

    /**
     * Change connection destination to new destination
     * @param con Connection
     * @param newdest String
     */
    private final void changeConnectionDestination(final Connection con, final String newdest) {
        if (!hwMode) {
            connectionByDestinationLock.lock();
            try {
                connectionByDestination.remove(con.destination);
                con.destination = newdest;
                connectionByDestination.put(newdest, con);
            } finally {
                connectionByDestinationLock.unlock();
            }
        }
    }

    /**
     * Get size of the message when transmitted over underlying network connection
     *
     * @param m Message
     * @param serializedLength int - if >= 0 it is used as a serialized size
     * @param noConnection boolean
     * @return int
     */
    @Override
    public final int getSimulatedMessageSize(final Message m, final int serializedLength, final boolean noConnection) {
        if (noConnection) {
            return 0;
        }
        int serLen = serializedLength;
        if (serLen < 0) {
            // count serialized length
            serLen = MessageSizeCounter.getMessageSerializedLength(m);
        }
        return HEADER_LENGTH + 1 + 2 + 2 + serLen;
    }

    /**
     * Transmit message to the destination by low level I/O operations.
     *
     * @param receivers Collection<Address> - specifies the receiver of the message
     * @param m Message - message to transmission
     * @param needMessageCopy boolean - iff true the binary encoded message in byte[] is requested
     * @return int - transmitted data size
     * @throws IOException
     */
    @Override
    public final int transmitMessage(final Collection<Address> receivers, final Message m) throws IOException {
        int msgSize = 0;

        try {
            // get appropriate connection
            final Connection con = getConnection(receivers.iterator().next());
            con.lockOutput.lock();
            try {
                final int addressTranslatorSize = 1 + ((m.isMulticast())?m.getReceivers().size():1) + 2;
                    // sender address + receiver addresses + optional buffer to avoid reallocation
                int msgHeaderLength = HEADER_LENGTH + 1 + 2 + 8*addressTranslatorSize + 2 + 2*receivers.size();
                    // 32-bit length of whole message without this length + 8-bit type of message +
                    //   16-bit no.addresses in address translator + address translator content (64-bit per each address) +
                    //   16-bit no.recipients + 16-bit localID per each receiver
                boolean ok = false;

                int msgLength = 0;
                con.outputBuffer.clear();
                // clear old address writer
                con.addressWriter.reset();
                while (!ok) {
                    try {
                        con.outputBuffer.position(msgHeaderLength);
                        // encode message
                        m.serialize(con.outputStream, con.addressWriter);
                        msgLength = con.outputBuffer.position() - msgHeaderLength;

                        ok = true;
                    } catch (BufferOverflowException ex) {
                        // small buffer
                        con.outputBuffer = ByteBuffer.allocateDirect(con.outputBuffer.capacity() * 2);
                        con.outputStream = new ByteBufferOutputStream(con.outputBuffer);
                        con.addressWriter.reset();
                    }
                    catch (Exception ex) {
                        MessageTransport.logger.severe("Message encoding error " +  ExceptionPrinter.toStringWithStackTrace(ex));
                        throw new IOException("Error while serializing/encoding message", ex);
                    }
                }

                final LinkedHashMap<Long, Short> translator = con.addressWriter.translator;
                // fill the message header
                // first check if the predicted address translator size doesn't exceed allocated space
                if (translator.size() > addressTranslatorSize) {
                    // we need move message forward in such a case
                    final int correctMsgHeaderLength = msgHeaderLength + 8*(translator.size() - addressTranslatorSize);
                    // ensure capacity of the secondary buffer
                    if (con.secondaryOutputBuffer.capacity() < (correctMsgHeaderLength + msgLength)) {
                        // reallocate buffer
                        con.secondaryOutputBuffer = ByteBuffer.allocateDirect(correctMsgHeaderLength + msgLength + 10);
                        con.secondaryOutputStream = new ByteBufferOutputStream(con.secondaryOutputBuffer);
                    } else {
                        // clear buffer
                        con.secondaryOutputBuffer.clear();
                    }

                    final ByteBuffer newOutputBuffer = con.secondaryOutputBuffer;
                    final ByteBufferOutputStream newOutputStream = con.secondaryOutputStream;

                    // copy message content
                    newOutputBuffer.position(correctMsgHeaderLength);
                    con.outputBuffer.limit(con.outputBuffer.position());
                    con.outputBuffer.position(msgHeaderLength);
                    newOutputBuffer.put(con.outputBuffer);

                    // swap buffers internals and release new one
                    con.secondaryOutputBuffer = con.outputBuffer;
                    con.secondaryOutputStream = con.outputStream;

                    con.outputBuffer = newOutputBuffer;
                    con.outputStream = newOutputStream;

                    // overwrite non-valid length
                    msgHeaderLength = correctMsgHeaderLength;
                }
                // fill message header in
                con.outputBuffer.position(0);
                // msg payload length
                writeInt(msgHeaderLength - HEADER_LENGTH + msgLength, con.outputBuffer);
                // msg type
                con.outputBuffer.put(m.getAsReference() ? MSG_TYPE_AS_REFERENCE : MSG_TYPE_STANDARD);
                // address translator
                int additionalSpace = Math.max(addressTranslatorSize - translator.size(), 0);
                writeShort(translator.size()+additionalSpace, con.outputBuffer);
                for (final Long addressID : translator.keySet()) {
                    writeLong(addressID, con.outputBuffer);
                }
                // fill additional space
                while (additionalSpace > 0) {
                    writeLong(0, con.outputBuffer);
                    additionalSpace--;
                }
                // receivers
                writeShort(receivers.size(), con.outputBuffer);
                for (final Address address : receivers) {
                    Short id = translator.get(address.getAddressId());
                    if (id == null) {
                        final String error = "Message encoding error: cannot find address in translator\n" +  address.toString();
                        MessageTransport.logger.severe(error);
                        throw new IOException(error);
                    }
                    writeShort(id, con.outputBuffer);
                }
                msgSize = msgHeaderLength + msgLength;

                // send buffer
                sendBuffer(con, msgSize);
            } finally {
                con.lockOutput.unlock();
            }
            // close connection if necessary
            if (hwMode) {
                // if MT is running in the HW mode , close connection after each message
                closeConnection(con);
                removeConnection(con);
            }
        }
        catch (NullPointerException ex2) {
            throw new IOException("Closed by foreign host");
        }

        return msgSize;
    }

    private final void sendBuffer(final Connection con, final int toTransmit) throws IOException {
        con.outputBuffer.position(toTransmit);
        con.outputBuffer.flip();
        try {
            // send buffer to the destination
            con.socketChannel.write(con.outputBuffer);
            while (con.outputBuffer.remaining() > 0) {
                if (con.writeSelector != null) {
                    con.writeSelector.select();
                    con.writeSelector.selectedKeys().clear();
                }
                con.socketChannel.write(con.outputBuffer);
            }
        }
        catch (IOException ex1) {
            // connection forcibly closed
            if (hwMode) {
                // remove connection
                closeConnection(con);
                removeConnection(con);
            }
            throw new IOException("Connection to the destination host was forcibly closed", ex1);
        }

    }

    /**
     *
     * <p>Title: A-Globe</p>
     * <p>Description: Internal Message Transport class used for representing connection</p>
     * <p>Copyright: Copyright (c) 2005</p>
     * <p>Company: Gerstner Laboratory</p>
     * @author David Sislak
     * @version $Revision: 1.38 $ $Date: 2010/11/30 09:12:27 $
     */
    private final class Connection {
        /**
         * Socket of the connection
         */
        private final Socket socket;

        /**
         * Socket channel of the connection
         */
        private final SocketChannel socketChannel;

        /**
         * Write selector
         */
        private Selector writeSelector;

        /**
         * Destination represented by the IP:port
         */
        private String destination;

        /**
         * Input buffer for this connection
         */
        private ByteBuffer inputBuffer;

        /**
         * input stream for this connection
         */
        private ByteBufferInputStream inputStream;

        /**
         * output buffer for this connection
         */
        private ByteBuffer outputBuffer;

        /**
         * output stream for this connection
         */
        private ByteBufferOutputStream outputStream;

        private AddressWriteCache addressWriter;
        private ByteBuffer secondaryOutputBuffer;
        private ByteBufferOutputStream secondaryOutputStream;

        /**
         * Lock output
         */
        private final ReentrantLock lockOutput = new ReentrantLock();

        /**
         * if true, headerInputBuffer has valid data
         */
        private boolean hasHeader;

        /**
         * Message length in the encoded format
         */
        private int msgLength;

        /**
         * true, if received through this connection at least one message; otherwise false
         */
        private boolean receivedFirst;

        private final HashMap<Long,ArrayList<AddressWaiter>> waitingForAddress = new HashMap<Long, ArrayList<AddressWaiter>>();
        private final ArrayDeque<IncompleteMsg> incompleteMsgs = new ArrayDeque<IncompleteMsg>();

        private short[] missingAddresses = new short[32];

        private MessageReceiver[] receivers = new MessageReceiver[32];
        private MessageTransportComponent[] destinationMts = new MessageTransportComponent[32];

        private final AddressReadCache addressReadCache = new AddressReadCache();

        /**
         * Initialize Connection instance
         *
         * @param _socket Socket - connection socket
         * @param _socketChannel SocketChannel - connection socketChannel
         * @param _destination String - destination of this connection in the form
         *   IP:port
         * @param isOutgoingInitialized boolean - true iff connection is outgoing
         * initialized
         */
        private Connection(final Socket _socket, final SocketChannel _socketChannel,
                final String _destination) {
            socket = _socket;
            socketChannel = _socketChannel;
            if (!hwMode) {
                try {
                    writeSelector = Selector.open();
                    socketChannel.register(writeSelector, SelectionKey.OP_WRITE);
                }
                catch (IOException ex) {
                    writeSelector = null;
                }
            }
            destination = _destination;
            inputBuffer = ByteBuffer.allocateDirect(MessageTransport.INITAL_MESSAGE_BUFFER_SIZE);
            inputStream = new ByteBufferInputStream(inputBuffer);
            outputBuffer = ByteBuffer.allocateDirect(MessageTransport.INITAL_MESSAGE_BUFFER_SIZE);
            outputStream = new ByteBufferOutputStream(outputBuffer);
            addressWriter = new AddressWriteCache();
            secondaryOutputBuffer = ByteBuffer.allocateDirect(MessageTransport.INITAL_MESSAGE_BUFFER_SIZE);
            secondaryOutputStream = new ByteBufferOutputStream(secondaryOutputBuffer);

            hasHeader = false;
            receivedFirst = false;
        }

        /**
         * Tests if header is complete or needs to be parsed yet
         */
        private final void testHeader() {
            if (hasHeader) {
                return;
            }
            if (inputBuffer.position() < HEADER_LENGTH) {
                return;
            }
            final int p = inputBuffer.position();
            inputBuffer.position(0);
            msgLength = readInt(inputBuffer);
            inputBuffer.position(p);
            hasHeader = true;
            if (msgLength + HEADER_LENGTH > inputBuffer.capacity()) {
                // need reallocating to bigger capacity
                final ByteBuffer newBuffer = ByteBuffer.allocateDirect(msgLength +  HEADER_LENGTH + 1);
                inputBuffer.flip();
                newBuffer.put(inputBuffer);
                inputBuffer = newBuffer;
                inputStream = new ByteBufferInputStream(inputBuffer);
            }
        }

        private final void parseAllAvailable() {
            while (parseOneMessage()) {}
        }

        private final void releaseIncomplete(final IncompleteMsg im) {
            // remove from waiting queue if it is there
            if (im.numberOfMissingAddresses > 0) {
                for (int i=0; i<im.numberOfTranslatorAddresses; i++) {
                    if (im.addressTranslator[i] == null) {
                        Long adrId = im.addressDirectory[i];
                        final ArrayList<AddressWaiter> waiters = waitingForAddress.get(adrId);
                        if (waiters != null) {
                            final Iterator<AddressWaiter> iter = waiters.iterator();
                            while (iter.hasNext()) {
                                final AddressWaiter item = iter.next();
                                if (item.im == im) {
                                    iter.remove();
                                    break;
                                }
                            }
                            if (waiters.size() == 0) {
                                waitingForAddress.remove(adrId);
                                arrayListAddressWaiterPool.addLast(waiters);
                            }
                        }
                    }
                }
            }

            Arrays.fill(im.addressTranslator, null);
            addressArraysPool.addLast(im.addressTranslator);
            im.addressTranslator = null;
            Arrays.fill(im.addressDirectory, 0);
            longArraysPool.addLast(im.addressDirectory);
            im.addressDirectory = null;

            // release itself
            im.release();
        }

        private final void clearQueues() {
            final long curTime = System.currentTimeMillis();

            // clear incomplete queue
            final long msgFrom = curTime - WAIT_FOR_MSG_MILLIS;
            IncompleteMsg im;
            while (((im = incompleteMsgs.peekFirst()) != null) && (im.timestamp < msgFrom)) {
                incompleteMsgs.pollFirst();

                MessageTransport.logger.warning("Addresses not received in specified timeout ("+WAIT_FOR_MSG_MILLIS+" ms), waiting for #addresses: " + im.numberOfMissingAddresses);

                releaseIncomplete(im);
            }
        }

        private final void requestAddresses(final int numberOfMissingAddresses, final short[] missingAddresses, final long[] addressDirectory) throws IOException {
            final int msgSize = HEADER_LENGTH + 1 + 2 + 8*numberOfMissingAddresses;
            // 32-bit message length + 8-bit message type + 16-bit number of missing addresses + 64-bit per each address as adrId

            lockOutput.lock();
            try {
                if (outputBuffer.capacity() < msgSize) {
                    outputBuffer = ByteBuffer.allocateDirect(msgSize + 1);
                    outputStream = new ByteBufferOutputStream(outputBuffer);
                } else {
                    outputBuffer.clear();
                }

                // fill request message

                // msg length
                writeInt(msgSize-HEADER_LENGTH, outputBuffer);
                // msg type
                outputBuffer.put(MSG_TYPE_REQ_ADDRESSES);
                writeShort(numberOfMissingAddresses, outputBuffer);
                for (int i=0; i<numberOfMissingAddresses; i++) {
                    writeLong(addressDirectory[missingAddresses[i]], outputBuffer);
                }

                // send buffer
                sendBuffer(this, msgSize);
            } finally {
                lockOutput.unlock();
            }
        }

        private final void responseForRequestedAddresses() throws IOException {
            final int numberOfRequestedAddresses = readShort(inputBuffer);
            lockOutput.lock();
            try {
                final int initMsgPosition = HEADER_LENGTH + 1 + 2;
                final int inOrigPosition = inputBuffer.position();
                boolean ok = false;

                outputBuffer.clear();

                // encode message
                while (!ok) {
                    try {
                        outputBuffer.position(initMsgPosition);

                        for (int i=0; i<numberOfRequestedAddresses; i++) {
                            final long addressId = readLong(inputBuffer);
                            final Address adr = Address.getAddressDefinitionForTransport(addressId);
                            if (adr == null) {
                                MessageTransport.logger.severe(MessageTransport.localAddress + " : "+destination+" requests address ("+i+" of "+numberOfRequestedAddresses+") Id "+addressId+" which is not present now");
                                writeLong(addressId, outputBuffer);
                                writeString("", outputBuffer);
                            } else {
                                writeLong(addressId, outputBuffer);
                                writeString(adr.toString(), outputBuffer);
                            }
                        }

                        ok = true;
                    } catch (BufferOverflowException ex) {
                        // small buffer
                        outputBuffer = ByteBuffer.allocateDirect(outputBuffer.capacity() * 2);
                        outputStream = new ByteBufferOutputStream(outputBuffer);

                        // reinitialize input position
                        inputBuffer.position(inOrigPosition);
                    } catch (RuntimeException ex) {
                        MessageTransport.logger.severe("Message encoding error:\n" +  ExceptionPrinter.toStringWithStackTrace(ex));
                        throw ex;
                    }
                }

                final int msgSize = outputBuffer.position();

                outputBuffer.position(0);
                // fill message header
                writeInt(msgSize - HEADER_LENGTH, outputBuffer);
                outputBuffer.put(MSG_TYPE_RESP_ADDRESSES);
                writeShort(numberOfRequestedAddresses, outputBuffer);

                // send data
                sendBuffer(this, msgSize);
            } finally {
                lockOutput.unlock();
            }
        }

        private final void processMessage(final ByteBuffer inputBuffer, final ByteBufferInputStream inputStream, final Address[] addressTranslator, final boolean asReference, final boolean debug) throws IOException, ClassNotFoundException {
            final int numberOfRecipients = readShort(inputBuffer);

            // ensure capacity
            if (receivers.length < numberOfRecipients) {
                receivers = new MessageReceiver[numberOfRecipients];
                destinationMts = new MessageTransportComponent[numberOfRecipients];
            }
            int numberOfLocalReceivers = 0;
            for (int j=0; j<numberOfRecipients; j++) {
                final int recId = readShort(inputBuffer);
                Address receiverAddress = addressTranslator[recId];
                if (receiverAddress == null) {
                    throw new IOException("Missing address receiver");
                }
                // try find destination container first
                final MessageTransportComponent destinationMt = MessageTransport.containerMT.get(receiverAddress.getContainerName());
                if (destinationMt != null) {
                    receiverAddress = destinationMt.translateMessageReceiver(receiverAddress);
                    // now try get receiver of the message
                    final MessageReceiver receiver = destinationMt.getMessageReceiver(receiverAddress);
                    if (receiver != null) {
                        receivers[numberOfLocalReceivers] = receiver;
                        destinationMts[numberOfLocalReceivers] = destinationMt;
                        numberOfLocalReceivers++;
                    } else {
                        // unknown receiver of the message
                        if (Platform.SHOW_UNDELIVERED_MESSAGES) {
                            MessageTransport.logger.warning(receiverAddress.getContainerName() +": Receiver not found: " + receiverAddress);
                        }
                    }
                } else {
                    // unknown local container
                    if (Platform.SHOW_UNDELIVERED_MESSAGES) {
                        MessageTransport.logger.warning("Target local container not found: " + receiverAddress);
                    }
                }
            }

            if (numberOfLocalReceivers == 0) {
                // no recipient at all
                return;
            }

            // parse message
            addressReadCache.addressTranslator = addressTranslator;
            Message m = null;

            // decode the message
            final int startp = inputBuffer.position();
            for (int i=0; i<numberOfLocalReceivers; i++) {
                final MessageReceiver receiver = receivers[i];
                final MessageTransportComponent destinationMt = destinationMts[i];
                if ((!asReference) || (m == null)) {
                    // rewind buffer for new reading
                    inputBuffer.position(startp);
                    m = Message.deserialize(inputStream, receiver, addressReadCache);
                    // register me as a holder of the message for a while
                    m.registerHolder();

                    // update connection destination only if it is not running in HW mode and
                    //   first message is received from this connection
                    if (!receivedFirst) {
                        changeConnectionDestination(this,m.getSender().getHost() + ":" + m.getSender().getPort());
                        receivedFirst = true;
                    }
                } else if (asReference) {
                    //register another holder of the incoming message
                    m.registerHolder();
                }
                // handle incoming message to the receiver
                destinationMt.processReceivedMessage(m, receiver);

                if (debug) {
                    System.err.println(m.toString());
                }

                if (!asReference) {
                    // release it
                    m.release();
                }
            }
            if (asReference && (m != null)) {
                // remove my own holder
                m.release();
            }

        }

        private final boolean parseOneMessage() {
            // check if we have a complete header available. Sets hasHeader and msgLength too.
            testHeader();
            if (!hasHeader) {
                return false;
            }
            if (inputBuffer.position() >= HEADER_LENGTH + msgLength) {
                final int oldEnd = inputBuffer.position();
                final int oldLimit = inputBuffer.limit();
                inputBuffer.position(HEADER_LENGTH);
                // set limit
                inputBuffer.limit(HEADER_LENGTH + msgLength);
                try {
                    final byte msgType = inputBuffer.get();
                    switch (msgType) {
                    case MSG_TYPE_AS_REFERENCE:
                    case MSG_TYPE_STANDARD: {
                        final int numberOfTranslatorAddresses = readShort(inputBuffer);
                        long[] addressDirectory = longArraysPool.pollLast();
                        Address[] addressTranslator = addressArraysPool.pollLast();
                        if ((addressDirectory == null) || (addressDirectory.length < numberOfTranslatorAddresses)) {
                            addressDirectory = new long[numberOfTranslatorAddresses];
                            addressTranslator = new Address[numberOfTranslatorAddresses];
                        }
                        if (missingAddresses.length < numberOfTranslatorAddresses) {
                            missingAddresses = new short[numberOfTranslatorAddresses];
                        }
                        // read and check existence of addresses
                        IncompleteMsg im = null;
                        int numberOfMissingAddresses = 0;
                        int k = 0;
                        for (int j=0; j<numberOfTranslatorAddresses; j++) {
                            final Long adrId = readLong(inputBuffer);
                            if (adrId == 0) {
                                continue;
                            }
                            addressDirectory[j] = adrId;
                            final Address adr = Address.getAddress(adrId);
                            if (adr != null) {
                                addressTranslator[j] = adr;
                            } else {
                                // remove expired
                                clearQueues();
                                // create incomplete msg
                                if (im == null) {
                                    final int oldPos = inputBuffer.position();
                                    inputBuffer.position(HEADER_LENGTH + 1 + 2 + numberOfTranslatorAddresses*8);
                                    final int toParse = inputBuffer.remaining();
                                    im = IncompleteMsg.getIncompleteMsg(toParse);
                                    im.addressDirectory = addressDirectory;
                                    im.addressTranslator = addressTranslator;
                                    im.msgType = msgType;
                                    im.timestamp = System.currentTimeMillis();
                                    im.numberOfTranslatorAddresses = numberOfTranslatorAddresses;

                                    // copy the rest of the message
                                    inputBuffer.get(im.msgBuffer.array(), 0, toParse);
                                    im.msgBuffer.position(0);
                                    im.msgBuffer.limit(toParse);

                                    // remember incomplete message
                                    incompleteMsgs.add(im);

                                    inputBuffer.position(oldPos);
                                }
                                // register for later processing
                                ArrayList<AddressWaiter> missingQueue = waitingForAddress.get(adrId);
                                if (missingQueue == null) {
                                    missingQueue = arrayListAddressWaiterPool.pollLast();
                                    if (missingQueue == null) {
                                        missingQueue = new ArrayList<AddressWaiter>();
                                    }
                                    waitingForAddress.put(adrId, missingQueue);

                                    // register for request
                                    missingAddresses[k] = (short)j;
                                    k++;
                                }
                                // register for later processing
                                missingQueue.add(AddressWaiter.getAddressWaiter(im, (short)j));
                                numberOfMissingAddresses++;
                            }
                        }
                        if (numberOfMissingAddresses != 0) {
                            im.numberOfMissingAddresses = numberOfMissingAddresses;
                            if (k != 0) {
                                // send request for missing addresses
                                requestAddresses(k, missingAddresses, addressDirectory);
                            }
                        } else {
                            // all addresses are known process the message
                            processMessage(inputBuffer, inputStream, addressTranslator, msgType == MSG_TYPE_AS_REFERENCE, false);

                            // release temporary fields
                            Arrays.fill(addressDirectory, 0);
                            longArraysPool.addLast(addressDirectory);
                            Arrays.fill(addressTranslator, null);
                            addressArraysPool.addLast(addressTranslator);
                        }
                        break;
                    }

                    case MSG_TYPE_REQ_ADDRESSES: {
                        // response for requested addresses
                        responseForRequestedAddresses();

                        break;
                    }

                    case MSG_TYPE_RESP_ADDRESSES: {
                        final int numberOfAddresses = readShort(inputBuffer);

                        // restore received addresses
                        for (int i=0; i<numberOfAddresses; i++) {
                            final Long adrId = readLong(inputBuffer);
                            final String adrStr = readString(inputBuffer);

                            final ArrayList<AddressWaiter> waiters = waitingForAddress.remove(adrId);
                            if (waiters != null) {
                                // have requesters
                                if (adrStr.length() == 0) {
                                    // debug address which is missing
                                    final StringBuilder sb = new StringBuilder(MessageTransport.localAddress+" : Missing address Id "+adrId+", waiters: "+waiters.size());
                                    for (AddressWaiter addressWaiter : waiters) {
                                        final IncompleteMsg related = addressWaiter.im;
                                        sb.append("\n missingId: "+addressWaiter.missingId+" addressTranslator size: "+related.numberOfTranslatorAddresses+" numberOfMissingAddresses: "+related.numberOfMissingAddresses+" ");
                                        sb.append("\n  current address translator:");
                                        for (int j=0; j < related.numberOfTranslatorAddresses; j++) {
                                            final long tAdrId = related.addressDirectory[j];
                                            if (tAdrId == 0) {
                                                continue;
                                            }
                                            sb.append("\n   [").append(j).append("]: ").append(tAdrId).append(" -> ");
                                            final Address adr = related.addressTranslator[j];
                                            if (adr != null) {
                                                sb.append(adr.toString());
                                            } else {
                                                sb.append("MISSING");
                                            }
                                        }
                                    }
                                    MessageTransport.logger.severe(sb.toString());
                                } else {

                                    final Address adr = Address.ensureSpecificAddress(adrId, adrStr);
                                    final boolean printMsg;
                                    if (DEBUG) {
                                        Integer cnt = debugAddressCounter.remove(adrId);
                                        if (cnt == null) {
                                            cnt = 1;
                                        } else {
                                            cnt = cnt + 1;
                                        }
                                        debugAddressCounter.put(adrId, cnt);
                                        if (cnt > 1) {
                                            System.err.println(adrId + " - "+adr.toString()+" - "+cnt+" times received");
                                            printMsg = true;
                                        } else {
                                            printMsg = false;
                                        }
                                    } else {
                                        printMsg = false;
                                    }

                                    for (final AddressWaiter addressWaiter : waiters) {
                                        final IncompleteMsg related = addressWaiter.im;
                                        related.addressTranslator[addressWaiter.missingId] = adr;
                                        related.numberOfMissingAddresses--;
                                        addressWaiter.release();

                                        if (related.numberOfMissingAddresses == 0) {
                                            // done, have all addresses parse the message
                                            processMessage(related.msgBuffer, related.bufInputStream, related.addressTranslator, related.msgType == MSG_TYPE_AS_REFERENCE, printMsg);

                                            // release incomplete
                                            releaseIncomplete(related);
                                            // not very effective, but happens only occasionally
                                            incompleteMsgs.remove(related);
                                        }
                                    }
                                }

                                // finally put array list to pool
                                waiters.clear();
                                arrayListAddressWaiterPool.addLast(waiters);
                            }
                        }

                        // prune queues
                        clearQueues();

                        break;
                    }

                    default:
                        MessageTransport.logger.warning("Unknown message type: "+msgType);
                    }
                }
                catch (IOException ex) {
                    MessageTransport.logger.severe("Error deserializing from socket (remote side: " +
                          socket.getInetAddress().getCanonicalHostName() + ")" + ExceptionPrinter.toStringWithStackTrace(ex));
                }
                catch (ClassNotFoundException ex) {
                    MessageTransport.logger.severe("Error deserializing from socket (remote side: " +
                          socket.getInetAddress().getCanonicalHostName() + ")" + ExceptionPrinter.toStringWithStackTrace(ex));
                }
                // restore limits
                inputBuffer.limit(oldLimit);
                inputBuffer.position(oldEnd);
                inputBuffer.flip();
                inputBuffer.position(HEADER_LENGTH + msgLength);
                inputBuffer.compact();
                hasHeader = false;
                msgLength = -1;
                return true;
            }

            // not enough data
            return false;
        }
    }

    private static final class AddressWriteCache implements AddressWriter {
        private short nextId = 0;
        final LinkedHashMap<Long, Short> translator = new LinkedHashMap<Long, Short>();

        /* @internal
         * (non-Javadoc)
         * @see aglobe.platform.transport.AddressWriter#writeAddress(aglobe.container.transport.Address)
         */
        @Override
        public short writeAddress(final Address address) {
            final Long addressId = address.getAddressId();
            Short cand;
            if ((cand = translator.get(addressId)) != null) {
                return cand;
            }
            translator.put(addressId, nextId);
            address.keepAfterSent();
            return nextId++;
        }

        void reset() {
            translator.clear();
            nextId = 0;
        }
    }

    private static final class AddressReadCache implements AddressReader {
        Address[] addressTranslator;

        /* (non-Javadoc)
         * @see aglobe.platform.transport.AddressReader#readAddress(short)
         */
        @Override
        public Address readAddress(final short addressHandler) {
            return addressTranslator[addressHandler];
        }

    }

    private static final class IncompleteMsg {
        private static final ArrayDeque<SoftReference<IncompleteMsg>> pool = new ArrayDeque<SoftReference<IncompleteMsg>>();

        long timestamp;
        ByteBuffer msgBuffer;
        ByteBufferInputStream bufInputStream;

        byte msgType = -1;
        int numberOfMissingAddresses = -1;
        int numberOfTranslatorAddresses = -1;

        long[] addressDirectory = null;
        Address[] addressTranslator = null;

        private IncompleteMsg() {

        }

        private static final IncompleteMsg getIncompleteMsg(final int size) {
            for (;;) {
                final SoftReference<IncompleteMsg> sr = pool.pollLast();
                if (sr == null) {
                    final IncompleteMsg retVal = new IncompleteMsg();
                    retVal.msgBuffer = ByteBuffer.allocate(size);
                    retVal.bufInputStream = new ByteBufferInputStream(retVal.msgBuffer);
                    return retVal;
                } else {
                    final IncompleteMsg retVal = sr.get();
                    if (retVal == null) {
                        continue;
                    }
                    if (retVal.msgBuffer.capacity() < size) {
                        retVal.msgBuffer = ByteBuffer.allocate(size);
                        retVal.bufInputStream = new ByteBufferInputStream(retVal.msgBuffer);
                    }
                    return retVal;
                }
            }
        }

        private final void release() {
            msgType = -1;
            numberOfMissingAddresses = -1;
            numberOfTranslatorAddresses = -1;

            pool.addLast(new SoftReference<IncompleteMsg>(this));
        }
    }

    private static final class AddressWaiter {
        private static final ArrayDeque<SoftReference<AddressWaiter>> pool = new ArrayDeque<SoftReference<AddressWaiter>>(1024);

        IncompleteMsg im;
        short missingId;

        private AddressWaiter() {

        }

        final static AddressWaiter getAddressWaiter(final IncompleteMsg im, final short missingId) {
            for (;;) {
                final SoftReference<AddressWaiter> sr = pool.pollLast();
                AddressWaiter retVal;
                if (sr == null) {
                    retVal = new AddressWaiter();
                } else {
                    retVal = sr.get();
                    if (retVal == null) {
                        continue;
                    }
                }
                retVal.im = im;
                retVal.missingId = missingId;
                return retVal;
            }
        }

        final void release() {
            this.im = null;
            pool.addLast(new SoftReference<AddressWaiter>(this));
        }
    }
}
