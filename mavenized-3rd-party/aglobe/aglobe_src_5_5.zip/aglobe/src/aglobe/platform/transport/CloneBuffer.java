package aglobe.platform.transport;

import aglobe.container.library.LibraryObjectInputStream;
import aglobe.container.transport.Address;
import aglobe.platform.Platform;
import aglobe.util.concurrent.NonblockingPoolArrayFIFO;

import java.io.IOException;
import java.io.OutputStream;
import java.io.InputStream;
import java.lang.management.ManagementFactory;
import java.lang.ref.SoftReference;
import java.util.ArrayList;
import java.util.LinkedHashMap;

/**
 *
 * <p>Title: A-Globe</p>
 * <p>Description: Internal class used for message cloning for local platform transmission.</p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.13 $ $Date: 2010/10/18 12:25:43 $
 */
public final class CloneBuffer {
    private static final NonblockingPoolArrayFIFO<SoftReference<CloneBuffer>> pool = new NonblockingPoolArrayFIFO<SoftReference<CloneBuffer>>(ManagementFactory.getOperatingSystemMXBean().getAvailableProcessors() * 10);

    /**
     * Initial clone buffer size. If limit is reached, buffer is enlarged to size old size + INIT_SIZE
     */
    private final static int INIT_SIZE = 10240;

    /**
     * Buffer content
     */
    private byte[] buf;

    /**
     * Current buffer size
     */
    private int bufSize;

    /**
     * Remaining space in the buffer
     */
    private int remaining;

    /**
     * Input position
     */
    private int in;

    /**
     * Output position
     */
    private int out;


    private final AddressCache addressCache;

    /**
     * Clone buffer ObjectOutputStream
     */
    public final MessageObjectOutputStream outputStream;

    /**
     * Clone buffer ObjectInputStream
     */
    public final LibraryObjectInputStream inputStream;

    public final static CloneBuffer getCloneBuffer() throws IOException {
        for (;;) {
            final SoftReference<CloneBuffer> cand = pool.pop();
            if (cand == null) {
                return new CloneBuffer();
            }
            final CloneBuffer cb = cand.get();
            if (cb != null) {
                return cb;
            }
        }
    }

    public final void release() {
        clear();
        pool.push(new SoftReference<CloneBuffer>(this));
    }


    /**
     * Initialization of the buffer
     * @throws IOException
     */
    private CloneBuffer() throws IOException {
        // create new buffer with initi_size
        buf = new byte[INIT_SIZE];
        bufSize = INIT_SIZE;
        init();

        addressCache = new AddressCache();
        outputStream = new MessageObjectOutputStream(new MyOutputStream(), addressCache);
        inputStream = new LibraryObjectInputStream(new MyInputStream(), Platform.class.getClassLoader(), addressCache);
    }

    /**
     * Clear buffer array.
     */
    private void init() {
        remaining = bufSize;
        in = 0;
        out = 0;
    }

    /**
     * Returns current amount of data which is in the buffer
     * @return int
     */
    public final int getDataSize() {
        return in + addressCache.getDataSize();
    }
    
    /**
     * Copy current buffer content to the Output Stream
     * @param dst OutputStream
     * @throws IOException
     */
    public final void copyBufferWithStreamHeader(final OutputStream dst) throws IOException {
        dst.write(buf, 0, in);
    }

    /**
     * Rewind input part of the buffer back to the begining for new clonning
     */
    public final void rewind() {
        out = 4;
    }

    /**
     * Clear buffer array and all shared objects caches in the streams, leave stream header for copying it outside
     */
    public final void clear() {
        remaining = bufSize - 4;
        in = 4;
        out = 4;
        addressCache.reset();
        try {
            outputStream.reset();
        }
        catch (IOException ex) {
            MessageTransport.logger.severe("Cannot reset output stream !!!");
        }
    }

    /**
     * Clear buffer array, but without reseting object output stream
     */
    public final void reset() {
        remaining = bufSize - 4;
        in = 4;
        out = 4;
    }

    /**
     * Increase buffer size. New buffer size will be old buffer size * 2
     */
    private void makeBufferLarger() {
        byte[] newBuf = new byte[bufSize * 2];
        System.arraycopy(buf, 0, newBuf, 0, buf.length);
        buf = newBuf;
        remaining += bufSize;
        bufSize *= 2;
    }

    /**
     * Get clone buffer output stream
     *
     * @return OutputStream
     * @throws IOException
     */
    public final MessageObjectOutputStream getOutputStream() throws IOException {
        return outputStream;
    }

    /**
     * Get clone buffer input stream
     *
     * @return InputStream
     * @throws IOException
     */
    public final LibraryObjectInputStream getInputStream() throws IOException {
        return inputStream;
    }

    /**
     *
     * <p>Title: A-Globe</p>
     * <p>Description: Input stream implementation for clone buffer</p>
     * <p>Copyright: Copyright (c) 2005</p>
     * <p>Company: Gerstner Laboratory</p>
     * @author David Sislak
     * @version $Revision: 1.13 $ $Date: 2010/10/18 12:25:43 $
     */
    private final class MyInputStream extends InputStream {
        /**
         * Constructor.
         */
        public MyInputStream() {
        }

        /**
         * Returns available data in the buffer
         * @return int
         */
        @Override
        public final int available() {
            return in - out;
        }

        /**
         * Not supported
         * @param n long
         * @throws IOException
         * @return long
         */
        @Override
        public final long skip(final long n) throws IOException {
            throw new IOException("Not supported");
        }

        /**
         * Read one byte from the buffer.
         * @return int - return -1 when buffer is empty
         */
        @Override
        public final int read() {
            if (out == in) {
                return -1;
            }
            return buf[out++];
        }

        /**
         * Read array of bytes from the buffer
         * @param b byte[]
         * @return int - read bytes. Return -1 if no values is read
         */
        @Override
        public final int read(final byte[] b) {
            return read(b, 0, b.length);
        }

        /**
         * Read max length of bytes and store data in the array b from the position off
         * @param b byte[]
         * @param off int
         * @param len int
         * @return int - number of the read bytes
         */
        @Override
        public final int read(final byte[] b, final int off, final int len) {
            if (out == in) {
                return -1;
            }
            int read = Math.min(in - out, len);
            System.arraycopy(buf, out, b, off, read);
            out += read;
            return read;
        }

        /**
         * Test if mark operation is supported
         * @return boolean
         */
        @Override
        public final boolean markSupported() {
            return false;
        }

        /**
         * Not supported
         * @param readlimit int
         */
        @Override
        public final void mark(final int readlimit) {
        }

        /**
         * Not supported
         * @throws IOException
         */
        @Override
        public final void reset() throws IOException {
            throw new IOException("Not supported");
        }

        /**
         * Close the stream
         */
        @Override
        public final void close() {
        }
    }


    /**
     *
     * <p>Title: A-Globe</p>
     * <p>Description: Output stream implementation for clone buffer</p>
     * <p>Copyright: Copyright (c) 2005</p>
     * <p>Company: Gerstner Laboratory</p>
     * @author David Sislak
     * @version $Revision: 1.13 $ $Date: 2010/10/18 12:25:43 $
     */
    private final class MyOutputStream extends OutputStream {
        /**
         * Constructor
         */
        public MyOutputStream() {

        }

        /**
         * Write byte b to the buffer
         * @param b int
         */
        @Override
        public final void write(final int b) {
            if (remaining == 0) {
                makeBufferLarger();
            }
            buf[in++] = (byte) b;
            remaining--;
        }

        /**
         * Write array of bytes to the buffer
         * @param b byte[]
         */
        @Override
        public final void write(final byte[] b) {
            write(b, 0, b.length);
        }

        /**
         * Write length bytes from position off to the buffer
         * @param b byte[]
         * @param off int
         * @param len int
         */
        @Override
        public final void write(final byte[] b, final int off, final int len) {
            if (remaining < len) {
                makeBufferLarger();
            }
            System.arraycopy(b, off, buf, in, len);
            in += len;
            remaining -= len;
        }

        /**
         * Flush output stream
         */
        @Override
        public final void flush() {
        }

        /**
         * Close output stream
         */
        @Override
        public final void close() {

        }
    }


    private final static class AddressCache implements AddressWriter, AddressReader {
        private short nextId = 0;
        private LinkedHashMap<Address, Short> addressCache = new LinkedHashMap<Address, Short>();
        private ArrayList<Address> readingStruct = new ArrayList<Address>();

        /* (non-Javadoc)
         * @see aglobe.platform.transport.AddressWriter#writeAddress(aglobe.container.transport.Address)
         */
        @Override
        public final short writeAddress(final Address address) {
            Short cand;
            if ((cand = addressCache.get(address)) != null) {
                return cand;
            }
            addressCache.put(address, nextId);
            return nextId++;
        }

        /* (non-Javadoc)
         * @see aglobe.platform.transport.AddressReader#readAddress(short)
         */
        @Override
        public final Address readAddress(final short addressHandler) {
            if (readingStruct.size() == 0) {
                readingStruct.addAll(addressCache.keySet());
            }
            return readingStruct.get(addressHandler);
        }

        private final void reset() {
            addressCache.clear();
            readingStruct.clear();
            nextId = 0;
        }

        private final int getDataSize() {
            return 2 /* number*/ + 8*addressCache.size() /* Each address is represented as a long*/;
        }
    }
}
