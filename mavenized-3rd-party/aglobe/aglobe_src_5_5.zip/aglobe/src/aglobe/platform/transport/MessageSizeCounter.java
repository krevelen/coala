/**
 *
 */
package aglobe.platform.transport;

import java.io.IOException;
import java.io.OutputStream;
import java.util.HashSet;

import aglobe.container.transport.Address;
import aglobe.ontology.Message;
import aglobe.util.concurrent.NonblockingPoolArrayFIFO;

/**
 * @internal
 * <p>Title: MessageSizeCounter</p>
 *
 * <p>Description: This class is used for counting the serialized message length</p>
 *
 * <p>Copyright: Copyright (c) 2009</p>
 *
 * <p>Company: Agent Technology Center</p>
 *
 * @author David Sislak
 * @version $Revision: 1.2 $ $Date: 2009/06/26 11:34:22 $
 *
 */
final class MessageSizeCounter {

    private static final NonblockingPoolArrayFIFO<NullAddressWriter> pool = new NonblockingPoolArrayFIFO<NullAddressWriter>(32);

    /**
     * Cannot be created
     */
    private MessageSizeCounter() {

    }

    /**
     * @internal
     * The method is used for counting serialized message length
     * @param m
     * @return
     */
    static final int getMessageSerializedLength(final Message m) {
        final NullOutputStream nos = new NullOutputStream();
        NullAddressWriter naw = pool.pop();
        if (naw == null) {
            naw = new NullAddressWriter();
        }
        try {
            m.serialize(nos, naw);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        // two bytes are given by the number of addresses, each address is stored as 8-byte length long
        //   and then there the message size itself
        final int size = 2 + 8*naw.knownAddresses.size() + nos.size;
        naw.knownAddresses.clear();
        pool.push(naw);
        return size;
    }

    private static final class NullOutputStream extends OutputStream {
        private int size = 0;

        /* (non-Javadoc)
         * @see java.io.OutputStream#write(int)
         */
        @Override
        public void write(int b) throws IOException {
            size++;
        }

        /* (non-Javadoc)
         * @see java.io.OutputStream#write(byte[], int, int)
         */
        @Override
        public void write(byte[] b, int off, int len) throws IOException {
            size += len;
        }

        /* (non-Javadoc)
         * @see java.io.OutputStream#write(byte[])
         */
        @Override
        public void write(byte[] b) throws IOException {
            size += b.length;
        }
    }

    private static final class NullAddressWriter implements AddressWriter {
        private HashSet<Long> knownAddresses = new HashSet<Long>();

        /* (non-Javadoc)
         * @see aglobe.platform.transport.AddressWriter#writeAddress(aglobe.container.transport.Address)
         */
        @Override
        public short writeAddress(Address address) {
            knownAddresses.add(address.getAddressId());

            return 0;
        }

    }
}
