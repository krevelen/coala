package aglobe.platform.transport;

import java.lang.ref.SoftReference;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.DatagramChannel;

import java.net.DatagramPacket;
import aglobe.container.transport.Address;
import aglobe.platform.Platform;
import aglobe.platform.thread.AglobeThreadPool;
import aglobe.util.concurrent.NonblockingPoolArrayFIFO;

import java.net.InetSocketAddress;
import java.util.HashSet;
import java.util.concurrent.ArrayBlockingQueue;

/**
 * <p>Title: A-Globe</p>
 *
 * <p>Description: Internal class used for low-level I/O MessageTransport operations for
 * multicast messages</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.27 $ $Date: 2010/10/13 12:29:49 $
 */
final class MulticastTransportLayerImpl extends DatagramMessageTransportLayerImpl {
    /**
     * UDP/IP receiving buffer size, 20 000kB
     */
    private static final int UDP_SOCKET_BUFFER_SIZE = 2048000;
    
    /**
     * Multicast group address
     */
    private final InetAddress multicastGroup;

    private final InetSocketAddress multicastSocket;

    /**
     * Multicast socket
     */
    private MulticastSocket multicastReceivingSocket;

    /**
     * Socket used for outgoing connection
     */
    private DatagramChannel outgoingChannel;
    
    private DatagramSocket outgoingSocket;

    /**
     * Outgoing Internet addresses
     */
    private HashSet<InetSocketAddress> outgoingInetAddresses;

    /**
     * Outgoing port
     */
    private int outgoingPort;

    private ArrayBlockingQueue<Packet> queue;

    private volatile boolean finished = false;

    private int currentOutgoingBufferSize;
    
    /**
     * Constructor
     *
     * @param multicastGroup InetAddress
     * @param multicastPort int
     * @param mtu int - MTU size, used for message fragments
     * @throws IOException - thrown when an error occurred
     */
    MulticastTransportLayerImpl(final InetAddress multicastGroup, final int multicastPort, final int mtu) throws IOException {
        super(multicastGroup, multicastPort, false, mtu);

        this.multicastGroup = multicastGroup;
        this.multicastSocket = new InetSocketAddress(multicastGroup, multicastPort);

        // log started multicast layer
        MessageTransport.logger.info("Multicast messages will be operated on "+multicastGroup.getHostAddress()+":"+multicastPort+" with MTU="+mtu);
    }

    @Override
    protected final void prepareSockets(final InetAddress address, final int _port) throws IOException {
        queue = new ArrayBlockingQueue<Packet>(128);

        // create multicast socket
        multicastReceivingSocket = new MulticastSocket(_port);
        // disable loopback mode
        multicastReceivingSocket.setLoopbackMode(false); // we need receive local information
        multicastReceivingSocket.setTimeToLive(200);
        multicastReceivingSocket.setTrafficClass(0x18);
        multicastReceivingSocket.setSendBufferSize(1024); // this socket is not used for sending
        multicastReceivingSocket.setReceiveBufferSize(UDP_SOCKET_BUFFER_SIZE);
        if (multicastReceivingSocket.getReceiveBufferSize() != UDP_SOCKET_BUFFER_SIZE) {
            MessageTransport.logger.warning("Cannot set datagram socket receive buffer size ! Will use only current buffer size "+multicastReceivingSocket.getReceiveBufferSize()+" Bytes which will have negative impact to communication performance. System administrator can allow setting large socket buffers.");
        }
        // join multicast group
        multicastReceivingSocket.joinGroup(address);

        // create outgoing channel
        outgoingChannel = DatagramChannel.open();
        outgoingChannel.configureBlocking(true);
        outgoingSocket = outgoingChannel.socket();
        outgoingSocket.setBroadcast(false);
        outgoingSocket.setTrafficClass(0x18);
        outgoingSocket.setReuseAddress(false);
        ensureSendBufferSize(10000);
        outgoingSocket.setReceiveBufferSize(UDP_SOCKET_BUFFER_SIZE); 
        if (outgoingSocket.getReceiveBufferSize() != UDP_SOCKET_BUFFER_SIZE) {
            MessageTransport.logger.warning("Cannot set datagram socket receive buffer size ! Will use only current buffer size "+outgoingSocket.getReceiveBufferSize()+" Bytes which will have negative impact to communication performance. System administrator can allow setting large socket buffers.");
        }
        outgoingSocket.bind(null); // bind to empheral local port
        outgoingPort = outgoingSocket.getLocalPort();

        // register all local outgoing addresses
        outgoingInetAddresses = new HashSet<InetSocketAddress>();
        InetAddress[] allMyIps = InetAddress.getAllByName(InetAddress.getLocalHost().getCanonicalHostName());
        if (allMyIps != null) {
            for (InetAddress inetAddress : allMyIps) {
                outgoingInetAddresses.add(new InetSocketAddress(inetAddress, outgoingPort));
            }
        }

        final Thread multicastReceivingThread = AglobeThreadPool.getThread(Platform.getPlatformThreadGroup(), new Runnable() {

            @Override
            public void run() {
                while (!finished) {
                    try {
                        final Packet packet = Packet.getPacket();
                        for (;;) {
                            final DatagramPacket incomingPacket = new DatagramPacket(packet.array, packet.array.length);
                            // read next packet
                            multicastReceivingSocket.receive(incomingPacket);

                            packet.length = incomingPacket.getLength();
                            packet.senderAddress = (InetSocketAddress) incomingPacket.getSocketAddress();
                            if (!outgoingInetAddresses.contains(packet.senderAddress)) {
                                // not my packet, parse it
                                break;
                            }
                            // otherwise skip that packet
                        }
                        // insert for parsing
                        queue.put(packet);
                    } catch (Throwable e) {
                    }
                }
            }

        }, "Multicast Message transport: Multicast socket receiving Thread");
        multicastReceivingThread.setPriority(Math.min(Thread.NORM_PRIORITY + 3, Thread.MAX_PRIORITY));
        multicastReceivingThread.start();

        final Thread addressReplierThread = AglobeThreadPool.getThread(Platform.getPlatformThreadGroup(), new Runnable() {

            @Override
            public void run() {
                while (!finished) {
                    try {
                        final Packet packet = Packet.getPacket();
                        final ByteBuffer inputBuffer = ByteBuffer.wrap(packet.array);
                        packet.senderAddress = (InetSocketAddress) outgoingChannel.receive(inputBuffer);
                        packet.length = inputBuffer.position();

                        // insert for parsing
                        queue.put(packet);
                    } catch (Throwable e) {
                    }
                }
            }

        }, "Multicast Message transport: Address replier receiving Thread");
        addressReplierThread.setPriority(Math.min(Thread.NORM_PRIORITY + 4, Thread.MAX_PRIORITY));
        addressReplierThread.start();

    }
    
    

    /* (non-Javadoc)
     * @see aglobe.platform.transport.DatagramMessageTransportLayerImpl#ensureSendBufferSize(int)
     */
    @Override
    protected void ensureSendBufferSize(int packets) throws SocketException {
        if (packets < currentOutgoingBufferSize) {
            return;
        }
        
        currentOutgoingBufferSize = packets;
        final int udpSocketBufferSize = mtu * currentOutgoingBufferSize;
        outgoingSocket.setSendBufferSize(udpSocketBufferSize);
        if (outgoingSocket.getSendBufferSize() != udpSocketBufferSize) {
            MessageTransport.logger.warning("Cannot set datagram socket sent buffer size ! Will use only current buffer size "+outgoingSocket.getSendBufferSize()+" Bytes which will have negative impact to communication performance. System administrator can allow setting large socket buffers.");
        }
    }

    /* (non-Javadoc)
     * @see aglobe.platform.transport.DatagramMessageTranpsortLayerImpl#closeSockets()
     */
    @Override
    protected final void closeSockets() {
        try {
            finished = true;

            // leave from multicast group first
            multicastReceivingSocket.leaveGroup(multicastGroup);
            multicastReceivingSocket.close();
            outgoingChannel.close();

            // insert dummy packet to unblock waiting thread,
            //  if the queue is full it is not necessary to insert new packet
            queue.offer(Packet.getPacket());
        }
        catch (IOException ex1) {
        }
    }

    /* (non-Javadoc)
     * @see aglobe.platform.transport.MessageTransportLayerImpl#getLocalAddress()
     */
    @Override
    final InetSocketAddress getLocalAddress() throws UnknownHostException {
        throw new RuntimeException("Not supported operation");
    }

    /* (non-Javadoc)
     * @see aglobe.platform.transport.DatagramMessageTranpsortLayerImpl#sendBuffer(java.net.InetSocketAddress, java.nio.ByteBuffer)
     */
    @Override
    protected final void sendBuffer(final InetSocketAddress sentTo, final ByteBuffer outputBuffer) throws IOException {
        final InetSocketAddress dest = (sentTo == null) ? multicastSocket : sentTo;
        outgoingChannel.send(outputBuffer, dest);
        while (outputBuffer.remaining() > 0) {
            Thread.yield();
            outgoingChannel.send(outputBuffer, dest);
        }
    }

    /* (non-Javadoc)
     * @see aglobe.platform.transport.DatagramMessageTranpsortLayerImpl#getDestinationInetSocketAddress(aglobe.container.transport.Address)
     */
    @Override
    protected final InetSocketAddress getDestinationInetSocketAddress(final Address targetPlatformAddress) {
        return null;
    }

    /* (non-Javadoc)
     * @see aglobe.platform.transport.DatagramMessageTranpsortLayerImpl#readToBuffer(java.nio.ByteBuffer)
     */
    @Override
    protected final InetSocketAddress readToBuffer(final ReadingBuffers inputBuffers) throws IOException {
        Packet packet;
        try {
            packet = queue.take();
        } catch (InterruptedException e) {
            throw new IOException("Closed");
        }
        if (finished) {
            throw new IOException("Closed");
        }

        final byte[] oldBuf = inputBuffers.readInputBuffer.array();
        inputBuffers.readInputBuffer = ByteBuffer.wrap(packet.array, packet.length, 0);
        inputBuffers.readInputStream = new ByteBufferInputStream(inputBuffers.readInputBuffer);
        final InetSocketAddress isa = packet.senderAddress;

        packet.array = oldBuf;
        packet.release();

        return isa;
    }

    private static class Packet {
        private final static NonblockingPoolArrayFIFO<SoftReference<Packet>> pool = new NonblockingPoolArrayFIFO<SoftReference<Packet>>(1024);

        private byte[] array;
        private int length;
        private InetSocketAddress senderAddress;

        private static Packet getPacket() {
            for (;;) {
                final SoftReference<Packet> sr = pool.pop();
                if (sr == null) {
                    final Packet packet = new Packet();
                    packet.array = new byte[65536];
                    return packet;
                }
                final Packet packet = sr.get();
                if (packet != null) {
                    return packet;
                }
            }
        }

        private void release() {
            this.senderAddress = null;
            pool.push(new SoftReference<Packet>(this));
        }
    }
}
