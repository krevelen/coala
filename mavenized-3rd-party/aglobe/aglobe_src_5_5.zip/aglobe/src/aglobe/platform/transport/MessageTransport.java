package aglobe.platform.transport;

import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

import aglobe.container.transport.Address;
import aglobe.container.transport.InvisibleContainerException;
import aglobe.ontology.Message;
import aglobe.platform.MessageTransportComponent;
import aglobe.platform.Platform;
import aglobe.util.ExceptionPrinter;
import aglobe.util.concurrent.NonblockingPoolArrayFIFO;

/**
 * <p>Title: </p>
 * <p>Description: Internal A-Globe class. Message transport layer of A-globe platform</p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.43 $ $Date: 2010/12/03 12:29:26 $
 */

public final class MessageTransport {
    /**
     * Name for the logger used by the MessageTransport layer
     */
    private static final String LOGGER = "platform.MessageTransport";

    /**
     * Initial message buffer size
     */
    public static final int INITAL_MESSAGE_BUFFER_SIZE = 65536;

    /**
     * Default MTU size for the UDP transport layer
     */
    public static final int DEFAULT_MTU = 1500;

    /**
     * Logger for the MessageTransport layer
     */
    static final Logger logger = Logger.getLogger(LOGGER);

    /**
     * Reference to the low level message transport layer which performs
     * sending and receiving operations with standard messages among different A-globe platforms
     */
    private static MessageTransportLayerImpl standardMessageTransportLayerImpl = null;

    /**
     * Reference to the low level message transport layer which performs
     * sending and receiving operations with multicast messages among different A-globe platforms
     */
    private static MulticastTransportLayerImpl multicastMessageTransportLayerImpl = null;

    /**
     * @internal
     * IP address where this MessageTransport listens for incoming messages
     * from outside of the Platform
     */
    public static InetSocketAddress localAddress;

    /**
     * @internal
     * Local host name for this MessageTransport
     */
    public static String localHostAddress;

    /**
     * @internal
     * Local port where this MessageTransport listens for incoming messages
     * from outside of the Platform
     */
    public static int localPort;

    /**
     * true iff platform was successfully initialized
     */
    private static boolean initialized = false;

    /**
     * Registered container MTs
     */
    static final Map<String, MessageTransportComponent> containerMT = new ConcurrentHashMap<String, MessageTransportComponent> ();

    private final static NonblockingPoolArrayFIFO<LinkedHashSet<Address>> poolOfLinkedHashSets = new NonblockingPoolArrayFIFO<LinkedHashSet<Address>>(ManagementFactory.getOperatingSystemMXBean().getAvailableProcessors() * 10);

    private final static NonblockingPoolArrayFIFO<LinkedHashMap<Address, LinkedHashSet<Address>>> poolOfMulticastReceiversPerPlatform = new NonblockingPoolArrayFIFO<LinkedHashMap<Address,LinkedHashSet<Address>>>(ManagementFactory.getOperatingSystemMXBean().getAvailableProcessors() * 3);

    /**
     * Holds size of the reference in the current system architecture
     */
    private static final int REFERENCE_SIZE = ("amd64".equals(ManagementFactory.getOperatingSystemMXBean().getArch())) ? 8 : 4;

    /**
     * Iff true the messages sent as reference should report standard size same as they are send normally
     */
    private static boolean useSimulatedMessageSize;

    private final static NonblockingPoolArrayFIFO<ArrayList<Address>> outgoingReceiversPool = new NonblockingPoolArrayFIFO<ArrayList<Address>>(ManagementFactory.getOperatingSystemMXBean().getAvailableProcessors()*5);

    /**
     *  Singleton
     */
    private MessageTransport() {
    }

    /**
     * Initialize Message Transport
     *
     * @param address InetAddress
     * @param port int
     * @param platform Platform
     * @param useTcp boolean - iff true there will be TCP message transport layer initialized, otherwise UDP will be used
     * @param hwMode boolean - true if MT should be started in special mode when connection between containers is used only for the one particular message and
     *   then it is closed. Option is valid only for the TCP message transport layer
     * @param mtu int - the MTU (maximum transmission unit for the layer OSI 2) in bytes. The option is used only for the UDP message transport layer
     * @param enableMulticastMT boolean - iff true it enables multicast low level message transport
     * @param multicastGroup InetAddress - multicast group IP address where multicast layer should operate
     * @param multicastPort int - multicast operating port
     * @param useSimulatedMessageSize boolean - true means that messages sent as reference should have reported true size
     * @throws IOException
     * @throws Exception
     */
    public final static void initialize(final InetAddress address, final int port,
            final Platform platform,
            final boolean useTcp, final boolean hwMode, final int mtu,
            final boolean enableMulticastMT,
            final InetAddress multicastGroup, final int multicastPort, final boolean useSimulatedMessageSize) throws
          IOException, Exception {
        MessageTransport.useSimulatedMessageSize = useSimulatedMessageSize;

        // parse MTU parameter
        int useMtu = DEFAULT_MTU;
        if (mtu != 0) {
            useMtu = mtu;
        }

        // start layer implementation
        if (useTcp) {
            // start TCP implementation
            standardMessageTransportLayerImpl = new TcpMessageTransportLayerImpl(address, port, hwMode);
        } else {
            // start UDP implementation
            standardMessageTransportLayerImpl = new UdpMessageTransportLayerImpl(address, port, useMtu);
        }
        // start multicast implementation
        if (enableMulticastMT) {
            try {
                multicastMessageTransportLayerImpl = new MulticastTransportLayerImpl(multicastGroup, multicastPort, useMtu);
            } catch (SocketException ex) {
                logger.warning("No multicast network interface available. Multicasting among JVMs is not enabled now.");
            }
        }
        // fetch local addresses
        localAddress = standardMessageTransportLayerImpl.getLocalAddress();
        localHostAddress = localAddress.getAddress().getHostAddress();
        localPort = localAddress.getPort();

        // set initialized
        initialized = true;
    }

    /**
     * Shutdown Message Transport Layer
     */
    public final static void shutdown() {
        if (initialized) {
            if (standardMessageTransportLayerImpl != null) {
                standardMessageTransportLayerImpl.stopMessageTransport();
                standardMessageTransportLayerImpl = null;
            }

            if (multicastMessageTransportLayerImpl != null) {
                multicastMessageTransportLayerImpl.stopMessageTransport();
                multicastMessageTransportLayerImpl = null;
            }
            
            localAddress = null;
            localHostAddress = null;
            localPort = 0;
            useSimulatedMessageSize = false;

            // remove all containers
            containerMT.clear();
            
            // remove initialized
            initialized = false;
        }
    }

    /**
     * Register message transport
     *
     * @param containerName String
     * @param mt MessageReceiver
     * @throws Exception
     */
    public final static void registerMessageTransport(final String containerName,
            final MessageTransportComponent mt) throws Exception {
        if (containerMT.containsKey(containerName)) {
            throw new Exception("Container name '" + containerName + "' already registred in the platform message transport.");
        }
        containerMT.put(containerName, mt);
    }

    /**
     * Deregister message transport
     *
     * @param containerName MessageTransport
     */
    public final static void deregisterMessageTransport(final String containerName) {
        containerMT.remove(containerName);
    }

    /**
     * @internal
     * Get size of the message when transmitted over underlying network connection
     *
     * @param m Message
     * @return int
     */
    public final static int getSimulatedMessageSize(final Message m) {
        if (m.isMulticast()) {
            if (useSimulatedMessageSize) {
                if (multicastMessageTransportLayerImpl != null) {
                    return multicastMessageTransportLayerImpl.getSimulatedMessageSize(m, -1, false);
                } else {
                    return standardMessageTransportLayerImpl.getSimulatedMessageSize(m, -1, false);
                }
            } else {
                return REFERENCE_SIZE;
            }
        } else {
            if (m.getReceiver().isSameContainer(m.getSender())) {
                return 0;
            } else {
                if (useSimulatedMessageSize) {
                    return standardMessageTransportLayerImpl.getSimulatedMessageSize(m, -1, false);
                } else {
                    return REFERENCE_SIZE;
                }
            }
        }
    }

    /**
     * @internal
     * Send standard message. The method is concurrent thread safe.
     *
     * @param m Message - message to sent
     * @param senderMt MessageTransport - sender message transport
     * @param onlyReference boolean - iff true message is passed only as a reference if it is possible
     * @param invisible boolean - true if target is rejected due to the simulated restrictions
     * @throws InvisibleContainerException
     */
    public final static void sendStandardMessage(final Message m) throws
            InvisibleContainerException {
        final Address receiver = m.getReceiver();
        if (receiver == null) {
            throw new IllegalArgumentException("Message has no receiver: "+m);
        }

        if (m.getReceiver().isLocalPlatform()) {
            sendLocalStandardMessage(m);
        } else {
            sendRemoteStandardMessage(m);
        }
    }

    /**
     *
     * @param m
     * @param senderMt
     * @param onlyReference
     * @return
     * @throws InvisibleContainerException
     */
    private final static void sendLocalStandardMessage(final Message m)
    throws InvisibleContainerException {
        final Address receiverAddress = m.getReceiver();

        final MessageTransportComponent destinationMt = MessageTransport.containerMT.get(receiverAddress.getContainerName());

        if (destinationMt == null) {
            // not known container name
            if (Platform.SHOW_UNDELIVERED_MESSAGES) {
                MessageTransport.logger.warning(m.getSender().getContainerName() +
                      ": Target container not reachable due to unknown local container. Original message:\n" +m);
            }
            m.setUndeliverable();
            throw (new InvisibleContainerException("Target container not reachable due to unknown local container: " +receiverAddress));
        }
        // try find receiver of the message
        final MessageReceiver receiver = destinationMt.getMessageReceiver(receiverAddress);
        if (receiver == null) {
            if (Platform.SHOW_UNDELIVERED_MESSAGES) {
                MessageTransport.logger.warning(receiverAddress.getContainerName() +
                      ": Receiver not found. Original message:\n" + m);
            }
            m.setUndeliverable();
            if (m.isMessageSizeRequired()) {
                if (m.getReceiver().isSameContainer(m.getSender())) {
                    m.setMessageSize(0);
                } else {
                    if (useSimulatedMessageSize) {
                        m.setMessageSize(standardMessageTransportLayerImpl.getSimulatedMessageSize(m, -1, false));
                    } else {
                        m.setMessageSize(REFERENCE_SIZE);
                    }
                }
            }
            return;
        }

        try {
            Message newm = null;

            if (m.getAsReference()) {
                // when sending message as a reference, the length of the message is 4 or 8 (reference)
                newm = m;
                if (m.isMessageSizeRequired()) {
                    if (m.getSender().isSameContainer(m.getReceiver())) {
                        m.setMessageSize(0);
                    } else {
                        if (useSimulatedMessageSize) {
                            m.setMessageSize(standardMessageTransportLayerImpl.getSimulatedMessageSize(m, -1, false));
                        } else {
                            m.setMessageSize(REFERENCE_SIZE);
                        }
                    }
                }
                // register new message holder
                m.registerHolder();
            } else {
                final CloneBuffer cloneBuffer = CloneBuffer.getCloneBuffer();
                try {
                    m.writeExternal(cloneBuffer.outputStream);
                    cloneBuffer.outputStream.flush();
                    // if copy message may be sent out, create it from cloning buffer
                    // deserialize message in correct class name space
                    cloneBuffer.inputStream.setClassLoader(receiver);
                    if (m.isMessageSizeRequired()) {
                        if (m.getSender().isSameContainer(m.getReceiver())) {
                            m.setMessageSize(0);
                        } else {
                            m.setMessageSize(standardMessageTransportLayerImpl.getSimulatedMessageSize(m, cloneBuffer.getDataSize(), false));
                        }
                    }
                    newm = Message.newInstance();
                    newm.readExternal(cloneBuffer.inputStream);
                } finally {
                    cloneBuffer.release();
                }
            }

            // incoming message
            destinationMt.processReceivedMessage(newm, receiver);

            return;
        }
        catch (Exception ex1) {
            MessageTransport.logger.severe("Problem with cloning message: " + ExceptionPrinter.toStringWithStackTrace(ex1) + "\nMessage: " + m);
            m.setUndeliverable();
            if (m.isMessageSizeRequired()) {
                m.setMessageSize(0);
            }
        }
    }

    /**
     *
     * @param m
     * @param senderMt
     * @param onlyReference
     * @return
     * @throws InvisibleContainerException
     */
    private final static void sendRemoteStandardMessage(final Message m)
    throws InvisibleContainerException {
        final Address receiverAddress = m.getReceiver();

        try {
            // try transmit message to the destination platform message transport if possible
            ArrayList<Address> singleReceiver = outgoingReceiversPool.pop();
            if (singleReceiver == null) {
                singleReceiver = new ArrayList<Address>(1);
            } else {
                singleReceiver.clear();
            }
            singleReceiver.add(m.getReceiver());
            final int msgSize = standardMessageTransportLayerImpl.transmitMessage(singleReceiver, m);
            singleReceiver.clear();
            outgoingReceiversPool.push(singleReceiver);
            if (m.isMessageSizeRequired()) {
                m.setMessageSize(msgSize);
            }
            return;
        }
        catch (Exception ex) {
            // send undeliverable info
            if (Platform.SHOW_UNDELIVERED_MESSAGES) {
                MessageTransport.logger.warning(m.getSender().getContainerName() +
                      ": Target container not reachable due to I/O connection failure. Original message:\n" +m);
            }
            m.setUndeliverable();
            if (m.isMessageSizeRequired()) {
                m.setMessageSize(0);
            }

            throw (new InvisibleContainerException("Target container not reachable due to I/O connection failure: " + receiverAddress, true, ex));
        }
    }

    /**
     * Sends multicast message. The method is concurrent thread safe.
     *
     * @param m Message - message to sent
     * @param senderMt MessageTransport - sender MT
     */
    public final static void sendMulticastMessage(final Message m) {
        final Collection<Address> receivers = m.getReceivers();
        MessageTransportComponent destinationMt;
        MessageReceiver messageReceiver;
        Message newm = null;
        int msgLength = 0;
        CloneBuffer cloneBuffer = null;
        final boolean onlyReference = m.getAsReference();

        LinkedHashSet<Address> localMulticastReceivers = poolOfLinkedHashSets.pop();
        if (localMulticastReceivers == null) {
            localMulticastReceivers = new LinkedHashSet<Address>(receivers.size());
        }
        LinkedHashSet<Address> remoteMulticastReceivers = poolOfLinkedHashSets.pop();
        if (remoteMulticastReceivers == null) {
            remoteMulticastReceivers = new LinkedHashSet<Address>(receivers.size());
        }
        LinkedHashSet<Address> remoteMulticastPlatforms = poolOfLinkedHashSets.pop();
        if (remoteMulticastPlatforms == null) {
            remoteMulticastPlatforms = new LinkedHashSet<Address>(receivers.size());
        }
        LinkedHashMap<Address, LinkedHashSet<Address>> remoteMulticastReceiversPerPlatform = poolOfMulticastReceiversPerPlatform.pop();
        if (remoteMulticastReceiversPerPlatform == null) {
            remoteMulticastReceiversPerPlatform = new LinkedHashMap<Address, LinkedHashSet<Address>>();
        }
        try {
            try {
                int localSize = -1;
                // go through all receivers
                for (final Address elem : receivers) {
                    // test if this is local platform message
                    if (elem.isLocalPlatform()) {
                        // local message
                        if (!localMulticastReceivers.contains(elem)) {
                            // not sent yet
                            // remember local multicast receiver
                            localMulticastReceivers.add(elem);

                            // try find appropriate destination MT
                            destinationMt = MessageTransport.containerMT.get(elem.getContainerName());
                            if (destinationMt == null) {
                                // not found
                                if (Platform.SHOW_UNDELIVERED_MESSAGES) {
                                    MessageTransport.logger.warning(m.getSender().getContainerName() +
                                            ": Target container not reachable due to unknown local container. Original message:\n" +m);
                                }
                                // skip it
                                continue;
                            }
                            // try find receiver of the message
                            messageReceiver = destinationMt.getMessageReceiver(elem);
                            if (messageReceiver == null) {
                                // receiver not found
                                if (Platform.SHOW_UNDELIVERED_MESSAGES) {
                                    MessageTransport.logger.warning(elem.getContainerName() + ": Receiver not found. Original message:\n" + m);
                                }
                                // skip it
                                continue;
                            }

                            try {
                                if (onlyReference) {
                                    // send as reference
                                    newm = m;

                                    // count msg size if required
                                    if (m.isMessageSizeRequired()) {
                                        if (localSize < 0) {
                                            if (useSimulatedMessageSize) {
                                                if (multicastMessageTransportLayerImpl != null) {
                                                    localSize = multicastMessageTransportLayerImpl.getSimulatedMessageSize(m, -1, false);
                                                } else {
                                                    localSize = standardMessageTransportLayerImpl.getSimulatedMessageSize(m, -1, false);
                                                }
                                            } else {
                                                localSize = REFERENCE_SIZE;
                                            }
                                            msgLength = localSize;
                                        } else {
                                            if (useSimulatedMessageSize && (multicastMessageTransportLayerImpl == null)) {
                                                msgLength += localSize;
                                            }
                                        }
                                    }

                                    // register new message holder
                                    newm.registerHolder();

                                    // incoming message
                                    destinationMt.processReceivedMessage(newm, messageReceiver);
                                } else {
                                    // fill message into cloning buffer only once
                                    if (cloneBuffer == null) {
                                        try {
                                            cloneBuffer = CloneBuffer.getCloneBuffer();
                                        }
                                        catch (Exception ex1) {
                                            MessageTransport.logger.severe("Problem with allocation of cloning buffer: " +
                                                    ExceptionPrinter.toStringWithStackTrace(ex1));
                                            m.setUndeliverable();
                                            if (m.isMessageSizeRequired()) {
                                                m.setMessageSize(0);
                                            }
                                            return;
                                        }
                                        
                                        m.writeExternal(cloneBuffer.outputStream);
                                        cloneBuffer.outputStream.flush();
                                    } else {
                                        // only rewind buffer back to the initial position
                                        cloneBuffer.rewind();
                                    }

                                    // count msg size if required
                                    if (m.isMessageSizeRequired()) {
                                        if (localSize < 0) {
                                            if (multicastMessageTransportLayerImpl != null) {
                                                localSize = multicastMessageTransportLayerImpl.getSimulatedMessageSize(m, cloneBuffer.getDataSize(), false);
                                            } else {
                                                localSize = standardMessageTransportLayerImpl.getSimulatedMessageSize(m, -1, false);
                                            }
                                            msgLength = localSize;
                                        } else {
                                            if (multicastMessageTransportLayerImpl == null) {
                                                msgLength += localSize;
                                            }
                                        }
                                    }

                                    // deserialize message in correct class name space
                                    cloneBuffer.inputStream.setClassLoader(messageReceiver);
                                    newm = Message.newInstance();
                                    newm.readExternal(cloneBuffer.inputStream);

                                    // incoming message
                                    destinationMt.processReceivedMessage(newm, messageReceiver);
                                }
                            } catch (Exception ex) {
                                MessageTransport.logger.severe("Problem with cloning message: " +
                                        ExceptionPrinter.toStringWithStackTrace(ex) + "\nMessage: " + m);
                            }

                        }
                    } else {
                        // remote message
                        if (!remoteMulticastReceivers.contains(elem)) {
                            // not sent yet
                            // remember destination
                            remoteMulticastReceivers.add(elem);

                            if (multicastMessageTransportLayerImpl == null) {
                                // collect per platform receivers
                                final Address platformDestination = elem.derivePlatformAddress();
                                remoteMulticastPlatforms.add(platformDestination);

                                LinkedHashSet<Address> platformReceivers = remoteMulticastReceiversPerPlatform.get(platformDestination);
                                if (platformReceivers == null) {
                                    platformReceivers = poolOfLinkedHashSets.pop();
                                    if (platformReceivers == null) {
                                        platformReceivers = new LinkedHashSet<Address>();
                                    }
                                    remoteMulticastReceiversPerPlatform.put(platformDestination, platformReceivers);
                                }
                                platformReceivers.add(elem);
                            }
                        }
                    }
                }

                if (remoteMulticastReceivers.size() > 0) {
                    if (multicastMessageTransportLayerImpl != null) {
                        // send message to remote receivers
                        try {
                            final int newLength = multicastMessageTransportLayerImpl.transmitMessage(remoteMulticastReceivers,m);

                            // update msg length & binary msg if requested and not set yet
                            if (newLength > 0) {
                                msgLength = newLength;
                            }
                        }
                        catch (IOException ex1) {
                            // sending problem
                            if (Platform.SHOW_UNDELIVERED_MESSAGES) {
                                MessageTransport.logger.warning(m.getSender().getContainerName() +
                                        ": Target containers not reachable due to I/O failure. Original message:\n" +m);
                            }
                            if (localMulticastReceivers.size() == 0) {
                                m.setUndeliverable();
                                if (m.isMessageSizeRequired()) {
                                    m.setMessageSize(0);
                                }
                                return;
                            }
                        }
                    } else {
                        // no multi-cast layer available, send the message grouped per platform uni-casting
                        for (final LinkedHashSet<Address> elem : remoteMulticastReceiversPerPlatform.values()) {
                            try {
                                final int newLength = standardMessageTransportLayerImpl.transmitMessage(elem, m);

                                if (newLength > 0) {
                                    msgLength += newLength;
                                }

                            } catch (Exception ex2) {
                                // sending problem
                                if (Platform.SHOW_UNDELIVERED_MESSAGES) {
                                    MessageTransport.logger.warning(m.getSender().getContainerName() +
                                            ": Target container not reachable due to I/O failure. Original message:\n" + m);
                                }
                            }
                        }
                    }
                } else if (localMulticastReceivers.size() == 0) {
                    m.setUndeliverable();
                    if (m.isMessageSizeRequired()) {
                        m.setMessageSize(0);
                    }
                    return;
                }

                if (m.isMessageSizeRequired()) {
                    m.setMessageSize(msgLength);
                }

                return;
            } finally {
                // release cloning buffer
                if (cloneBuffer != null) {
                    cloneBuffer.release();
                }
            }
        } finally {
            // release temporary buffers
            localMulticastReceivers.clear();
            poolOfLinkedHashSets.push(localMulticastReceivers);
            remoteMulticastReceivers.clear();
            poolOfLinkedHashSets.push(remoteMulticastReceivers);
            remoteMulticastPlatforms.clear();
            poolOfLinkedHashSets.push(remoteMulticastPlatforms);

            if (remoteMulticastReceiversPerPlatform.size() > 0) {
                for (LinkedHashSet<Address> an : remoteMulticastReceiversPerPlatform.values()) {
                    an.clear();
                    poolOfLinkedHashSets.push(an);
                }
            }
            remoteMulticastReceiversPerPlatform.clear();
            poolOfMulticastReceiversPerPlatform.push(remoteMulticastReceiversPerPlatform);

        }
    }
}
