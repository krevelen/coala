package aglobe.platform.transport;

import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.Collection;

import aglobe.ontology.Message;
import java.io.IOException;
import aglobe.container.transport.Address;

/**
 * <p>Title: A-Globe</p>
 *
 * <p>Description: The message transport layer implementation interface which
 * provide functions for low level I/O message transmission.</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.11 $ $Date: 2009/06/26 11:34:22 $
 */
abstract class MessageTransportLayerImpl {
    protected final static boolean DEBUG = false;

    /**
     * @internal
     */
    public static final byte MSG_TYPE_STANDARD = 0;
    /**
     * @internal
     */
    public static final byte MSG_TYPE_AS_REFERENCE = 1;
    /**
     * @internal
     */
    public static final byte MSG_TYPE_REQ_ADDRESSES = 2;
    /**
     * @internal
     */
    public static final byte MSG_TYPE_RESP_ADDRESSES = 3;

    /**
     * Returns local MessageTransport address where message transport listens
     * for the new incoming messages
     *
     * @return InetSocketAddress
     * @throws UnknownHostException
     */
    abstract InetSocketAddress getLocalAddress() throws UnknownHostException;

    /**
     * Transmit message to the destination by low level I/O operations. The method is concurrent thread safe.
     *
     * @param receivers Collection<Address> - specify the receivers of the message
     * @param m Message - message to transmission
     * @param needMessageCopy boolean - iff true the binary encoded message in byte[] is requested
     * @param asReferenceOnly - specify that multiple receivers of the same message at one container should got
     * the same instance
     * @throws IOException
     */
    abstract int transmitMessage(final Collection<Address> receivers, final Message m) throws IOException;

    /**
     * Stops message transport layer and close all opened connections
     */
    abstract void stopMessageTransport();

    /**
     * Get size of the message when transmitted over underlying network connection
     *
     * @param m Message
     * @param serializedLength int - if >= 0 it is used as a serialized size
     * @param noConnection boolean - iff true it means that there is no connection to the destination port
     * @return int
     */
    abstract int getSimulatedMessageSize(final Message m, final int serializedLength, final boolean noConnection);

    /**
     * Write short to the output buffer
     *
     * @param v int
     * @param outputBuffer ByteBuffer
     */
    protected static final void writeShort(final int v, final ByteBuffer outputBuffer) {
        outputBuffer.put((byte) (v >>> 8));
        outputBuffer.put((byte) v);
    }

    /**
     * Write int to the output buffer
     *
     * @param v int
     * @param outputBuffer ByteBuffer
     */
    protected static final void writeInt(final int v, final ByteBuffer outputBuffer) {
        outputBuffer.put((byte) (v >>> 24));
        outputBuffer.put((byte) (v >>> 16));
        outputBuffer.put((byte) (v >>> 8));
        outputBuffer.put((byte) v);
    }

    /**
     * Write long to the output buffer
     *
     * @param v long
     * @param outputBuffer ByteBuffer
     */
    protected static final void writeLong(final long v, final ByteBuffer outputBuffer) {
        outputBuffer.put((byte) (v >>> 56));
        outputBuffer.put((byte) (v >>> 48));
        outputBuffer.put((byte) (v >>> 40));
        outputBuffer.put((byte) (v >>> 32));
        outputBuffer.put((byte) (v >>> 24));
        outputBuffer.put((byte) (v >>> 16));
        outputBuffer.put((byte) (v >>> 8));
        outputBuffer.put((byte) v);
    }

    protected final static void writeString(final String string, final ByteBuffer outputBuffer) {
        if (string == null) {
            writeShort(-1, outputBuffer);
        } else {
            final int len = string.length();
            writeShort(len, outputBuffer);
            final char[] chars = new char[len];
            string.getChars(0, len, chars, 0);
            for (int i = 0; i < len; i++) {
                outputBuffer.putChar(chars[i]);
            }
        }
    }

    /**
     * Read short from the input buffer
     *
     * @param inputBuffer ByteBuffer
     * @return int
     */
    protected static final int readShort(final ByteBuffer inputBuffer) {
        int retVal = 0;
        retVal |= (inputBuffer.get() & 0xff) << 8;
        retVal |= (inputBuffer.get() & 0xff);
        return retVal;
    }

    /**
     * Read int from the input buffer
     * @param inputBuffer ByteBuffer
     * @return int
     */
    protected static final int readInt(final ByteBuffer inputBuffer) {
        int retVal = 0;
        retVal |= (inputBuffer.get() & 0xff) << 24;
        retVal |= (inputBuffer.get() & 0xff) << 16;
        retVal |= (inputBuffer.get() & 0xff) << 8;
        retVal |= (inputBuffer.get() & 0xff);
        return retVal;
    }

    /**
     * Read long from the input buffer
     * @param inputBuffer ByteBuffer
     * @return long
     */
    protected static final long readLong(final ByteBuffer inputBuffer) {
        long retVal = 0;
        retVal |= (inputBuffer.get() & 0xffL) << 56;
        retVal |= (inputBuffer.get() & 0xffL) << 48;
        retVal |= (inputBuffer.get() & 0xffL) << 40;
        retVal |= (inputBuffer.get() & 0xffL) << 32;
        retVal |= (inputBuffer.get() & 0xffL) << 24;
        retVal |= (inputBuffer.get() & 0xffL) << 16;
        retVal |= (inputBuffer.get() & 0xffL) << 8;
        retVal |= (inputBuffer.get() & 0xffL);
        return retVal;
    }

    protected final static String readString(final ByteBuffer inputBuffer) {
        final int len = readShort(inputBuffer);
        if (len < 0) {
            return null;
        } else {
            if (len == 0) {
                return "";
            }
            final char[] buf = new char[len];
            for (int i = 0; i < len; i++) {
                buf[i] = inputBuffer.getChar();
            }
            return new String(buf);
        }
    }



}
