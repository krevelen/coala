/**
 *
 */
package aglobe.platform.transport;

import aglobe.container.transport.Address;

/**
 * <p>Title: A-Globe</p>
 *
 * <p>Description: Interface implemented by every entity having several receivers.</p>
 *
 * <p>Copyright: Copyright (c) 2009</p>
 *
 * <p>Company: Agent Technology Center</p>
 *
 * @author David Sislak
 * @version $Revision: 1.2 $ $Date: 2009/06/15 13:38:01 $
 *
 */
public interface MessageReceiverSplitter {

    /**
     * Returns required receiver.
     * @param receiver
     * @return
     */
    public MessageReceiver getMessageReceiver(final Address receiver) throws RecepientNotFound;
}
