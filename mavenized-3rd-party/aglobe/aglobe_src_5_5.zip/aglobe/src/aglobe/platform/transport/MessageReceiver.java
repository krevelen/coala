package aglobe.platform.transport;

import aglobe.container.library.EntityClassLoader;
import aglobe.ontology.LibInfo;
import aglobe.ontology.Message;
import aglobe.platform.Platform;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: Interface implemented by every entity able to receive incoming message.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.3 $ $Date: 2010/10/18 12:25:43 $
 */
public abstract class MessageReceiver {
    private static final ClassLoader systemClassLoader = Platform.class.getClassLoader(); 

    /**
     * Entity's class loader, don't change it
     */
    private transient EntityClassLoader classLoader = null;

    private transient LibInfo.LibUser libraryUser = new LibInfo.LibUser();

    /**
     * Get class loader.
     *
     * @return
     */
    public ClassLoader getClassLoader() {
        return (classLoader != null)? classLoader : systemClassLoader;
    }

    /**
     * Set receiver's class loader.
     * @param classLoader
     */
    public void setClassLoader(final EntityClassLoader classLoader, final String receiverName, final boolean isAgent) {
        if (this.classLoader != null) {

            // deregister from the previous one first
            this.classLoader.removeClassLoaderOwner(this, libraryUser);
        }
        this.classLoader = classLoader;

        if (this.classLoader != null) {
            libraryUser = new LibInfo.LibUser();
            libraryUser.setName(receiverName);
            libraryUser.setType(isAgent?"agent":"service");

            this.classLoader.addClassLoaderOwner(this, libraryUser);
        }
    }

    /**
     * Store incoming message to the end of the queue for later parsing
     * @param m Message - incoming message
     */
    public abstract void incomingMessage(final Message m);

}
