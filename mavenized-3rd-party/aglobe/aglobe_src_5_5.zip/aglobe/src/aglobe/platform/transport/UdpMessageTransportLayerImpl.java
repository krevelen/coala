package aglobe.platform.transport;

import java.io.IOException;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.nio.channels.DatagramChannel;
import java.util.HashMap;

import aglobe.container.transport.Address;

/**
 * <p>Title: A-Globe</p>
 *
 * <p>Description: Internal class used for low-level I/O MessageTransport operations over UDP</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.31 $ $Date: 2010/10/13 12:17:03 $
 */
final class UdpMessageTransportLayerImpl extends DatagramMessageTransportLayerImpl {
    /**
     * UDP/IP receiving buffer size, 20 000kB
     */
    private static final int UDP_SOCKET_BUFFER_SIZE = 20480000;
    
    private final InetAddress address;

    /**
     * UDP socket channel
     */
    private DatagramChannel socketChannel;

    /**
     * UDP socket used for low level I/O operations
     */
    private DatagramSocket socket;

    /**
     * Hash map of socket addresses for all known platforms
     */
    private final HashMap<Address, InetSocketAddress> socketAddress = new HashMap<Address,InetSocketAddress>();
    
    private int currentOutgoingBufferSize;

    /**
     * Constructor
     *
     * @param address InetAddress
     * @param _port int - port where MT will listens for incoming messages, 0 means that the free port is requested
     * @param mtu int - MTU size, used for message fragments
     * @throws IOException
     */
    UdpMessageTransportLayerImpl(final InetAddress address, final int _port, final int mtu) throws
          IOException {
        super(address, _port, true, mtu);
        this.address = address;
    }

    @Override
    protected final void prepareSockets(final InetAddress address, final int _port) throws IOException {
        // create UDP sockets
        socketChannel = DatagramChannel.open();
        socketChannel.configureBlocking(true);
        socket = socketChannel.socket();
        socket.setBroadcast(false);
        socket.setTrafficClass(0x18);
        socket.setReuseAddress(false);
        ensureSendBufferSize(10000);
        socket.setReceiveBufferSize(UDP_SOCKET_BUFFER_SIZE); 
        if (socket.getReceiveBufferSize() != UDP_SOCKET_BUFFER_SIZE) {
            MessageTransport.logger.warning("Cannot set datagram socket receive buffer size ! Will use only current buffer size "+socket.getReceiveBufferSize()+" Bytes which will have negative impact to communication performance. System administrator can allow setting large socket buffers.");
        }
        socket.bind(new InetSocketAddress(_port));
    }
    
    /* (non-Javadoc)
     * @see aglobe.platform.transport.DatagramMessageTransportLayerImpl#ensureSendBufferSize(int)
     */
    @Override
    protected void ensureSendBufferSize(int packets) throws SocketException {
        if (packets < currentOutgoingBufferSize) {
            return;
        }
        
        currentOutgoingBufferSize = packets;
        final int udpSocketBufferSize = mtu * currentOutgoingBufferSize;
        socket.setSendBufferSize(udpSocketBufferSize);
        if (socket.getSendBufferSize() != udpSocketBufferSize) {
            MessageTransport.logger.warning("Cannot set datagram socket sent buffer size ! Will use only current buffer size "+socket.getSendBufferSize()+" Bytes which will have negative impact to communication performance. System administrator can allow setting large socket buffers.");
        }
    }

    /* (non-Javadoc)
     * @see aglobe.platform.transport.DatagramMessageTranpsortLayerImpl#closeSockets()
     */
    @Override
    protected final void closeSockets() {
        try {
            socketChannel.close();
        }
        catch (IOException ex1) {
        }
    }

    /* (non-Javadoc)
     * @see aglobe.platform.transport.MessageTransportLayerImpl#getLocalAddress()
     */
    @Override
    public final InetSocketAddress getLocalAddress() throws UnknownHostException {
        return new InetSocketAddress((address != null)?address:InetAddress.getLocalHost(),
                                     socket.getLocalPort());
    }

    /* (non-Javadoc)
     * @see aglobe.platform.transport.DatagramMessageTranpsortLayerImpl#sendBuffer(java.net.InetSocketAddress, java.nio.ByteBuffer)
     */
    @Override
    protected final void sendBuffer(final InetSocketAddress sentTo, final ByteBuffer outputBuffer) throws IOException {
        socketChannel.send(outputBuffer, sentTo);
        while (outputBuffer.remaining() > 0) {
            Thread.yield();
            socketChannel.send(outputBuffer, sentTo);
        }
    }

    /* (non-Javadoc)
     * @see aglobe.platform.transport.DatagramMessageTranpsortLayerImpl#getDestinationInetSocketAddress(aglobe.container.transport.Address)
     */
    @Override
    protected final InetSocketAddress getDestinationInetSocketAddress(final Address targetPlatformAddress) {
        InetSocketAddress retVal = socketAddress.get(targetPlatformAddress);
        if (retVal == null) {
            retVal = new InetSocketAddress(targetPlatformAddress.getHost(), targetPlatformAddress.getPort());
            socketAddress.put(targetPlatformAddress, retVal);
        }
        return retVal;
    }

    /* (non-Javadoc)
     * @see aglobe.platform.transport.DatagramMessageTranpsortLayerImpl#readToBuffer(java.nio.ByteBuffer)
     */
    @Override
    protected final InetSocketAddress readToBuffer(final ReadingBuffers inputBuffers) throws IOException {
        return (InetSocketAddress)socketChannel.receive(inputBuffers.readInputBuffer);
    }
}
