package aglobe.platform.transport;

/**
 * @internal
 * <p>Title: A-Globe</p>
 * <p>Description: RecepientNotFound exception. Thrown internally when recipient
 * specified by the receiver address is not found.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.2 $ $Date: 2009/06/15 13:38:01 $
 */
public final class RecepientNotFound extends RuntimeException {
    private static final long serialVersionUID = -5167423237023440986L;

    /**
     * Exception constructor
     * @param s String - exception message
     */
    public RecepientNotFound(String s) {
        super(s);
    }

    /**
     * Creates exception without any exception message
     */
    public RecepientNotFound() {
        super();
    }
}
