/**
 *
 */
package aglobe.platform.transport;

import java.io.IOException;
import java.io.InputStream;
import java.lang.management.ManagementFactory;
import java.lang.ref.SoftReference;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.nio.BufferOverflowException;
import java.nio.ByteBuffer;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import aglobe.container.transport.Address;
import aglobe.ontology.Message;
import aglobe.platform.MessageTransportComponent;
import aglobe.platform.Platform;
import aglobe.platform.thread.AglobeThreadPool;
import aglobe.util.ExceptionPrinter;
import aglobe.util.concurrent.NonblockingPoolArrayFIFO;

/**
 * <p>Copyright: Copyright (c) 2009</p>
 *
 * <p>Company: Agent Technology Center</p>
 *
 * @author David Sislak
 * @version $Revision: 1.2 $ $Date: 2010/10/13 11:17:30 $
 *
 */
abstract class DatagramMessageTransportLayerImpl extends MessageTransportLayerImpl implements Runnable {
    /**
     * Message fragment header length in bytes
     */
    private final static int MESSAGE_FRAGMENT_HEADER_LENGTH = 8;

    /**
     * Timeout specifying how long we can expect next fragment of the message
     * from the last message
     */
    private final static long WAIT_FOR_MSG_MILLIS = 3000;

    /**
     * How long we will keep information about messages to ignore in the memory
     */
    private final static long HOLD_IGNORE_INFO_FOR_MILLIS = 30000;

    private final boolean useDirectBuffers;
    protected final int mtu;

    // ==================================================
    // Outgoing part
    // ==================================================

    /**
     * The size of the msg part content is mtu excluding any IP, UDP and message headers
     */
    protected final int usefullMsgPartContentSize;

    /**
     * Outgoing message ID counter
     */
    private final AtomicInteger outgoingMessageIDcounter = new AtomicInteger(0);


    // ==================================================
    // Incoming part
    // ==================================================

    /**
     * true if receiving thread may be stopped
     */
    private boolean stop;

    /**
     * Lock object used during message transport shutdown
     */
    private final Object stopLock = new Object();

    /**
     * sets to true after receiving thread finish
     */
    private boolean finished;

    /**
     * Receiving thread
     */
    private final Thread receivingThread;

    /**
     * Messages that should be ignored
     */
    private final HashMap<Long,MsgToIgnore> msgToIgnore = new HashMap<Long,MsgToIgnore>();

    /**
     * Messages that should be ignored head
     */
    private MsgToIgnore msgToIgnoreHead = null;

    /**
     * Incomplete messages
     */
    private final HashMap<Long,IncompleteMsg> incompleteMsg = new HashMap<Long,IncompleteMsg>();

    /**
     * Incomplete message list head
     */
    private IncompleteMsg incompleteMsgHead = null;


    private final HashMap<Long,ArrayList<AddressWaiter>> waitingForAddress = new HashMap<Long, ArrayList<AddressWaiter>>();

    private final ArrayDeque<long[]> longArraysPool = new ArrayDeque<long[]>();
    private final ArrayDeque<short[]> shortArraysPool = new ArrayDeque<short[]>();
    private final ArrayDeque<Address[]> addressArraysPool = new ArrayDeque<Address[]>();
    private final ArrayDeque<MessageReceiver[]> messageReceiverArraysPool = new ArrayDeque<MessageReceiver[]>();
    private final ArrayDeque<MessageTransportComponent[]> messageTransportComponentArraysPool = new ArrayDeque<MessageTransportComponent[]>();
    private final ArrayDeque<ArrayList<AddressWaiter>> arrayListAddressWaiterPool = new ArrayDeque<ArrayList<AddressWaiter>>();

    private final AddressReadCache addressReadCache = new AddressReadCache();

    private final HashMap<Long, Integer> debugAddressCounter = new HashMap<Long, Integer>();


    // ==================================================


    protected DatagramMessageTransportLayerImpl(final InetAddress address, final int _port, boolean useDirectBuffers, final int mtu) throws IOException {
        this.useDirectBuffers = useDirectBuffers;
        this.mtu = mtu;
        // the length of one msg part is 20 bytes for IP header, 8 bytes for UDP header and message fragment header length
        this.usefullMsgPartContentSize = mtu - 20 - 8 - MESSAGE_FRAGMENT_HEADER_LENGTH;

        stop = false;
        finished = false;

        // create sockets
        prepareSockets(address, _port);

        // initialize msg to ignore head
        msgToIgnoreHead = MsgToIgnore.getMsgToIgnore(0);
        msgToIgnoreHead.next = msgToIgnoreHead;
        msgToIgnoreHead.prev = msgToIgnoreHead;

        // initialize incomplete msg head
        incompleteMsgHead = IncompleteMsg.getIncompleteMsg(0, 0, 0);
        incompleteMsgHead.next = incompleteMsgHead;
        incompleteMsgHead.prev = incompleteMsgHead;


        // start receiving thread
        receivingThread = AglobeThreadPool.getThread(Platform.getPlatformThreadGroup(), this, this.getClass().getName()+" Message transport: Receiving Thread");
        receivingThread.setPriority(Math.min(Thread.NORM_PRIORITY + 3, Thread.MAX_PRIORITY));
        receivingThread.start();
    }

    /**
     * Stops message transport layer and close all opened connections
     */
    @Override
    final void stopMessageTransport() {
        synchronized (stopLock) {
            stop = true;
            closeSockets();
            while (!finished) {
                try {
                    stopLock.wait();
                }
                catch (InterruptedException ex) {
                }
            }
        }
    }

    protected abstract void prepareSockets(final InetAddress address, final int _port) throws IOException;
    protected abstract void closeSockets();
    protected abstract void sendBuffer(final InetSocketAddress sentTo, final ByteBuffer outputBuffer) throws IOException;
    protected abstract InetSocketAddress getDestinationInetSocketAddress(final Address targetPlatformAddress);
    protected abstract InetSocketAddress readToBuffer(final ReadingBuffers inputBuffers) throws IOException;
    protected abstract void ensureSendBufferSize(final int packets) throws SocketException;

    // ==================================================
    // Outgoing part
    // ==================================================

    /* (non-Javadoc)
     * @see aglobe.platform.transport.MessageTransportLayerImpl#getSimulatedMessageSize(aglobe.ontology.Message, int, boolean)
     */
    @Override
    final int getSimulatedMessageSize(final Message m, final int serializedLength, final boolean noConnection) {
        int serLen = serializedLength;
        if (serLen < 0) {
            serLen = MessageSizeCounter.getMessageSerializedLength(m);
        }
        final int toTransmit = 1 + 2 + 2 + 4 + serLen;
        final int numberOfFragments = (int)Math.ceil(((double)toTransmit)/usefullMsgPartContentSize);
        return toTransmit + numberOfFragments * MESSAGE_FRAGMENT_HEADER_LENGTH;
    }

    protected final int sendBuffer(final InetSocketAddress sentTo, final int toTransmit, final ByteBuffer outputBuffer) throws IOException {
        // count total number of fragments to transmit
        final int numberOfFragments = (int)Math.ceil(((double)toTransmit)/usefullMsgPartContentSize);
        ensureSendBufferSize(numberOfFragments*2);
        
        
        // prepare unique outgoing message id
        final int outgoingMessageID = outgoingMessageIDcounter.getAndIncrement();

        for (int i=0; i<numberOfFragments; i++) {
            // Transmit one fragment
            final int fragmentStart = i*usefullMsgPartContentSize;
            int dataToSent;
            if (i != (numberOfFragments - 1)) {
                dataToSent = MESSAGE_FRAGMENT_HEADER_LENGTH + usefullMsgPartContentSize;
            } else {
                dataToSent = MESSAGE_FRAGMENT_HEADER_LENGTH + (toTransmit - (numberOfFragments-1)*usefullMsgPartContentSize);
            }

            // fill fragment header
            outputBuffer.position(fragmentStart);
            writeShort(outgoingMessageID, outputBuffer);
            writeShort(usefullMsgPartContentSize, outputBuffer);
            writeShort(i, outputBuffer);
            writeShort(numberOfFragments, outputBuffer);

            // send one fragment
            outputBuffer.position(fragmentStart);
            outputBuffer.limit(fragmentStart + dataToSent);

            sendBuffer(sentTo, outputBuffer);
        }

        return toTransmit + numberOfFragments * MESSAGE_FRAGMENT_HEADER_LENGTH;
    }

    /* (non-Javadoc)
     * @see aglobe.platform.transport.MessageTransportLayerImpl#transmitMessage(java.util.Collection, aglobe.ontology.Message)
     */
    @Override
    final int transmitMessage(final Collection<Address> receivers, final Message m) throws IOException {
        // prepare receivers size
        final int addressTranslatorSize = 1 + ((m.isMulticast())?m.getReceivers().size():1) + 2;
            // sender address + receiver addresses + optional buffer to avoid reallocation
        int msgHeaderLength = 1+ 2 + 8*addressTranslatorSize + 2 + 2*receivers.size() + 4;
            // 8-bit type byte + 16-bit no.addresses in address translator + address translator content (64-bit per each address) +
            //   16-bit no.recipients + 16-bit localID per each receiver + 32-bit msg content length

        int initMsgPosition = MESSAGE_FRAGMENT_HEADER_LENGTH + msgHeaderLength;
        int msgLength = 0;
        boolean ok = false;

        // get buffers
        final OutputBuffers ob = OutputBuffers.getOutputBuffers();
        ByteBuffer outputBuffer = ob.outputBuffer;
        ByteBufferOutputStream outputStream = ob.outputStream;
        final AddressWriteCache addressWriter = ob.addressWriter;

        // encode message
        while (!ok) {
            try {
                outputBuffer.position(initMsgPosition);
                // encode message
                m.serialize(outputStream, addressWriter);
                msgLength = outputBuffer.position() - initMsgPosition;

                ok = true;
            } catch (BufferOverflowException ex) {
                // small buffer
                ob.allocate(ob.outputBuffer.capacity() * 2);
                outputBuffer = ob.outputBuffer;
                outputStream = ob.outputStream;
            } catch (IOException ex) {
                MessageTransport.logger.severe("Message encoding error:\n" +  ExceptionPrinter.toStringWithStackTrace(ex) +"\nMessage: "+m);
                ob.release();
                throw ex;
            }
        }

        Address targetPlatformAddress = null;

        final LinkedHashMap<Long, Short> translator = addressWriter.translator;
        // fill the message header
        // first check if the predicted address translator size doesn't exceed allocated space
        if (translator.size() > addressTranslatorSize) {
            // we need move message forward in such a case
            final int correctMsgHeaderLength = msgHeaderLength + 8*(translator.size() - addressTranslatorSize);
            final int correctInitMsgPosition = MESSAGE_FRAGMENT_HEADER_LENGTH + correctMsgHeaderLength;
            final OutputBuffers newOb = OutputBuffers.getOutputBuffers();

            // ensure capacity
            if (newOb.outputBuffer.capacity() < (correctInitMsgPosition + msgLength)) {
                // reallocate buffer
                ob.allocate(correctInitMsgPosition + msgLength + 10);
            }

            final ByteBuffer newOutputBuffer = newOb.outputBuffer;

            // copy message content
            newOutputBuffer.position(correctInitMsgPosition);
            outputBuffer.limit(outputBuffer.position());
            outputBuffer.position(initMsgPosition);
            newOutputBuffer.put(outputBuffer);

            // swap buffers internals and release new one
            ob.outputBuffer = newOutputBuffer;
            ob.outputStream = newOb.outputStream;

            newOb.outputBuffer = outputBuffer;
            newOb.outputStream = outputStream;

            outputBuffer = ob.outputBuffer;
            outputStream = ob.outputStream;

            // release helper buffer
            newOb.release();

            // overwrite non-valid length
            msgHeaderLength = correctMsgHeaderLength;
            initMsgPosition = correctInitMsgPosition;
        }

        // fill message header in
        outputBuffer.position(MESSAGE_FRAGMENT_HEADER_LENGTH);
        // msg type
        outputBuffer.put(m.getAsReference()?MSG_TYPE_AS_REFERENCE:MSG_TYPE_STANDARD);
        // address translator
        int additionalSpace = Math.max(addressTranslatorSize - translator.size(), 0);
        writeShort(translator.size()+additionalSpace, outputBuffer);
        for (final Long addressID : translator.keySet()) {
            writeLong(addressID, outputBuffer);
        }
        // fill additional space
        while (additionalSpace > 0) {
            writeLong(0, outputBuffer);
            additionalSpace--;
        }
        // receivers
        writeShort(receivers.size(), outputBuffer);
        for (final Address address : receivers) {
            if (targetPlatformAddress == null) {
                targetPlatformAddress = address.derivePlatformAddress();
            }
            Short id = translator.get(address.getAddressId());
            if (id == null) {
                final String error = "Message encoding error: cannot find address in translator\n" +  address.toString();
                MessageTransport.logger.severe(error);
                ob.release();
                throw new IOException(error);
            }
            writeShort(id, outputBuffer);
        }
        // msg payload size
        writeInt(msgLength, outputBuffer);

        // send message
        final int msgSize = sendBuffer(getDestinationInetSocketAddress(targetPlatformAddress), msgHeaderLength+msgLength, outputBuffer);

        // release output buffers
        ob.release();

        // return necessary values
        return msgSize;
    }


    // ==================================================
    // Incoming part
    // ==================================================

    /**
     * Test if msg with specified msg ID should be ignored
     * @param msgId long
     * @return boolean - true iff msg should be ignored
     */
    private final boolean testIfIgnore(final long msgId) {
        MsgToIgnore mti;
        if ((mti = msgToIgnore.get(msgId)) != null) {
            // update time
            mti.timestamp = System.currentTimeMillis();
            // remove from the current list position
            mti.prev.next = mti.next;
            mti.next.prev = mti.prev;
            // put it to the end of the list
            msgToIgnoreHead.prev.next = mti;
            mti.prev = msgToIgnoreHead.prev;
            mti.next = msgToIgnoreHead;
            msgToIgnoreHead.prev = mti;

            return true;
        }
        return false;
    }

    /**
     * Add new msg to the ignore list
     * @param msgId long
     */
    private final void addToIgnore(final long msgId) {
        final MsgToIgnore mti = MsgToIgnore.getMsgToIgnore(msgId);
        msgToIgnore.put(msgId, mti);
        // update time-stamp
        mti.timestamp = System.currentTimeMillis();
        // append to the end
        msgToIgnoreHead.prev.next = mti;
        mti.prev = msgToIgnoreHead.prev;
        mti.next = msgToIgnoreHead;
        msgToIgnoreHead.prev = mti;
    }

    /**
     * Test if msg is already known/received some part of message
     *
     * @param msgId long
     * @return IncompleteMsg - iff found returns incomplete message object, otherwise null
     */
    private final IncompleteMsg testIfKnown(final long msgId) {
        IncompleteMsg im;
        if ((im = incompleteMsg.get(msgId)) != null) {
            // update time
            im.timestamp = System.currentTimeMillis();
            // remove from the list position
            im.prev.next = im.next;
            im.next.prev = im.prev;
            // put it to the end of the list
            incompleteMsgHead.prev.next = im;
            im.prev = incompleteMsgHead.prev;
            im.next = incompleteMsgHead;
            incompleteMsgHead.prev = im;

            return im;
        }
        return null;
    }

    /**
     * Add incomplete msg to the incomplete list
     * @param im IncompleteMsg
     */
    private final void addToIncomplete(final IncompleteMsg im) {
        incompleteMsg.put(im.msgId, im);
        // update time-stamp
        im.timestamp = System.currentTimeMillis();
        // append to the end
        incompleteMsgHead.prev.next = im;
        im.prev = incompleteMsgHead.prev;
        im.next = incompleteMsgHead;
        incompleteMsgHead.prev = im;
    }

    /**
     * Remove from incomplete msg, specified one
     * @param im IncompleteMsg
     */
    private final void releaseIncomplete(final IncompleteMsg im, final boolean isInserted) {
        if (isInserted) {
            im.prev.next = im.next;
            im.next.prev = im.prev;
            incompleteMsg.remove(im.msgId);
        }

        if (im.addressTranslator != null) {
            // remove from waiting queue if it is there
            if (im.numberOfMissingAddresses > 0) {
                for (int i=0; i<im.numberOfTranslatorAddresses; i++) {
                    if (im.addressTranslator[i] == null) {
                        Long adrId = im.addressDirectory[i];
                        final ArrayList<AddressWaiter> waiters = waitingForAddress.get(adrId);
                        if (waiters != null) {
                            final Iterator<AddressWaiter> iter = waiters.iterator();
                            while (iter.hasNext()) {
                                final AddressWaiter item = iter.next();
                                if (item.im == im) {
                                    iter.remove();
                                    break;
                                }
                            }
                            if (waiters.size() == 0) {
                                waitingForAddress.remove(adrId);
                                arrayListAddressWaiterPool.addLast(waiters);
                            }
                        }
                    }
                }
            }

            Arrays.fill(im.addressTranslator, null);
            addressArraysPool.addLast(im.addressTranslator);
            im.addressTranslator = null;
            Arrays.fill(im.addressDirectory, 0);
            longArraysPool.addLast(im.addressDirectory);
            im.addressDirectory = null;
        }
        if (im.receiversIds != null) {
            shortArraysPool.addLast(im.receiversIds);
            im.receiversIds = null;
        }
        if (im.localReceivers != null) {
            Arrays.fill(im.localReceivers, null);
            messageReceiverArraysPool.addLast(im.localReceivers);
            im.localReceivers = null;
            Arrays.fill(im.destinationMts, null);
            messageTransportComponentArraysPool.addLast(im.destinationMts);
            im.destinationMts = null;
        }

        im.release();
    }

    /**
     * Removes unnecessary items from the queues
     */
    private final void clearQueues() {
        final long curTime = System.currentTimeMillis();

        // clear incomplete queue first
        final long msgFrom = curTime - WAIT_FOR_MSG_MILLIS;
        IncompleteMsg im;
        while (((im = incompleteMsgHead.next) != incompleteMsgHead) && (im.timestamp < msgFrom)) {
            // add it to the ignore queue
            addToIgnore(im.msgId);
            
            MessageTransport.logger.severe("Missing datagrams, got only "+ im.parsedFragments + " of " + im.totalFragments+". Your network connection is unreliable. Please, use TCP/IP connection instead of UDP and do not use multicast.");

            // remove im from incomplete
            releaseIncomplete(im, true);
        }

        // clear ignore queue first
        final long ignoreFrom = curTime - HOLD_IGNORE_INFO_FOR_MILLIS;
        MsgToIgnore mti;
        while (((mti = msgToIgnoreHead.next) != msgToIgnoreHead) && (mti.timestamp < ignoreFrom)) {
            // remove it from ignore queue
            mti.prev.next = mti.next;
            mti.next.prev = mti.prev;
            msgToIgnore.remove(mti.msgId);

            mti.release();
        }
    }

    /**
     * @throws IOException
     * @internal
     */
    private final void requestAddresses(final InetSocketAddress requestFrom, final int numberOfMissingAddresses, final short[] missingAddresses, final long[] addressDirectory) throws IOException {
        final int msgSize = MESSAGE_FRAGMENT_HEADER_LENGTH + 1 + 2 + 8*numberOfMissingAddresses;
        // 8-bit msg type + 16-bit number of missing addresses + 64-bit per each address as adrId

        // get buffers
        final OutputBuffers ob = OutputBuffers.getOutputBuffers();
        ByteBuffer outputBuffer = ob.outputBuffer;
        if (outputBuffer.capacity() < msgSize) {
            // small buffer
            ob.allocate(msgSize + 1);
            outputBuffer = ob.outputBuffer;
        }

        // fill request message
        outputBuffer.position(MESSAGE_FRAGMENT_HEADER_LENGTH);
        // msg type
        outputBuffer.put(MSG_TYPE_REQ_ADDRESSES);
        writeShort(numberOfMissingAddresses, outputBuffer);
        for (int i=0; i<numberOfMissingAddresses; i++) {
            writeLong(addressDirectory[missingAddresses[i]], outputBuffer);
        }

        //  send buffer
        sendBuffer(requestFrom, msgSize, outputBuffer);

        // release output buffers
        ob.release();
    }

    private final void responseForRequestedAddresses(final InetSocketAddress requestFrom, final int numberOfRequestedAddresses, final ByteBuffer readFrom) throws IOException {
        final int initMsgPosition = MESSAGE_FRAGMENT_HEADER_LENGTH + 1 + 2;
        boolean ok = false;
        final int inOrigPosition = readFrom.position();

        // get buffers
        final OutputBuffers ob = OutputBuffers.getOutputBuffers();
        ByteBuffer outputBuffer = ob.outputBuffer;

        // encode message
        while (!ok) {
            try {
                outputBuffer.position(initMsgPosition);

                for (int i=0; i<numberOfRequestedAddresses; i++) {
                    final long addressId = readLong(readFrom);
                    final Address adr = Address.getAddressDefinitionForTransport(addressId);
                    if (adr == null) {
                        throw new RuntimeException(requestFrom.toString()+" requests addressId "+addressId+" which is not present now");
                    }
                    writeLong(addressId, outputBuffer);
                    writeString(adr.toString(), outputBuffer);
                }
                ok = true;
            } catch (BufferOverflowException ex) {
                // small buffer
                ob.allocate(ob.outputBuffer.capacity() * 2);
                outputBuffer = ob.outputBuffer;

                // reinitialize input position
                readFrom.position(inOrigPosition);
            } catch (RuntimeException ex) {
                MessageTransport.logger.severe("Message encoding error:\n" +  ExceptionPrinter.toStringWithStackTrace(ex));
                ob.release();
                throw ex;
            }
        }

        final int msgSize = outputBuffer.position() - MESSAGE_FRAGMENT_HEADER_LENGTH;

        outputBuffer.position(MESSAGE_FRAGMENT_HEADER_LENGTH);
        // fill message header
        outputBuffer.put(MSG_TYPE_RESP_ADDRESSES);
        writeShort(numberOfRequestedAddresses, outputBuffer);

        // send data
        sendBuffer(requestFrom, msgSize, outputBuffer);

        // release output buffers
        ob.release();
    }

    /**
     * Parse incoming message from the input stream
     */
    private final void parseMsg(final int numberOfLocalReceivers, final MessageTransportComponent[] destinationMts, final MessageReceiver[] receivers, final ByteBuffer inputBuffer, final InputStream inputStream, final boolean asReference, final Address[] addressTranslator, final boolean debug) {
        try {
            final int msgLength = readInt(inputBuffer);
            addressReadCache.addressTranslator = addressTranslator;

            // set buffer limit
            inputBuffer.limit(inputBuffer.position()+msgLength);

            Message m = null;

            // decode the message
            final int startp = inputBuffer.position();
            for (int i=0; i<numberOfLocalReceivers; i++) {
                final MessageReceiver mr = receivers[i];
                final MessageTransportComponent destinationMt = destinationMts[i];
                if ((!asReference) || (m == null)) {
                    // rewind buffer for new reading
                    inputBuffer.position(startp);
                    m = Message.deserialize(inputStream, mr, addressReadCache);
                    // register me as a message holder for a while
                    m.registerHolder();
                } else if (asReference) {
                    // register another holder of the incoming message
                    m.registerHolder();
                }

                // handle incoming message to the receiver
                destinationMt.processReceivedMessage(m, mr);

                if (debug) {
                    System.err.println(m.toString());
                }

                if (!asReference) {
                    // release it
                    m.release();
                }
            }
            if (asReference && (m != null)) {
                // remove my own holder
                m.release();
            }
        }
        catch (Throwable ex) {
            ex.printStackTrace();
            MessageTransport.logger.severe("Error parsing received message:\n" + ExceptionPrinter.toStringWithStackTrace(ex));
        }
    }

    private final boolean processBuffer(final IncompleteMsg im, final int remainingSize, final ByteBuffer inputBuffer, final InputStream inputStream, final boolean bufferCopied, final boolean debug) {
        // check receivers IDs
        if (im.receiversIds == null) {
            if ((1 + 2 + 8*im.numberOfTranslatorAddresses + 2 + 2*im.numberOfRecipients) > remainingSize) {
                // not whole receivers inside
                return true;
            }
            // set position to the start of receivers section
            inputBuffer.position(MESSAGE_FRAGMENT_HEADER_LENGTH + 1 + 2 + 8*im.numberOfTranslatorAddresses + 2);

            im.receiversIds = shortArraysPool.pollLast();
            if ((im.receiversIds == null) || (im.receiversIds.length < im.numberOfRecipients)) {
                im.receiversIds = new short[im.numberOfRecipients];
            }
            // read them and check that I know all messages
            int k = 0;
            for (int j=0; j<im.numberOfRecipients; j++) {
                final int recId = readShort(inputBuffer);
                im.receiversIds[j] = (short)recId;
                if (im.addressTranslator[recId] == null) {
                    // count missing receiver
                    k++;
                }
            }
            if (k != 0) {
                // missing recipient
                return true;
            }
        } else {
            if (im.numberOfMissingAddresses > 0) {
                // we are still waiting for addresses
                return true;
            }
        }

        // check for receivers
        if (im.localReceivers == null) {
            // prepare local receivers
            int k = 0;
            for (int j=0; j<im.numberOfRecipients; j++) {
                final Address receiverAddress = im.addressTranslator[im.receiversIds[j]];
                // try find destination container first
                final MessageTransportComponent destinationMt = MessageTransport.containerMT.get(receiverAddress.getContainerName());

                if (destinationMt != null) {
                    // now try get receiver of the message
                    final MessageReceiver receiver = destinationMt.getMessageReceiver(receiverAddress);
                    if (receiver != null) {
                        // known receiver
                        if (k == 0) {
                            im.localReceivers = messageReceiverArraysPool.pollLast();
                            im.destinationMts = messageTransportComponentArraysPool.pollLast();
                            if ((im.localReceivers == null) || (im.localReceivers.length < im.numberOfRecipients)) {
                                im.localReceivers = new MessageReceiver[im.numberOfRecipients];
                                im.destinationMts = new MessageTransportComponent[im.numberOfRecipients];
                            }
                        }
                        im.localReceivers[k] = receiver;
                        im.destinationMts[k] = destinationMt;
                        k++;
                    } else {
                        // unknown receiver of the message
                        if (Platform.SHOW_UNDELIVERED_MESSAGES) {
                            MessageTransport.logger.warning(receiverAddress.getContainerName() +": Receiver not found: " + receiverAddress);
                        }
                        // try next recipient
                        continue;
                    }
                } else {
                    // unknown local container
                    if (Platform.SHOW_UNDELIVERED_MESSAGES) {
                        MessageTransport.logger.warning("Target local container not found: " + receiverAddress);
                    }
                    // try next recipient
                    continue;
                }
            }
            // update the true number of recipients
            im.numberOfLocalReceivers = k;
        }

        // check that there is some receiver for this message
        if (im.numberOfLocalReceivers == 0) {
            // no receiver for the message
            if (im.parsedFragments != im.totalFragments) {
                // ignore other parts
                addToIgnore(im.msgId);
            }
            releaseIncomplete(im, bufferCopied);

            // read other packet
            return false;
        }

        if ((im.numberOfMissingAddresses > 0) || (im.parsedFragments != im.totalFragments)) {
            // we are still waiting for other addresses OR message is not complete yet
            return true;
        }

        // yes we are sure that there exist some receiver for the message, parse the message
        inputBuffer.position(MESSAGE_FRAGMENT_HEADER_LENGTH + 1 + 2 + 8*im.numberOfTranslatorAddresses + 2 + 2*im.numberOfRecipients);
        parseMsg(im.numberOfLocalReceivers, im.destinationMts, im.localReceivers, inputBuffer, inputStream, im.msgType==MSG_TYPE_AS_REFERENCE, im.addressTranslator, debug);

        releaseIncomplete(im, bufferCopied);

        return false;
    }

    /* (non-Javadoc)
     * @see java.lang.Runnable#run()
     */
    @Override
    public void run() {
        // allocate input buffer, the maximum size of the UDP packet is 64kB
        final ReadingBuffers readBuffers = new ReadingBuffers();
        readBuffers.readInputBuffer = useDirectBuffers ? ByteBuffer.allocateDirect(65536) : ByteBuffer.allocate(65536);
        readBuffers.readInputStream = new ByteBufferInputStream(readBuffers.readInputBuffer);
        ByteBuffer inputBuffer;
        ByteBufferInputStream inputStream;
        InetSocketAddress sender;

        int fragmentMsgId;
        int fragmentSize = 0;
        int fragmentPosition;
        int totalFragments;
        int remainingSize;

        short[] missingAddresses = null;

        IncompleteMsg im;
        boolean bufferCopied;

        try {
            while (!stop) {
                try {
                    // clear buffers
                    clearQueues();

                    // Prepare for read operation
                    if (readBuffers.readInputBuffer != null) {
                        readBuffers.readInputBuffer.clear();
                    }

                    // read next datagram
                    sender = readToBuffer(readBuffers);

                    // prepare reading buffer
                    inputBuffer = readBuffers.readInputBuffer;
                    inputStream = readBuffers.readInputStream;

                    // prepare for reading operations
                    inputBuffer.flip();

                    // build unique MSG ID
                    fragmentMsgId = readShort(inputBuffer);
                    long msgId = 0;
                    final byte[] rawAddress = sender.getAddress().getAddress();
                    if (rawAddress.length == 4) {
                        // IPv4 - 4 bytes
                        for (int i=0; i<4; i++) {
                            msgId |= rawAddress[i]&0xff;
                            msgId <<= 8;
                        }
                    } else {
                        // IPv6 - 16 bytes
                        for (int i=0; i<4; i++) {
                            msgId |= (rawAddress[i]&0xff)^(rawAddress[i+4]&0xff)^(rawAddress[i+8]&0xff)^(rawAddress[i+12]&0xff);
                            msgId <<= 8;
                        }
                    }
                    msgId <<= 8;
                    msgId |= (sender.getPort() & 0xffff);
                    msgId <<= 16;
                    msgId |= fragmentMsgId;

                    // test if message should be ignored
                    if (!testIfIgnore(msgId)) {
                        // test if message is already known
                        if ((im = testIfKnown(msgId)) != null) {
                            // msg is already known
                            inputBuffer.position(4); // skip already known useful size
                            fragmentPosition = readShort(inputBuffer);
                            inputBuffer.position(MESSAGE_FRAGMENT_HEADER_LENGTH); // skip the number of fragments
                            // fill the next part to the buffer
                            if (useDirectBuffers) {
                                inputBuffer.get(im.msgBufferArray, MESSAGE_FRAGMENT_HEADER_LENGTH + fragmentPosition * im.fragmentSize, inputBuffer.remaining());
                            } else {
                                System.arraycopy(inputBuffer.array(), MESSAGE_FRAGMENT_HEADER_LENGTH, im.msgBufferArray, MESSAGE_FRAGMENT_HEADER_LENGTH + fragmentPosition * im.fragmentSize, inputBuffer.remaining());
                            }
                            bufferCopied = true;
                            im.parsedFragments++;

                            // re-map buffer it to im
                            inputBuffer = im.msgBuffer;
                            inputStream = im.bufInputStream;
                            remainingSize = im.fragmentSize * im.totalFragments;
                        } else {
                            // not known and not ignored yet
                            fragmentSize = readShort(inputBuffer);
                            fragmentPosition = readShort(inputBuffer);
                            totalFragments = readShort(inputBuffer);

                            im = IncompleteMsg.getIncompleteMsg(msgId, fragmentSize, totalFragments);
                            bufferCopied = false;
                            im.parsedFragments = 1;
                            remainingSize = inputBuffer.remaining();
                        }
                        if ((fragmentPosition == 0) || (im.parsedFragments == im.totalFragments)) {
                            if (fragmentPosition == 0) {
                                inputBuffer.position(MESSAGE_FRAGMENT_HEADER_LENGTH);
                                im.msgType = inputBuffer.get();
                            }
                            switch (im.msgType) {
                            case MSG_TYPE_STANDARD:
                            case MSG_TYPE_AS_REFERENCE: {
                                if (fragmentPosition == 0) {
                                    // we are sure that it is at the correct position
                                    im.numberOfTranslatorAddresses = readShort(inputBuffer);
                                }

                                // check translator
                                if (im.addressDirectory == null) {
                                    if ((1 + 2 + im.numberOfTranslatorAddresses*8 + 2) > remainingSize) {
                                        // not whole address directory inside
                                        break;
                                    }

                                    // prepare address translator
                                    im.addressDirectory = longArraysPool.pollLast();
                                    im.addressTranslator = addressArraysPool.pollLast();
                                    if ((im.addressDirectory == null) || (im.addressDirectory.length < im.numberOfTranslatorAddresses)) {
                                        im.addressDirectory = new long[im.numberOfTranslatorAddresses];
                                        im.addressTranslator = new Address[im.numberOfTranslatorAddresses];
                                    }
                                    // prepare missing list
                                    if ((missingAddresses == null) || (missingAddresses.length < im.numberOfTranslatorAddresses)) {
                                        missingAddresses = new short[im.numberOfTranslatorAddresses];
                                    }

                                    inputBuffer.position(MESSAGE_FRAGMENT_HEADER_LENGTH + 1 + 2); // skip msg type, msg number of translator addresses
                                    // read and check existence of addresses
                                    int k = 0;
                                    for (int j=0; j<im.numberOfTranslatorAddresses; j++) {
                                        final Long adrId = readLong(inputBuffer);
                                        if (adrId == 0) {
                                            continue;
                                        }
                                        im.addressDirectory[j] = adrId;
                                        final Address adr = Address.getAddress(adrId);
                                        if (adr != null) {
                                            im.addressTranslator[j] = adr;
                                        } else {
                                            ArrayList<AddressWaiter> missingQueue = waitingForAddress.get(adrId);
                                            if (missingQueue == null) {
                                                missingQueue = arrayListAddressWaiterPool.pollLast();
                                                if (missingQueue == null) {
                                                    missingQueue = new ArrayList<AddressWaiter>(2);
                                                }
                                                waitingForAddress.put(adrId, missingQueue);

                                                // register for request
                                                missingAddresses[k] = (short)j;
                                                k++;
                                            }
                                            // register for later processing
                                            missingQueue.add(AddressWaiter.getAddressWaiter(im, (short)j));
                                            im.numberOfMissingAddresses++;
                                        }
                                    }
                                    // read recipients if it is possible
                                    im.numberOfRecipients = readShort(inputBuffer);

                                    if (k != 0) {
                                        // send request for missing addresses
                                        requestAddresses(sender, k, missingAddresses, im.addressDirectory);
                                    } else {
                                        // no missing addresses
                                    }
                                }

                                // do the rest processing
                                if (processBuffer(im, remainingSize, inputBuffer, inputStream, bufferCopied, false)) {
                                    break;
                                }

                                // read other packet
                                continue;
                            }

                            case MSG_TYPE_REQ_ADDRESSES: {
                                if (im.parsedFragments != im.totalFragments) {
                                    // wait for all
                                    break;
                                }
                                inputBuffer.position(MESSAGE_FRAGMENT_HEADER_LENGTH + 1);
                                final int numberOfRequestedAddresses = readShort(inputBuffer);
                                // send response
                                responseForRequestedAddresses(sender, numberOfRequestedAddresses, inputBuffer);

                                // remove it
                                releaseIncomplete(im, bufferCopied);
                                continue;
                            }

                            case MSG_TYPE_RESP_ADDRESSES: {
                                if (im.parsedFragments != im.totalFragments) {
                                    // wait for all
                                    break;
                                }
                                inputBuffer.position(MESSAGE_FRAGMENT_HEADER_LENGTH + 1);
                                final int numberOfAddresses = readShort(inputBuffer);

                                // restore received addresses
                                for (int i=0; i<numberOfAddresses; i++) {
                                    final Long adrId = readLong(inputBuffer);
                                    final String adrStr = readString(inputBuffer);

                                    final ArrayList<AddressWaiter> waiters = waitingForAddress.remove(adrId);
                                    if (waiters != null) {
                                        // have requesters
                                        final Address adr = Address.ensureSpecificAddress(adrId, adrStr);
                                        final boolean printMsg;
                                        if (DEBUG) {
                                            Integer cnt = debugAddressCounter.remove(adrId);
                                            if (cnt == null) {
                                                cnt = 1;
                                            } else {
                                                cnt = cnt + 1;
                                            }
                                            debugAddressCounter.put(adrId, cnt);
                                            if (cnt > 1) {
                                                System.err.println(adrId + " - "+adr.toString()+" - "+cnt+" times received");
                                                printMsg = true;
                                            } else {
                                                printMsg = false;
                                            }
                                        } else {
                                            printMsg = false;
                                        }

                                        for (final AddressWaiter addressWaiter : waiters) {
                                            final IncompleteMsg related = addressWaiter.im;
                                            related.addressTranslator[addressWaiter.missingId] = adr;
                                            related.numberOfMissingAddresses--;
                                            addressWaiter.release();

                                            if (related.numberOfMissingAddresses == 0) {
                                                // done, have all addresses parse the message
                                                processBuffer(related, related.fragmentSize * related.totalFragments, related.msgBuffer, related.bufInputStream, true, printMsg);
                                            }
                                        }

                                        // finally put array list to pool
                                        waiters.clear();
                                        arrayListAddressWaiterPool.addLast(waiters);
                                    }
                                }

                                // remove it
                                releaseIncomplete(im, bufferCopied);
                                continue;
                            }

                            default:
                                MessageTransport.logger.warning("Unknown message type: " + im.msgType);
                            // remove it
                            releaseIncomplete(im, bufferCopied);
                            continue;
                            }

                        }
                        // fill msg buffer if not filled yet
                        if (!bufferCopied) {
                            // copy buffer and put it to incomplete
                            inputBuffer.position(MESSAGE_FRAGMENT_HEADER_LENGTH);
                            if (useDirectBuffers) {
                                inputBuffer.get(im.msgBufferArray, MESSAGE_FRAGMENT_HEADER_LENGTH + fragmentPosition * fragmentSize, inputBuffer.remaining());
                            } else {
                                System.arraycopy(inputBuffer.array(), MESSAGE_FRAGMENT_HEADER_LENGTH, im.msgBufferArray, MESSAGE_FRAGMENT_HEADER_LENGTH + fragmentPosition * fragmentSize, inputBuffer.remaining());
                            }
                            addToIncomplete(im);
                        }
                    }
                } catch (IOException ex1) {
                }
            }
        } catch (Throwable ex) {
            MessageTransport.logger.severe("Datagram Message Transport Layer Throwable:\n" + ExceptionPrinter.toStringWithStackTrace(ex));
        }
        synchronized (stopLock) {
            finished = true;
            stopLock.notify();
        }
    }


    // ==================================================
    // Internal objects
    // ==================================================

    protected static final class ReadingBuffers {
        ByteBuffer readInputBuffer = null;
        ByteBufferInputStream readInputStream = null;
    }


    private static final class MsgToIgnore {
        private static final NonblockingPoolArrayFIFO<SoftReference<MsgToIgnore>> pool = new NonblockingPoolArrayFIFO<SoftReference<MsgToIgnore>>(2048);

        /**
         * Id of message to ignore
         */
        long msgId;

        /**
         * Last accessed timestamp millis
         */
        long timestamp;

        /**
         * Previous
         */
        MsgToIgnore prev;

        /**
         * Next
         */
        MsgToIgnore next;

        private MsgToIgnore() {

        }

        final static MsgToIgnore getMsgToIgnore(final long msgId) {
            for (;;) {
                final SoftReference<MsgToIgnore> sr = pool.pop();
                MsgToIgnore retVal;
                if (sr == null) {
                    retVal = new MsgToIgnore();
                } else {
                    retVal = sr.get();
                    if (retVal == null) {
                        continue;
                    }
                }
                retVal.msgId = msgId;
                return retVal;
            }
        }

        final void release() {
            prev = null;
            next = null;
            pool.push(new SoftReference<MsgToIgnore>(this));
        }
    }


    private static final class IncompleteMsg {
        private static final NonblockingPoolArrayFIFO<SoftReference<IncompleteMsg>> pool = new NonblockingPoolArrayFIFO<SoftReference<IncompleteMsg>>(2048);

        /**
         * Message unique identifier
         */
        long msgId;

        /**
         * Last accessed time-stamp
         */
        long timestamp;

        /**
         * Previous
         */
        IncompleteMsg prev;

        /**
         * Next
         */
        IncompleteMsg next;

        /**
         * Fragment size
         */
        int fragmentSize;

        /**
         * Total number of fragments
         */
        int totalFragments;

        /**
         * Parsed fragments
         */
        int parsedFragments = 0;

        /**
         * Number of all recipients, -1 if not known yet
         */
        int numberOfRecipients = -1;

        int numberOfLocalReceivers = -1;

        /**
         * Message local receivers, can be null if not known yet
         */
        MessageReceiver[] localReceivers = null;

        /**
         * Destination MTs, can be null. But iff receiver != null this must be != null too.
         */
        MessageTransportComponent[] destinationMts = null;

        /**
         * Msg buffer
         */
        ByteBuffer msgBuffer;

        /**
         * Buffer input stream
         */
        ByteBufferInputStream bufInputStream;

        /**
         * Msg buffer back-end array
         */
        byte[] msgBufferArray;

        byte msgType = -1;

        int numberOfTranslatorAddresses = -1;

        long[] addressDirectory = null;

        Address[] addressTranslator = null;

        int numberOfMissingAddresses = 0;

        short[] receiversIds = null;

        @SuppressWarnings("unused")
		int numberOfRequestedAddresses = -1;
        @SuppressWarnings("unused")
		long reqMsgId = -1;

        /**
         * Constructor
         *
         * @param msgId long
         * @param fragmentSize int
         * @param totalFragments int
         * @param recipientLength int
         */
        private IncompleteMsg() {
        }

        static final IncompleteMsg getIncompleteMsg(final long msgId, final int fragmentSize, final int totalFragments) {
            final int bufSize = MESSAGE_FRAGMENT_HEADER_LENGTH + fragmentSize * totalFragments + 1;

            for (;;) {
                final SoftReference<IncompleteMsg> sr = pool.pop();
                IncompleteMsg retVal;
                if (sr == null) {
                    retVal = new IncompleteMsg();
                    retVal.msgBuffer = ByteBuffer.allocate(bufSize);
                    retVal.bufInputStream = new ByteBufferInputStream(retVal.msgBuffer);
                    retVal.msgBufferArray = retVal.msgBuffer.array();
                } else {
                    retVal = sr.get();
                    if (retVal == null) {
                        continue;
                    }
                    if (retVal.msgBuffer.capacity() < bufSize) {
                        retVal.msgBuffer = ByteBuffer.allocate(bufSize);
                        retVal.bufInputStream = new ByteBufferInputStream(retVal.msgBuffer);
                        retVal.msgBufferArray = retVal.msgBuffer.array();
                    } else {
                        // clear buffer
                        retVal.msgBuffer.clear();
                    }
                }
                retVal.msgId = msgId;
                retVal.fragmentSize = fragmentSize;
                retVal.totalFragments = totalFragments;
                return retVal;
            }
        }

        final void release() {
            prev = null;
            next = null;
            parsedFragments = 0;
            numberOfRecipients = -1;
            numberOfLocalReceivers = -1;
            msgType = -1;
            numberOfTranslatorAddresses = -1;
            numberOfMissingAddresses = 0;

            numberOfRequestedAddresses = -1;
            reqMsgId = -1;

            pool.push(new SoftReference<IncompleteMsg>(this));
        }
    }

    private static final class OutputBuffers {
        private static final NonblockingPoolArrayFIFO<SoftReference<OutputBuffers>> pool = new NonblockingPoolArrayFIFO<SoftReference<OutputBuffers>>(ManagementFactory.getOperatingSystemMXBean().getAvailableProcessors()*2);

        /**
         * Output buffer
         */
        ByteBuffer outputBuffer;

        /**
         * Output stream
         */
        ByteBufferOutputStream outputStream;

        final AddressWriteCache addressWriter;

        /**
         * Can be created only locally
         * @throws IOException
         */
        private OutputBuffers() throws IOException {
            addressWriter = new AddressWriteCache();
            allocate(MessageTransport.INITAL_MESSAGE_BUFFER_SIZE);
        }

        static final OutputBuffers getOutputBuffers() throws IOException {
            for (;;) {
                final SoftReference<OutputBuffers> sr = pool.pop();
                if (sr == null) {
                    return new OutputBuffers();
                }
                OutputBuffers retVal = sr.get();
                if (retVal != null) {
                    return retVal;
                }
            }
        }

        final void allocate(final int capacity) {
            outputBuffer = ByteBuffer.allocateDirect(capacity);
            outputStream = new ByteBufferOutputStream(outputBuffer);
            addressWriter.reset();
        }


        final void release() {
            outputBuffer.clear();
            addressWriter.reset();
            pool.push(new SoftReference<OutputBuffers>(this));
        }
    }

    private static final class AddressWriteCache implements AddressWriter {
        private short nextId = 0;
        final LinkedHashMap<Long, Short> translator = new LinkedHashMap<Long, Short>();

        /* @internal
         * (non-Javadoc)
         * @see aglobe.platform.transport.AddressWriter#writeAddress(aglobe.container.transport.Address)
         */
        @Override
        public short writeAddress(final Address address) {
            final Long addressId = address.getAddressId();
            Short cand;
            if ((cand = translator.get(addressId)) != null) {
                return cand;
            }
            translator.put(addressId, nextId);
            address.keepAfterSent();
            return nextId++;
        }

        void reset() {
            translator.clear();
            nextId = 0;
        }
    }

    private static final class AddressReadCache implements AddressReader {
        Address[] addressTranslator;

        /* (non-Javadoc)
         * @see aglobe.platform.transport.AddressReader#readAddress(short)
         */
        @Override
        public Address readAddress(final short addressHandler) {
            return addressTranslator[addressHandler];
        }

    }

    private static final class AddressWaiter {
        private static final NonblockingPoolArrayFIFO<SoftReference<AddressWaiter>> pool = new NonblockingPoolArrayFIFO<SoftReference<AddressWaiter>>(1024);

        IncompleteMsg im;
        short missingId;

        private AddressWaiter() {

        }

        final static AddressWaiter getAddressWaiter(final IncompleteMsg im, final short missingId) {
            for (;;) {
                final SoftReference<AddressWaiter> sr = pool.pop();
                AddressWaiter retVal;
                if (sr == null) {
                    retVal = new AddressWaiter();
                } else {
                    retVal = sr.get();
                    if (retVal == null) {
                        continue;
                    }
                }
                retVal.im = im;
                retVal.missingId = missingId;
                return retVal;
            }
        }

        final void release() {
            this.im = null;
            pool.push(new SoftReference<AddressWaiter>(this));
        }
    }
}
