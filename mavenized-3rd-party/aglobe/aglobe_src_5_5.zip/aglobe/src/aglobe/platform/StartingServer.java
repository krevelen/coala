package aglobe.platform;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @internal
 * <p>Title: A-Globe</p>
 * <p>Description: Through this class next containers are started inside this AgentPlatform.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.19 $ $Date: 2010/12/03 12:29:26 $
 */
public final class StartingServer implements Runnable {
    /**
     * owner platform
     */
    private final Platform owner;

    /**
     * Listining UDP socket
     */
    private DatagramSocket socket = null;

    /**
     * true iff this platform is in the shutdown phase
     */
    private volatile boolean killing = false;

    /**
     * Starting server constructor
     * @param owner Platform - owner platform
     * @param platformNumber int - platform identifier number 0 - 99
     * @throws SocketException - throws if there is some problem
     */
    public StartingServer(Platform owner, int platformNumber) throws SocketException {
      this.owner = owner;
      // create new socket
      socket = new DatagramSocket(Platform.BASE_PLATFORM_PORT + platformNumber);
      socket.setSoTimeout(1000);
    }

    /**
     * Main method for starting server thread
     */
    @Override
	@SuppressWarnings("unchecked")
    public void run() {
      byte[] buf = new byte[10240];
      DatagramPacket dp = new DatagramPacket(buf, buf.length);
      while (!killing) {
        try {
          // wait for incoming starting datagram
          socket.receive(dp);
          // parse starting datagram
          ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(
              dp.getData(), 0, dp.getLength()));
          try {
            LinkedList<String> ll = (LinkedList<String>) in.readObject();
            String[] args = new String[ll.size()];
            for (int i = 0; i < ll.size(); i++) {
              String item = ll.get(i);
              args[i] = item;
            }
            byte[] replyBuf;
            try {
              // send status reply to the client
              Platform.readAgentServiceListAndStartContainer(args, 0);
              replyBuf = Platform.STARTED.getBytes();
            }
            catch (Exception ex1) {
              owner.logger.severe("Problem during starting new A-globe container:\n"+ex1.toString());
              // send exception back to the requester
              replyBuf = ex1.toString().getBytes();
            }
            DatagramPacket reply = new DatagramPacket(replyBuf, replyBuf.length,
                dp.getAddress(), dp.getPort());
            socket.send(reply);
          }
          catch (Exception ex) {
            ex.printStackTrace();
            // some problem with starting
          }
          dp = new DatagramPacket(buf, buf.length);
        }
        catch (SocketTimeoutException ex) {
          //timeout expire, no data waiting
        }
        catch (IOException ex) {
          Logger.getLogger("StartingServer").log(Level.SEVERE,
                                                 "Receiving exeption", ex);
          dp = new DatagramPacket(buf, buf.length);
        }
      }
    }

    /**
     * Stop starting server thread
     */
    public void kill() {
      killing = true;
    }
  }
