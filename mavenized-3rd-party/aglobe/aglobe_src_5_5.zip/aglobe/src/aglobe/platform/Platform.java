package aglobe.platform;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Method;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.SocketAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Timer;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.LookAndFeel;
import javax.swing.UIManager;

import aglobe.container.AgentContainer;
import aglobe.container.transport.Address;
import aglobe.ontology.AgentInfo;
import aglobe.ontology.AgentList;
import aglobe.ontology.Libraries;
import aglobe.ontology.LogConfiguration;
import aglobe.ontology.ServiceInfo;
import aglobe.ontology.ServiceList;
import aglobe.platform.thread.AglobeThreadPool;
import aglobe.platform.transport.MessageTransport;
import aglobe.util.AglobeXMLtools;
import aglobe.util.ExceptionPrinter;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: The main A-Globe class. By this class A-Globe Platform and Containers are started. </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.93 $ $Date: 2010/12/03 12:29:26 $
 */
public final class Platform {
    /**
     * Major A-globe version number
     */
    public static final int MAJOR_VERSION = 5;

    /**
     * Minor A-globe version number
     */
    public static final int MINOR_VERSION = 5;

    /**
     * @internal
     * Default platform number if no -platform parameter is specified.
     */
    public static final int DEFAULT_PLATFORM_NUBMER = 0;

    /**
     * @internal
     * A maximum allowed platform number for -platform parameter.
     */
    public static final int MAX_PLATFORM_NUMBER = 999;

    /**
     * @internal
     * Base starting server platform UDP port
     */
    public static final int BASE_PLATFORM_PORT = 6000;

    /**
     * @internal
     * Starting timeout, used when start new container remotely
     */
    public static final int STARTING_TIMEOUT = 8000;

    /**
     * Platform timer used for all containers running in this platform
     */
    public static Timer TIMER = new Timer();

    /**
     * @internal
     * Successful reply from container startup
     */
    public static final String STARTED = "Started";

    /**
     * @internal
     * Thread stack size used for each thread. Iff 0 default value will be used
     */
    public static long THREAD_STACK_SIZE = 0;

    /**
     * A default port of the platform message transport
     */
    private static final int DEFAULTPORT = 0;

    /**
     * @internal
     * If true Message transport layer will show all undelivered messages in the logs.
     */
    public static boolean SHOW_UNDELIVERED_MESSAGES;

    /**
     * Starting arguments
     */
    private String[] args;

    /**
     * Staring arguments as list
     */
    private List<String> params;

    /**
     * Current platform number
     */
    private int platformNumber;

    /**
     * Current starting server for listening requests for new containers
     */
    private StartingServer ss;

    /**
     * Starting server thread
     */
    private Thread ssThread;

    /**
     * Platform thread group
     */
    private static ThreadGroup platformThreadGroup = null;

    /**
     * Associated containers with it's names
     */
    private static ConcurrentHashMap<String,AgentContainer> containers = new ConcurrentHashMap<String, AgentContainer> ();

    /**
     * Hold information about initialized containers
     */
    private static LinkedHashMap<String, AgentContainer> initializedContainers = new LinkedHashMap<String, AgentContainer>();

    /**
     * Registered platform monitors
     */
    private static LinkedHashSet<PlatformMonitor> platformMonitors = new LinkedHashSet<PlatformMonitor>();

    /**
     * Registered containers monitors
     */
    private static LinkedHashSet<ContainerMonitor> containerMonitors = new LinkedHashSet<ContainerMonitor>();

    /**
     * Sync lock used for monitor reporting
     */
    private static ReentrantLock monitorLock = new ReentrantLock();

    /**
     * Platform logger
     */
    Logger logger = Logger.getLogger("Platform");

    /**
     * Sync used during platform shutdown
     */
    private static ReentrantLock waiterSync = new ReentrantLock();
    private static Condition waiterCondition = waiterSync.newCondition();
    
    private Integer exitCode = null;

    /**
     * @internal
     * private constructor called by main method
     * @param args String[] - starting arguments
     */
    public Platform(String[] args) {
        // load starting arguments
        params = Arrays.asList(args);

        if (params.indexOf("-noSkin") < 0) {
            // load skin
            try {
                ClassLoader cl = Platform.class.getClassLoader();
                final Class<?> cSkinLookAndFeel = cl.loadClass(
                      "com.l2fprod.gui.plaf.skin.SkinLookAndFeel");
                Class<?> cSkin = cl.loadClass("com.l2fprod.gui.plaf.skin.Skin");
                Object skin = null;
                try {
                    InputStream in = this.getClass().getResourceAsStream(
                          "atg.zip");
                    Method mLoadThemePack = cSkinLookAndFeel.getMethod(
                          "loadThemePack", new Class[] {InputStream.class});
                    skin = mLoadThemePack.invoke(null, in);
                }
                catch (Exception ex1) {
                }
                if (skin == null) {
                    Method mLoadThemePack = cSkinLookAndFeel.getMethod(
                          "loadThemePack", new Class[] {String.class});
                    try {
                        skin = mLoadThemePack.invoke(null,
                              "../../aglobe/skin/atg.zip");
                    }
                    catch (Exception ex2) {
                    }
                    if (skin == null) {
                        skin = mLoadThemePack.invoke(null,
                              "../aglobe/skin/atg.zip");
                    }
                }

                Method mSetSkin = cSkinLookAndFeel.getMethod("setSkin",
                      new Class[] {cSkin});
                mSetSkin.invoke(null, skin);
                final Object lnf = cSkinLookAndFeel.newInstance();

                UIManager.setLookAndFeel( (LookAndFeel) lnf);
                UIManager.addPropertyChangeListener(new PropertyChangeListener() {
                    @Override
					public void propertyChange(PropertyChangeEvent evt) {
                        Object newLF = evt.getNewValue();

                        if (! (cSkinLookAndFeel.isInstance(newLF))) {
                            try {
                                UIManager.setLookAndFeel( (LookAndFeel) lnf);
                            }
                            catch (Exception e) {

                            }
                        }
                    }
                });
                JFrame.setDefaultLookAndFeelDecorated(true);
                JDialog.setDefaultLookAndFeelDecorated(true);
            }
            catch (Exception ex) {
            }
        }

        int i;
        
        if (params.indexOf("-noLogManagement") < 0) {
        	// read logging properties
        	try {
        		LogManager.getLogManager().readConfiguration(Platform.class.
        				getResourceAsStream("logging.properties"));
        	}
        	catch (IOException ex) {
        	}
        	catch (SecurityException ex) {
        	}


        	// initialize aglobe logger
        	if ((i = params.indexOf("-logConf")) != -1) {
        		String logConf = params.get(i + 1);
        		// try read configuration
        		LogConfiguration logConfiguration = null;
        		try {
        			logConfiguration = (LogConfiguration) AglobeXMLtools.unmarshallJAXBObject(LogConfiguration.class, new File(logConf));
        		} catch (Exception ex3) {
        			logger.warning("Cannot parse Aglobe logger configuration due to:\n"+ExceptionPrinter.toStringWithStackTrace(ex3));
        		}
        		aglobe.util.Logger.initialize(logConfiguration, true);
        	} else {
        		aglobe.util.Logger.initialize(null, false);
        	}
        }

        if (params.indexOf("-showUndeliveredMessages") != -1) {
            Platform.SHOW_UNDELIVERED_MESSAGES = true;
        }
        else {
            Platform.SHOW_UNDELIVERED_MESSAGES = false;
        }

        if (params.indexOf("-help") != -1 || params.indexOf("-name") == -1) {
            // print usage help
            logger.info("\n\nA-Globe Platform V" + Platform.MAJOR_VERSION + "." +
                        Platform.MINOR_VERSION + "\n" +
                        "Author: David Sislak (sislakd@feld.cvut.cz)\n" +
                        "Agent Technology Center, Gerstner Laboratory: http://agents.felk.cvut.cz\n" +
                        "\nUsage:\n" +
                        "  java -jar AGlobe.jar -help (for this help)\n" +
                        "  java -jar AGlobe.jar -name {name} [optional_container_params] [optional_platform_params] [[agent_name:main_class] ...]\n\n" +
                        "Container parameters:\n" +
                        "  -platform {nnn}   = connect to or create platform number nnn <0-999> (defualt 0)\n" +
                        "  -name {name}      = set the 'name' as container name (mandatory parameter)\n" +
                        "  -gui              = show container GUI\n" +
                        "  -store {dir}      = root directory to use by Store\n" +
                        "  -containerStore   = container store information are stored directly in store root\n" +
                        "  -noStoreChange    = store of the agent container cannot be modified\n" +
                        "  -p {name}={value} = special parametr\n" +
                        "  -topics           = enable topics messaging (can be used only with permanent connection of platform)\n"+
                        "  -topicsPlatforms {aglobe://host1:port1/,aglobe://host2:port2/,...}  = should be used when autodetection doesn't work properly\n"+
                        "  -topicsNoKeepAlive= disable keep alive pings among services\n" +
                        "  -systemName {name}= system name used for system detection (default 'default')\n" +
                        "  -noCommand        = don't start command service\n" +
                        "  -noDirectory      = don't start Yellow pages service\n" +
                        "  -noMigration      = don't start library loader, deploy, library directory and agent mover services\n" +
                        "  -noStartingServer = don't listen for remote commands\n" +
                        "  -agentMonitor     = start agent monitoring service\n" +
                        "  -linkName {name}  = link name is used for automatical container lincation of container with the same name on the local network\n" +
                        "  -uniqueNames      = command line agent names and agent names in the store configuration are made unique\n" +
                        "  -agentList (path) =  path to the AgentList XML file containing the agents to be launched on startup, multiple parameter occurrences supported\n" +
                        "  -visibilityService= name of a class providing the Visibility Service, if not provided, RangeVisibilityService will be used as default one\n"+
                        "\nPlatform parameters (has effect only during startup of the first container in the platform):\n" +
                        "  -showUndeliveredMessages = show all undelivered messages in the platform log\n" +
                        "  -simulateMessageSize = message size in the CommunicationInfo will holds correct values for all messages and also for messages sent as refernce only as they are send by network link\n" +
                        "  -tcp              = start TCP message transport layer (has higher priority than -udp if used concurrently)\n" +
                        "  -udp              = start UDP message transport layer (default option for hardware visibility mode, otherwise tcp is default)\n" +
                        "  -mtu {nnnn}       = MTU in bytes used for the UDP & multicast message transport layer (default value 1500)\n" +
                        "  -ip a.b.c.d       = specifies one of the local IP address on which the platform will be operating\n" +
                        "  -port {nnn}       = message transport will accept incoming TCP/UDP unicast messages on port nnn\n" +
                        "  -enableMulticastMT= if specified it enables to use low level multicast protocol for sending multi-recipient messages (by default disabled)\n"+
                        "  -multicastAddr {IP:port} = specify multicast group IP and port where platform will send and receive multicast messages, if not specified IP and port is automatically generated from the first started container system name\n" +
                        "  -noLogManagement  = do not manage log messages by Aglobe (useful if Aglobe is started within other framework, e.g. Tomcat)\n" +
                        "  -logConf {conf_file} = logging configuration, if not specified all is log over INFO level\n" +
                        "  -noSkin           = do not apply aglobe skin\n" +
                        "\n[[service_name::main_class] ...]\n = list of services to start in the container" +
                        "\n[[agent_name:main_class] ...]\n = list of agents to start in the container" +
                        "  If any agents or services for startup are specified in the starting parameters, the agents and services from previous A-globe run are not started again.\n" +
                        "\n\n");
            // finalize aglobe logger
            aglobe.util.Logger.close();
            exitCode = 0;
        } else {
            // read platform number
            platformNumber = DEFAULT_PLATFORM_NUBMER;
            if ( (i = params.indexOf("-platform")) != -1) {
                platformNumber = Integer.parseInt(params.get(i + 1));
                if (platformNumber < 0 || platformNumber > MAX_PLATFORM_NUMBER) {
                    logger.severe(
                            "Platform number must be number between 0 and "+MAX_PLATFORM_NUMBER);
                    // finalize aglobe logger
                    aglobe.util.Logger.close();
                    exitCode = 1;
                }
            }

            this.args = args;
        }
    }

    private static void reinitStaticVariables() {
        THREAD_STACK_SIZE = 0;
        SHOW_UNDELIVERED_MESSAGES = false;
        platformThreadGroup = null;
        containers = new ConcurrentHashMap<String, AgentContainer> ();
        initializedContainers = new LinkedHashMap<String, AgentContainer>();
        platformMonitors = new LinkedHashSet<PlatformMonitor>();
        containerMonitors = new LinkedHashSet<ContainerMonitor>();
        monitorLock = new ReentrantLock();
        waiterSync = new ReentrantLock();
        waiterCondition = waiterSync.newCondition();

        TIMER.cancel();
        TIMER = new Timer();
    }

    /**
     * @internal
     * Main starting method for A-globe
     * @param args String[] - starting arguments
     */
    public static void main(String[] args) {

        final int retVal = internalMain(args);

        // finalize aglobe logger
        aglobe.util.Logger.close();

        System.exit(retVal);
    }

    /**
     * @internal
     * Allows for restarting the platform completely without the need to
     * restart JVM.
     * @param args A-globe starting arguments.
     */
    public static int internalMain(String[] args) {
        informPlatformMonitors(PlatformMonitor.PlatformState.STARTED);

        // create platform object
        Platform platform;
        platform = new Platform(args);
        if (platform.exitCode == null) {
            platform.run();
        }

        informPlatformMonitors(PlatformMonitor.PlatformState.STOPPED);
        reinitStaticVariables();
        if (platform.exitCode == null) {
            return 0;
        } else {
            return platform.exitCode;
        }
    }

    /**
     * @internal
     * Returns platform thread group
     * @return ThreadGroup
     */
    public static ThreadGroup getPlatformThreadGroup() {
        return platformThreadGroup;
    }

    /**
     * Returns all containers on platform
     * @return ThreadGroup
     */
    public static Collection<AgentContainer> getContainers() {
        return new ArrayList<AgentContainer>(containers.values());
    }

    /**
     * Return specified container
     * @param containerName String
     * @return AgentContainer - null if container not running here
     */
    public static AgentContainer getContainer(String containerName) {
        return containers.get(containerName);
    }

    /**
     * @internal
     * Platform body started from the main method
     */
    public void run() {
        // Create platform Thread
        assert platformThreadGroup == null;
        platformThreadGroup = new ThreadGroup("Platform: " + platformNumber);
        // try to create starting server listener on specified port
        try {
            // check for the noStartingServer parameter
            boolean shouldCreateStartingServer = params.indexOf("-noStartingServer") == -1;

            if (shouldCreateStartingServer) {
                ss = new StartingServer(this, platformNumber);
            }

            // starting server created it means that this is first container for that platform
            logger.info("Creating new platform number: " + platformNumber);

            // info message
            if (!Platform.SHOW_UNDELIVERED_MESSAGES) {
                logger.info("Undelivered messages will not be logged by Message Transport Layer (use '-showUndeliveredMessages').");
            }

            // initialize Thread pool
            AglobeThreadPool.initialize();

            // create starting server thread
            if (shouldCreateStartingServer) {
                ssThread = AglobeThreadPool.getThread(platformThreadGroup, ss, "StartingServer of platform number " + platformNumber);
                ssThread.setPriority(Math.min(Thread.NORM_PRIORITY + 2, Thread.MAX_PRIORITY));
                ssThread.start();
            }

            // prepare message transport parameters
            int i;
            int agentsFrom = 0;
            int port = DEFAULTPORT;
            boolean hwMode = false;
            boolean useTcp = true;
            int mtu = 0; // 0 means use default
            boolean useSimulatedMessageSize = false;

            // read requested container port
            if ((i = params.indexOf("-port")) != -1) {
                try {
                    port = Integer.parseInt(params.get(i + 1));
                }
                catch (Exception ex2) {
                    logger.warning("-port option has no number, use default option");
                }
            }

            // read requested local IP
            InetAddress useThisLocalAddress = null;
            if ((i = params.indexOf("-ip")) != -1) {
                String ip = params.get(i+1);
                try {
                    useThisLocalAddress = InetAddress.getByName(ip);
                    SocketAddress sa = new InetSocketAddress(useThisLocalAddress, 0);
                    try {
                        ServerSocket ss = new ServerSocket();
                        ss.bind(sa);
                        ss.close();
                        logger.info("Will operate on specified IP: "+ip);
                    } catch (IOException ex9) {
                        logger.warning("Specified IP is not local addresss: "+ip);
                        useThisLocalAddress = null;
                    }
                } catch (UnknownHostException ex8) {
                    logger.warning("Wrong IP specified: "+ip);
                }
            }

            // check for the hardwareVisibility parameter
            if ((i = params.indexOf("-hardwareVisibility")) != -1) {
                hwMode = true;
                useTcp = false;
            }

            // check for the UDP transport parameter
            if ((i = params.indexOf("-udp")) != -1) {
                useTcp = false;
            }

            // check for the TCP transport parameter
            if ((i = params.indexOf("-tcp")) != -1) {
                useTcp = true;
            }

            // load mtu if necessary
            if ((!useTcp) && (i = params.indexOf("-mtu")) != -1) {
                try {
                    mtu = Integer.parseInt(params.get(i + 1));
                    if ( (mtu < 576) || (mtu > 65535)) {
                        mtu = 0;
                        logger.warning("MTU is out of allowed range 576 - 65535. Use default option.");
                    }
                }
                catch (Exception ex4) {
                    logger.warning(
                          "-mtu option has no number parameter, use default option");
                }
            }

            // log that message transport will use UDP layer
            if (!useTcp) {
                logger.info("The message transport layer will use UDP for message transmission (MTU=" +
                      ((mtu == 0) ? MessageTransport.DEFAULT_MTU : mtu) + ").");
            }

            // read system name otherwise use default
            String systemName = AgentContainer.DEFAULT_SYSTEM_NAME;
            if ((i = params.indexOf("-systemName")) != -1) {
                try {
                    systemName = params.get(i + 1);
                }
                catch (Exception ex5) {
                    logger.warning("-systemName has no {name} specified, use default option");
                }
            }

            boolean enabledMulticastMT = false;
            if (params.indexOf("-enableMulticastMT") != -1) {
                enabledMulticastMT = true;
            }

            // read multicast IP address group
            InetAddress multicastGroup = null;
            int multicastPort = 0;
            if (enabledMulticastMT) {
                if ((i = params.indexOf("-multicastAddr")) != -1) {
                    try {
                        String tmp = params.get(i + 1);
                        String parts[] = tmp.split(":");
                        if (parts.length != 2) {
                            throw new Exception();
                        }
                        agentsFrom = i + 2;
                        multicastGroup = InetAddress.getByName(parts[0]);
                        multicastPort = Integer.parseInt(parts[1]);
                        if ((multicastPort < 0) || (multicastPort > 65535)) {
                            throw new Exception();
                        }
                        byte[] addr = multicastGroup.getAddress();
                        int first = addr[0] & 0xff;
                        if ((first < 224) || (first > 239)) {
                            logger.warning("No multicast address specified in -multicast attribute, will use automatically generated one");
                            multicastGroup = null;
                        } else {
                            if ((first == 224) && (addr[1] == 0) &&
                                (addr[2] == 0)) {
                                logger.warning("Multicast address from reserved space was specified in -multicast attribute, will use automatically generated one");
                                multicastGroup = null;
                            }
                        }
                    } catch (Exception ex6) {
                        logger.warning("-multicast has no {IP:port} specified or in wrong format, will use automatically generated one");
                        multicastGroup = null;
                    }
                }
                if (multicastGroup == null) {
                    // automatically generate multicast address
                    int systemNameHash = systemName.hashCode();
                    try {
                        multicastGroup = InetAddress.getByAddress(new byte[] {(byte)
                                233, (byte) ((systemNameHash >> 24) & 0xff),
                                (byte) ((systemNameHash >> 16) & 0xff),
                                (byte) ((systemNameHash >> 8) & 0xff)});
                        multicastPort = systemNameHash & 0xffff;
                    } catch (Exception ex7) {
                        ex7.printStackTrace();

                        // exit platform
                        ss.kill();
                        AglobeThreadPool.finish();
                        exitCode = 1;
                        return;
                    }
                }
            }

            // read parameter for configuration with simulated message size
            if (params.indexOf("-simulateMessageSize") != -1) {
                useSimulatedMessageSize = true;
                logger.info("Messages sent as reference will have reported true size which they will have while sending by standard low level transmission depending on the underlying level");
            }

            // initialize message transport layer
            try {
                MessageTransport.initialize(useThisLocalAddress, port,
                                            this,
                                            useTcp, hwMode, mtu, enabledMulticastMT, multicastGroup,
                                            multicastPort,useSimulatedMessageSize);

                try {
                    readAgentServiceListAndStartContainer(args, agentsFrom);

                    informPlatformMonitors(PlatformMonitor.PlatformState.INITIALIZED);

                    // wait for finish all containers
                    waitForFinish();
                    informPlatformMonitors(PlatformMonitor.PlatformState.SHUTTING_DOWN);

                    logger.info("A-globe platform " + platformNumber + " removed.");
                }
                catch (Exception ex1) {
                    logger.severe("Couldn't start container.");
                }
            }
            catch (Exception ex3) {
                ex3.printStackTrace();
                logger.severe("Problem during message platform initialization: " + ex3);
            }
        }
        catch (SocketException ex) {
            // it means that there is some existing platform with requested number
            // if couldn't start server listener , try start first container in existing platform
            startRemote();
        }

        // wait 1 second for termination
        synchronized (this) {
            try {
                wait(1000);
            } catch (InterruptedException e) {
            }
        }
        
        MessageTransport.shutdown();

        // remove starting server
        if (ss != null) {
            ss.kill();
            ss = null;
        }

        // finalize thread pool
        AglobeThreadPool.finish();
        
    }

    /**
     * @internal
     * Used for tests - do not use for a regular operation.
     * Starts a new container on the platform based on the arguments, including
     * agents and services specified.
     *
     * @param args Container command line.
     */
    public static void startTestContainer(String[] args) throws Exception {
        readAgentServiceListAndStartContainer(args, 0);
    }

    /**
     * @internal
     * Reads the list of agents and services in the parameters and starts the container
     *
     * @param args String[]
     * @param agentsFrom int
     * @throws Exception
     */
    static void readAgentServiceListAndStartContainer(String[] args, int agentsFrom) throws Exception {
        // prepare agents and services for startup if there are some
        AgentList al = new AgentList();
        ServiceList sl = new ServiceList();
        int j;
        for (j = args.length - 1; j >= 0; j--) {
            if (j < agentsFrom) {
                break;
            }
            String par = args[j];
            String[] twin = par.split("::");
            if (twin.length == 2) {
                String sname = twin[0];
                String mainclass = twin[1];
                ServiceInfo si = new ServiceInfo();
                si.setName(sname);
                si.setMainClass(mainclass);
                Libraries lib = new Libraries();
                si.setLibraries(lib);
                sl.getServiceInfo().add(si);
            } else {
                twin = par.split(":");
                if (twin.length == 2) {
                    String aname = twin[0];
                    String mainclass = twin[1];
                    AgentInfo ai = new AgentInfo();
                    ai.setName(aname);
                    ai.setReadableName(aname);
                    ai.setMainClass(mainclass);
                    Libraries lib = new Libraries();
                    ai.setLibraries(lib);
                    al.getAgentInfo().add(ai);
                } else {
                    break;
                }
            }
        }
        if (al.getAgentInfo().size() == 0) {
            al = null;
        }
        if (sl.getServiceInfo().size() == 0) {
            sl = null;
        }
        // start first container
        startNewContainer(args, al, sl, null);
    }

    /**
     * Waits for finishing all containers in this agent platform
     */
    private void waitForFinish() {
        waiterSync.lock();
        try {
            while (true) {
                try {
                    waiterCondition.await();
                } catch (InterruptedException ex) {
                }
                if (containers.size() == 0) {
                    break;
                }
            }
        } finally {
            waiterSync.unlock();
        }
    }

    /**
     * @internal
     * Called by agent container, when agent container finished
     *
     * @param containerName String
     */
    public static void containerFinishedNotify(String containerName) {
        waiterSync.lock();
        try {
            containers.remove(containerName);
            waiterCondition.signal();
        } finally {
            waiterSync.unlock();
        }
    }

    /**
     * Start new agent container in other existing agent platform
     */
    private void startRemote() {
        logger.info("Trying to start new container in the existing platform: " +
                    platformNumber);
        LinkedList<String> ll = new LinkedList<String> (Arrays.asList(args));
        try {
            // send starting datagram
            DatagramSocket socket = new DatagramSocket();
            socket.setSoTimeout(Platform.STARTING_TIMEOUT);
            ByteArrayOutputStream outBytes = new ByteArrayOutputStream(10240);
            new ObjectOutputStream(outBytes).writeObject(ll);
            byte[] outBuf = outBytes.toByteArray();
            DatagramPacket dp = new DatagramPacket(outBuf, outBuf.length,
                  InetAddress.getLocalHost(),
                  BASE_PLATFORM_PORT +
                  platformNumber);
            socket.send(dp);

            // wait for reply
            byte[] inBuf = new byte[1024];
            DatagramPacket recdp = new DatagramPacket(inBuf, inBuf.length);
            try {
                socket.receive(recdp);
                String response = new String(recdp.getData(), 0,
                                             recdp.getLength());
                if (!response.equals(STARTED)) {
                    logger.severe("The container wasn't started with folowing error message:\n" + response);
                    
                    exitCode = 1;
                    return;
                }
                logger.info("The container was started on platform: " + platformNumber);

                exitCode = 0;
                return;
            }
            catch (IOException ex) {
                logger.severe("The container wasn't started during timeout " + Platform.STARTING_TIMEOUT + " ms.");

                exitCode = 1;
                
                return;
            }

        }
        catch (Exception ex) {
            logger.severe("Couldn't create new socket.");

            exitCode = 1;
            return;
        }
    }

    /**
     * @internal
     * Start new agent container in my agent platform
     *
     * @param args String[] - starting parameters
     * @param agentList AgentList - start these agents. Could be null
     * @param serviceList ServiceList - start these services. Could be null
     * @param librarySourceContainer Address - source container for the libraries. Can be null.
     * @throws Exception - throws if there is some problem with starting new
     *   agent container
     */
    public static void startNewContainer(String[] args, AgentList agentList,
                                         ServiceList serviceList,
                                         Address librarySourceContainer) throws Exception {
        startNewContainer(args, agentList, serviceList, librarySourceContainer, false);
    }

    /**
     * @internal
     * Start new agent container in my agent platform
     *
     * @param args String[]
     * @param agentList AgentList
     * @param serviceList ServiceList
     * @param librarySourceContainer Address
     * @param waitForPreviousFinish boolean - iff true the thread will be blocked until previous container with same name
     * is not removed
     * @throws Exception
     */
    public static void startNewContainer(String[] args, AgentList agentList,
                                         ServiceList serviceList,
                                         Address librarySourceContainer,
                                         boolean waitForPreviousFinish) throws
          Exception {

        // read container name
        List<String> params = Arrays.asList(args);
        int i = params.indexOf("-name");
        if (i == -1) {
            throw new Exception("Missing container name starting attribute");
        }
        String cname;
        try {
            cname = params.get(i + 1);
        }
        catch (Exception ex) {
            throw new Exception(
                  "Wrong format of container name starting attribute");
        }
        // test container name if it is unique
        if (containers.containsKey(cname)) {
            if (!waitForPreviousFinish) {
                throw new Exception("Container with name '" + cname + "' already exists.");
            }
            else {
                // block until previous container is removed
                waiterSync.lock();
                try {
                    while (true) {
                        try {
                            waiterCondition.await(5, TimeUnit.SECONDS);
                        } catch (InterruptedException ex) {
                        }
                        if (!containers.containsKey(cname)) {
                            break;
                        }
                    }
                } finally {
                    waiterSync.unlock();
                }
            }
        }

        // create new agent container thread
        AgentContainer ac = new AgentContainer(args, agentList, serviceList, librarySourceContainer);
        containers.put(cname, ac);
    }

    /**
     * Register platform monitor
     * @param monitor PlatformMonitor
     */
    public static void registerPlatformMonitor(PlatformMonitor monitor) {
        monitorLock.lock();
        try {
            platformMonitors.add(monitor);
        } finally {
            monitorLock.unlock();
        }
    }

    /**
     * Unregister platform monitor
     * @param monitor ContainerMonitor
     */
    public static void deregisterPlatformMonitor(PlatformMonitor monitor) {
        monitorLock.lock();
        try {
            platformMonitors.remove(monitor);
        } finally {
            monitorLock.unlock();
        }
    }

    private static void informPlatformMonitors(PlatformMonitor.PlatformState currentState) {
        monitorLock.lock();
        try {
            for (PlatformMonitor monitor : platformMonitors)
                monitor.platformStateChanged(currentState);
        } finally {
            monitorLock.unlock();
        }
    }

    /**
     * Register container monitor
     * @param monitor ContainerMonitor
     */
    public static void registerContainerMonitor(ContainerMonitor monitor) {
        monitorLock.lock();
        try {
            containerMonitors.add(monitor);
            for (AgentContainer elem : initializedContainers.values()) {
                monitor.containerStarted(elem);
            }
        } finally {
            monitorLock.unlock();
        }
    }

    /**
     * Deregister container monitor
     * @param monitor ContainerMonitor
     */
    public static void deregisterContainerMonitor(ContainerMonitor monitor) {
        monitorLock.lock();
        try {
            containerMonitors.remove(monitor);
        } finally {
            monitorLock.unlock();
        }
    }

    /**
     * @internal
     * This method is called by Aglobe container notifying that the container is initialized
     * @param container AgentContainer
     */
    public static void containerInitialized(AgentContainer container) {
        monitorLock.lock();
        try {
            for (ContainerMonitor elem : containerMonitors) {
                elem.containerStarted(container);
            }
            initializedContainers.put(container.getContainerName(), container);
        } finally {
            monitorLock.unlock();
        }
    }

    /**
     * @internal
     * This method is called by Aglobe container notifying that the container is being shutting down
     * @param container AgentContainer
     */
    public static void containerShuttingDown(AgentContainer container) {
        monitorLock.lock();
        try {
            String containerName = container.getContainerName();
            for (ContainerMonitor elem : containerMonitors) {
                elem.containerRemoved(containerName);
            }
            initializedContainers.remove(containerName);
        } finally {
            monitorLock.unlock();
        }

    }

    /**
     * @internal
     * This method kills all containers at the platform. It should be called only once
     */
    public static void killPlatform() {
        for (AgentContainer agentContainer : containers.values()) {
            agentContainer.shutdown();
        }
    }
}
