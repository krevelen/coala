package examples.agent.multicast;

import aglobe.container.agent.*;
import aglobe.ontology.AgentInfo;
import aglobe.ontology.Message;
import aglobe.container.transport.Address;
import java.util.LinkedHashSet;
import aglobe.ontology.MessageConstants;
import aglobe.service.directory.DirectoryListener;
import aglobe.service.directory.DirectoryRecord;
import aglobe.service.directory.DirectoryService;
import aglobe.container.transport.*;

/**
 * <p>Title: A-Globe</p>
 *
 * <p>Description: Multicast sender agent is used for testing A-globe multicast
 * messaging. When button is pressed, the multicast message to all visible
 * MulticastReceiver agents is sent.</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.9 $ $Date: 2010/08/04 11:48:06 $
 */
public class MulticastSender
      extends Agent {
    private static final long serialVersionUID = -3362342620680487206L;

    /**
     * Service used for finding multicast receivers.
     */
    public static final String MULTICAST_TESTER = "MULTICAST_TESTER";

    /**
     * agent GUI
     */
    public MulticastSenderGUI gui;

    /**
     * Directory shell
     */
    private DirectoryService.Shell dirShell;

    /**
     * Known receivers
     */
    private LinkedHashSet<Address> receivers = new LinkedHashSet<Address>();

    /**
     * Agent's initialization method.
     *
     * @param ai Agent should get its name from there.
     * @param initState This parameter can be used if this method is
     *   overriden. Can have values: isCREATED - an agent is created
     *   isRESTARTED - an agent is restarted from autorun configuration
     *   isMOVED - an agent is moved from another container isCLONED - an
     *   agent is clonned from its mother agent isMOVEFAILED - agent's
     *   movement was unsuccessful
     */
    @Override
    public void init(AgentInfo ai, int initState) {
        gui = new MulticastSenderGUI(this);

        dirShell = (DirectoryService.Shell)getContainer().getServiceManager().getService(this, DirectoryService.SERVICENAME);
        if (dirShell == null) {
            logSevere("Cannot find directory service.");
            stop();
            return;
        }

        dirShell.subscribe(new DirectoryListener() {
            @Override
			public void handleNewRegister(String containerName,
                                          DirectoryRecord[] records,
                                          String matchingFilter) {
            }

            @Override
			public void handleDeregister(String containerName,
                                         DirectoryRecord[] records,
                                         String matchingFilter) {
            }

            @Override
			public void handleVisible(String containerName,
                                      DirectoryRecord[] records,
                                      String matchingFilter) {
                // add to the receiver list
                for (DirectoryRecord elem : records) {
                    receivers.add(elem.address);
                }
            }

            @Override
			public void handleInvisible(String containerName,
                                        DirectoryRecord[] records,
                                        String matchingFilter) {
                // remove from the receiver list
                for (DirectoryRecord elem : records) {
                    receivers.remove(elem.address);
                }
            }

            @Override
			public void addEvent(Runnable e) {
                MulticastSender.this.addEvent(e);
            }
        }, MULTICAST_TESTER);
    }

    /**
     * This method must be declared by the child class to handle an incoming
     * messsage.
     *
     * @param m The message.
     */
    @Override
	public void handleIncomingMessage(Message m) {
        logSevere("Unexpected incoming message: "+m);
        m.release();
    }

    /**
     * Send testing multicast message
     */
    void sendMulticastMessage() {
        if (receivers.size() == 0) {
            logWarning("No receivers");
            return;
        }
        Message m = Message.newInstance(MessageConstants.INFORM, getAddress(), receivers);
        m.setContent("Multicast test message");
        try {
            sendMessage(m);
        }
        catch (InvisibleContainerException ex) {
        }
        m.release();
    }
}
