package examples.agent.multicast;

import aglobe.container.agent.*;
import aglobe.ontology.Message;
import aglobe.ontology.AgentInfo;
import aglobe.service.directory.*;

/**
 * <p>Title: A-Globe</p>
 *
 * <p>Description: Multicast receiver agent is used as a receiver part for the
 * multicast messages sent by Multicast sender agent. All received messages are
 * logged to the gui.
 * </p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.9 $ $Date: 2010/08/04 11:48:06 $
 */
public class MulticastReceiver
      extends Agent {
    private static final long serialVersionUID = 7559789152274706266L;

    /**
     * GUI
     */
    public MulticastReceiverGUI gui;

    /**
     * Directory shell
     */
    private DirectoryService.Shell dirShell;

    /**
     * Handles incoming messages
     * @param m Message
     */
    @Override
	public void handleIncomingMessage(Message m) {
        gui.logString(m.toString());
        m.release();
    }

    /**
     * Agent's initialization method.
     *
     * @param ai Agent should get its name from there.
     * @param initState This parameter can be used if this method is
     *   overriden. Can have values: isCREATED - an agent is created
     *   isRESTARTED - an agent is restarted from autorun configuration
     *   isMOVED - an agent is moved from another container isCLONED - an
     *   agent is clonned from its mother agent isMOVEFAILED - agent's
     *   movement was unsuccessful
     */
    @Override
    public void init(AgentInfo ai, int initState) {
        gui = new MulticastReceiverGUI(this);

        dirShell = (DirectoryService.Shell)getContainer().getServiceManager().getService(this, DirectoryService.SERVICENAME);
        if (dirShell == null) {
            logSevere("Cannot find directory service.");
            stop();
            return;
        }

        try {
            dirShell.register(this,
                              new String[] {MulticastSender.MULTICAST_TESTER});
        }
        catch (DirectoryException ex) {
            ex.printStackTrace();
        }
    }
}
