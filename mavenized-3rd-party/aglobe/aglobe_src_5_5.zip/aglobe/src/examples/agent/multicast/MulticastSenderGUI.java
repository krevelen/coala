package examples.agent.multicast;

import javax.swing.JButton;
import java.awt.GridBagLayout;
import java.awt.*;
import aglobe.util.gui.RememberPositionJFrame;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * <p>Title: A-Globe</p>
 *
 * <p>Description: Multicast sender graphics user interface with one button
 * for sending multicast message</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.5 $ $Date: 2010/08/04 11:48:06 $
 */
public class MulticastSenderGUI extends RememberPositionJFrame {
    private static final long serialVersionUID = 2241789501294744075L;

    /**
     * GUI owner
     */
    private MulticastSender owner;

    JButton jButton1 = new JButton();
    GridBagLayout gridBagLayout1 = new GridBagLayout();

    /**
     * Constructor
     * @param owner MulticastSender
     */
    public MulticastSenderGUI(MulticastSender owner) {
        super(owner);
        this.owner = owner;
        try {
            jbInit();
            setTitle("Multicast sender");
            pack();
            setVisible(true);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        jButton1.setText("Send multicast message");
        jButton1.addActionListener(new ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                jButton1_actionPerformed(e);
            }
        });
        this.getContentPane().setLayout(gridBagLayout1);
        this.getContentPane().add(jButton1,
                                  new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
              , GridBagConstraints.EAST, GridBagConstraints.NONE,
              new Insets(0, 0, 0, 0), 0, 0));
    }

    /**
     * @param e
     */
    public void jButton1_actionPerformed(ActionEvent e) {
        owner.addEvent(new Runnable() {
            @Override
			public void run() {
                owner.sendMulticastMessage();
            }
        });
    }

}
