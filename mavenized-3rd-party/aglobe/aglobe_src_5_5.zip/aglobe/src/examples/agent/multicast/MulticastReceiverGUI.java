package examples.agent.multicast;

import java.awt.GridBagLayout;
import java.awt.*;
import aglobe.util.gui.SearchableTextArea;
import aglobe.util.gui.RememberPositionJFrame;

/**
 * <p>Title: A-Globe</p>
 *
 * <p>Description: agent platform A-Globe</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.4 $ $Date: 2008/11/23 09:14:13 $
 */
public class MulticastReceiverGUI
      extends RememberPositionJFrame {
    private static final long serialVersionUID = 2308849741533892339L;
    GridBagLayout gridBagLayout1 = new GridBagLayout();
    SearchableTextArea jTextArea1 = new SearchableTextArea();

    public MulticastReceiverGUI(MulticastReceiver owner) {
        super(owner);
        try {
            jbInit();
            setTitle("Multicast receiver");
            pack();
            setVisible(true);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    private void jbInit() throws Exception {
        this.getContentPane().setLayout(gridBagLayout1);
        this.getContentPane().add(jTextArea1,
                                  new GridBagConstraints(0, 0, 1, 1, 0.1, 0.1
              , GridBagConstraints.CENTER, GridBagConstraints.BOTH,
              new Insets(0, 0, 0, 0), 0, 0));
    }

    /**
     * Log message
     * @param toLog String
     */
    void logString(String toLog) {
        jTextArea1.appendLine(toLog);
    }
}
