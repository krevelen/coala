package examples.agent.benchmark;

import aglobe.container.transport.*;
import aglobe.ontology.*;
import aglobe.service.directory.*;

import java.util.TimerTask;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2007</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author Milan Rollo
 * @version $Revision$ $Date$
 */
public class OtherAgentRecord {

    private BenchmarkAgent owner;
    // name of the agent (name of the container!)
    private String name;
    // address of the agent
    private Address address;
    // agent is visible
    private boolean visible = true;
    // send messages to this agent
    private boolean communicationEnabled = false;
    // size of 1kB
    public static final int kB = 1024;

    // timer that checks time of the last received ack
    private TimerTask ackResponseTimerTask;
    private long lastAckTime; // millis

    // traffic counters
    private long totalAckSend;
    private long totalAckSendSize;

    private long totalMsgSend;
    private long totalMsgSendSize;

    private long totalAckReceived;
    private long totalAckReceivedSize;

    private long totalMsgReceived;
    private long totalMsgReceivedSize;

    private long totalMsgFailed;
    private long totalMsgFailedSize;

    private long snapshotSend;
    private long snapshotReceived;
    private long snapshotFailed;

    private long intervalSendSize;
    private long intervalReceivedSize;
    private long intervalFailedSize;

    // unique message Id
    private int msgId = 0;

    // last acknowledged message Id
    private int lastAckMessageId = 0;

    private int messageSize;

    private int ackSize;

    /**
     * Constructor
     *
     * @param owner BenchmarkAgent
     * @param record DirectoryRecord
     */
    public OtherAgentRecord(BenchmarkAgent owner, DirectoryRecord record) {
        this.owner = owner;
        this.address = record.address;
        this.name = record.containerName; // each agent has to run in separate container
    }

    public boolean isVisible() {
        return visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public boolean isCommunicationEnabled() {
        return communicationEnabled;
    }

    public void setCommunicationEnabled(boolean communicationEnabled) {
        this.communicationEnabled = communicationEnabled;
    }

    public Address getAddress() {
        return address;
    }

    public String getName() {
        return name;
    }

    // total outgiong traffic is test messages size + acknowledgements size
    public long getSendTotal(){
        return (totalMsgSendSize + totalAckSendSize)/kB;
    }

    // total incomming traffic is test messages size + acknowledgements size
    public long getReceivedTotal(){
        return (totalMsgReceivedSize + totalAckReceivedSize)/kB;
    }

    // size of the traffic failed
    public long getFailedTotal(){
        return totalMsgFailedSize/kB;
    }

    // traffic during the last interval
    public long getSendInterval(){
        return intervalSendSize/kB;
    }

    public long getReceivedInterval(){
        return intervalReceivedSize/kB;
    }

    public long getFailedInterval(){
        return intervalFailedSize/kB;
    }

    /**
     * Return new message Id
     * @return int
     */
    private int getMsgId(){
        return ++msgId;
    }

    /**
     * Clear important values
     */
    public void clearValues(){
        msgId = 0;
        lastAckMessageId = 0;
        messageSize = 0;
    }

    public void clearGUI(){
        totalAckSend = 0;
        totalAckSendSize = 0;
        totalAckReceived = 0;
        totalAckReceivedSize = 0;
        totalMsgFailed = 0;
        totalMsgFailedSize = 0;
        totalMsgReceived = 0;
        totalMsgReceivedSize = 0;
        totalMsgSend = 0;
        totalMsgSendSize = 0;
        snapshotSend = 0;
        snapshotFailed = 0;
        snapshotReceived = 0;
    }

    /**
     * Process test message from the agent
     * @param m Message
     */
    public void processMessage(Message m){
        // increase total number of messages received from this agent (incomming traffic)
        totalMsgReceived++;
        // increase total size of messages received from this agent (incomming traffic)
        int size = m.getMessageSize();
        if (size > 0) {
            totalMsgReceivedSize+=size;
        }
        // send acknowledge back to this agent
        sendAck(m);
    }

    /**
     * Process acknowledge
     * @param m Message
     */
    public void processAck(Message m){
        // increase total number of acks received from this agent (incomming traffic)
        totalAckReceived++;
        // increase total size of acks received from this agent (incomming traffic)
        if (ackSize <= 0) {
            // predict size of the ack only once - size won't be precise,
            // but the performance increases heavily
            ackSize = m.getMessageSize();
        }
        if (ackSize > 0) {
            totalAckReceivedSize+=ackSize;
        }
        // get id of the acknowledged message
        int id = Integer.parseInt(m.getInReplyTo());
        countFailure(id);
    }

    /**
     * Send messages according to the id of the acknowledgement
     *
     * @param id int Id of the message this ack replies to
     */
    private void countFailure(int id){
        // if id <= last ack ID, message should be already counted into the failed msgs
        if (id <= lastAckMessageId) {
            owner.logWarning("OOPS, received message with id <= lastAckId!");
            return;
        }
        // get the number of skipped messages
        int skippedMsgs = id - lastAckMessageId;
        if (skippedMsgs > 1) {
            // if number is > 1 some message was skipped
            totalMsgFailed+=(skippedMsgs-1);
            totalMsgFailedSize+=(skippedMsgs-1)*messageSize;
        }
        // set last ack id to id of this message
        lastAckMessageId = id;
        // set new last ack time
        lastAckTime = System.currentTimeMillis();
        if (!owner.gui.isMulticastEnabled()) {
            // unicast - resend skipped messages immediatelly
            resendMessages(skippedMsgs);
        }
    }

    /**
     * Resend messages if some were skipped
     * @param skippedMsgs int
     */
    private void resendMessages(int skippedMsgs) {
        if (skippedMsgs > owner.windowLength) {
            // this can happen when ackResponse timer resends messages
            skippedMsgs = owner.windowLength;
        }
        // send new messages (at least one)
        for (int i=0; i<skippedMsgs; i++) {
            sendMessage();
        }
    }

    /**
     * Send test message to this agent (UNICAST VERSION)
     */
    public void sendMessage(){
        // if communication is disabled on GUI, don't send any messages
        if (!owner.gui.isCommunicationEnabled()) return;
        // communication is enabled
        Message m = Message.newInstance(MessageConstants.INFORM, owner.getAddress(), address);
        m.setMessageSizeRequired();
        m.setContent(owner.getContent());
        // use reply with field for message id
        m.setReplyWith(String.valueOf(getMsgId()));
        try {
            owner.sendMessageAsReference(m);
            // increase total number of messages send to this agent (outgoing traffic)
            totalMsgSend++;
            // increase total size of messages send to this agent (outgoing traffic)
            if (messageSize == 0) {
                messageSize = m.getMessageSize();
                owner.logInfo("Real message size: " + messageSize);
            }
            totalMsgSendSize+=messageSize;
        }
        catch (InvisibleContainerException ex) {
        }
        m.release();
    }

    /**
     * Send ack back to the original sender. In reply to field will be used for message id.
     *
     * @param m Message original message used to get ID of the ack
     */
    public void sendAck(Message m){
        Message ack = m.getReply(owner.getAddress());
        ack.setPerformative(MessageConstants.INFORM_DONE);
        ack.setMessageSizeRequired();
//        System.out.println("Sending ack for: "+m.getReplyWith());
        try {
            owner.sendMessageAsReference(ack);
            // increase total number of acks send to this agent (outgoing traffic)
            totalAckSend++;
            // increase total size of acks send to this agent (outgoing traffic)
            int size = ack.getMessageSize();
            if (size > 0) {
                totalAckSendSize+=size;
            }
        }
        catch (InvisibleContainerException ex) {
        }
        ack.release();
    }

    /**
     * Multicast message was send from BenchmarkAgent, increase number and size of messages
     * @param size int size of the message
     */
    public void multicastMessageWasSend(int size){
        // set size of the message (used also in countFailure method)
        messageSize = size;
        // increase total number and size of messages send to this agent (outgoing traffic)
        totalMsgSend++;
        totalMsgSendSize+=messageSize;
    }

    /**
     * Count traffic during the last interval
     */
    public void intervalTraffic(){
        long totalSend = totalMsgSendSize + totalAckSendSize;
        long totalReceived = totalMsgReceivedSize + totalAckReceivedSize;
        long totalFailed = totalMsgFailedSize;
        intervalSendSize = totalSend - snapshotSend;
        intervalReceivedSize = totalReceived - snapshotReceived;
        intervalFailedSize = totalFailed - snapshotFailed;
        snapshotSend = totalSend;
        snapshotReceived = totalReceived;
        snapshotFailed = totalFailed;
    }

    /**
     * Start ack timer - check the time when last ack arrived. When the delay is > then given interval
     * resend the messages (used when connection was interrupted)
     */
    public void startAckTimer(){
        ackResponseTimerTask = new TimerTask(){
            @Override
            public void run() {
                // test the delay between last ack and current time
                if (System.currentTimeMillis() - lastAckTime > BenchmarkAgent.ACK_DELAY) {
                    owner.logInfo("Acknowledge from " + getName() + " not arrived in last " +
                            (System.currentTimeMillis() - lastAckTime)/1000 +
                            " second(s) - resending message!");
                    // send only one message - try to reestablish the connection
                    // failures will be counted to all agents once the first ack will arrive
                    resendMessages(1);
                }
            }
        };
        owner.getContainer().TIMER.schedule(ackResponseTimerTask, BenchmarkAgent.ACK_DELAY, BenchmarkAgent.ACK_DELAY);
    }

    /**
     * Stop timer that checks ack responses
     */
    public void stopAckTimer(){
        ackResponseTimerTask.cancel();
        owner.getContainer().TIMER.purge();
    }

}
