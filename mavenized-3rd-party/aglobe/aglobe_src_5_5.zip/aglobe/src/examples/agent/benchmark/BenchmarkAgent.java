package examples.agent.benchmark;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.TimerTask;

import javax.swing.SwingUtilities;

import aglobe.container.agent.Agent;
import aglobe.container.transport.Address;
import aglobe.container.transport.InvisibleContainerException;
import aglobe.ontology.AgentInfo;
import aglobe.ontology.Message;
import aglobe.ontology.MessageConstants;
import aglobe.service.directory.DirectoryException;
import aglobe.service.directory.DirectoryListener;
import aglobe.service.directory.DirectoryRecord;
import aglobe.service.directory.DirectoryService;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: Communication benchmark</p>
 * <p>Copyright: Copyright (c) 2007</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author Milan Rollo
 * @version $Revision$ $Date$
 */
public class BenchmarkAgent extends Agent {

    private static final long serialVersionUID = -5268777314556975439L;

    // identifier used by directory services
    public static final String BENCHMARK_AGENT = "BENCHMARK_AGENT";

    // gui refence
    public BenchmarkAgentGUI gui;

    // Directory shell
    private DirectoryService.Shell dirShell;

    // Other known benchmark agents
    private Map<Address, OtherAgentRecord> otherAgents = new HashMap<Address, OtherAgentRecord>();

    // Content of the messages send to other agents
    private byte[] content;

    // periodically invoke interval traffic computation
    private TimerTask intervalTrafficEvent;

    // invoke computation each second
    private final int interval = 1000;

    // MULTICAST VARIABLES
    // unique multicast message Id
    private int multicastMsgId;

    // size of the multicast message
    private int multicastMessageSize;

    // receivers of the multicast message
    private ArrayList<Address> multicastReceivers;

    // last acknowledged multicast message Id
    // it is the highest number from acks received from all multicast receivers
    private int lastUniqueMulticastAckId;

    private TimerTask multicastAckResponseTimerTask;
    public static final long ACK_DELAY = 1000;
    private long lastMulticastAckTime; // millis

    protected int windowLength;

    /**
     * Agent's initialization method
     * @param ai AgentInfo
     * @param initState int
     */
    @Override
    public void init(AgentInfo ai, int initState) {
        try {
            SwingUtilities.invokeAndWait(new Runnable() {
                @Override
				public void run() {
                    gui = new BenchmarkAgentGUI(BenchmarkAgent.this);
                }
            });
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }

        // init directory services
        dirShell = (DirectoryService.Shell)getContainer().getServiceManager().getService(this, DirectoryService.SERVICENAME);
        if (dirShell == null) {
            logSevere("Cannot find directory service.");
            stop();
            return;
        }

        subscribeDirServices();

        // display traffic during last second on GUI
        intervalTrafficEvent = this.scheduleEvent(new Runnable() {
            @Override
			public void run() {
                BenchmarkAgent.this.intervalTraffic();
            }
        }, 1000, interval);

    }

    /* (non-Javadoc)
     * @see aglobe.container.agent.Agent#finish()
     */
    @Override
    protected void finish() {
        if (intervalTrafficEvent != null) {
            intervalTrafficEvent.cancel();
            intervalTrafficEvent = null;
        }

        super.finish();
    }



    /**
     * Get content of the messages
     * @return byte[]
     */
    public byte[] getContent(){
        return content;
    }

    /**
     * Prepare new dummy content of the messages
     * Method is invoked when Start button on GUI is pressed
     * @param n int size of the content in bytes (set by the slider on GUI)
     */
    public void prepareContent(int n){
        content = new byte[n];
    }

    /**
     * Return new message Id
     * @return int
     */
    private int getMulticastMsgId(){
        return ++multicastMsgId;
    }

    /**
     * Subscribe directory services and register myself
     */
    private void subscribeDirServices() {
        // register myself as benchmark agent
        try {
            dirShell.register(this, new String[] {BENCHMARK_AGENT});
        }
        catch (DirectoryException ex) {
            ex.printStackTrace();
        }

        // subscribe for other benchmark agents
        dirShell.subscribe(new DirectoryListener() {
            @Override
			public void handleNewRegister(String containerName,
                                          DirectoryRecord[] records,
                                          String matchingFilter) {
            }

            @Override
			public void handleDeregister(String containerName,
                                         DirectoryRecord[] records,
                                         String matchingFilter) {
            }

            @Override
			public void handleVisible(String containerName,
                                      DirectoryRecord[] records,
                                      String matchingFilter) {
                // add to the receiver list
                for (DirectoryRecord elem : records) {
                    // skip myself
                    if (elem.address.equals(BenchmarkAgent.this.getAddress())) continue;
                    // get record of other agent
                    OtherAgentRecord oar = otherAgents.get(elem.address);
                    if (oar == null) {
                        oar = new OtherAgentRecord(BenchmarkAgent.this, elem);
                        otherAgents.put(elem.address, oar);
                        gui.addRecord(oar);
                    }
                    oar.setVisible(true);
                    gui.updateValues();
                }
            }

            @Override
			public void handleInvisible(String containerName,
                                        DirectoryRecord[] records,
                                        String matchingFilter) {
                // remove from the receiver list
                for (DirectoryRecord elem : records) {
                    OtherAgentRecord oar = otherAgents.get(elem.address);
                    if (oar == null) {
                        logWarning("Unknown agent become invisible: " + elem.containerName);
                    }
                    else {
                        oar.setVisible(false);
                        gui.updateValues();
                    }
                }
            }

            @Override
			public void addEvent(Runnable e) {
                BenchmarkAgent.this.addEvent(e);
            }
        }, BENCHMARK_AGENT);
    }

    /**
     * Process all incomming messages
     * @param m Message
     */
    @Override
	public void handleIncomingMessage(Message m) {
        OtherAgentRecord oar = otherAgents.get(m.getSender());
        if (oar == null) {
            logWarning("Received message from unknown agent: " + m.getSender());
            return;
        }
        // message arrived
        if (m.getPerformative().equals(MessageConstants.INFORM)) {
            // logInfo(this.getContainer().getContainerName() + ": received test message " + m.getReplyWith() + " from " + m.getSender());
        	m.setMessageSize(1024);
            oar.processMessage(m);
        }
        // acknowledge arrived
        else if (m.getPerformative().equals(MessageConstants.INFORM_DONE)) {
            // logInfo(this.getContainer().getContainerName() + ": received ack message " + m.getInReplyTo() + "  from " + m.getSender());
        	m.setMessageSize(1024);
            oar.processAck(m);
            if (gui.isMulticastEnabled()) {
                // multicast
                int id = Integer.parseInt(m.getInReplyTo());
                if (id <= lastUniqueMulticastAckId) {
                    // received older ack
                    // do nothing
                }
                else {
                    // received new ack, resend skipped messages (id > lastId)
                    int skippedMsgs = id - lastUniqueMulticastAckId;
                    // resend the messages (at least one)
                    resendMulticastMessages(skippedMsgs);
                    // set new value to lastUniqueMulticastAckId
                    lastUniqueMulticastAckId = id;
                }
                // set time of the last received multicast ack
                lastMulticastAckTime = System.currentTimeMillis();
            }
        }
        m.release();
    }

    /**
     * Method invoked from GUI (Start button was pressed)
     *
     * @param contentSize int
     * @param windowLength int
     */
    public void start(int contentSize, int windowLength) {
        // prepare content of the test messages
        prepareContent(contentSize);
        // set window length
        this.windowLength = windowLength;
        // send messages to all selected agents
        if (!gui.isMulticastEnabled()) {
            // unicast
            for (OtherAgentRecord oar : otherAgents.values()) {
                if (oar.isCommunicationEnabled()) {
                    oar.clearValues();
                    // send appropriate number of messages to all enabled agents
                    for (int i=0; i<windowLength; i++) {
                        oar.sendMessage();
                    }
                    // start ack timer
                    oar.startAckTimer();
                }
            }
        }
        else {
            // multicast
            clearValues();
            // prepare list of multicast message receivers
            for (OtherAgentRecord oar : otherAgents.values()) {
                if (oar.isCommunicationEnabled()) {
                    multicastReceivers.add(oar.getAddress());
                    oar.clearValues();
                }
            }
            // send appropriate number of multicast messages to all enabled agents
            for (int i=0; i<windowLength; i++) {
                sendMulticastMessage();
            }
            // start ack timer
            startMulticastAckTimer();
        }

    }

    /**
     * Method invoked from GUI (Stop button was pressed)
     */
    protected void stopPressed(){
        if (gui.isMulticastEnabled()) {
            // stop multicast timer
            // in this case the timer is common for all agents
            stopMulticastAckTimer();
        }
        else {
            // stop individual timers
            for (OtherAgentRecord oar : otherAgents.values()) {
                if (oar.isCommunicationEnabled()) {
                    oar.stopAckTimer();
                }
            }
        }
    }

    /**
     * Send multicast message to the receivers
     */
    /** @todo add timer that will resend the messages (check whether the agents are accessible) */
    private void sendMulticastMessage() {
        // if communication is disabled on GUI, don't send any messages
        if (!gui.isCommunicationEnabled()) return;
        Message m = Message.newInstance(MessageConstants.INFORM, getAddress(), multicastReceivers);
        m.setMessageSizeRequired();
        m.setContent(getContent());
        // use reply with field for message id
        m.setReplyWith(String.valueOf(getMulticastMsgId()));
        try {
            sendMessageAsReference(m);
            // measure the size of the multicast message
            if (multicastMessageSize == 0) {
                // if size of the test message was not measured, do it
            	multicastMessageSize = m.getMessageSize();
                logInfo("Real multicast message size: " + multicastMessageSize);
            }
            // increase total number and size of messages send to particular agents (outgoing traffic)
            for (Address address : multicastReceivers) {
                OtherAgentRecord oar = otherAgents.get(address);
                if (oar != null) {
                    oar.multicastMessageWasSend(multicastMessageSize);
                }
            }
        }
        catch (InvisibleContainerException ex) {
        }
        m.release();
    }

    /**
     * Resend multicast messages if some were skipped
     * @param skippedMsgs int
     */
    private void resendMulticastMessages(int skippedMsgs) {
        if (skippedMsgs > windowLength) {
            // this can happen when ackResponse timer resends messages
            skippedMsgs = windowLength;
        }
        // send new multicast messages (at least one)
        for (int i=0; i<skippedMsgs; i++) {
            sendMulticastMessage();
        }
    }

    /**
     * Clear values of the multicast message
     */
    public void clearValues(){
        multicastReceivers = new ArrayList<Address>();
        multicastMsgId = 0;
        multicastMessageSize = 0;
        lastUniqueMulticastAckId = 0;
    }

    /**
     * Count traffic during the last interval
     */
    private void intervalTraffic(){
        for (OtherAgentRecord oar : otherAgents.values()) {
            oar.intervalTraffic();
        }
        if (gui!=null) {
            gui.updateValues();
        }
    }

    /**
     * Start ack timer - check the time when last ack arrived. When the delay is > then given interval
     * resend the messages (used when connection was interrupted)
     */
    private void startMulticastAckTimer(){
        multicastAckResponseTimerTask = new TimerTask(){
            @Override
            public void run() {
                // test the delay between last ack and current time
                if (System.currentTimeMillis() - lastMulticastAckTime > ACK_DELAY) {
                    logInfo("Acknowledge not arrived in last " +
                            (System.currentTimeMillis() - lastMulticastAckTime)/1000 +
                            " second(s) - resending multicast message!");
                    // send only one message - try to reestablish the connection
                    // failures will be counted to all agents once the first ack will arrive
                    resendMulticastMessages(1);
                }
            }
        };
        getContainer().TIMER.schedule(multicastAckResponseTimerTask, ACK_DELAY, ACK_DELAY);
    }

    /**
     * Stop ack timer when Stop button is pressed
     */
    private void stopMulticastAckTimer(){
        multicastAckResponseTimerTask.cancel();
        getContainer().TIMER.purge();
    }

    /**
     * Clear values in GUI
     */
    public void clearGUI(){
        for (OtherAgentRecord oar : otherAgents.values()) {
            oar.clearGUI();
        }
        if (gui!=null) {
            gui.updateValues();
        }
    }

}
