package examples.agent.directory;

import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;
import java.awt.event.*;
import aglobe.util.gui.RememberPositionJFrame;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: agent platform A-Globe</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.6 $ $Date: 2010/08/04 11:48:05 $
 */

public class DirectoryAgentGUI
      extends RememberPositionJFrame {
    private static final long serialVersionUID = 4611795624631149436L;
    GridBagLayout gridBagLayout1 = new GridBagLayout();
    JPanel jPanel1 = new JPanel();
    JPanel jPanel2 = new JPanel();
    JPanel jPanel3 = new JPanel();
    GridBagLayout gridBagLayout2 = new GridBagLayout();
    GridBagLayout gridBagLayout3 = new GridBagLayout();
    GridBagLayout gridBagLayout4 = new GridBagLayout();
    Border border1;
    TitledBorder titledBorder1;
    Border border2;
    TitledBorder titledBorder2;
    Border border3;
    TitledBorder titledBorder3;
    JPanel jPanel4 = new JPanel();
    JLabel jLabel1 = new JLabel();
    GridBagLayout gridBagLayout5 = new GridBagLayout();
    JTextField providerServiceName = new JTextField();
    JPanel jPanel5 = new JPanel();
    GridBagLayout gridBagLayout6 = new GridBagLayout();
    JButton register = new JButton();
    JButton deregister = new JButton();
    JPanel jPanel6 = new JPanel();
    JPanel jPanel7 = new JPanel();
    GridBagLayout gridBagLayout7 = new GridBagLayout();
    GridBagLayout gridBagLayout8 = new GridBagLayout();
    JLabel jLabel2 = new JLabel();
    JTextField filter = new JTextField();
    JButton unsubscribe = new JButton();
    JButton subscribe = new JButton();
    JScrollPane jScrollPane1 = new JScrollPane();
    JTextArea listenerLog = new JTextArea();

    private DirectoryAgent owner;

    public DirectoryAgentGUI(DirectoryAgent owner) {
        super(owner);
        this.owner = owner;
        try {
            jbInit();
            setSize(300,300);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    void jbInit() throws Exception {
        border1 = new EtchedBorder(EtchedBorder.RAISED, Color.white,
                                   new Color(148, 145, 140));
        titledBorder1 = new TitledBorder(border1, "Provider");
        border2 = new EtchedBorder(EtchedBorder.RAISED, Color.white,
                                   new Color(148, 145, 140));
        titledBorder2 = new TitledBorder(border2, "Subscriber");
        border3 = new EtchedBorder(EtchedBorder.RAISED, Color.white,
                                   new Color(148, 145, 140));
        titledBorder3 = new TitledBorder(border3, "ListenerLog");
        this.getContentPane().setLayout(gridBagLayout1);
        jPanel1.setLayout(gridBagLayout2);
        jPanel2.setLayout(gridBagLayout3);
        jPanel3.setLayout(gridBagLayout4);
        jPanel1.setBorder(titledBorder1);
        jPanel2.setBorder(titledBorder2);
        jPanel3.setBorder(titledBorder3);
        jLabel1.setText("Service name:");
        jPanel4.setLayout(gridBagLayout5);
        providerServiceName.setToolTipText("");
        providerServiceName.setText("");
        jPanel5.setLayout(gridBagLayout6);
        register.setText("Register");
        register.addActionListener(new DirectoryAgentGUI_register_actionAdapter(this));
        deregister.setToolTipText("");
        deregister.setText("Deregister");
        deregister.addActionListener(new
                                     DirectoryAgentGUI_deregister_actionAdapter(this));
        jPanel7.setMaximumSize(new Dimension(32767, 32767));
        jPanel7.setLayout(gridBagLayout7);
        jPanel6.setLayout(gridBagLayout8);
        jLabel2.setText("Filter:");
        filter.setToolTipText("");
        filter.setText("");
        unsubscribe.setText("Unsubscribe");
        unsubscribe.addActionListener(new
                                      DirectoryAgentGUI_unsubscribe_actionAdapter(this));
        subscribe.setText("Subscribe");
        subscribe.addActionListener(new
                                    DirectoryAgentGUI_subscribe_actionAdapter(this));
        listenerLog.setToolTipText("");
        listenerLog.setText("");
        listenerLog.setLineWrap(true);
        this.getContentPane().add(jPanel1,
                                  new GridBagConstraints(0, 0, 1, 1, 0.1, 0.0
              , GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
              new Insets(0, 0, 0, 0), 0, 0));
        jPanel1.add(jPanel4, new GridBagConstraints(1, 1, 1, 1, 0.1, 0.0
              , GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
              new Insets(0, 0, 0, 0), 0, 0));
        jPanel4.add(jLabel1, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
              , GridBagConstraints.WEST, GridBagConstraints.NONE,
              new Insets(0, 0, 0, 5), 0, 0));
        jPanel4.add(providerServiceName,
                    new GridBagConstraints(2, 0, 1, 1, 0.1, 0.0
                                           , GridBagConstraints.CENTER,
                                           GridBagConstraints.HORIZONTAL,
                                           new Insets(0, 0, 0, 0), 0, 0));
        this.getContentPane().add(jPanel2,
                                  new GridBagConstraints(0, 1, 1, 1, 0.1, 0.0
              , GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
              new Insets(0, 0, 0, 0), 0, 0));
        this.getContentPane().add(jPanel3,
                                  new GridBagConstraints(0, 2, 1, 1, 0.1, 0.1
              , GridBagConstraints.CENTER, GridBagConstraints.BOTH,
              new Insets(0, 0, 0, 0), 0, 0));
        jPanel3.add(jScrollPane1, new GridBagConstraints(0, 0, 1, 1, 0.1, 0.1
              , GridBagConstraints.CENTER, GridBagConstraints.BOTH,
              new Insets(0, 0, 0, 0), 0, 0));
        jScrollPane1.getViewport().add(listenerLog, null);
        jPanel1.add(jPanel5, new GridBagConstraints(1, 2, 1, 1, 0.1, 0.0
              , GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
              new Insets(5, 0, 5, 0), 0, 0));
        jPanel5.add(register, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
              , GridBagConstraints.CENTER, GridBagConstraints.NONE,
              new Insets(0, 0, 0, 10), 0, 0));
        jPanel5.add(deregister, new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
              , GridBagConstraints.CENTER, GridBagConstraints.NONE,
              new Insets(0, 10, 0, 0), 0, 0));
        jPanel2.add(jPanel6, new GridBagConstraints(1, 1, 1, 1, 0.1, 0.0
              , GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
              new Insets(0, 0, 0, 0), 0, 0));
        jPanel6.add(jLabel2, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
              , GridBagConstraints.CENTER, GridBagConstraints.NONE,
              new Insets(0, 0, 0, 5), 0, 0));
        jPanel6.add(filter, new GridBagConstraints(2, 0, 1, 1, 0.1, 0.0
              , GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
              new Insets(0, 0, 0, 0), 0, 0));
        jPanel2.add(jPanel7, new GridBagConstraints(1, 2, 1, 1, 0.1, 0.0
              , GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
              new Insets(10, 0, 10, 0), 0, 0));
        jPanel7.add(unsubscribe, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
              , GridBagConstraints.CENTER, GridBagConstraints.NONE,
              new Insets(0, 10, 0, 0), 0, 0));
        jPanel7.add(subscribe, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
              , GridBagConstraints.CENTER, GridBagConstraints.NONE,
              new Insets(0, 0, 0, 10), 0, 0));
    }

    /**
     * Add message to the log area
     * @param msg String
     */
    void addToListenerLog(final String msg) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
			public void run() {
                listenerLog.append("\n" + msg);
            }
        });
    }

    /**
     * @param e
     */
    void register_actionPerformed(ActionEvent e) {
        if (providerServiceName.getText().length() > 0) {
            owner.register(providerServiceName.getText());
        }
    }

    /**
     * @param e
     */
    void deregister_actionPerformed(ActionEvent e) {
        if (providerServiceName.getText().length() > 0) {
            owner.deregister(providerServiceName.getText());
        }
    }

    /**
     * @param e
     */
    void subscribe_actionPerformed(ActionEvent e) {
        if (filter.getText().length() > 0) {
            owner.subscribe(filter.getText());
        }
    }

    /**
     * @param e
     */
    void unsubscribe_actionPerformed(ActionEvent e) {
        if (filter.getText().length() > 0) {
            owner.unsubscribe(filter.getText());
        }
    }
}

class DirectoryAgentGUI_register_actionAdapter
      implements java.awt.event.ActionListener {
    DirectoryAgentGUI adaptee;

    DirectoryAgentGUI_register_actionAdapter(DirectoryAgentGUI adaptee) {
        this.adaptee = adaptee;
    }

    @Override
	public void actionPerformed(ActionEvent e) {
        adaptee.register_actionPerformed(e);
    }
}

class DirectoryAgentGUI_deregister_actionAdapter
      implements java.awt.event.ActionListener {
    DirectoryAgentGUI adaptee;

    DirectoryAgentGUI_deregister_actionAdapter(DirectoryAgentGUI adaptee) {
        this.adaptee = adaptee;
    }

    @Override
	public void actionPerformed(ActionEvent e) {
        adaptee.deregister_actionPerformed(e);
    }
}

class DirectoryAgentGUI_subscribe_actionAdapter
      implements java.awt.event.ActionListener {
    DirectoryAgentGUI adaptee;

    DirectoryAgentGUI_subscribe_actionAdapter(DirectoryAgentGUI adaptee) {
        this.adaptee = adaptee;
    }

    @Override
	public void actionPerformed(ActionEvent e) {
        adaptee.subscribe_actionPerformed(e);
    }
}

class DirectoryAgentGUI_unsubscribe_actionAdapter
      implements java.awt.event.ActionListener {
    DirectoryAgentGUI adaptee;

    DirectoryAgentGUI_unsubscribe_actionAdapter(DirectoryAgentGUI adaptee) {
        this.adaptee = adaptee;
    }

    @Override
	public void actionPerformed(ActionEvent e) {
        adaptee.unsubscribe_actionPerformed(e);
    }
}
