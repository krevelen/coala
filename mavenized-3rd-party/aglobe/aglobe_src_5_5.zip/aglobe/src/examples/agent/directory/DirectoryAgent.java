package examples.agent.directory;

import aglobe.container.agent.*;
import aglobe.ontology.*;
import aglobe.service.directory.*;

import java.util.Collection;
import java.util.HashSet;

/**
 * <p>
 * Title: A-Globe
 * </p>
 * <p>
 * Description: Agent which use directory service
 * </p>
 * <p>
 * Copyright: Copyright (c) 2004
 * </p>
 * <p>
 * Company: Gerstner Laboratory
 * </p>
 *
 * @author David Sislak
 * @version $Revision: 1.15 $ $Date: 2010/08/04 11:48:05 $
 */

public class DirectoryAgent extends Agent implements DirectoryListener {
    private static final long serialVersionUID = -3248998508668585959L;

    /**
     * Directory agent gui reference
     */
    public DirectoryAgentGUI gui;

    /**
     * Directory service shell
     */
    private DirectoryService.Shell directory;

    /**
     * Agent's initialization method.
     *
     * @param ai
     *            Agent should get its name from there.
     * @param initState
     *            This parameter can be used if this method is overridden.
     */
    @Override
    public void init(AgentInfo ai, int initState) {

        try {
            gui = new DirectoryAgentGUI(this);
            gui.setTitle("Directory Agent: " + getAddress().toString());
            gui.pack();
            gui.setVisible(true);
        } catch (Exception ex) {
            logWarning("Cannot create GUI due to: " + ex);
        }

        directory = (DirectoryService.Shell) getContainer().getServiceManager().getService(this, DirectoryService.SERVICENAME);
    }

    @Override
	public void handleIncomingMessage(Message m) {
        logWarning("Unexpected incoming message: " + m);
        m.release();
    }

    /**
     * Converts array to string
     *
     * @param ar
     *            Object[]
     * @return String
     */
    private String convertArrayToString(Object[] ar) {
        String retVal = "";
        for (int i = 0; i < ar.length; i++)
            retVal += ("[" + ar[i].toString() + "]");
        return retVal;
    }

    /**
     * Handles new registration in the directory.
     *
     * @param containerName
     *            String - container name where the agent/service have been
     *            registered
     * @param records
     *            DirectoryRecord[] - array of the agents/services which are
     *            registered. An agent/service can handle its own registration
     *            too.
     * @param matchingFilter
     *            String - matching filter to which is this callback. Can be
     *            used if an someone has more subscriptions to the same listener
     *            with cross filter. In this case registration info about one
     *            agent/service can be handled two times
     */
    @Override
	public void handleNewRegister(String containerName, DirectoryRecord[] records, String matchingFilter) {
        if (gui != null) {
            gui.addToListenerLog("New register:\nContainer: " + containerName + "\nFilter: " + matchingFilter + "\nRecords: " + convertArrayToString(records));
        }
    }

    /**
     * Handles de-registration of the agent/service.
     *
     * @param containerName
     *            String - container name where the agent/service have been
     *            deregistered
     * @param records
     *            DirectoryRecord[] - array of the agents/services which are
     *            deregistered. Only address and containerName fields are valid;
     *            services field couldn't have valid data. An agent/service can
     *            handle its own deregistration too.
     * @param matchingFilter
     *            String - matching filter to which is this callback. Can be
     *            used if an someone has more subscriptions to the same listener
     *            with cross filter.
     */
    @Override
	public void handleDeregister(String containerName, DirectoryRecord[] records, String matchingFilter) {
        if (gui != null) {
            gui.addToListenerLog("Deregister:\nContainer: " + containerName + "\nFilter: " + matchingFilter + "\nRecords: " + convertArrayToString(records));
        }
    }

    /**
     * Handles that some agents/services becomes visible to me.
     *
     * @param containerName
     *            String - container name where agents/services become visible
     * @param records
     *            DirectoryRecord[] - array of the agents/services which become
     *            visible. Only address and containerName fields are valid;
     *            services field couldn't have valid data. An agent/service can
     *            handle its own visibility too.
     * @param matchingFilter
     *            String - matching filter to which is this callback. Can be
     *            used if an someone has more subscriptions to the same listener
     *            with cross filter.
     */
    @Override
	public void handleVisible(String containerName, DirectoryRecord[] records, String matchingFilter) {
        if (gui != null) {
            gui.addToListenerLog("Visible:\nContainer: " + containerName + "\nFilter: " + matchingFilter + "\nRecords: " + convertArrayToString(records));
        }
    }

    /**
     * Handles that some agents/services becomes invisible to me.
     *
     * @param containerName
     *            String - container name where agents/services become invisible
     * @param records
     *            DirectoryRecord[] - array of the agents/services which become
     *            invisible. Only address and containerName fields are valid;
     *            services field couldn't have valid data. An agent/service can
     *            handle its own invisibility too.
     * @param matchingFilter
     *            String - matching filter to which is this callback. Can be
     *            used if an someone has more subscriptions to the same listener
     *            with cross filter.
     */
    @Override
	public void handleInvisible(String containerName, DirectoryRecord[] records, String matchingFilter) {
        if (gui != null) {
            gui.addToListenerLog("Invisible:\nContainer: " + containerName + "\nFilter: " + matchingFilter + "\nRecords: " + convertArrayToString(records));
        }
    }

    /**
     * register
     *
     * @param text
     *            String
     */
    void register(String text) {
        if (directory != null) {
            if (gui != null) {
                gui.addToListenerLog("Register: " + text);
            }
            Collection<String> add = new HashSet<String>();
            add.add(text);
            try {
                directory.register(this, add);
            } catch (DirectoryException ex) {
                if (gui != null) {
                    gui.addToListenerLog("Register exception: " + ex);
                }
            }
        }
    }

    /**
     * Deregister
     *
     * @param text
     *            String
     */
    void deregister(String text) {
        if (directory != null) {
            if (gui != null) {
                gui.addToListenerLog("Deregister: " + text);
            }
            Collection<String> add = new HashSet<String>();
            add.add(text);
            try {
                directory.deregister(add);
            } catch (DirectoryException ex) {
                if (gui != null) {
                    gui.addToListenerLog("Deregister exception: " + ex);
                }
            }
        }
    }

    /**
     * Subscribe
     *
     * @param text
     *            String
     */
    void subscribe(String text) {
        if (directory != null) {
            if (gui != null) {
                gui.addToListenerLog("Subscribe: " + text);
            }
            directory.subscribe(this, text);
        }
    }

    /**
     * Unsubscribe
     *
     * @param text
     *            String
     */
    void unsubscribe(String text) {
        if (directory != null) {
            if (gui != null) {
                gui.addToListenerLog("Unsubscribe: " + text);
            }
            directory.unsubscribe(this, text);
        }
    }
}
