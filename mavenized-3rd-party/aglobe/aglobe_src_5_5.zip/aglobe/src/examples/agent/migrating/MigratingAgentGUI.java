package examples.agent.migrating;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import aglobe.util.*;

/**
 * <p>
 * Title: A-Globe
 * </p>
 * <p>
 * Description: GUI of the Migrating Agent
 * </p>
 * <p>
 * Copyright: Copyright (c) 2003
 * </p>
 * <p>
 * Company: Gerstner Laboratory
 * </p>
 *
 * @author David Sislak
 * @version $Revision: 1.8 $ $Date: 2010/08/04 11:48:05 $
 *
 */

public class MigratingAgentGUI extends JFrame {
    private static final long serialVersionUID = 789211825350406607L;

    /**
     * owner Migrating AGent
     */
    MigratingAgent owner = null;

    /**
     * GUI components
     */
    private BorderLayout borderLayout2 = new BorderLayout();

    private JPanel jPanelOne = new JPanel();

    private JPanel jPanel1 = new JPanel();

    private JPanel jPanel2 = new JPanel();

    private JLabel jLabel1 = new JLabel();

    private JButton dieButton = new JButton();

    JButton migrateButton = new JButton();

    private GridLayout gridLayout1 = new GridLayout();

    private GridBagLayout gridBagLayout1 = new GridBagLayout();

    JComboBox hostComboBox = new JComboBox();

    CardLayout cardLayout1 = new CardLayout();

    JPanel jPanelTwo = new JPanel();

    BorderLayout borderLayout1 = new BorderLayout();

    JLabel textLabel = new JLabel();

    JButton cancelButton = new JButton();

    JPanel jPanel3 = new JPanel();

    BorderLayout borderLayout3 = new BorderLayout();

    JPanel jPanel4 = new JPanel();

    BorderLayout borderLayout4 = new BorderLayout();

    JLabel pictureLabel = new JLabel();

    JMenuBar jMenuBar1 = new JMenuBar();

    JMenu jMenu1 = new JMenu();

    JMenuItem jMenuItem1 = new JMenuItem();

    /**
     *
     * @param owner
     *            MigratingAgent - owner agent of this GUI
     */
    public MigratingAgentGUI(MigratingAgent owner) {
        try {
            this.owner = owner;
            jbInit();
            pack();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * no args constructor is needed for deserialization gui window
     */
    public MigratingAgentGUI() {
        try {
            jbInit();
            pack();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * GUI init method
     *
     * @throws Exception
     */
    private void jbInit() throws Exception {
        this.getContentPane().setLayout(borderLayout3);
        jPanel4.setLayout(borderLayout4);
        pictureLabel.setText("");
        jMenu1.setText("File");
        jMenuItem1.setAction(null);
        jMenuItem1.setText("Load image");
        this.setJMenuBar(jMenuBar1);
        this.getContentPane().add(jPanel3, BorderLayout.CENTER);
        jPanel3.setLayout(cardLayout1);
        jLabel1.setText("Dest:");
        dieButton.setText("Die");
        migrateButton.setText("Migrate");
        jPanel2.setLayout(gridLayout1);
        jPanel1.setLayout(gridBagLayout1);
        jPanelOne.setLayout(borderLayout2);
        jPanelTwo.setLayout(borderLayout1);
        textLabel.setRequestFocusEnabled(true);
        textLabel.setHorizontalAlignment(SwingConstants.CENTER);
        textLabel.setText("Moving to ");
        cancelButton.setText("Cancel");
        jPanel1.add(jLabel1, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(3, 3, 3, 3), 0, 0));
        jPanel1.add(hostComboBox, new GridBagConstraints(1, 1, 1, 1, 0.1, 0.0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(3, 3, 3, 3),
                0, 0));
        jPanelOne.add(jPanel2, BorderLayout.SOUTH);
        jPanelOne.add(jPanel1, BorderLayout.CENTER);
        jPanel2.add(migrateButton, null);
        jPanel2.add(dieButton, null);
        jPanel3.add(jPanelOne, "jPanelOne");
        jPanel3.add(jPanelTwo, "jPanelTwo");
        jPanelTwo.add(textLabel, BorderLayout.CENTER);
        jPanelTwo.add(cancelButton, BorderLayout.SOUTH);
        this.getContentPane().add(jPanel4, BorderLayout.EAST);
        jPanel4.add(pictureLabel, BorderLayout.CENTER);
        jMenuBar1.add(jMenu1);
        jMenu1.add(jMenuItem1);
        // setTitle(owner.getAddress().toString());
    }

    public void init() {
        dieButton.addActionListener(new java.awt.event.ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                dieButton_actionPerformed(e);
            }
        });
        migrateButton.addActionListener(new java.awt.event.ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                migrateButton_actionPerformed(e);
            }
        });
        cancelButton.addActionListener(new java.awt.event.ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                cancelButton_actionPerformed(e);
            }
        });
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                jMenuItem1_actionPerformed(e);
            }
        });
    }

    /**
     * @param e
     */
    void migrateButton_actionPerformed(ActionEvent e) {
        if (hostComboBox.getSelectedIndex() < 0)
            return;
        owner.migrate((String) hostComboBox.getSelectedItem());
    }

    /**
     * @param e
     */
    void dieButton_actionPerformed(ActionEvent e) {
        owner.exit();
    }

    /**
     * Add destination to the destination combo box
     *
     * @param name
     *            String
     */
    void addDestination(final String name) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
			public void run() {
                hostComboBox.removeItem(name);
                hostComboBox.addItem(name);
            }
        });
    }

    /**
     * Show message dialog
     *
     * @param text
     *            String
     */
    void showMessage(final String text) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
			public void run() {
                JOptionPane.showMessageDialog(null, text);
            }
        });
    }

    /**
     * @param e
     */
    void cancelButton_actionPerformed(ActionEvent e) {
        owner.cancelMigrate();
    }

    /**
     * @param e
     */
    void jMenuItem1_actionPerformed(ActionEvent e) {
        JFileChooser fcImage = new JFileChooser();
        fcImage.setFileFilter(new FileUtils.FileFilter(new String[] { FileUtils.GIF, FileUtils.JPG, FileUtils.JPEG }, "Image files (*.gif,*.jpg,*.jpeg)"));
        int retVal = fcImage.showOpenDialog(null);
        if (retVal == JFileChooser.APPROVE_OPTION) {
            File file = fcImage.getSelectedFile();
            ImageIcon icon = new ImageIcon(file.toString());
            pictureLabel.setIcon(icon);

            pictureLabel.invalidate();
            this.pack();
        }
    }

}
