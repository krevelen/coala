package examples.agent.migrating;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;

import javax.swing.SwingUtilities;

import aglobe.container.agent.Agent;
import aglobe.container.transport.Address;
import aglobe.ontology.AgentInfo;
import aglobe.ontology.Message;
import aglobe.service.topics.ContainerHandler;
import aglobe.service.topics.ContainerMonitor;
import aglobe.service.visibility.VisibilityNotifier;
import aglobe.service.visibility.VisibilityService;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: <code>MigratingAgent</code> demonstrates interactively agents'
 * ability to migrate across containers and platforms.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.41 $ $Date: 2010/08/04 11:48:05 $
 */
public class MigratingAgent
      extends Agent {
    // this constant has to be changed, when Agent's variables are changed
    private static final long serialVersionUID = -3565777661595L;

    /**
     * GUI window
     */
    public MigratingAgentGUI gui;

    private VisibilityService.Shell visShell = null;
    
    private ContainerMonitor containerMonitor = null;

    /**
     * List of all known containers
     */
    private LinkedHashMap<String, Address> allContainers = new LinkedHashMap<String, Address> ();

    /**
     * List of current visible containers
     */
    private LinkedHashSet<Address> visibleContainer = new LinkedHashSet<Address>();

    /**
     * Synchronization object
     */
    private Integer lock = new Integer(0);

    /**
     * true iff agent want migrate
     */
    private transient boolean wantMigrate;

    /**
     * Agent is in the migration procedure
     */
    private boolean migrating;

    /**
     * Destination agent container for the migrating agent
     */
    private Address destinationAddress;

    public MigratingAgent() {
    }
    
    private void containerVisible(final Address containerAddress) {
        if (allContainers.put(containerAddress.getContainerName(),containerAddress) == null) {
        	if (!containerAddress.isSameContainer(getAddress())) {
        		SwingUtilities.invokeLater(new Runnable() {
        			@Override
        			public void run() {
        				gui.hostComboBox.addItem(containerAddress.getContainerName());
        			}

        		});
        	}
        }
        if (visibleContainer.add(containerAddress)) {
        	synchronized (lock) {
        		if (wantMigrate) {
        			// try to migrate again, now that the visibility's changed
        			tryMigrate(destinationAddress);
        		}
        	}
        }
    }
    
    private void containerInvisible(final Address containerAddress) {
    	 visibleContainer.remove(containerAddress);
    }

    /**
     * Initialization of <code>MigratingAgent</code>, its GUI and the GIS shell.
     * @param ai AgentInfo
     * @param initState int
     */
    @SuppressWarnings("serial")
    @Override
    public void init(final AgentInfo ai, final int initState) {
        if (gui == null) {
            // if I haven't own gui, create new one
            try {
                SwingUtilities.invokeAndWait(new Runnable() {
                    @Override
					public void run() {
                        gui = new MigratingAgentGUI(MigratingAgent.this);
                        gui.setTitle("Migrating Agent - " + getContainer().getContainerName() +
                                ":" + ai.getReadableName());
                        gui.init();
                        gui.setVisible(true);
                   }
                });
            } catch (Exception ex) {
                logWarning("Cannot create GUI due to: " + ex);
            }
        } else {
            // set the title of the gui window with my current container location name
            // this is applied after migration
            SwingUtilities.invokeLater(new Runnable() {
                @Override
				public void run() {
                    gui.setTitle("Migrating Agent - " + getContainer().getContainerName() +
                                 ":" + ai.getReadableName());
                    gui.init();
                    gui.setVisible(true);
                }
            });
        }

        if (initState != isMOVEFAILED) {
            // agent started or moved
            destinationAddress = null;

            if (gui != null) {
                // update GUIcombo box with new containers that the agent can migrate to
                SwingUtilities.invokeLater(new Runnable() {
                    @Override
					public void run() {
                        gui.cardLayout1.first(gui.jPanel3);
                        gui.hostComboBox.removeAllItems();
                        for (Address adr : allContainers.values()) {
                            if (!adr.isSameContainer(getAddress())) {
                                gui.hostComboBox.addItem(adr.getContainerName());
                            }
                        }
                    }
                });
            }
        } else {
            // migration failed
            wantMigrate = true;
            if (gui != null) {
                SwingUtilities.invokeLater(new Runnable() {
                    @Override
					public void run() {
                        gui.cardLayout1.last(gui.jPanel3);
                    }
                });
            }
        }
        migrating = false;

        if (containerMonitor == null) {
        	try {
				containerMonitor = new ContainerMonitor(this, new ContainerHandler() {
					
					@Override
					public void containerStarted(Address containerAddress) {
						containerVisible(containerAddress);
					}
					
					@Override
					public void containerFinished(String containerName) {
						final Address containerAddress = allContainers.get(containerName);
						if (containerAddress != null) {
							containerInvisible(containerAddress);
						}
					}
				});
			} catch (Exception e) {
				e.printStackTrace();
			}
        }
        
        // initialize Visibility shell
        if (visShell == null) {
            visShell = (VisibilityService.Shell) getContainer().getServiceManager().getService(this, VisibilityService.SERVICENAME);
            if (visShell == null) {
                logSevere("Migrating agent can run only on the container with VisibilityService running");
                kill();
            }
            visShell.register(new VisibilityNotifier() {

                @Override
                public void becomeInvisible(final Address containerAddress) {
                    containerInvisible(containerAddress);
                }

                @Override
                public void becomeVisible(final Address containerAddress) {
                	containerVisible(containerAddress);
                }

                @Override
                public void addEvent(final Runnable e) {
                    MigratingAgent.this.addEvent(e);
                }

            });
        }
    }

    /**
     * This method overrides the standard <code>Agent</code>'s method responsible
     * for handling all incoming messages.
     * It should never be executed since <code>MigratingAgent</code> doesn't
     * expect any messages to come.
     * @param m Message - an incoming message
     */
    @Override
	public void handleIncomingMessage(Message m) {
        logWarning("Unexpected message: " + m.toString());
        m.release();
    }

    /**
     * This method performs agent's migration.
     * Before that, the agent subscribes visibility updates since its visibility
     * changes as a result of migration to a different container.
     * @param containerName String - destination container name
     */
    public void migrate(final String containerName) {
        // this method is called from the gui thread, needs to be executed in the
        // agent thread !!!
        addEvent(new Runnable() {
            @Override
			public void run() {
            	final Address containerAddress = allContainers.get(containerName);
            	if (containerAddress != null) {
                    if (gui != null) {
                        SwingUtilities.invokeLater(new Runnable() {
                            @Override
							public void run() {
                                gui.textLabel.setText("Moving to " +containerName);
                                gui.cardLayout1.last(gui.jPanel3);
                            }
                        });
                    }
                    wantMigrate = true;
                    destinationAddress = containerAddress;
                    tryMigrate(destinationAddress);
                    return;
            	}
                logWarning("Target not found: "+containerName+"\nKnown: "+allContainers);
            }
        });
    }

    /**
     * This method tries to perform agent's migration depending on the destination
     * container visibility.
     * @param dest Address - destination address.
     */
    private void tryMigrate(Address dest) {
        try {
            if (visibleContainer.contains(dest.deriveContainerAddress())) {
                migrate(dest);
            }
        } catch (Exception ex) {
            logWarning("Migrate Warning " + ex);
        }
    }

    /**
     * This method cancels agent's migration.
     */
    public void cancelMigrate() {
        // method is called from the gui thread !!!
        synchronized (lock) {
            if (!migrating) {
                wantMigrate = false;
                if (gui != null) {
                    SwingUtilities.invokeLater(new Runnable() {
                        @Override
						public void run() {
                            gui.cardLayout1.first(gui.jPanel3);
                        }
                    });
                }
            }
        }
    }

    /**
     * This method kills the agent. It is called by the GUI.
     */
    public void exit() {
        kill();
    }


    /**
     * This method should perform quick clean up (such as close opened files, hide
     * GUI etc.).
     */
    @Override
    protected void finish() {
        if (visShell != null) {
            visShell.dispose();
            visShell = null;
        }
        if (containerMonitor != null) {
        	containerMonitor.dispose();
        	containerMonitor = null;
        }

    }
}
