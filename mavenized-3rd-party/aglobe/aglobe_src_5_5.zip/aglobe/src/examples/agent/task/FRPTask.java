package examples.agent.task;

import aglobe.container.agent.*;
import aglobe.container.task.*;
import aglobe.container.transport.*;
import aglobe.ontology.*;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: <code>FRPTask</code> handles Fipa Request Protocol<br>
 *  - the incoming message Content should contain a DirService name
 * (e.g. platform/service/directory)<br>
 *  - <code>FRPTask</code> answers AGREE to every REQUEST message,
 *  then it searches for the given DirService and sends DONE containing
 *  the search result or sends FAILURE if timeout is reached.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.17 $ $Date: 2010/08/04 11:48:05 $
 */

public class FRPTask extends TimeoutTask
{
  Message m;  // the original request
  private final CMAgent owner;

  public FRPTask(CMAgent owner, Message m) {
    super(owner, 5000);  // required!

    this.m= m;
    this.owner = owner;

    // send AGREE
    Message re= m.getReply();
    re.setPerformative(MessageConstants.AGREE);
    re.setContent(this.toString());
    try {
      sendMessage(re);
    }
    catch (InvisibleContainerException ex) {
        owner.logWarning("Problem with sending message: "+ex);
    }
    re.release();

    // create the Query message
    Message qm = Message.newInstance(
      MessageConstants.REQUEST,
      m.getReceiver(),
      Address.getLocalServiceAddress(getConversationManager().getContainer(),
      m.getContent().toString())
    );
    Query q= new Query();
    q.setParam("name");
    q.setValue(".*");  // regular expression - matches all
    qm.setContent(q);
    try {
      sendMessage(qm);
    }
    catch (InvisibleContainerException ex) {
        owner.logWarning("Problem with sending message: "+ex);
    }
    qm.release();

  }

  /**
   * This method is called when timeout is reached.
   * It sends FAILURE message.
   * The timer and the message handling run in different threads and therefore
   * <code>timeout</code> and <code>handleIncomingMessage()</code> have to be
   * synchronized.
   */
  @Override
synchronized protected void timeout() {
    // create FAILURE message
    Message re= m.getReply();
    re.setPerformative(MessageConstants.FAILURE);
    re.setContent(this.toString());
    try {
      sendMessage(re);  // send the message
    }
    catch (InvisibleContainerException ex) {
        owner.logWarning("Problem with sending message: "+ex);
    }
    re.release();

    cancelTask();  // deregister this task
  }

  /**
   * This method overrides the standard <code>Agent</code>'s method responsible
   * for handling all incoming messages.
   * The new implementation sends DONE/FAILURE message depending on the incoming
   * message.
   * The timer and the message handling run in different threads and therefore
   * <code>timeout</code> and <code>handleIncomingMessage()</code> have to be
   * synchronized.
   * @param m Message - an incoming message
   */
  @Override
synchronized public void handleIncomingMessage(Message m)
  {
    // create the response
    Message re= this.m.getReply();
    re.setContent(m.getContent());

    // Query was returned - success and DONE
    if (m.getContent() instanceof Query) {
      re.setPerformative(MessageConstants.DONE);
    }
    else {  // other result than query - FAILURE
      re.setPerformative(MessageConstants.FAILURE);
    }

    try {
      sendMessage(re); // send DONE/FAILURE
    }
    catch (InvisibleContainerException ex) {
        owner.logWarning("Problem with sending message: "+ex);
    }
    re.release();

    m.release();
    cancelTask(); // deregister this task
  }

    /**
     * This method canceles this task.
     *
     */
    @Override
    public void cancelTask() {
        if (m != null) {
            m.release();
            m = null;
        }
        super.cancelTask();
    }
}
