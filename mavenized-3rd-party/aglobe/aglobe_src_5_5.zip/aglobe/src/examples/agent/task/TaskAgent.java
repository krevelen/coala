package examples.agent.task;

import aglobe.container.agent.*;
import aglobe.ontology.*;

/**
 * <p>
 * Title: A-Globe
 * </p>
 * <p>
 * Description: <code>TaskAgent</code> utilizes the concept of tasks when
 * handling incoming messages.
 * </p>
 * <p>
 * Copyright: Copyright (c) 2003
 * </p>
 * <p>
 * Company: Gerstner Laboratory
 * </p>
 *
 * @author David Sislak
 * @version $Revision: 1.12 $ $Date: 2008/11/23 09:14:13 $
 */

public class TaskAgent extends CMAgent {

    private static final long serialVersionUID = 5311157529526435224L;

    public TaskAgent() {
    }

    /**
     * Initialization of <code>TaskAgent</code> and registration of
     * <code>IdleTask()</code>.
     *
     * @param a
     *            AgentInfo
     * @param initState
     *            int
     */
    @Override
    public void init(AgentInfo a, int initState) {
        setIdleTask(new IdleTask(this)); // register IdleTask
    }
}
