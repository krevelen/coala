package examples.agent.task;

import aglobe.container.agent.*;
import aglobe.container.task.*;
import aglobe.ontology.*;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: <code>IdleTask</code> is a simple task, which creates
 * an <code>FRPTask</code> to handle each incoming request.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.12 $ $Date: 2010/08/04 11:48:05 $
 */

public class IdleTask extends Task
{
  private final CMAgent owner;

  public IdleTask(CMAgent owner) {
    super(owner); // required!
    this.owner = owner;
  }

  /**
   * This method overrides standard <code>Agent</code>'s method responsible for
   * handling all incoming messages.
   * This implementation creates an <code>FRPTask</code> for each incoming request.
   * @param m Message - an incoming message
   */
  @Override
public void handleIncomingMessage(Message m) {
    if (m.getPerformative().equalsIgnoreCase(MessageConstants.REQUEST)) {
        new FRPTask(owner, m); // create a task to handle the request
        return;
    }
    m.release();
  }
}
