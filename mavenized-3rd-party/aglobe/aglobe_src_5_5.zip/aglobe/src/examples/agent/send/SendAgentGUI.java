package examples.agent.send;

import java.io.*;
import java.lang.reflect.*;
import java.util.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

import aglobe.container.transport.*;
import aglobe.ontology.*;
import aglobe.util.*;
import aglobe.util.gui.RememberPositionJFrame;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: Sender Agent GUI</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.17 $ $Date: 2010/08/04 11:48:05 $
 */

public class SendAgentGUI extends RememberPositionJFrame {
    private static final long serialVersionUID = -3959030640650558914L;

    private SendAgent owner = null;

    private Set<Object> ontologies = new HashSet<Object>();

    final JFileChooser fc = new JFileChooser(new File(System.getProperty(
            "user.home") + "\\My Documents\\Moje\\Inaccessibility\\Source\\msg"));

    private GridBagLayout gridBagLayout1 = new GridBagLayout();
    private JPanel leftPanel = new JPanel();
    private JPanel rightPanel = new JPanel();
    private AddressPanel senderPanel = new AddressPanel("Sender");
    private AddressPanel receiverPanel = new AddressPanel("Receiver");
    private JLabel jLabel1 = new JLabel();
    private JTextField performativeTextField = new JTextField();
    private JLabel jLabel2 = new JLabel();
    private JLabel jLabel3 = new JLabel();
    private JTextField protocolTextField = new JTextField();
    private JLabel jLabel4 = new JLabel();
    private JComboBox ontologyCombo = new JComboBox();
    private JLabel jLabel5 = new JLabel();
    private JTextField convidTextField = new JTextField();
    private JLabel jLabel6 = new JLabel();
    private JLabel jLabel7 = new JLabel();
    private JTextField inreplytoTextField = new JTextField();
    private JTextField replywithTextField = new JTextField();
    private JLabel jLabel8 = new JLabel();
    private JTextField reasonTextField = new JTextField();
    private JScrollPane jScrollPane1 = new JScrollPane();
    private JTextArea contentTextArea = new JTextArea();
    private Border border2;
    private JButton sendButton = new JButton();
    private JScrollPane jScrollPane2 = new JScrollPane();
    private Border border3;
    private TitledBorder titledBorder1;
    private JTextArea incomingTextArea = new JTextArea();
    private JMenuBar jMenuBar1 = new JMenuBar();
    private JMenu fileMenu = new JMenu();
    private BorderLayout borderLayout1 = new BorderLayout();
    private JSplitPane jSplitPane1 = new JSplitPane();
    private JMenuItem jMenuItem1 = new JMenuItem();
    JButton clearButton = new JButton();

    public SendAgentGUI(SendAgent _owner) {
        super(_owner);
        try {
            owner = _owner;
            jbInit();

            fc.setFileFilter(new FileUtils.FileFilter(new String[] {FileUtils.
                    XML, FileUtils.TXT}, "Text files (*.xml,*.txt)"));

            if (owner != null) {
                Address a = owner.getAddress();
                senderPanel.setAddress(a);
                receiverPanel.setHost(a.getHost());
                receiverPanel.setPort(a.getPort());
                receiverPanel.setContainerName(a.getContainerName());
            }

            addOntology("java.lang.String");
            addOntology("atg.ontology.Query");
            addOntology("atg.ontology.Command");

            pack();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        border2 = BorderFactory.createBevelBorder(BevelBorder.LOWERED,
                                                  Color.white, Color.white,
                                                  new Color(115, 114, 105),
                                                  new Color(165, 163, 151));
        border3 = BorderFactory.createEtchedBorder(Color.white,
                new Color(165, 163, 151));
        titledBorder1 = new TitledBorder(border3, "Incoming Messages");
        leftPanel.setLayout(gridBagLayout1);
        rightPanel.setLayout(borderLayout1);
        jLabel1.setText("Performative:");
        performativeTextField.setText("REQUEST");
        performativeTextField.setColumns(20);
        jLabel2.setText("Content:");
        jLabel3.setText("Protocol:");
        protocolTextField.setColumns(20);
        jLabel4.setText("Ontology:");
        jLabel5.setText("Conv. ID:");
        convidTextField.setColumns(20);
        jLabel6.setText("In Reply To:");
        jLabel7.setText("Reply With:");
        inreplytoTextField.setColumns(20);
        replywithTextField.setColumns(20);
        jLabel8.setText("Reason:");
        reasonTextField.setColumns(20);
        contentTextArea.setText("Hello World!");
        contentTextArea.setColumns(20);
        contentTextArea.setRows(5);
        jScrollPane1.setBorder(border2);
        ontologyCombo.setEditable(true);
        sendButton.setText("Send");
        sendButton.addActionListener(new java.awt.event.ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                sendButton_actionPerformed(e);
            }
        });
        jScrollPane2.setBorder(titledBorder1);
        incomingTextArea.setEditable(false);
        incomingTextArea.setText("Incoming messages:");
        incomingTextArea.setColumns(20);
        incomingTextArea.setLineWrap(true);
        fileMenu.setText("File");
        fileMenu.setMnemonic(KeyEvent.VK_F);
        jMenuItem1.setMnemonic('X');
        jMenuItem1.setText("Exit");
        jMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(88,
                java.awt.event.KeyEvent.ALT_MASK, false));
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                jMenuItem1_actionPerformed(e);
            }
        });
        clearButton.setText("Clear incoming log");
        clearButton.addActionListener(new ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                clearButton_actionPerformed(e);
            }
        });
        jScrollPane1.getViewport().add(contentTextArea, null);
        jScrollPane2.getViewport().add(incomingTextArea, null);
        rightPanel.add(jScrollPane2, BorderLayout.CENTER);

        jSplitPane1.add(leftPanel, JSplitPane.LEFT);
        jSplitPane1.add(rightPanel, JSplitPane.RIGHT);
        jMenuBar1.add(fileMenu);
        fileMenu.add(jMenuItem1);
        this.getContentPane().add(jSplitPane1, BorderLayout.CENTER);
        leftPanel.add(jLabel1, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
                , GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL,
                new Insets(0, 3, 3, 3), 0, 0));
        leftPanel.add(performativeTextField,
                      new GridBagConstraints(1, 2, 1, 1, 0.1, 0.0
                                             , GridBagConstraints.CENTER,
                                             GridBagConstraints.HORIZONTAL,
                                             new Insets(0, 0, 3, 3), 0, 0));
        leftPanel.add(jLabel2, new GridBagConstraints(0, 3, 1, 1, 0.0, 0.1
                , GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL,
                new Insets(3, 3, 3, 3), 0, 0));
        leftPanel.add(jLabel3, new GridBagConstraints(0, 4, 1, 1, 0.0, 0.0
                , GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL,
                new Insets(0, 3, 3, 3), 0, 0));
        leftPanel.add(protocolTextField,
                      new GridBagConstraints(1, 4, 1, 1, 0.1, 0.0
                                             , GridBagConstraints.CENTER,
                                             GridBagConstraints.HORIZONTAL,
                                             new Insets(0, 0, 3, 3), 0, 0));
        leftPanel.add(jLabel4, new GridBagConstraints(0, 5, 1, 1, 0.0, 0.0
                , GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL,
                new Insets(3, 3, 3, 3), 0, 0));
        leftPanel.add(ontologyCombo,
                      new GridBagConstraints(1, 5, 1, 1, 0.1, 0.0
                                             , GridBagConstraints.CENTER,
                                             GridBagConstraints.HORIZONTAL,
                                             new Insets(0, 0, 3, 3), 0, 0));
        leftPanel.add(jLabel5, new GridBagConstraints(0, 6, 1, 1, 0.0, 0.0
                , GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL,
                new Insets(0, 3, 3, 3), 0, 0));
        leftPanel.add(convidTextField,
                      new GridBagConstraints(1, 6, 1, 1, 0.1, 0.0
                                             , GridBagConstraints.CENTER,
                                             GridBagConstraints.HORIZONTAL,
                                             new Insets(0, 0, 3, 3), 0, 0));
        leftPanel.add(jLabel6, new GridBagConstraints(0, 7, 1, 1, 0.0, 0.0
                , GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL,
                new Insets(0, 3, 3, 3), 0, 0));
        leftPanel.add(jLabel7, new GridBagConstraints(0, 8, 1, 1, 0.0, 0.0
                , GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL,
                new Insets(0, 3, 3, 3), 0, 0));
        leftPanel.add(inreplytoTextField,
                      new GridBagConstraints(1, 7, 1, 1, 0.1, 0.0
                                             , GridBagConstraints.CENTER,
                                             GridBagConstraints.HORIZONTAL,
                                             new Insets(0, 0, 3, 3), 0, 0));
        leftPanel.add(replywithTextField,
                      new GridBagConstraints(1, 8, 1, 1, 0.1, 0.0
                                             , GridBagConstraints.CENTER,
                                             GridBagConstraints.HORIZONTAL,
                                             new Insets(0, 0, 3, 3), 0, 0));
        leftPanel.add(jLabel8, new GridBagConstraints(0, 9, 1, 1, 0.0, 0.0
                , GridBagConstraints.WEST, GridBagConstraints.BOTH,
                new Insets(0, 3, 3, 3), 0, 0));
        leftPanel.add(reasonTextField,
                      new GridBagConstraints(1, 9, 1, 1, 0.1, 0.0
                                             , GridBagConstraints.CENTER,
                                             GridBagConstraints.HORIZONTAL,
                                             new Insets(0, 0, 3, 3), 0, 0));
        leftPanel.add(receiverPanel,
                      new GridBagConstraints(0, 1, 2, 1, 0.1, 0.0
                                             , GridBagConstraints.CENTER,
                                             GridBagConstraints.HORIZONTAL,
                                             new Insets(0, 3, 3, 3), 0, 0));
        leftPanel.add(senderPanel, new GridBagConstraints(0, 0, 2, 1, 0.1, 0.0
                , GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
                new Insets(3, 3, 3, 3), 0, 0));
        leftPanel.add(jScrollPane1, new GridBagConstraints(1, 3, 1, 1, 0.1, 0.1
                , GridBagConstraints.CENTER, GridBagConstraints.BOTH,
                new Insets(0, 0, 3, 3), 0, 0));
        leftPanel.add(sendButton, new GridBagConstraints(0, 10, 2, 1, 0.1, 0.0
                , GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
                new Insets(0, 3, 3, 3), 0, 0));
        leftPanel.add(clearButton, new GridBagConstraints(0, 11, 2, 1, 0.1, 0.0
                , GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
                new Insets(0, 0, 0, 0), 0, 0));
        this.setJMenuBar(jMenuBar1);
    }

    /**
     * @param e
     */
    void sendButton_actionPerformed(ActionEvent e) {
        addOntology(ontologyCombo.getSelectedItem());
        Message m = Message.newInstance(performativeTextField.getText(),
                                senderPanel.getAddress(),
                                receiverPanel.getAddress());

        try { // Try to create an object from content.
            String s = ontologyCombo.getSelectedItem().toString();
            ClassLoader cl = owner.getClass().getClassLoader();
            Class<?> cc = cl.loadClass(s);
            Method unm = cc.getMethod("unmarshal", new Class[] {InputStream.class});
            ByteArrayInputStream incont = new ByteArrayInputStream(
                    contentTextArea.getText().getBytes());
            m.setContent(unm.invoke(null, new Object[] {incont}));
            incont.close();
        } catch (Exception ex) {
            m.setContent(contentTextArea.getText());
        }

        m.setProtocol(protocolTextField.getText());
        m.setConversationID(convidTextField.getText());
        m.setInReplyTo(inreplytoTextField.getText());
        m.setReplyWith(replywithTextField.getText());
        m.setReason(reasonTextField.getText());

        owner.send(m);
        m.release();
    }

    private void addOntology(Object s) {
        if (ontologies.add(s))
            ontologyCombo.addItem(s);
    }

    public void logMessage(Message msg) {
        final String msgStr = msg.toString();
        SwingUtilities.invokeLater(new Runnable() {
            @Override
			public void run() {
                incomingTextArea.append("\nMessage: ======\n" + msgStr);
            }
        });
    }

    public void logString(final String s) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
			public void run() {
                incomingTextArea.append("\n" + s);
            }
        });
    }

    /**
     * @param e
     */
    void jMenuItem1_actionPerformed(ActionEvent e) {
        owner.exit();
    }

    /**
     * @param e
     */
    public void clearButton_actionPerformed(ActionEvent e) {
        incomingTextArea.setText("Incoming messages:");
    }
}
