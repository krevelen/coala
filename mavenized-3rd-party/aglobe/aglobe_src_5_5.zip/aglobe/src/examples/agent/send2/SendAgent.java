package examples.agent.send2;

import aglobe.container.agent.*;
import aglobe.container.transport.*;
import aglobe.ontology.*;

/**
 * <p>
 * Title: A-Globe
 * </p>
 * <p>
 * Description: <code>SendAgent</code> allows the user to send messages
 * interactively.
 * </p>
 * <p>
 * Copyright: Copyright (c) 2003
 * </p>
 * <p>
 * Company: Gerstner Laboratory
 * </p>
 *
 * @author David Sislak
 * @version $Revision: 1.13 $ $Date: 2010/08/04 11:48:05 $
 */

public class SendAgent extends Agent implements MessageConstants {
    private static final long serialVersionUID = 9091386325101598695L;

    /**
     * SendAgent's GUI
     */
    public SendAgentGUI gui = null;

    public SendAgent() {
    }

    /**
     * Initialization of <code>SendAgent</code> and its GUI.
     *
     * @param a
     *            AgentInfo
     * @param initState
     *            int
     */
    @Override
    public void init(AgentInfo a, int initState) {
        try {
            gui = new SendAgentGUI(this);
            gui.setTitle("" + getAddress().toString());
            gui.pack();
            gui.setVisible(true);
        } catch (Exception ex) {
            logWarning("Cannot create GUI due to: " + ex);
        }
    }

    /**
     * This method sends a message.
     *
     * @param m
     *            Message - a message to be sent
     */
    protected void send(Message m) {
        try {
            sendMessage(m);
        } catch (InvisibleContainerException ex) {
            logSevere("Cannot send message: " + ex);
            if (gui != null) {
                gui.logString("Cannot send message: " + ex);
            }
        }
    }

    /**
     * This method overrides the standard <code>Agent</code>'s method
     * responsible for handling all incoming messages. The new implementation
     * displays the incoming message in the GUI.
     *
     * @param m
     *            Message - an incoming message
     */
    @Override
	public void handleIncomingMessage(Message m) {
        if (gui != null) {
            gui.logMessage(m);
        }
        m.release();
    }

    /**
     * This method kills the agent. It is called when the GUI closes.
     */
    protected void exit() {
        kill();
    }

}
