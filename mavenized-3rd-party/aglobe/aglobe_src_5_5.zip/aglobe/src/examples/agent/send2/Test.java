
package examples.agent.send2;

import java.io.IOException;
import java.io.Externalizable;
import java.io.ObjectOutput;
import java.io.ObjectInput;
import aglobe.util.ConversionTools;

public class Test implements Externalizable
{
    private String _Content;

    public String getContent() {
        return _Content;
    }

    public void setContent(String _Content) {
        this._Content = _Content;
    }

    @Override
    public boolean equals(Object ob) {
        if (this == ob) {
            return true;
        }
        if (!(ob instanceof Test)) {
            return false;
        }
        Test tob = ((Test) ob);
        if (_Content!= null) {
            if (tob._Content == null) {
                return false;
            }
            if (!_Content.equals(tob._Content)) {
                return false;
            }
        } else {
            if (tob._Content!= null) {
                return false;
            }
        }
        return true;
    }

    @Override
    public int hashCode() {
        int h = 0;
        h = ((127 *h)+((_Content!= null)?_Content.hashCode(): 0));
        return h;
    }

    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer("<<Test");
        if (_Content!= null) {
            sb.append(" Content=");
            sb.append(_Content.toString());
        }
        sb.append(">>");
        return sb.toString();
    }

    @Override
	public void writeExternal(ObjectOutput out) throws IOException {
        ConversionTools.writeString(out, _Content);
    }

    @Override
	public void readExternal(ObjectInput in) throws ClassNotFoundException,
            IOException {
        _Content = ConversionTools.readString(in);
    }


}
