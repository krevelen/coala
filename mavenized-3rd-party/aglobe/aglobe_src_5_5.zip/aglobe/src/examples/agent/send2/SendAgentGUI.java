package examples.agent.send2;

import java.io.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

import aglobe.container.transport.*;
import aglobe.ontology.*;
import aglobe.util.*;
import aglobe.util.gui.RememberPositionJFrame;

/**
 * <p>Title: A-Globe</p>
 * <p>Description: Sender Agent GUI</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gerstner Laboratory</p>
 * @author David Sislak
 * @version $Revision: 1.11 $ $Date: 2010/08/04 11:48:05 $
 */

public class SendAgentGUI extends RememberPositionJFrame {
    private static final long serialVersionUID = 8885713336680132898L;

    private SendAgent owner = null;

    final JFileChooser fc = new JFileChooser(new File(System.getProperty(
            "user.home") + "\\My Documents\\Moje\\Inaccessibility\\Source\\msg"));

    private GridBagLayout gridBagLayout1 = new GridBagLayout();
    private JPanel leftPanel = new JPanel();
    private JPanel rightPanel = new JPanel();
    private AddressPanel senderPanel = new AddressPanel("Sender");
    private AddressPanel receiverPanel = new AddressPanel("Receiver");
    private JLabel jLabel1 = new JLabel();
    private JTextField performativeTextField = new JTextField();
    private JLabel jLabel2 = new JLabel();
    private JScrollPane jScrollPane1 = new JScrollPane();
    private JTextArea contentTextArea = new JTextArea();
    private Border border2;
    private JButton sendButton = new JButton();
    private JScrollPane jScrollPane2 = new JScrollPane();
    private Border border3;
    private TitledBorder titledBorder1;
    private JTextArea incomingTextArea = new JTextArea();
    private JMenuBar jMenuBar1 = new JMenuBar();
    private JMenu fileMenu = new JMenu();
    private JSplitPane jSplitPane1 = new JSplitPane();
    private JMenuItem jMenuItem1 = new JMenuItem();
    JButton clearButton = new JButton();
    GridBagLayout gridBagLayout2 = new GridBagLayout();
    GridBagLayout gridBagLayout3 = new GridBagLayout();

    public SendAgentGUI(SendAgent _owner) {
        super(_owner);
        try {
            owner = _owner;
            jbInit();

            fc.setFileFilter(new FileUtils.FileFilter(new String[] {FileUtils.
                    XML, FileUtils.TXT}, "Text files (*.xml,*.txt)"));

            if (owner != null) {
                Address a = owner.getAddress();
                senderPanel.setAddress(a);
                receiverPanel.setHost(a.getHost());
                receiverPanel.setPort(a.getPort());
                receiverPanel.setContainerName(a.getContainerName());
            }

            pack();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        border2 = BorderFactory.createBevelBorder(BevelBorder.LOWERED,
                                                  Color.white, Color.white,
                                                  new Color(115, 114, 105),
                                                  new Color(165, 163, 151));
        border3 = BorderFactory.createEtchedBorder(Color.white,
                new Color(165, 163, 151));
        titledBorder1 = new TitledBorder(border3, "Incoming Messages");
        leftPanel.setLayout(gridBagLayout1);
        rightPanel.setLayout(gridBagLayout3);
        jLabel1.setText("Performative:");
        performativeTextField.setText("REQUEST");
        performativeTextField.setColumns(20);
        jLabel2.setText("Content:");
        contentTextArea.setText("Hello World!");
        contentTextArea.setColumns(20);
        contentTextArea.setRows(5);
        jScrollPane1.setBorder(border2);
        sendButton.setText("Send");
        sendButton.addActionListener(new java.awt.event.ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                sendButton_actionPerformed(e);
            }
        });
        jScrollPane2.setBorder(titledBorder1);
        incomingTextArea.setEditable(false);
        incomingTextArea.setText("Incoming messages:");
        incomingTextArea.setColumns(20);
        incomingTextArea.setLineWrap(true);
        fileMenu.setText("File");
        fileMenu.setMnemonic(KeyEvent.VK_F);
        jMenuItem1.setMnemonic('X');
        jMenuItem1.setText("Exit");
        jMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(88,
                java.awt.event.KeyEvent.ALT_MASK, false));
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                jMenuItem1_actionPerformed(e);
            }
        });
        clearButton.setText("Clear incoming log");
        clearButton.addActionListener(new ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
                clearButton_actionPerformed(e);
            }
        });
        this.getContentPane().setLayout(gridBagLayout2);
        jSplitPane1.add(leftPanel, JSplitPane.LEFT);
        jMenuBar1.add(fileMenu);
        fileMenu.addSeparator();
        fileMenu.add(jMenuItem1);
        jSplitPane1.add(rightPanel, JSplitPane.RIGHT);
        leftPanel.add(jLabel1, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
                , GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL,
                new Insets(0, 3, 3, 3), 0, 0));
        leftPanel.add(performativeTextField,
                      new GridBagConstraints(1, 2, 1, 1, 0.1, 0.0
                                             , GridBagConstraints.CENTER,
                                             GridBagConstraints.HORIZONTAL,
                                             new Insets(0, 0, 3, 3), 0, 0));
        leftPanel.add(jLabel2, new GridBagConstraints(0, 3, 1, 1, 0.0, 0.1
                , GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL,
                new Insets(3, 3, 3, 3), 0, 0));
        leftPanel.add(receiverPanel,
                      new GridBagConstraints(0, 1, 2, 1, 0.1, 0.0
                                             , GridBagConstraints.CENTER,
                                             GridBagConstraints.HORIZONTAL,
                                             new Insets(0, 3, 3, 3), 0, 0));
        leftPanel.add(senderPanel, new GridBagConstraints(0, 0, 2, 1, 0.1, 0.0
                , GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
                new Insets(3, 3, 3, 3), 0, 0));
        leftPanel.add(jScrollPane1, new GridBagConstraints(1, 3, 1, 1, 0.1, 0.1
                , GridBagConstraints.CENTER, GridBagConstraints.BOTH,
                new Insets(0, 0, 3, 3), 0, 0));
        leftPanel.add(sendButton, new GridBagConstraints(0, 5, 2, 1, 0.1, 0.0
                , GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
                new Insets(0, 3, 3, 3), 0, 0));
        jScrollPane2.getViewport().add(incomingTextArea, null);
        jScrollPane1.getViewport().add(contentTextArea, null);

        leftPanel.add(clearButton, new GridBagConstraints(0, 6, 2, 1, 0.1, 0.0
                , GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
                new Insets(0, 0, 0, 0), 0, 0));
        rightPanel.add(jScrollPane2,
                       new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0
                                              , GridBagConstraints.CENTER,
                                              GridBagConstraints.BOTH,
                                              new Insets(0, 0, 0, 0), 0, 0));
        this.getContentPane().add(jSplitPane1,
                                  new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0
                , GridBagConstraints.CENTER, GridBagConstraints.BOTH,
                new Insets(0, 0, 0, 0), 0, 0));

        this.setJMenuBar(jMenuBar1);
    }

    /**
     * @param e
     */
    void sendButton_actionPerformed(ActionEvent e) {
        Message m = Message.newInstance(performativeTextField.getText(),
                                senderPanel.getAddress(),
                                receiverPanel.getAddress());

        Test content = new Test();
        content.setContent(contentTextArea.getText());
        m.setContent(content);

        owner.send(m);
        m.release();
    }

    public void logMessage(Message msg) {
        final String msgLog = msg.toString();
        SwingUtilities.invokeLater(new Runnable() {
            @Override
			public void run() {
                incomingTextArea.append("\nMessage: ======\n" + msgLog);
            }
        });
    }

    public void logString(final String s) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
			public void run() {
                incomingTextArea.append("\n" + s);
            }
        });
    }

    /**
     * @param e
     */
    void jMenuItem1_actionPerformed(ActionEvent e) {
        owner.exit();
    }

    /**
     * @param e
     */
    public void clearButton_actionPerformed(ActionEvent e) {
        incomingTextArea.setText("Incoming messages:");
    }
}
