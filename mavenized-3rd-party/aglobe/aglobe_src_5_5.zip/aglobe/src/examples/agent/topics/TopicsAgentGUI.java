package examples.agent.topics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import javax.swing.WindowConstants;
import javax.swing.border.BevelBorder;
import javax.swing.border.TitledBorder;
import javax.swing.SwingUtilities;

import aglobe.util.gui.RememberPositionJFrame;


/**
* This code was edited or generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED FOR
* THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED
* LEGALLY FOR ANY CORPORATE OR COMMERCIAL PURPOSE.
*/
public class TopicsAgentGUI extends RememberPositionJFrame {
    private static final long serialVersionUID = 5696109226469753895L;
    private JPanel jPanel1;
    private JScrollPane jScrollPane1;
    private JButton sendTopicButton;
    private JTextArea logTextPane;
    private JPanel jPanel4;
    private JButton deregisterButton;
    private JButton registerButton;
    private JButton unsubscribeButton;
    private JButton subscribeButton;
    private JPanel jPanel3;
    private JTextField topicTextField;
    private JLabel jLabel1;
    private JPanel jPanel2;

    private TopicsAgent owner;

    public TopicsAgentGUI(final TopicsAgent owner) {
        super(owner);
        this.owner = owner;
        initGUI();
    }

    private void initGUI() {
        try {
            setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
            this.setTitle("Topics Agent");
            this.setMinimumSize(new java.awt.Dimension(400, 300));
            GridBagLayout thisLayout = new GridBagLayout();
            this.setLocale(new java.util.Locale("en", "US"));
            thisLayout.rowWeights = new double[] {0.0, 0.1};
            thisLayout.rowHeights = new int[] {7, 7};
            thisLayout.columnWeights = new double[] {0.1};
            thisLayout.columnWidths = new int[] {7};
            getContentPane().setLayout(thisLayout);

            jPanel1 = new JPanel();
            GridBagLayout jPanel1Layout = new GridBagLayout();
            jPanel1Layout.columnWidths = new int[] {7};
            jPanel1Layout.rowHeights = new int[] {7, 7};
            jPanel1Layout.columnWeights = new double[] {0.1};
            jPanel1Layout.rowWeights = new double[] {0.1, 0.1};
            getContentPane().add(jPanel1, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
            jPanel1.setLayout(jPanel1Layout);
            jPanel1.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(BevelBorder.RAISED, new java.awt.Color(255,255,255), null), "Control", TitledBorder.LEADING, TitledBorder.DEFAULT_POSITION));

            jPanel4 = new JPanel();
            GridBagLayout jPanel4Layout = new GridBagLayout();
            jPanel4Layout.columnWidths = new int[] {7, -1};
            jPanel4Layout.rowHeights = new int[] {7};
            jPanel4Layout.columnWeights = new double[] {0.1, 0.0};
            jPanel4Layout.rowWeights = new double[] {0.1};
            getContentPane().add(jPanel4, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
            jPanel4.setLayout(jPanel4Layout);
            jPanel4.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(BevelBorder.RAISED, new java.awt.Color(255,255,255), null), "Events", TitledBorder.LEADING, TitledBorder.DEFAULT_POSITION));

            jScrollPane1 = new JScrollPane();
            jPanel4.add(jScrollPane1, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
            jScrollPane1.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

            logTextPane = new JTextArea();
            jScrollPane1.setViewportView(logTextPane);
            logTextPane.setEditable(false);
            logTextPane.setFocusable(false);

            jPanel2 = new JPanel();
            GridBagLayout jPanel2Layout = new GridBagLayout();
            jPanel2Layout.columnWidths = new int[] {7, 7};
            jPanel2Layout.rowHeights = new int[] {7};
            jPanel2Layout.columnWeights = new double[] {0.0, 0.1};
            jPanel2Layout.rowWeights = new double[] {0.1};
            jPanel1.add(jPanel2, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
            jPanel2.setLayout(jPanel2Layout);

            jPanel3 = new JPanel();
            GridBagLayout jPanel3Layout = new GridBagLayout();
            jPanel3Layout.columnWidths = new int[] {7, 7};
            jPanel3Layout.rowHeights = new int[] {7, 7, 20};
            jPanel3Layout.columnWeights = new double[] {0.1, 0.1};
            jPanel3Layout.rowWeights = new double[] {0.1, 0.1, 0.1};
            jPanel1.add(jPanel3, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
            jPanel3.setLayout(jPanel3Layout);

            subscribeButton = new JButton();
            jPanel3.add(subscribeButton, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 0, 5), 0, 0));
            subscribeButton.setLayout(null);
            subscribeButton.setText("Subscribe");
            subscribeButton.addActionListener(new ActionListener() {
                @Override
				public void actionPerformed(ActionEvent evt) {
                    final String topic = topicTextField.getText();
                    owner.addEvent(new Runnable() {

                        @Override
                        public void run() {
                            owner.topicsShell.subscribeHandlerAsync(topic, owner);
                            logEvent("Subscribed: "+topic);
                        }

                    });
                }
            });

            unsubscribeButton = new JButton();
            jPanel3.add(unsubscribeButton, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 0, 5), 0, 0));
            unsubscribeButton.setLayout(null);
            unsubscribeButton.setText("Unsubscribe");
            unsubscribeButton.addActionListener(new ActionListener() {
                @Override
				public void actionPerformed(ActionEvent evt) {
                    final String topic = topicTextField.getText();
                    owner.addEvent(new Runnable() {

                        @Override
                        public void run() {
                            owner.topicsShell.unsubscribeHandler(topic, owner);
                            logEvent("Unsubscribed: "+topic);
                        }

                    });
                }
            });

            registerButton = new JButton();
            jPanel3.add(registerButton, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 0, 5), 0, 0));
            registerButton.setLayout(null);
            registerButton.setText("Register Notifier");
            registerButton.addActionListener(new ActionListener() {
                @Override
				public void actionPerformed(ActionEvent evt) {
                    final String topic = topicTextField.getText();
                    owner.addEvent(new Runnable() {

                        @Override
                        public void run() {
                            owner.topicsShell.registerNotifier(topic, owner);
                            logEvent("Notifier registered: "+topic);
                        }

                    });
                }
            });

            deregisterButton = new JButton();
            jPanel3.add(deregisterButton, new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 0, 5), 0, 0));
            deregisterButton.setLayout(null);
            deregisterButton.setText("Deregister Notifier");

            sendTopicButton = new JButton();
            jPanel3.add(sendTopicButton, new GridBagConstraints(0, 2, 2, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(10, 5, 0, 5), 0, 0));
            sendTopicButton.setLayout(null);
            sendTopicButton.setText("Send Topic");
            sendTopicButton.addActionListener(new ActionListener() {
                @Override
				public void actionPerformed(ActionEvent evt) {
                    final String topic = topicTextField.getText();
                    owner.addEvent(new Runnable() {

                        @Override
                        public void run() {
                            owner.topicsShell.sendTopic(topic, null, null);
                            logEvent("Topic sent: "+topic);
                        }

                    });
                }
            });

            deregisterButton.addActionListener(new ActionListener() {
                @Override
				public void actionPerformed(ActionEvent evt) {
                    final String topic = topicTextField.getText();
                    owner.addEvent(new Runnable() {

                        @Override
                        public void run() {
                            owner.topicsShell.deregisterNotifier(topic, owner);
                            logEvent("Notifier deregistered: "+topic);
                        }

                    });
                }
            });

            jLabel1 = new JLabel();
            jPanel2.add(jLabel1, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 5, 0, 5), 0, 0));
            jLabel1.setText("Topic:");
            jLabel1.setLayout(null);

            topicTextField = new JTextField();
            jPanel2.add(topicTextField, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 5, 0, 5), 0, 0));

            pack();
            this.setSize(381, 260);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void logEvent(final String text) {
        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                logTextPane.append(text+"\n");
            }

        });
    }
}
