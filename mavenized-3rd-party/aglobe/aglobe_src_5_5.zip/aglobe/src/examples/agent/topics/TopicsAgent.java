/**
 *
 */
package examples.agent.topics;

import javax.swing.SwingUtilities;

import aglobe.container.agent.Agent;
import aglobe.ontology.AgentInfo;
import aglobe.ontology.Message;
import aglobe.service.topics.TopicsHandler;
import aglobe.service.topics.TopicsService;
import aglobe.service.topics.TopicsSubscriptionNotifier;

/**
 * <p>Title: TopicsAgent</p>
 *
 * <p>Description: Demonstration of Topics usage</p>
 *
 * <p>Copyright: Copyright (c) 2009</p>
 *
 * <p>Company: Agent Technology Center</p>
 *
 * @author David Sislak
 * @version $Revision: 1.5 $ $Date: 2010/12/03 12:29:26 $
 *
 */
public class TopicsAgent extends Agent implements TopicsHandler, TopicsSubscriptionNotifier {
    private static final long serialVersionUID = 7534520001818048596L;

    public TopicsAgentGUI gui;
    TopicsService.Shell topicsShell;

    /* (non-Javadoc)
     * @see aglobe.container.agent.Agent#init(aglobe.ontology.AgentInfo, int)
     */
    @Override
    public void init(AgentInfo a, int initState) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                gui = new TopicsAgentGUI(TopicsAgent.this);
                gui.setVisible(true);
            }

        });

        topicsShell = (TopicsService.Shell) getContainer().getServiceManager().getService(this, TopicsService.SERVICENAME);
        if (topicsShell == null) {
            logSevere("Can be started only on the container with Topics enabled");
            stop();
            return;
        }
        topicsShell.sendTopic("init", null, null);
    }

    /* (non-Javadoc)
     * @see aglobe.container.ElementaryEntity#finish()
     */
    @Override
    protected void finish() {
        super.finish();

        if (topicsShell != null) {
            topicsShell.dispose();
        }
    }

    /* (non-Javadoc)
     * @see aglobe.container.MessageHandler#handleIncomingMessage(aglobe.ontology.Message)
     */
    @Override
    public void handleIncomingMessage(Message m) {
        logSevere("Unexpected incoming message: "+m);
    }

    /* (non-Javadoc)
     * @see aglobe.service.topics.TopicsHandler#handleIncomingTopic(java.lang.String, java.lang.Object, java.lang.String)
     */
    @Override
    public void handleIncomingTopic(String topic, Object content, String reason) {
        gui.logEvent("handleIncomingTopic: "+topic);
    }

    /* (non-Javadoc)
     * @see aglobe.service.topics.TopicsSubscriptionNotifier#hasSubscriber(java.lang.String)
     */
    @Override
    public void hasSubscriber(String topic) {
        gui.logEvent("hasSubscriber: "+topic);
    }

    /* (non-Javadoc)
     * @see aglobe.service.topics.TopicsSubscriptionNotifier#noSubscriber(java.lang.String)
     */
    @Override
    public void noSubscriber(String topic) {
        gui.logEvent("noSubscriber: "+topic);
    }

}
