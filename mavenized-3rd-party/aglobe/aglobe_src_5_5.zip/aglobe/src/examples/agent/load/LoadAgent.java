package examples.agent.load;

import aglobe.container.agent.*;
import aglobe.ontology.*;
import aglobe.platform.thread.AglobeThreadPool;

/**
 * <p>Title: Air Trafic Control Simulator</p>
 *
 * <p>Description: Load agent consume CPU time only.</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: Gerstner Laboratory</p>
 *
 * @author David Sislak
 * @version $Revision: 1.10 $ $Date: 2010/08/04 11:48:06 $
 */
public class LoadAgent extends Agent {

    private static final long serialVersionUID = 7805480561970939168L;

    /**
     * This method must be declared by the child class to handle an incoming
     * message.
     *
     * @param m The message.
     */
    @Override
	public void handleIncomingMessage(Message m) {
        logSevere("Unexpected incoming message: "+m);
        m.release();
    }

    /**
     * Agent's initialization method.
     *
     * @param ai Agent should get its name from there.
     * @param initState This parameter can be used if this method is
     *   overriden. Can have values: isCREATED - an agent is created
     *   isRESTARTED - an agent is restarted from autorun configuration
     *   isMOVED - an agent is moved from another container isCLONED - an
     *   agent is clonned from its mother agent isMOVEFAILED - agent's
     *   movement was unsuccessful
     */
    @Override
    public void init(AgentInfo ai, int initState) {

        // create load thread
        Thread t = AglobeThreadPool.getThread(new Runnable() {
            @Override
			public void run() {
                while (true) {}
            }
        },"LoadThread");

        // set lower priority 1 below normal
        t.setPriority(Math.max(Thread.NORM_PRIORITY-1,Thread.MIN_PRIORITY));
        t.start();

    }
}
